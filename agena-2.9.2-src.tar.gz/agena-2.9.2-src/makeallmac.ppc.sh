cd src
sh makemacosx.ppc.sh
cd ..
cd ports
cd zlib-1.2.5
make clean
chmod a+x ./configure
./configure && make
cd ..
cd gzip
make -f makefile.macosx clean
make -f makefile.macosx
make -f makefile.macosx install
cd ..
cd mapm_4.9.5
make -f makefile.osx.ppc clean
make -f makefile.osx.ppc
cd ..
cd mapmagena
make -f makefile.macosx.ppc clean
make -f makefile.macosx.ppc
make -f makefile.macosx.ppc install
cd ..
#cd g2agena
#make clean
#chmod a+x ./configure
#./configure
#make
#cd gdi
#make -f makefile.macosx clean
#make -f makefile.macosx
#make -f makefile.macosx install
cd ../../..
