#!/usr/bin/sh
cd src
sh makesolaris.sh
cd ..
cd ports
cd zlib-1.2.8
make clean
chmod a+x ./configure
./configure && make
cd ..
cd gzip
make -f makefile.solaris clean
make -f makefile.solaris
make -f makefile.solaris install
cd ..
cd mapm_4.9.5
make -f makefile.solaris clean
make -f makefile.solaris
cd ..
cd mapmagena
make -f makefile.solaris clean
make -f makefile.solaris
make -f makefile.solaris install
cd ..
cd cordic
sh makesolaris.sh
cd ..
cd g2agena
make clean
chmod a+x ./configure
./configure
make
cd gdi
make -f makefile.solaris clean
make -f makefile.solaris
make -f makefile.solaris install
cd ../../..
cd ../fltk-1.1.10/editor
make -f makefile.solaris clean
make -f makefile.solaris
cd ../../agena

