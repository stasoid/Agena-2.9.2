cd src
sh makemacosx.sh
cd ..
cd ports
#cd libusb-1.0.18
#make clean
#chmod a+x ./configure
#./configure && make
#cd ..
#cd lualibusb1-1.0.1.agena
#make -f makefile.linux clean
#make -f makefile.linux
#make -f makefile.linux install
#cd ..
cd zlib-1.2.8
make clean
chmod a+x ./configure
./configure && make
cd ..
cd gzip
make -f makefile.macosx clean
make -f makefile.macosx
make -f makefile.macosx install
cd ..
cd mapm_4.9.5
make -f makefile.osx clean
make -f makefile.osx
cd ..
cd mapmagena
make -f makefile.macosx clean
make -f makefile.macosx
make -f makefile.macosx install
cd ..
cd xml
make -f makefile.macosx clean
make -f makefile.macosx
make -f makefile.macosx install
cd ..
cd cordic
sh makemac.sh
cd ..
cd g2agena
make clean
chmod a+x ./configure
#./configure
./configure --x-libraries=/usr/X11/lib --x-includes=/usr/X11/include --disable-dependency-tracking
make
cd gdi
make -f makefile.macosx clean
make -f makefile.macosx
make -f makefile.macosx install
cd ../../..
cd ../fltk-1.1.10/editor
make -f makefile.macosx clean
make -f makefile.macosx
cd ../../agena
