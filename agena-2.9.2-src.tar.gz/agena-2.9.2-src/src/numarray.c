/*
** $Id: numarray.c,v 0.1 12.10.2015 $
** Numarray Library
** See Copyright Notice in agena.h
*/


/* The numarray package implements arrays of the C data types of either double, unsigned char, and signed 4-byte integers.

The arrays implemented by this package are called numarrays for short.

Since numbers stored to numarrays consume less space, numarrays may be useful if a large amount of numbers have to be processed, but the amount of random-access memory of your system is limited. Operations on numarrays, however, are usually
slower than those on Agena's native structures: tables, pairs, sequences, or registers - so you trade speed for memory.

Internally, numarrays are userdata structures that also support various metamethods.

You can create numarrays, assign and read numbers, resize arrays, store them to binary files, and read from files.
Functions to convert arrays to Agena's native structures, and vice versa, are provided, as well.

To create an array of unsigned chars, use numarray.uchar, of doubles use numarray.double, and of integers use numarray.integer. The number of entries to be stored must be given when calling these three procedures. When
creating arrays, all slots are automatically filled with zeros. All array indices start with number 1.

Agena's standard indexing functions save and read numbers. So, for example, a[1] := -1 stores the number -1
to index 1 of the array a. a[1] reads the value stored at index 1 of the array a. Alternatively, numarray.put
and numarray.get save and read numbers, respectively. Furthermore, numarray.include bulk-assigns numbers.

Arrays can be shrinked or extended with the numarray.resize function.

Arrays can be converted to sequences and registers with numarray.toseq and numarray.toreg. numarray.toarray
creates arrays from sequences and registers.

numarray.whereis searches for numbers, and numarray.iterate can sequentially traverse arrays.

numarray.write writes the contents of any array to a binary file. numarray.readuchars reads a complete file of unsigned
chars, numarray.readdoubles of doubles, and numarray.readintegers of signed integers with only one call. To open
and close these files, use binio.open and binio.close. Most other binio function, such as binio.sync binio.rewind,
and binio.filepos, is supported, as well, with the exception of the binio.read* procedures. The low-level numarray.read
function is used by the above mentioned numarray.read* functions.

The following metamethods exist: standard read and write indexing (see above), in operator, strict and approximate
equality (=, ==, <>, ~=, ~<> operators), size and `tostring`. To easily add further metamethods, have a look at the end
of the lib/numarray.agn source file.

*/


#define numarray_c
#define LUA_LIB

#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <math.h>
#include <unistd.h>

#include "agena.h"
#include "agnxlib.h"
#include "agenalib.h"
#include "lstate.h"
#include "agnhlps.h"

/* for numarray.used: */
#include "lstring.h"
#include "lapi.h"


#define luai_nummod(a,b)    ((a) - floor((a)/(b))*(b))

#define checkarray(L, n) (NumArray *)luaL_checkudata(L, n, "numarray")

#if !(defined(LUA_DOS) || defined(__OS2__) || defined(LUA_ANSI))
#define AGENA_NUMARRAYLIBNAME "numarray"
LUALIB_API int (luaopen_numarray) (lua_State *L);
#endif


typedef struct NumArray {
  size_t size;         /* number of slots */
  char datatype;       /* is array a double (==1), int32_t (==2), or uchar (==0) array ? */
  union data {
    lua_Number *n;     /* pointer to various lua_Number values */
    unsigned char *c;  /* pointer to various char values */
    int32_t *i;        /* pointer to various signed int values */
  } data;
} NumArray;


/* numarray.[uchar|double|integer](n)

   Creates a userdata array of unsigned chars or (signed) doubles with the given number of entries n, with n an integer,
   and with each slot set to the number 0. Initially, the number of elements can be zero or more, use numarray.resize to
   extend the array before assigning values.

   Due to advice by Luiz Henrique de Figueiredo the implementation uses explicit malloc's of the arrays, since
   resizing userdata via lmem functionality seems to be tricky:
   http://stackoverflow.com/questions/29806478/reallocating-resizing-lua-5-1-userdata-in-c */

/* leaves a numarray on top of the stack */
#define createnumarrayfileio(t,ut,what,n) { \
  a = (NumArray *)lua_newuserdata(L, sizeof(NumArray)); \
  a->size = (n); \
  a->datatype = (what); \
  if (what == 1) { \
    a->data.n = malloc((n) * sizeof(t)); \
    if (a->data.n == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } else if (what == 2) { \
    a->data.i = malloc((n) * sizeof(t)); \
    if (a->data.i == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } else { \
    a->data.c = malloc((n) * sizeof(t)); \
    if (a->data.c == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } \
  luaL_getmetatable(L, "numarray"); \
  lua_setmetatable(L, -2); \
  lua_pushstring(L, ut); \
  agn_setutype(L, -2, -1); \
  agn_poptop(L); \
}

/* leaves a numarray on top of the stack */
#define buildfn(t,ut,what) { \
  int64_t n; \
  NumArray *a; \
  n = luaL_checkint(L, 1); \
  luaL_argcheck(L, n >= 0, 1, "invalid size"); \
  a = (NumArray *)lua_newuserdata(L, sizeof(NumArray)); \
  a->size = n; \
  a->datatype = what; \
  if (what == 1) { \
    a->data.n = calloc(n, sizeof(t)); \
    if (a->data.n == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } else if (what == 2) { \
    a->data.i = calloc(n, sizeof(t)); \
    if (a->data.i == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } else { \
    a->data.c = calloc(n, sizeof(t)); \
    if (a->data.c == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } \
  luaL_getmetatable(L, "numarray"); \
  lua_setmetatable(L, -2); \
  lua_pushstring(L, ut); \
  agn_setutype(L, -2, -1); \
  agn_poptop(L); \
}

#define createarray(L, a, what, n) { \
  a = (NumArray *)lua_newuserdata(L, sizeof(NumArray)); \
  a->size = (n); \
  a->datatype = what; \
  if (what == 1) { \
    a->data.n = calloc(n, sizeof(lua_Number)); \
    if (a->data.n == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } else if (what == 2) { \
    a->data.i = calloc(n, sizeof(int32_t)); \
    if (a->data.i == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } else { \
    a->data.c = calloc(n, sizeof(unsigned char)); \
    if (a->data.c == NULL) \
      luaL_error(L, "Error: memory allocation failed."); \
  } \
  luaL_getmetatable(L, "numarray"); \
  lua_setmetatable(L, -2); \
  lua_pushstring(L, (what == 1) ? "double" : ((what == 2) ? "integer" : "uchar")); \
  agn_setutype(L, -2, -1); \
  agn_poptop(L); \
}


static int numarray_uchar (lua_State *L) {
  buildfn(unsigned char, "uchar", 0);
  return 1;
}


static int numarray_double (lua_State *L) {
  buildfn(lua_Number, "double", 1);
  return 1;
}


static int numarray_integer (lua_State *L) {
  buildfn(int32_t, "integer", 2);
  return 1;
}


/* numarray.put (a, i, v)

   With a any numarray, sets number v to a[i], where i, the index, is an integer counting from 1. */

static int numarray_put (lua_State *L) {  /* set a number to the given slot. */
  NumArray *a = checkarray(L, 1);
  int64_t index = agn_checkinteger(L, 2) - 1;  /* realign Lua/Agena index to C index, starting from 0 */
  lua_Number x = agn_checknumber(L, 3);
  if (index < 0 || index >= a->size)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "numarray.put", index + 1);
  switch (a->datatype) {
    case 0: a->data.c[index] = x; break;
    case 1: a->data.n[index] = x; break;
    case 2: a->data.i[index] = x; break;
    default: lua_assert(0);
  }
  return 0;
}


/* numarray.get (a, i)

  With a any numarray, returns the value stored at a[i], where i, the index, is an integer counting from 1. */

static int numarray_get (lua_State *L) {  /* get a number from the given Lua/Agena index. */
  NumArray *a = checkarray(L, 1);
  int64_t index = agn_checkinteger(L, 2) - 1;  /* realign Lua/Agena index to C index, starting from 0 */
  if (index < 0 || index >= a->size)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "numarray.get", index + 1);
  switch (a->datatype) {
    case 0: lua_pushnumber(L, a->data.c[index]); break;
    case 1: lua_pushnumber(L, a->data.n[index]); break;
    case 2: lua_pushnumber(L, a->data.i[index]); break;
    default: lua_assert(0);
  }
  return 1;
}

/* this C helper function tries to realloc the ud, but fails. Call:
   a = reallocud(L, a, a->size, n, a->datatype ? sizeof(lua_Number) : sizeof(char), sizeof(NumArray));

void *reallocud (lua_State *L, void *block, size_t o, size_t n, size_t sizeofelem, size_t sizeofnumarray) {
  if (n + 1 > MAX_SIZET/sizeofelem)
    luaL_error(L, "Error in " LUA_QS ": memory allocation error: block too big.", "(reallocud)", n);
  else
    return agn_resizeud(L, block, sizeofnumarray + o*sizeofelem, sizeofnumarray + n*sizeofelem);
} */


static int numarray_purge (lua_State *L) {  /* 2.9.1, delete a number at a given slot. */
  int64_t index;
  size_t i;
  int resize, zerosize;  /* realloc array after deletion ? */
  lua_Number x = 0;
  NumArray *a = checkarray(L, 1);
  index = agn_checkinteger(L, 2) - 1;  /* realign Lua/Agena index to C index, starting from 0 */
  resize = agnL_optboolean(L, 3, 1);
  if (index < 0 || index >= a->size || a->size < 1)
    luaL_error(L, "Error in " LUA_QS ": index %d out-of-range or array empty.", "numarray.purge", index + 1);
  zerosize = a->size == 1;  /* shrinking to zero blocks causes segmentation faults, so prevent this */
  switch (a->datatype) {
    case 0:
      x = a->data.c[index];
      for (i=index + 1; i < a->size - 1; i++)
        a->data.c[i] = a->data.c[i + 1];
      if (resize) {
        if ((a->data.c = realloc(a->data.c, (--a->size + zerosize) * sizeof(unsigned char))) == NULL)
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.purge");
      } else
        a->data.c[a->size - 1] = 0;
      break;
    case 1:
      x = a->data.n[index];
      for (i=index + 1; i < a->size - 1; i++)
        a->data.n[i] = a->data.n[i + 1];
      if (resize) {
        if ((a->data.n = realloc(a->data.n,(--a->size + zerosize) * sizeof(lua_Number))) == NULL)
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.purge");
      } else
        a->data.n[a->size - 1] = 0;
      break;
    case 2:
      x = a->data.i[index];
      for (i=index + 1; i < a->size - 1; i++)
        a->data.i[i] = a->data.i[i + 1];
      if (resize) {
        if ((a->data.i = realloc(a->data.i, (--a->size + zerosize) * sizeof(int32_t))) == NULL)
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.purge");
      } else
        a->data.i[a->size - 1] = 0;
      break;
    default: lua_assert(0);
  }
  lua_pushnumber(L, x);
  return 1;
}


/* numarray.resize (a, n): The function resizes a numarray userdata structure a to the given number of entries n. Thus you
   can extend or shrink a numarray. When shrinking a numarray, the function first overwrites the entries to be `deleted`
   with zeros. When extending, it fills the new array slots with zeros.

   The function returns the new size, an integer.

   The function issues an error if the new size is less than 1 (an array cannot be shrinked to zero bytes). */

static int numarray_resize (lua_State *L) {
  int64_t n, i;
  int zerosize;
  NumArray *a = checkarray(L, 1);
  zerosize = 0;  /* added 2.9.1 */
  n = agnL_checkint(L, 2);  /* absolute new size */
  if (n  < 0)
    luaL_error(L, "Error in " LUA_QS ": invalid new size %d.", "numarray.resize", n);
  else if (a->size == 0 && n == 0) {  /* do nothing */
    lua_pushinteger(L, 0);
    return 1;
  } else if (n == 0)
    zerosize = 1;  /* trying to realloc to 0 bytes will cause segmentation faults later, so leave at least one block assigned */
  if (n != a->size) {  /* extend or shrink (or do nothing if a->size == n)*/
    if (a->datatype == 1) {
      /* if (a->size > n) { for (i=a->size - 1; i > (n + zerosize) - 1; i--) a->data.n[i] = 0; }; */ /* overwrite values in memory part to be deleted */
      if ((a->data.n = realloc(a->data.n, (n + zerosize) * sizeof(lua_Number))) == NULL)
        luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.resize");
      if (n > a->size) { for(i=a->size; i < n; i++) a->data.n[i] = 0; };  /* fill added space with zeros */
    } else if (a->datatype == 2) {
      /* if (a->size > n) { for (i=a->size - 1; i > (n + zerosize) - 1; i--) a->data.i[i] = 0; }; */ /* overwrite values in memory part to be deleted */
      if ((a->data.i = realloc(a->data.i, (n + zerosize) * sizeof(int32_t))) == NULL)
        luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.resize");
      if (n > a->size) { for(i=a->size; i < n; i++) a->data.i[i] = 0; };  /* fill added space with zeros */
    } else {
      /* if (a->size > n) { for (i=a->size - 1; i > (n + zerosize) - 1; i--) a->data.c[i] = 0; }; */
      if ((a->data.c = realloc(a->data.c, (n + zerosize) * sizeof(unsigned char))) == NULL)
        luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.resize");
      if (n > a->size) { for(i=a->size; i < n; i++) a->data.c[i] = 0; };
    }
    a->size = n;
  }
  lua_pushinteger(L, a->size);
  return 1;
}


/* numarray.iterate (a [, i [, p]])
Returns an iterator function that when called returns the next value in the numarray userdata structure
a, or null if there are no further entries in the structure.

If an index i is passed, the first call to the iterator function returns the i-th element in
the numarray list and with subsequent calls, the respective elements after index i.

You may also pass a positive integer step p to the iterator function: If given, then in subsequent
calls the p-th element after the respective current one is returned, equivalent to giving an optional
step size in numeric for loops.

Example:

> import numarray

> a := numarray.double(3)

> for i to 3 do a[i] := i * Pi od

> f := numarray.iterate(a, 2):  # return all values starting with index 2
procedure(01CDC200)

> f():
6.2831853071796

> f():
9.4247779607694

> f():  # no more values in a
null
*/

static int iterate (lua_State *L) {
  NumArray *a;
  size_t pos, step;
  a = lua_touserdata(L, lua_upvalueindex(1));
  pos = lua_tointeger(L, lua_upvalueindex(2));
  step = lua_tointeger(L, lua_upvalueindex(3));
  if (pos > a->size)
    lua_pushnil(L);
  else {
    lua_pushnumber(L, a->datatype == 1 ? a->data.n[pos - 1] :
      ((a->datatype == 2) ? a->data.i[pos - 1] : a->data.c[pos - 1]));
    lua_pushinteger(L, pos + step);
    lua_replace(L, lua_upvalueindex(2));
  }
  return 1;
}

static int numarray_iterate (lua_State *L) {
  int64_t pos, step;
  NumArray *a = checkarray(L, 1);
  pos = agnL_optinteger(L, 2, 1);
  step = agnL_optinteger(L, 3, 1);
  if (pos < 1 || (pos > a->size && a->size != 0))  /* when iterating, return null if the array is empty */
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "numarray.iterate", pos);
  if (step < 1)
    luaL_error(L, "Error in " LUA_QS ": step size must be a positive.", "numarray.iterate");
  lua_pushvalue(L, 1);
  lua_pushinteger(L, pos);
  lua_pushinteger(L, step);
  lua_pushcclosure(L, &iterate, 3);
  return 1;
}


static int mt_getsize (lua_State *L) {  /* returns the number of allocated slots in the userdata numeric array */
  NumArray *a = checkarray(L, 1);
  lua_pushinteger(L, a->size);
  return 1;
}


static int mt_array2string (lua_State *L) {  /* at the console, the array is formatted as follows: */
  NumArray *a = checkarray(L, 1);
  if (agn_getutype(L, 1)) {
    lua_pushfstring(L, "(%d)", a->size);
    lua_concat(L, 2);
  } else
    luaL_error(L, "Error in " LUA_QS ": invalid array.", "numarray.__tostring");
  return 1;
}


static int mt_arraygc (lua_State *L) {  /* please do not forget to garbage collect deleted userdata */
  (void)L;
  NumArray *a = checkarray(L, 1);
  if (a->datatype == 1) { xfree(a->data.n); }
  else if (a->datatype == 2) { xfree(a->data.i); }
  else { xfree(a->data.c); }
  return 0;
}


/* Returns the index for a given value what in the numarray a. By default, the search starts at the beginning of the array,
   but you may pass any valid position pos (a positive integer) to determine where to start the search. The return is
   the index position, a positive number, or `null` if `what` could not be found in a.

   By default, the function checks for exact equality to detect the existence of a value. By passing the fourth argument
   eps, a non-negative number, the function also compares the values approximately with the given maximum deviation eps.
   See approx for more details. */

static int numarray_whereis (lua_State *L) {
  size_t i, pos, isapprox;
  lua_Number what, eps;
  what = agn_checknumber(L, 1);
  NumArray *a = checkarray(L, 2);
  pos = agnL_optinteger(L, 3, 1) - 1;
  eps = luaL_optnumber(L, 4, 0);
  if (eps < 0)
    luaL_error(L, "Error in " LUA_QS ": fourth argument must be non-negative.", "numarray.whereis");
  isapprox = lua_gettop(L) == 4;
  if (pos < 0 || pos >= a->size)
    luaL_error(L, "Error in " LUA_QS ": index %d out-of-range.", "numarray.whereis", pos + 1);
  switch (a->datatype) {
    case 0:
      for (i=pos; i < a->size; i++) {
        if (a->data.c[i] == what || (isapprox && tools_approx(a->data.c[i], what, eps))) {
          lua_pushinteger(L, i + 1);
          return 1;
        }
      }
      break;
    case 1:
      for (i=pos; i < a->size; i++) {
        if (a->data.n[i] == what || (isapprox && tools_approx(a->data.n[i], what, eps))) {
          lua_pushinteger(L, i + 1);
          return 1;
        }
      }
      break;
    case 2:
      for (i=pos; i < a->size; i++) {
        if (a->data.i[i] == what || (isapprox && tools_approx(a->data.i[i], what, eps))) {
          lua_pushinteger(L, i + 1);
          return 1;
        }
      }
      break;
    default:
      lua_assert(0);
  }
  lua_pushnil(L);
  return 1;
}


static void arrayeq (lua_State *L, int (*fn)(lua_Number, lua_Number, lua_Number)) {  /* based on the linalg package (function meq) */
  size_t i;
  int flag;
  lua_Number eps;
  NumArray *a, *b;
  a = checkarray(L, 1);
  b = checkarray(L, 2);
  flag = 1;
  if (a->size != b->size || a->datatype != b->datatype)
    lua_pushfalse(L);
  else {  /* arrays have same dimension */
    eps = agn_getepsilon(L);
    switch (a->datatype) {
      case 0:
        for (i=0; i < a->size; i++) {
          if (!fn(a->data.c[i], b->data.c[i], eps)) {
            flag = 0;
            goto endofarrayeq;  /* exit in case of inequality */
          }
        }
        break;
      case 1:
        for (i=0; i < a->size; i++) {
          if (!fn(a->data.n[i], b->data.n[i], eps)) {
            flag = 0;
            goto endofarrayeq;  /* exit in case of inequality */
          }
        }
        break;
      case 2:
        for (i=0; i < a->size; i++) {
          if (!fn(a->data.i[i], b->data.i[i], eps)) {
            flag = 0;
            goto endofarrayeq;  /* exit in case of inequality */
          }
        }
        break;
      default:
        lua_assert(0);
    }
  }
endofarrayeq:
  lua_pushboolean(L, flag);
}

static int equal (lua_Number x, lua_Number y, lua_Number eps) {  /* strict equality, eps does not matter */
  return x == y;
}

static int mt_aeq (lua_State *L) {
  arrayeq(L, tools_approx);
  return 1;
}


static int mt_eeq (lua_State *L) {
  arrayeq(L, equal);
  return 1;
}


/* numarray.read (fh [, bufsize])

Reads data from the file denoted by its filehandle fh and returns a numarray userdata structure
of unsigned C chars.

The file should before be opened with `binio.open` and should finally be closed with `binio.close`.

In general, the function reads in a limited amount of bytes per call. If only fh is passed, the
number of bytes read is determined by the environ.kernel('buffersize') setting, usually 512 bytes.

You can pass the second argument bufsize, a positive integer, to read less or more bytes. Passing
the bufsize argument may also be necessary if your platform requires that an internal input buffer
is aligned to a certain block size.

The function increments the file position thereafter so that the next bytes in the file can be read
with a new call to numarray.read.

If the end of the file has been reached, or there is nothing to read at all, null is returned.
In case of an error, it quits with the respective error.

See also: numarray.readdoubles, numarray.readintegers, numarray.readuchars. */

/* based on binio.readbytes. */

static int numarray_read (lua_State *L) {
  int64_t s, i;
  int hnd, n, en;
  NumArray *a;
  unsigned char *buffer;
  hnd = agn_checkposint(L, 1);
  s = luaL_optinteger(L, 2, agn_getbuffersize(L));  /* reading a lot of bytes at one stroke will cause block size errors, so keep the buffer small */
  if (s == -1)
    luaL_error(L, "Error in " LUA_QS " with file #%d: file I/O error.", "numarray.read", hnd);
  else if (s <= 0)
    s = LUAL_BUFFERSIZE;
  buffer = malloc(s * sizeof(unsigned char));
  if (buffer == NULL)
    luaL_error(L, "Error in " LUA_QS " with file #%d: memory allocation error.", "numarray.read", hnd);
  n = read(hnd, buffer, s * sizeof(unsigned char));
  en = errno;
  if (n > 0) {
    createnumarrayfileio(unsigned char, "uchar", 0, n);
    for (i=0; i < n; i++)
      a->data.c[i] = buffer[i];
  }
  else if (n == 0)
    lua_pushnil(L);
  else {
    xfree(buffer);
    luaL_error(L, "Error in " LUA_QS " with file #%d: %s.", "numarray.read", hnd, my_ioerror(en));
  }
  xfree(buffer);
  return 1;
}


/* numarray.write (fh, a [, pos [, nvalues]])

   based on binio.writebytes; writes unsigned chars, doubles, or integers stored in a numarray userdata a to the file denoted by its
   numeric file handle fh. The file should be opened with binio.open and closed with binio.close.

   The start position `pos` is 1 by default but can be changed to any other valid position in the numarray.

   The number of values (not bytes 1) `nvalues` to be written can be changed by passing an optional fourth argument, a positive
   number, and by default equals the total number of entries in `a`. Depending on the data type stored to the numarray, the
   function automatically computes the number of bytes to be written. Passing the `nvalues` argument may also be necessary if your
   platform requires that buffers must be aligned to a particular block size.

   The function returns the index of the next start position (an integer) for a further call to write a entirely, or `null`,
   if the end of the numarray has been reached.

   No further information is stored to the file created, so you always must know the type of data you want to read in later.

   Example on how to write an entire array of 4,096 integers piece-by-piece:

   > a := numarray.integer(4 * 1024);
   > fd := binio.open('uchar.bin');
   > pos := 1;
   > do
   >    pos := numarray.write(fd, a, pos, 1024)  # write 1024 values per each call
   > until pos = null;
   > binio.close(fd);

   Use `binio.sync` if you want to make sure that any unwritten content is written to the file when calling `numarray.write`
   multiple times on one numarray. */

static int numarray_write (lua_State *L) {
  int hnd, en;
  int64_t i, nchars, start;
  ssize_t nbytes, nbyteswritten, totnbytes, c;
  unsigned char *buffer, *dst;
  size_t j;
  NumArray *a;
  hnd = agn_checkposint(L, 1);
  a = checkarray(L, 2);
  switch (a->datatype) {
    case 0: nbytes = sizeof(unsigned char); break;
    case 1: nbytes = sizeof(lua_Number); break;
    case 2: nbytes = sizeof(int32_t); break;
    default: nbytes = 0; lua_assert(0);  /* avoid compiler warnings */
  }
  start = agnL_optinteger(L, 3, 1) - 1;
  if (start < 0 || start >= a->size)
    luaL_error(L, "Error in " LUA_QS " with file #%d: start position %d out-of-range.", "numarray.write", hnd, start + 1);
  nchars = agnL_optinteger(L, 4, a->size);  /* number of values (not bytes) in array to be written */
  if (start + nchars > a->size) nchars = a->size - start;
  if (nchars < 1)
    luaL_error(L, "Error in " LUA_QS " with file #%d: invalid number of bytes to be written.", "numarray.write", hnd);
  totnbytes = nchars * nbytes;
  buffer = malloc(totnbytes);
  if (buffer == NULL)
    luaL_error(L, "Error in " LUA_QS " with file #%d: memory allocation error.", "numarray.write", hnd);
  switch (a->datatype) {
    case 0:
      for (i=start; i < start + nchars; i++)
        buffer[i - start] = a->data.c[i];
      break;
    case 1: {
      uint64_t u;
      c = 0;
      for (i=start; i < start + nchars; i++) {
        u = tools_double2uint(a->data.n[i]);  /* convert to Little Endian `integer` */
        dst = (unsigned char *)&u;
        for (j=0; j < nbytes; j++)
          buffer[c++] = dst[j];
      }
      break;
    }
    case 2: {
      int32_t u;
      c = 0;
      for (i=start; i < start + nchars; i++) {
        u = a->data.i[i];
#if BYTE_ORDER == BIG_ENDIAN
        tools_swapint32_t(&u);  /* convert to Little Endian 32-bit `integer` */
#endif
        dst = (unsigned char *)&u;
        for (j=0; j < nbytes; j++)
          buffer[c++] = dst[j];
      }
      break;
    }
    default:
      lua_assert(0);
  }
  if ( (nbyteswritten = write(hnd, buffer, totnbytes) ) == -1) {
    en = errno;
    xfree(buffer);
    luaL_error(L, "Error in " LUA_QS " with file #%d: %s.", "numarray.write", hnd, my_ioerror(en));
  }
  if (luai_nummod(nbyteswritten, nbytes) != 0) {
    xfree(buffer);
    luaL_error(L, "Error in " LUA_QS " with file #%d: write error.", "numarray.write", hnd);
  }
  nbytes = nbyteswritten / nbytes;
  if (start + nbytes + 1 > a->size)  /* no more bytes to be written */
    lua_pushnil(L);
  else
    lua_pushinteger(L, start + nbytes + 1);  /* returns the next start position for a further call to write further parts of the numarray */
  xfree(buffer);
  return 1;
}


/* numarray.toseq (a)

Receives a numarray userdata structure a and converts it into a sequence of numbers, the return. */

static int numarray_toseq (lua_State *L) {
  size_t i;
  NumArray *a = checkarray(L, 1);
  agn_createseq(L, a->size);
  switch (a->datatype) {
    case 0:
      for (i=0; i < a->size; i++)
        lua_seqsetinumber(L, -1, i + 1, a->data.c[i]);
      break;
    case 1:
      for (i=0; i < a->size; i++)
        lua_seqsetinumber(L, -1, i + 1, a->data.n[i]);
      break;
    case 2:
      for (i=0; i < a->size; i++)
        lua_seqsetinumber(L, -1, i + 1, a->data.i[i]);
      break;
    default:
      lua_assert(0);
  }
  return 1;
}


/* numarray.toreg (a)

Receives a numarray userdata structure a and converts it into a register of numbers, the return. */

static int numarray_toreg (lua_State *L) {
  size_t i;
  NumArray *a = checkarray(L, 1);
  agn_createreg(L, a->size);
  switch (a->datatype) {
    case 0:
      for (i=0; i < a->size; i++) {
        lua_regsetinumber(L, -1, i + 1, a->data.c[i]);
      }
      break;
    case 1:
      for (i=0; i < a->size; i++) {
        lua_regsetinumber(L, -1, i + 1, a->data.n[i]);
      }
      break;
    case 2:
      for (i=0; i < a->size; i++) {
        lua_regsetinumber(L, -1, i + 1, a->data.i[i]);
      }
      break;
    default:
      lua_assert(0);
  }
  return 1;
}

/* numarray.toarray(o [, option])

   Converts a sequence or register o of number into a numarray. By default, a double array is returned;
   if the second argument `option` is the string 'uchar', an unsigned char array is created; if it is the
   string 'integer', an integer array is returned. By default, option is the string 'double'.

   If a value in o is not a number, zero is written to the array. */

static int numarray_toarray (lua_State *L) {
  int64_t i, n;
  int what;
  NumArray *a;
  static const char *const datatypes[] = {"uchar", "double", "integer", NULL};
  what = agnL_checkoption(L, 2, "double", datatypes);
  switch (lua_type(L, 1)) {
    case LUA_TSEQ: {
      n = agn_seqsize(L, 1);
      createarray(L, a, what, n);
      switch (a->datatype) {
        case 0:
          for (i=0; i < n; i++)
            a->data.c[i] = (unsigned char)lua_seqgetinumber(L, 1, i + 1);
          break;
        case 1:
          for (i=0; i < n; i++)
            a->data.n[i] = lua_seqgetinumber(L, 1, i + 1);
          break;
        case 2:
          for (i=0; i < n; i++)
            a->data.i[i] = (int32_t)lua_seqgetinumber(L, 1, i + 1);
          break;
        default:
          lua_assert(0);
      }
      break;
    }
    case LUA_TREG: {
      n = agn_reggettop(L, 1);
      createarray(L, a, what, n);
      switch (a->datatype) {
        case 0:
          for (i=0; i < n; i++)
            a->data.c[i] = (unsigned char)agn_reggetinumber(L, 1, i + 1);
          break;
        case 1:
          for (i=0; i < n; i++)
            a->data.n[i] = agn_reggetinumber(L, 1, i + 1);
          break;
        case 2:
          for (i=0; i < n; i++)
            a->data.i[i] = (int32_t)agn_reggetinumber(L, 1, i + 1);
          break;
        default:
          lua_assert(0);
      }
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": sequence or register expected, got %s.",
        "numarray.toarray", luaL_typename(L, 1));
  }
  return 1;
}

/* numarray.include(a, pos, b)

   Copies all values in the numarray b into the numarray a, starting at index pos (a number) of a. The function
   returns nothing. Both numarrays must by of the same type: either be uchar, integer, or double arrays. */

static int numarray_include (lua_State *L) {
  size_t i, pos;
  NumArray *a, *b;
  a = checkarray(L, 1);
  pos = agn_checkposint(L, 2) - 1;
  if (lua_type(L, 3) == LUA_TUSERDATA) {
    b = checkarray(L, 3);
    if (b->size + pos > a->size)
      luaL_error(L, "Error in " LUA_QS ": first numarray not large enough.", "numarray.include");
    if (b->size == 0)
      luaL_error(L, "Error in " LUA_QS ": second numarray is empty.", "numarray.include");
    if (a->datatype != b->datatype)
      luaL_error(L, "Error in " LUA_QS ": both numarrays must by of the same type.", "numarray.include");
    switch (a->datatype) {  /* if size of b is 0, nothing happens */
      case 0:
        for (i=pos; i < pos + b->size; i++)
          a->data.c[i] = b->data.c[i - pos];
        break;
      case 1:
        for (i=pos; i < pos + b->size; i++)
          a->data.n[i] = b->data.n[i - pos];
        break;
      case 2:
        for (i=pos; i < pos + b->size; i++)
          a->data.i[i] = b->data.i[i - pos];
        break;
      default:
        lua_assert(0);
    }
  } else if (lua_type(L, 3) == LUA_TNUMBER) {  /* added 2.9.1 */
    lua_Number x = agn_tonumber(L, 3);
    if (pos > a->size)  /* allow index pos = a->size + 1 */
      luaL_error(L, "Error in " LUA_QS ": index %d out-of-range.", "numarray.include", pos + 1);
    /* enlarge array by one slot and shift values to open space */
    switch (a->datatype) {
      case 0:
        if ((a->data.c = realloc(a->data.c, (a->size + 1) * sizeof(unsigned char))) == NULL)
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.include");
        a->size++;
        for (i=a->size - 1; i > pos; i--)
          a->data.c[i] = a->data.c[i - 1];
        a->data.c[pos] = x;
        break;
      case 1:
        if ((a->data.n = realloc(a->data.n, (a->size + 1) * sizeof(lua_Number))) == NULL)
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.include");
        a->size++;
        for (i=a->size - 1; i > pos; i--)
          a->data.n[i] = a->data.n[i - 1];
        a->data.n[pos] = x;
        break;
      case 2:
        if ((a->data.i = realloc(a->data.i, (a->size + 1) * sizeof(int32_t))) == NULL)
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "numarray.include");
        a->size++;
        for (i=a->size - 1; i > pos; i--)
          a->data.i[i] = a->data.i[i - 1];
        a->data.i[pos] = x;
        break;
      default: lua_assert(0);
    }
  } else
    luaL_error(L, "Error in " LUA_QS ": argument #3 must either be a numarray or number, got %d.",
      "numarray.include", luaL_typename(L, 3));
  return 0;
}


/* Returns the number of bytes consumed by the given array. */

static int numarray_used (lua_State *L) {
  int64_t r;
  size_t size;
  NumArray *a = checkarray(L, 1);
  GCObject *o = index2gco(L, 1);
  r = sizeof(NumArray) + sizeudata(gco2u(o));
  size = a->size;
  switch (a->datatype) {
    case 0:
      if (size == 0 && a->data.c != NULL) size = 1;
      r += size * sizeof(unsigned char);
      break;
    case 1:
      if (size == 0 && a->data.n != NULL) size = 1;
      r += size * sizeof(lua_Number);
      break;
    case 2:
      if (size == 0 && a->data.i != NULL) size = 1;
      r += size * sizeof(int32_t);
      break;
    default:
      lua_assert(0);
  }
  lua_pushnumber(L, r);
  return 1;
}


static const struct luaL_Reg numarray_arraylib [] = {  /* metamethods for numeric userdata `n` */
  {"__aeq", mt_aeq},                     /* approximate equality mt */
  {"__eq", mt_eeq},                      /* equality mt */
  {"__eeq", mt_eeq},                     /* strict equality mt */
  {"__index", numarray_get},             /* n[p], with p the index, counting from 1 */
  {"__writeindex", numarray_put},        /* n[p] := value, with p the index, counting from 1 */
  {"__tostring", mt_array2string},       /* for output at the console, e.g. print(n) */
  {"__size", mt_getsize},
  {"__gc", mt_arraygc},                  /* please do not forget garbage collection */
  {NULL, NULL}
};


static const luaL_Reg numarraylib[] = {
  {"double", numarray_double},
  {"get", numarray_get},
  {"include", numarray_include},
  {"integer", numarray_integer},
  {"iterate", numarray_iterate},
  {"purge", numarray_purge},
  {"put", numarray_put},
  {"read", numarray_read},
  {"resize", numarray_resize},
  {"toarray", numarray_toarray},
  {"toreg", numarray_toreg},
  {"toseq", numarray_toseq},
  {"uchar", numarray_uchar},
  {"used", numarray_used},
  {"whereis", numarray_whereis},
  {"write", numarray_write},
  {NULL, NULL}
};


/*
** Open numarray library
*/
LUALIB_API int luaopen_numarray (lua_State *L) {
  luaL_newmetatable(L, "numarray");  /* metatable for numarray userdata, adds it to the registry with key 'numarray' */
  luaL_register(L, NULL, numarray_arraylib);  /* assign C metamethods to this metatable */
  luaL_register(L, AGENA_NUMARRAYLIBNAME, numarraylib);
  return 1;
}

