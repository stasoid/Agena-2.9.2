/*
** $Id: agncmpt.h $
** Compatibility definitions
** See Copyright notices in this file, and - where not indicated - in agena.h
** initiated by Alexander Walz, before 2009
*/

#ifndef agncmpt_h
#define agncmpt_h

#include "agnhlps.h"

/* In OpenSUSE 10.3, trunc, log2, exp2, fma, fdim do not exist although their definitions are included in tgmath.h */

#if (defined(__sun) && defined(__SVR4)) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__)  /* trunc, log2, exp2, fma, fdim */
#include <tgmath.h>
#endif

/* DJGPP does not have fma */
#if !(defined(__WIN32) || defined(__sun) && defined(__SVR4) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__))  /* 2.8.4 fix */
#undef fma
#define fma tools_fma
#endif

/* DJGPP does not have fdim */
#if !(defined(__WIN32) || defined(__sun) && defined(__SVR4) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__))  /* 2.8.4 */
#undef fdim
#define fdim tools_fdim
#endif

/* DJGPP does not know trunc */
#if !(defined(__WIN32) || defined(__sun) && defined(__SVR4) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__))  /* 2.8.4 fix */
#undef trunc
#define trunc(x)  ( ((x) > 0) ? floor((x)) : ceil((x)) )
#endif

#if !(defined(__WIN32) || defined(__sun) && defined(__SVR4) || defined(__linux__) && !defined(OPENSUSE) || defined(LUA_DOS) || defined(__APPLE__))  /* 2.8.4 fix */
#undef log2
#define log2(x)  ( ((x)) > 0 ? log((x))/log(2) : AGN_NAN )
#endif

/* #if !(defined(__WIN32) || defined(__sun) && defined(__SVR4) || defined(__linux__) && !defined(OPENSUSE) || defined(LUA_DOS)) */ /* 2.8.4 fix */
/* #define exp2(x)  (pow(2, (x))) */
/* 2.8.4, we use the Cephes implementation for the antilog2 operator on all platforms: */
#undef exp2  /* 2.8.4 improvement */
#define exp2 cephes_exp2
/* #endif */

/* faster than exp((x) * LN10//log(10)) */
/* DJGPP _has_ exp10 */
/* #if !(defined(LUA_DOS)) */ /* 2.8.4 */
/* #define exp10(x)  ( pow(10, (x)) ) */
/* 2.8.4, we use the Cephes implementation for the antilog10 operator on all platforms: */
#undef exp10  /* 2.8.4 improvement */
#define exp10 cephes_exp10
/* #endif */

/* DJGPP does not have isunordered */
#if defined(__sun) && defined(__SVR4)  /* 2.8.4 */
#define isunordered(x, y) __builtin_isunordered(x, y)
#elif !(defined(__WIN32) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__) || defined(__OS2__))
#define isunordered(x, y)  (!(((x) != AGN_NAN) && ((y) != AGN_NAN)))
#endif

/* DJGPP does not have isfinite */
#if defined(__sun) && defined(__SVR4)  /* 2.8.4 */
#define isfinite(x) __builtin_isfinite(x)
#elif !(defined(__WIN32) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__) || defined(__OS2__))
#define isfinite tools_isfinite
#endif

/* DJGPP does not know signbit */
#if defined(__sun) && defined(__SVR4)  /* 2.8.4 */
#define signbit(x) __builtin_signbit(x)
#elif !(defined(__WIN32) || defined(__linux__) && !defined(OPENSUSE) || defined(__APPLE__) || defined(__OS2__))  /* 2.8.4 fix and extension */
#undef signbit
#define signbit tools_signbit  /* FIXME: testing for -0.0 does not work in OpenSUSE 10.3/GCC 4.4.5 */
#endif

/* Solaris 10 does not have isinf */
#if defined(__sun) && defined(__SVR4)  /* 2.9.0 */
#define isinf(x)  ((x) == -HUGE_VAL || (x) == HUGE_VAL)
#endif

/* needed to compile under Solaris; orig in MinGW: 0x8000 */
#if !defined(_WIN32) && !defined(LUA_DOS) && !defined(__OS2__)
#define O_BINARY      0x0000
#endif

/* at least in GCC there are problems with fmax, see http://gcc.gnu.org/ml/gcc-bugs/2004-01/msg00620.html:
  `The symptom is that values of the mathematical functions fmaxf, fminf, fmax, fmin, fmaxl, fminl are
   all wrong. This makes the results of some numerical computations junks.` - 0.26.4. */
#define fMax(a, b)  (((a) > (b)) ? (a) : (b))  /* substitute */
#define fMin(a, b)  (((a) < (b)) ? (a) : (b))  /* substitute */

/* define constant `undefined` */
#ifdef NAN
#define AGN_NAN NAN
#elif defined(INFINITY)
#define AGN_NAN (INFINITY/INFINITY)
#else
#define AGN_NAN (tools_nan())
#endif

/* define complex unit I, which natively is not known to Solaris */
#ifdef __unix__
#undef _Complex_I
#define _Complex_I   (0.0F + 1.0iF)
#undef I
#define I   _Complex_I
#endif

/* The floating-point expression evaluation method, not known in MinGW/GCC 3.4.6
       -1  indeterminate
        0  evaluate all operations and constants just to the range and
           precision of the type
        1  evaluate operations and constants of type float and double
           to the range and precision of the double type, evaluate
           long double operations and constants to the range and
           precision of the long double type
        2  evaluate all operations and constants to the range and
           precision of the long double type;
   According to various newsgroup, its value is always 0. */
#ifndef FLT_EVAL_METHOD
#define FLT_EVAL_METHOD 0
#endif


#ifndef math_opt_barrier
#define math_opt_barrier(x) \
({ __typeof (x) __x = x; __asm ("" : "+m" (__x)); __x; })
#define math_force_eval(x) __asm __volatile ("" : : "m" (x))
#endif

#if defined(LUA_DOS)
#  define fopen64 fopen
#  define ftello64 ftell
#  define _ftelli64 ftello64
#  define fseeko64 fseek
#  define _fseeki64 fseeko64
#  define lseek64 lseek
#else
#  define fopen64 fopen
#  define ftello64 ftell
#  define _ftelli64 ftello64
#  define fseeko64 fseek
#  define _fseeki64 fseeko64
#  define lseek64 lseek
#endif


#ifndef LUA_DOS
  #include <stdint.h>     /* for int32_t */
  #include <sys/types.h>  /* for off_t & off64_t */
  #ifndef off64_t
    #define off64_t off_t
  #endif
#endif

#ifndef uint32_t
#  define uint32_t  unsigned long int
#endif

#ifndef uint64_t
#  define uint64_t  unsigned long long
#endif

#ifndef int64_t
#  define int64_t off64_t
#endif

#ifndef ULLONG_MAX
#  ifdef ULONG_LONG_MAX
#    define ULLONG_MAX ULONG_LONG_MAX
#  endif
#endif

#ifndef LLONG_MIN
#  ifdef LONG_LONG_MIN
#    define LLONG_MIN LONG_LONG_MIN
#  endif
#endif

#ifndef LLONG_MAX
#  ifdef LONG_LONG_MAX
#    define LLONG_MAX LONG_LONG_MAX
#  endif
#endif


#define TRUNC	trunc

#if !defined(umount2) && defined(umount)
  #define umount2((x), (y))	umount((x))
#endif

#endif

