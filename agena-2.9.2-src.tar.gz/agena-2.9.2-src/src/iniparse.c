/*
$Id: iniparse.c, initiated September 24, 2014 $
initialisation file parser library
Based on Nicolas Devillard's iniparser 3.1 library available at
http://ndevilla.free.fr/iniparser:

Copyright (c) 2000-2011 by Nicolas Devillard.

MIT License

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.

Agena binding written by Alexander Walz, see same MIT copyright notice in agena.h */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <ctype.h>

#define iniparse_c
#define LUA_LIB

#include "agena.h"

#include "agnhlps.h"
#include "agncmpt.h"
#include "llimits.h"
#include "agnconf.h"

#include "iniparse.h"


/** Maximum value size for integers and doubles. */
#define MAXVALSZ    1024

/** Minimal allocated number of entries in a dictionary */
#define DICTMINSZ   128

/** Invalid key token */
#define DICT_INVALID_KEY    ((char*)-1)

/* Private functions */

/* Doubles the allocated size associated to a pointer, 'size' is the current allocated size. */
static void *mem_double (void *ptr, int size) {
  void *newptr;
  newptr = calloc(2*size, 1);
  if (newptr == NULL) {
    return NULL;
  }
  memcpy(newptr, ptr, size);
  free(ptr);
  return newptr;
}

/**
  @brief    Duplicate a string
  @param    s String to duplicate
  @return   Pointer to a newly allocated string, to be freed with free()

  This is a replacement for strdup(). This implementation is provided
  for systems that do not have it.
 */

static char *xstrdup (const char *s) {
  char *t;
  if (!s)
    return NULL;
  t = (char*)malloc(strlen(s) + 1);
  if (t) {
    strcpy(t,s);
  }
  return t;
}


/**
  @brief    Remove blanks at the beginning and the end of a string.
  @param    s   String to parse.
  @return   ptr to statically allocated string.

  This function returns a pointer to a statically allocated string,
  which is identical to the input string, except that all blank
  characters at the end and the beg. of the string have been removed.
  Do not free or modify the returned string! Since the returned string
  is statically allocated, it will be modified at each function call
  (not re-entrant). */

static char *strstrip (const char *s) {
  static char l[ASCIILINESZ+1];
  char *last;
  if (s == NULL) return NULL;
  while (isspace((int)*s) && *s) s++;
  memset(l, 0, ASCIILINESZ+1);
  strcpy(l, s);
  last = l + strlen(l);
  while (last > l) {
    if (!isspace((int)*(last - 1)))
      break;
    last --;
  }
  *last = (char)0;
  return (char*)l;
}


/* Function codes */

/**
  @brief    Compute the hash key for a string.
  @param    key     Character string to use for key.
  @return   1 unsigned int on at least 32 bits.

  This hash function has been taken from an Article in Dr Dobbs Journal.
  This is normally a collision-free function, distributing keys evenly.
  The key is stored anyway in the struct so that collision can be avoided
  by comparing the key itself in last resort.
 */

unsigned dictionary_hash (const char *key) {
  int len;
  unsigned hash;
  int i;
  len = strlen(key);
  for (hash=0, i=0; i < len; i++) {
    hash += (unsigned)key[i];
    hash += (hash<<10);
    hash ^= (hash>>6);
  }
  hash += (hash <<3);
  hash ^= (hash >>11);
  hash += (hash <<15);
  return hash;
}

/**
  @brief    Create a new dictionary object.
  @param    size    Optional initial size of the dictionary.
  @return   1 newly allocated dictionary objet.

  This function allocates a new dictionary object of given size and returns
  it. If you do not know in advance (roughly) the number of entries in the
  dictionary, give size=0.
 */

dictionary *dictionary_new (int size) {
  dictionary *d;
  /* If no size was specified, allocate space for DICTMINSZ */
  if (size<DICTMINSZ) size=DICTMINSZ;
  if (!(d = (dictionary *)calloc(1, sizeof(dictionary)))) {
    return NULL;
  }
  d->size = size;
  d->val  = (char **)calloc(size, sizeof(char*));
  d->key  = (char **)calloc(size, sizeof(char*));
  d->hash = (unsigned int *)calloc(size, sizeof(unsigned));
  return d;
}

/**
  @brief  Delete a dictionary object
  @param    d   dictionary object to deallocate.
  @return   void

  Deallocate a dictionary object and all memory associated to it. */

void dictionary_del (dictionary *d) {
  int i;
  if (d == NULL) return;
  for (i=0; i < d->size; i++) {
    if (d->key[i] != NULL)
      free(d->key[i]);
    if (d->val[i] != NULL)
      free(d->val[i]);
  }
  free(d->val);
  free(d->key);
  free(d->hash);
  free(d);
  return;
}

/**
  @brief    Get a value from a dictionary.
  @param    d       dictionary object to search.
  @param    key     Key to look for in the dictionary.
  @param    def     Default value to return if key not found.
  @return   1 pointer to internally allocated character string.

  This function locates a key in a dictionary and returns a pointer to its
  value, or the passed 'def' pointer if no such key can be found in
  dictionary. The returned character pointer points to data internal to the
  dictionary object, you should not try to free it or modify it. */

char * dictionary_get (dictionary *d, const char *key, char *def) {
  unsigned hash;
  int i;
  hash = dictionary_hash(key);
  for (i=0; i < d->size; i++) {
    if (d->key[i] == NULL)
      continue;
    /* Compare hash */
    if (hash == d->hash[i]) {
      /* Compare string, to avoid hash collisions */
      if (!strcmp(key, d->key[i])) {
        return d->val[i];
      }
    }
  }
  return def;
}

/**
  @brief    Set a value in a dictionary.
  @param    d       dictionary object to modify.
  @param    key     Key to modify or add.
  @param    val     Value to add.
  @return   int     0 if Ok, anything else otherwise

  If the given key is found in the dictionary, the associated value is
  replaced by the provided one. If the key cannot be found in the
  dictionary, it is added to it.

  It is Ok to provide a NULL value for val, but NULL values for the dictionary
  or the key are considered as errors: the function will return immediately
  in such a case.

  Notice that if you dictionary_set a variable to NULL, a call to
  dictionary_get will return a NULL value: the variable will be found, and
  its value (NULL) is returned. In other words, setting the variable
  content to NULL is equivalent to deleting the variable from the
  dictionary. It is not possible (in this implementation) to have a key in
  the dictionary without value.

  This function returns non-zero in case of failure. */

int dictionary_set (dictionary *d, const char *key, const char *val) {
  int i;
  unsigned hash;
  if (d == NULL || key == NULL) return -1;
  /* Compute hash for this key */
  hash = dictionary_hash(key);
  /* Find if value is already in dictionary */
  if (d->n > 0) {
    for (i=0; i < d->size; i++) {
      if (d->key[i] == NULL)
        continue;
      if (hash == d->hash[i]) { /* Same hash value */
        if (!strcmp(key, d->key[i])) {   /* Same key */
          /* Found a value: modify and return */
          if (d->val[i] != NULL)
            free(d->val[i]);
          d->val[i] = val ? xstrdup(val) : NULL;
          /* Value has been modified: return */
          return 0;
        }
      }
    }
  }
  /* Add a new value */
  /* See if dictionary needs to grow */
  if (d->n == d->size) {
    /* Reached maximum size: reallocate dictionary */
    d->val  = (char **)mem_double(d->val,  d->size * sizeof(char*));
    d->key  = (char **)mem_double(d->key,  d->size * sizeof(char*));
    d->hash = (unsigned int *)mem_double(d->hash, d->size * sizeof(unsigned));
    if ((d->val == NULL) || (d->key == NULL) || (d->hash == NULL)) {
      /* Cannot grow dictionary */
      return -1;
    }
    /* Double size */
    d->size *= 2;
  }
  /* Insert key in the first empty slot. Start at d->n and wrap at
       d->size. Because d->n < d->size this will necessarily
       terminate. */
  for (i=d->n; d->key[i]; ) {
    if(++i == d->size) i = 0;
  }
  /* Copy key */
  d->key[i]  = xstrdup(key);
  d->val[i]  = val ? xstrdup(val) : NULL;
  d->hash[i] = hash;
  d->n ++;
  return 0;
}


/**
  @brief    Delete a key in a dictionary
  @param    d       dictionary object to modify.
  @param    key     Key to remove.
  @return   void

  This function deletes a key in a dictionary. Nothing is done if the
  key cannot be found. */

void dictionary_unset (dictionary *d, const char *key) {
  unsigned hash;
  int i;
  if (key == NULL) {
    return;
  }
  hash = dictionary_hash(key);
  for (i=0; i < d->size; i++) {
    if (d->key[i] == NULL)
      continue;
    /* Compare hash */
    if (hash == d->hash[i]) {
      /* Compare string, to avoid hash collisions */
      if (!strcmp(key, d->key[i])) {
        /* Found key */
        break;
      }
    }
  }
  if (i >= d->size)
    /* Key not found */
    return;

  free(d->key[i]);
  d->key[i] = NULL;
  if (d->val[i] != NULL) {
    free(d->val[i]);
    d->val[i] = NULL;
  }
  d->hash[i] = 0;
  d->n --;
  return;
}


/**
  @brief  Load a single line from an INI file
  @param    input_line  Input line, may be concatenated multi-line input
  @param    section     Output space to store section
  @param    key         Output space to store key
  @param    value       Output space to store value
  @return   line_status value */

line_status iniparser_line (const char *input_line, char *section, char *key, char *value) {
  line_status sta;
  char line[ASCIILINESZ + 1];
  int len;
  strcpy(line, strstrip(input_line));
  len = (int)strlen(line);
  sta = LINE_UNPROCESSED;
  if (len < 1) {
    /* Empty line */
    sta = LINE_EMPTY;
  } else if (line[0] == '#' || line[0] == ';') {
    /* Comment line */
    sta = LINE_COMMENT;
  } else if (line[0] == '[' && line[len-1] == ']') {
    /* Section name */
    sscanf(line, "[%[^]]", section);
    strcpy(section, strstrip(section));
    /* strcpy(section, strlwc(section)); */
    sta = LINE_SECTION;
  } else if (sscanf(line, "%[^=] = \"%[^\"]\"", key, value) == 2
       ||  sscanf(line, "%[^=] = '%[^\']'",   key, value) == 2
       ||  sscanf(line, "%[^=] = %[^;#]",   key, value) == 2) {
    /* Usual key=value, with or without comments */
    strcpy(key, strstrip(key));
    /* strcpy(key, strlwc(key)); */
    strcpy(value, strstrip(value));
    /*
     * sscanf cannot handle '' or "" as empty values
     * this is done here
     */
    if (!strcmp(value, "\"\"") || (!strcmp(value, "''"))) {
      value[0] = 0;
    }
    sta = LINE_VALUE;
  } else if (sscanf(line, "%[^=] = %[;#]", key, value) == 2
       ||    sscanf(line, "%[^=] %[=]", key, value) == 2) {
    /*
     * Special cases:
     * key=
     * key=;
     * key=#
     */
    strcpy(key, strstrip(key));
    /* strcpy(key, strlwc(key)); */
    value[0]=0;
    sta = LINE_VALUE;
  } else {
    /* Generate syntax error */
    sta = LINE_ERROR;
  }
  return sta;
}


/**
  @brief  Parse an ini file and return an allocated dictionary object
  @param    ininame Name of the ini file to read.
  @return   Pointer to newly allocated dictionary

  This is the parser for ini files. This function is called, providing
  the name of the file to be read. It returns a dictionary object that
  should not be accessed directly, but through accessor functions
  instead.

  The returned dictionary must be freed using iniparser_freedict(). */

dictionary *iniparser_load (const char *ininame) {
  FILE *in;
  char line     [ASCIILINESZ+1];
  char section  [ASCIILINESZ+1];
  char key      [ASCIILINESZ+1];
  char tmp      [ASCIILINESZ+1];
  char val      [ASCIILINESZ+1];
  int len;
  int last = 0;
  int lineno = 0;
  int errs = 0;
  dictionary *dict;
  if ((in = fopen64(ininame, "r")) == NULL) {
    /* fprintf(stderr, "iniparser: cannot open %s\n", ininame); */
    return NULL;
  }
  dict = dictionary_new(0);
  if (!dict) {
    fclose(in);
    return NULL;
  }
  memset(line,    0, ASCIILINESZ);
  memset(section, 0, ASCIILINESZ);
  memset(key,     0, ASCIILINESZ);
  memset(val,     0, ASCIILINESZ);
  last = 0;
  while (fgets(line+last, ASCIILINESZ-last, in) != NULL) {
    lineno++;
    len = (int)strlen(line)-1;
    if (len == 0)
      continue;
    /* Safety check against buffer overflows */
    if ((line[len] != '\n' && (fgets(line+last, ASCIILINESZ-last, in) != NULL))) {
      /* 2.3.0 RC 2 fix: EOF not yet reached (line+last still keeps the last line otherwise) ? */
      fprintf(stderr,
        "iniparser: input line too long in %s (%d)\n",
        ininame,
        lineno);
      dictionary_del(dict);
      fclose(in);
      return NULL;
    }
    /* Get rid of \n and spaces at end of line */
    while ((len >= 0) &&
        ((line[len] == '\n') || (isspace(line[len])))) {
      line[len] = 0;
      if (len != 0) len--;  /* Agena 2.3.0 RC 2 fix: \r's in a line may result in a negative value of len */
    }
    /* Detect multi-line */
    if (line[len] == '\\') {
      /* Multi-line value */
      last = len;
      continue;
    } else {
      last = 0;
    }
    switch (iniparser_line(line, section, key, val)) {
      case LINE_EMPTY: case LINE_COMMENT: break;
      case LINE_SECTION:
        errs = dictionary_set(dict, section, NULL);
        break;
      case LINE_VALUE:
        sprintf(tmp, "%s:%s", section, key);
        errs = dictionary_set(dict, tmp, val);
        break;
      case LINE_ERROR:
        fprintf(stderr, "iniparse: syntax error in %s (%d):\n",
          ininame,
          lineno);
        fprintf(stderr, "-> %s\n", line);
        errs++;
        break;
      default: break;
    }
    memset(line, 0, ASCIILINESZ);
    last = 0;
    if (errs < 0) {
      /* fprintf(stderr, "iniparser: memory allocation failure\n"); */
      break;
    }
  }
  if (errs) {
    dictionary_del(dict);
    dict = NULL;
  }
  fclose(in);
  return dict;
}

