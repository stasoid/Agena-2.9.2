/*
** $Id: lapi.h,v 2.2 2005/04/25 19:24:10 roberto Exp $
** Auxiliary functions from Lua API
** See Copyright Notice in agena.h
*/

#ifndef liolib_h
#define liolib_h
#endif
