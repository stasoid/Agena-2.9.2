/******************************************************************************
 * $Id: dbfopen.c,v 1.48 2003/03/10 14:51:27 warmerda Exp $
 *
 * Project:  Shapelib
 * Purpose:  Implementation of .dbf access API documented in dbf_api.html.
 * Author:   Frank Warmerdam, warmerdam@pobox.com
 *
 ******************************************************************************
 * Copyright (c) 1999, Frank Warmerdam
 *
 * This software is available under the following "MIT Style" license,
 * or at the option of the licensee under the LGPL (see LICENSE.LGPL).  This
 * option is discussed in more detail in shapelib.html.
 *
 * --
 *
 * Permission is hereby granted, free of charge, to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction, including without limitation
 * the rights to use, copy, modify, merge, publish, distribute, sublicense,
 * and/or sell copies of the Software, and to permit persons to whom the
 * Software is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included
 * in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
 * OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 ******************************************************************************
 *
 * $Log: dbfopen.c,v $
 * Revision 1.48  2003/03/10 14:51:27  warmerda
 * DBFWrite* calls now return FALSE if they have to truncate
 *
 * The xBase package, initiated June 05, 2010, written by Alexander Walz.
 * This Agena Binding is largely based on the Shapelib 1.2.10 source files, with
 * codepage, and the DBFMarkRecordDeleted and DBFIsRecordDeleted C functions taken
 * from the Shapelib 1.3.0 distribution.

 * Extensions to process binary Doubles added in Agena 2.2.0 RC 3.
*/

/* Supported input for dBASE data types:

   Data Type 		Data Input
   C (Character) 	All OEM code page characters.
   D (Date) 		Numbers and a character to separate month, day, and year (stored internally as 8 digits in YYYYMMDD format).
   N (Numeric) 		- . 0 1 2 3 4 5 6 7 8 9
   F (Float)        - . 0 1 2 3 4 5 6 7 8 9
   L (Logical) 		? Y y N n T t F f (? when not initialized).
   O (Binary Double)  stored in Litte Endian byte order */

#include "xbase.h"

#include <math.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#define xbase_c
#define LUA_LIB

#include "agena.h"
#include "agnxlib.h"
#include "agenalib.h"
#include "agnhlps.h"
#include "agnt64.h"
#include "agncmpt.h"

#ifndef lua_boxpointer
#define lua_boxpointer(L, u) \
	(*(void **)(lua_newuserdata(L,  sizeof(void *))) = (u))
#endif

#if !(defined(LUA_DOS) || defined(__OS2__) || defined(LUA_ANSI))
#define AGENA_XBASELIBNAME "xbase"
LUALIB_API int (luaopen_xbase) (lua_State *L);
#endif


#ifndef FALSE
#  define FALSE		0
#  define TRUE		1
#endif

static int	nStringFieldLen = 0;
static char *pszStringField = NULL;

/* forward declaration */
static int xbase_gc (lua_State *L);


DBFHandle *aux_gethandle (lua_State *L, int idx, const char *procname) {
  DBFHandle *hnd = (DBFHandle *)luaL_checkudata(L, idx, "xbase");
  if (*hnd == NULL)
    luaL_error(L, "Error in " LUA_QS ": invalid file handle.", procname);
  return hnd;
}


/************************************************************************/
/*                             SfRealloc()                              */
/*                                                                      */
/*      A realloc cover function that will access a NULL pointer as     */
/*      a valid input.                                                  */
/************************************************************************/

static void * SfRealloc (void * pMem, int nNewSize) {
  if (pMem == NULL)
    return((void *)malloc(nNewSize));
  else
    return((void *)realloc(pMem,nNewSize));
}


/************************************************************************/
/*                           DBFWriteHeader()                           */
/*                                                                      */
/*      This is called to write out the file header, and field          */
/*      descriptions before writing any actual data records.  This      */
/*      also computes all the DBFDataSet field offset/size/decimals     */
/*      and so forth values.                                            */
/************************************************************************/

static void DBFWriteHeader (DBFHandle psDBF) {
  unsigned char abyHeader[XBASE_FLDHDR_SZ];
  int i, yy, mm, dd;
  struct TM *stm;
  Time64_T t = time(NULL);
  if (!psDBF->bNoHeader) return;
  psDBF->bNoHeader = FALSE;
  /* Initialize the file header information.	*/
  for (i=0; i < XBASE_FLDHDR_SZ; i++)
    abyHeader[i] = 0;
  stm = gmtime64(&t);
  if (stm == NULL) {  /* invalid date ? */
    yy = 0; mm = 5; dd = 8;
  } else {
    yy = stm->tm_year;
    mm = stm->tm_mon+1;
    dd = stm->tm_mday;
  }
  abyHeader[0] = psDBF->dBaseVersion;  /* 2.2.0 RC 3 */
  abyHeader[1] = yy;	 /* YY */
  abyHeader[2] = mm;	 /* MM */
  abyHeader[3] = dd;	 /* DD */
  /* date updated on close, record count preset at zero */
  abyHeader[8] = psDBF->nHeaderLength % 256;  /* number of bytes in the header (16-bit number). */
  abyHeader[9] = psDBF->nHeaderLength / 256;
  abyHeader[10] = psDBF->nRecordLength % 256;  /* number of bytes in the record (16-bit number). */
  abyHeader[11] = psDBF->nRecordLength / 256;
  abyHeader[29] = (unsigned char)(psDBF->iLanguageDriver);
  /* Write the initial 32 byte file header, and all the field descriptions. */
  _fseeki64(psDBF->fp, 0, 0);
  fwrite(abyHeader, XBASE_FLDHDR_SZ, 1, psDBF->fp);
  fwrite(psDBF->pszHeader, XBASE_FLDHDR_SZ, psDBF->nFields, psDBF->fp);
  /* Write out the newline character if there is room for it. */
  if (psDBF->nHeaderLength > 32*psDBF->nFields + 32) {
    char cNewline;
    cNewline = 0x0d;
    fwrite(&cNewline, 1, 1, psDBF->fp);
  }
}


/************************************************************************/
/*                           DBFLoadRecord()                            */
/************************************************************************/

int DBFLoadRecord (DBFHandle psDBF, int iRecord) {
  if (psDBF->nCurrentRecord != iRecord) {
    int nRecordOffset;
    if (!DBFFlushRecord(psDBF)) {
      return FALSE;
    }
    nRecordOffset =
      psDBF->nRecordLength * iRecord + psDBF->nHeaderLength;
    if (_fseeki64(psDBF->fp, nRecordOffset, SEEK_SET) != 0) {
      /* printf("fseek(%ld) failed on DBF file.\n", (long) nRecordOffset); */
      /* char szMessage[128];
         sprintf(szMessage, "fseek(%ld) failed on DBF file.\n", (long) nRecordOffset);
         psDBF->sHooks.Error(szMessage); */
      return FALSE;
    }
    if (fread(psDBF->pszCurrentRecord, psDBF->nRecordLength, 1, psDBF->fp) != 1) {
      /* printf("fread(%d) failed on DBF file.\n", psDBF->nRecordLength); */
      /* char szMessage[128];
         sprintf(szMessage, "fread(%d) failed on DBF file.\n", psDBF->nRecordLength);
         psDBF->sHooks.Error(szMessage); */
      return FALSE;
    }
    psDBF->pszCurrentRecord[psDBF->nRecordLength] = '\0';  /* better sure than sorry, 2.2.0 RC 2 extension */
    psDBF->nCurrentRecord = iRecord;
  }
  return TRUE;
}

/************************************************************************/
/*                           DBFFlushRecord()                           */
/*                                                                      */
/*      Write out the current record if there is one.                   */
/************************************************************************/

/* modified for Agena 0.32.4, patched 2.2.0 RC 2 */

int DBFFlushRecord (DBFHandle psDBF) {
  int nRecordOffset, result, i;
  if (psDBF->bCurrentRecordModified && psDBF->nCurrentRecord > -1) {
    FILE *f = psDBF->fp;
    result = 0;
    psDBF->bCurrentRecordModified = FALSE;
    nRecordOffset = psDBF->nRecordLength * psDBF->nCurrentRecord
                    + psDBF->nHeaderLength;
    if (_fseeki64(f, nRecordOffset, 0) == 0) result |= 1;
    /* if (fwrite(psDBF->pszCurrentRecord, psDBF->nRecordLength, 1, f) == 1) result |= 2; */
    for (i=0; i < psDBF->nRecordLength; i++) {  /* 2.2.0 RC 3, make sure that entire record is written,
      including embedded 0's that may be part of a binary Double */
      if (fwrite(psDBF->pszCurrentRecord++, 1, 1, f) == 1) result |= 2;
    }
    psDBF->pszCurrentRecord -= psDBF->nRecordLength;
    if (fflush(f) == 0) result |= 4;
  } else  /* nothing to do, 2.2.0 RC 2 */
    result = -1;
  return (result == -1 || result == 7);
}


static int xbase_sync (lua_State *L) {
  int res;
  DBFHandle *hnd;
  hnd = aux_gethandle(L, 1, "xbase.sync");
  res = DBFFlushRecord(*hnd);
  if (res == 1)
    lua_pushtrue(L);
  else
    lua_pushfail(L);
  return 1;
}


/************************************************************************/
/*                              DBFOpen()                               */
/*                                                                      */
/*      Open a .dbf file.                                               */
/************************************************************************/

DBFHandle SHPAPI_CALL DBFOpen (const char * pszFilename, const char * pszAccess) {
  DBFHandle psDBF;
  unsigned char *pabyBuf;
  int nFields, nHeadLen, nRecLen, iField, i;
  char *pszBasename, *pszFullname;
  /* We only allow the access strings "rb" and "r+". */
  if (strcmp(pszAccess,"r") != 0 && strcmp(pszAccess,"r+") != 0
    && strcmp(pszAccess,"rb") != 0 && strcmp(pszAccess,"rb+") != 0
    && strcmp(pszAccess,"r+b") != 0) {
    return NULL;
  }
  if (strcmp(pszAccess,"r") == 0)
    pszAccess = "rb";
  if (strcmp(pszAccess,"r+") == 0)
    pszAccess = "rb+";
  /* Compute the base (layer) name. If there is any extension on the passed in
     filename we will strip it off. */
  pszBasename = (char *)malloc(strlen(pszFilename) + 5);
  strcpy(pszBasename, pszFilename);
  for (i = strlen(pszBasename)-1;
    i > 0 && pszBasename[i] != '.' && pszBasename[i] != '/'
          && pszBasename[i] != '\\';  i--) {}
  if (pszBasename[i] == '.')
    pszBasename[i] = '\0';
  pszFullname = (char *)malloc(strlen(pszBasename) + 5);
  sprintf(pszFullname, "%s.dbf", pszBasename);
  psDBF = (DBFHandle) calloc(1, sizeof(DBFInfo));
  psDBF->fp = fopen(pszFullname, pszAccess);
  if (psDBF->fp == NULL) {
    sprintf(pszFullname, "%s.DBF", pszBasename);
    psDBF->fp = fopen(pszFullname, pszAccess);
  }
  free(pszBasename);
  psDBF->filename = (char *)malloc(strlen(pszFilename) + 5);
  strcpy(psDBF->filename, pszFullname);
  free(pszFullname);
  if (psDBF->fp == NULL) {
    free(psDBF);
    return NULL;
  }
  psDBF->bNoHeader = FALSE;
  psDBF->nCurrentRecord = -1;
  psDBF->bCurrentRecordModified = FALSE;
  /* Read Table Header info */
  pabyBuf = (unsigned char *)malloc(500 * sizeof(char));
  if (fread(pabyBuf, 32, 1, psDBF->fp) != 1) {
    fclose(psDBF->fp);
    free(pabyBuf);
    free(psDBF);
    return NULL;
  }
  psDBF->nRecords =
    pabyBuf[4] + pabyBuf[5]*256 + pabyBuf[6]*256*256 + pabyBuf[7]*256*256*256;
  psDBF->nHeaderLength = nHeadLen = pabyBuf[8] + pabyBuf[9]*256;
  psDBF->nRecordLength = nRecLen = pabyBuf[10] + pabyBuf[11]*256;
  psDBF->iLanguageDriver = pabyBuf[29];
  if (nHeadLen < 32) {
    fclose(psDBF->fp);
    free(pabyBuf);
    free(psDBF);
    return NULL;
  }
  psDBF->nFields = nFields = (nHeadLen - 32) / 32;
  psDBF->pszCurrentRecord = (char *)malloc(nRecLen + 1);  /* better sure than sorry, 2.2.0 RC 2 */
  /* Figure out the code page from the LDID and CPG */
  psDBF->pszCodePage = (char *)malloc(500 * sizeof(char));
  sprintf(psDBF->pszCodePage, "LDID/%d", psDBF->iLanguageDriver);  /* a codepage of 0x00 means `invalid` or `undetermined` */
  psDBF->lastmodified = (pabyBuf[1]+1900)*10000 + pabyBuf[2]*100 + pabyBuf[3];  /* added 0.32.5 */
  /* Read in Field Definitions */
  pabyBuf = (unsigned char *)SfRealloc(pabyBuf, nHeadLen);
  psDBF->pszHeader = (char *)pabyBuf;
  _fseeki64(psDBF->fp, 32, 0);
  if (fread(pabyBuf, nHeadLen-32, 1, psDBF->fp) != 1) {
    fclose(psDBF->fp);
    free(pabyBuf);
    free(psDBF);
    return NULL;
  }
  psDBF->panFieldOffset = (int *)malloc(sizeof(int) * nFields);
  psDBF->panFieldSize = (int *)malloc(sizeof(int) * nFields);
  psDBF->panFieldDecimals = (int *)malloc(sizeof(int) * nFields);
  psDBF->pachFieldType = (char *)malloc(sizeof(char) * nFields);
  for (iField = 0; iField < nFields; iField++) {
    unsigned char *pabyFInfo;
    pabyFInfo = pabyBuf+iField*32;
    if (pabyFInfo[11] == 'N' || pabyFInfo[11] == 'F') {
      psDBF->panFieldSize[iField] = pabyFInfo[16];
      psDBF->panFieldDecimals[iField] = pabyFInfo[17];
    } else {  /* should cover dates, 2.1.6 */
      psDBF->panFieldSize[iField] = pabyFInfo[16] + pabyFInfo[17]*256;
      psDBF->panFieldDecimals[iField] = 0;
    }
    psDBF->pachFieldType[iField] = (char)pabyFInfo[11];
    if (iField == 0)
      psDBF->panFieldOffset[iField] = 1;
    else
      psDBF->panFieldOffset[iField] =
        psDBF->panFieldOffset[iField-1] + psDBF->panFieldSize[iField-1];
  }
  /* check for valid xBase file (0x0d flag at end of fields block), 0.32.4 */
  if (nHeadLen > 32 && pabyBuf[nHeadLen-33] != 0x0d) {
    fprintf(stderr, "Error in `xbase.open`: this does not seem to be a known or valid xBase file.\n\n");
    fclose(psDBF->fp);
    free(pabyBuf);
    free(psDBF);
    return NULL;
  }
  return psDBF;
}


static int xbase_open (lua_State *L) {
  const char *fn, *attr;
  DBFHandle hnd;
  fn = luaL_checkstring(L, 1);
  attr = luaL_optstring(L, 2, "read");
  if (strcmp(attr, "write") == 0 || strcmp(attr, "append") == 0 ||
    strcmp(attr, "r+") == 0 || strcmp(attr, "a") == 0 || strcmp(attr, "w") == 0)
    attr = "rb+";
  else if (strcmp(attr, "read") == 0 || strcmp(attr, "r") == 0)
    attr = "rb";
  else
    luaL_error(L, "Error in " LUA_QS ": unknown option " LUA_QS ".", "xbase.open", attr);
  hnd = DBFOpen(fn, attr);
  if (hnd == NULL)
    luaL_error(L, "Error in " LUA_QS ": could not open " LUA_QS ".", "xbase.open", fn);
  else {
    lua_boxpointer(L, hnd);
    luaL_getmetatable(L, "xbase");
    lua_setmetatable(L, -2);
  }
  return 1;
}


static int xbase_readdbf (lua_State *L) {  /* fixed 2.2.0 RC 2; extended 2.2.0 RC 5 */
  const char *fn;
  DBFHandle hnd;
  int nrecords, nfields, i, j, multifields, *fieldinfo, offset, ncols, nargs;
  lua_Integer *cols;
  char iofailure, ismarked;
  fn = NULL;
  if (lua_isstring(L, 1)) {
    fn = lua_tostring(L, 1);
    hnd = DBFOpen(fn, "rb");
    if (hnd == NULL)
      luaL_error(L, "Error in " LUA_QS ": could not open " LUA_QS ".", "xbase.readdbf", fn);
  } else {
    hnd = *aux_gethandle(L, 1, "xbase.readdbf");
  }
  nrecords = DBFGetRecordCount(hnd);
  nfields = DBFGetFieldCount(hnd);
  if (nrecords == 0 || nfields == 0)
    luaL_error(L, "Error in " LUA_QS ": database is empty.", "xbase.readdbf");
  fieldinfo = malloc(nfields*sizeof(int));
  if (fieldinfo == NULL)
    luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "xbase.readdbf");
  agn_createseq(L, nrecords);
  for (j=0; j < nfields; j++) {
    fieldinfo[j] = DBFGetFieldInfo(hnd, j, NULL, NULL, NULL);
  }
  ncols = 0;
  nargs = lua_gettop(L);
  cols = NULL;
  if (nargs > 1 && lua_ispair(L, 2)) {
    const char *setting;
    agn_pairgeti(L, 2, 1);  /* get left-hand side */
    if (lua_type(L, -1) != LUA_TSTRING) {
      int type = lua_type(L, -1);
      lua_pop(L, 2);  /* clear stack */
      xfree(fieldinfo);
      luaL_error(L, "Error in " LUA_QS ": string expected for left-hand side, got %s.", "environ.kernel",
        lua_typename(L, type));
    }
    setting = lua_tostring(L, -1);
    if (strcmp(setting, "fields") == 0) {
      lua_Integer x;
      ncols = 1;
      agn_pairgeti(L, 2, 2);  /* get right-hand side */
      if (agn_isnumber(L, -1)) {
        cols = malloc(1 * sizeof(lua_Integer));
        if (cols == NULL) {
          xfree(fieldinfo);
          lua_pop(L, 2);  /* pop lhs and rhs of pair */
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "xbase.readdbf");
        }
        x = (lua_Integer)agn_tonumber(L, -1);
        if (x < 1 || x > nfields) {
          xfree(fieldinfo);
          lua_pop(L, 2);  /* pop lhs and rhs of pair */
          luaL_error(L, "Error in " LUA_QS ": field %d does not exist.", "xbase.readdbf", x);
        }
        cols[0] = x - 1;
        lua_pop(L, 2);  /* pop lhs and rhs of pair */
      } else if (lua_istable(L, -1)) {
        ncols = agn_size(L, -1);
        if (ncols < 1) {
          xfree(fieldinfo);
          lua_pop(L, 2);  /* pop lhs and rhs of pair */
          luaL_error(L, "Error in " LUA_QS ", in option fields: table is empty.", "xbase.readdbf");
        }
        cols = malloc(ncols * sizeof(lua_Integer));
        if (cols == NULL) {
          xfree(fieldinfo);
          lua_pop(L, 2);  /* pop lhs and rhs of pair */
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "xbase.readdbf");
        }
        for (i=0; i < ncols; i++) {
          x = (lua_Integer)agn_getinumber(L, -1, i+1);
          if (x < 1 || x > nfields) {
            xfree(fieldinfo); xfree(cols);
            lua_pop(L, 2);  /* pop lhs and rhs of pair */
            luaL_error(L, "Error in " LUA_QS ": field %d does not exist.", "xbase.readdbf", x);
          }
          cols[i] = x - 1;
        }
        lua_pop(L, 2);
      } else if (lua_isseq(L, -1)) {
        ncols = agn_seqsize(L, -1);
        if (ncols < 1) {
          xfree(fieldinfo);
          lua_pop(L, 2);  /* pop lhs and rhs of pair */
          luaL_error(L, "Error in " LUA_QS ", in option fields: sequence is empty.", "xbase.readdbf");
        }
        cols = malloc(ncols * sizeof(lua_Integer));
        if (cols == NULL) {
          xfree(fieldinfo);
          lua_pop(L, 2);  /* pop lhs and rhs of pair */
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "xbase.readdbf");
        }
        for (i=0; i < ncols; i++) {
          x = (lua_Integer)agn_seqgetinumber(L, -1, i+1);
          if (x < 1 || x > nfields) {
            xfree(fieldinfo); xfree(cols);
            lua_pop(L, 2);  /* pop lhs and rhs of pair */
            luaL_error(L, "Error in " LUA_QS ": field %d does not exist.", "xbase.readdbf", x);
          }
          cols[i] = x - 1;
        }
        lua_pop(L, 2);
      } else {
        xfree(fieldinfo);
        luaL_error(L, "Error in " LUA_QS ": invalid right-hand side for fields option.", "xbase.readdbf");
      }
    } else {
      agn_poptop(L);
      xfree(fieldinfo);
      luaL_error(L, "Error in " LUA_QS ": unknown option %s.", "xbase.readdbf", setting);
    }
  } else {
    ncols = nfields;
    cols = malloc(ncols * sizeof(lua_Integer));
    if (cols == NULL) {
      xfree(fieldinfo);
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "xbase.readdbf");
    }
    for (i=0; i < ncols; i++) cols[i] = i;
  }
  offset = 0;
  multifields = ncols != 1;
  for (i=0; i < nrecords; i++) {
    if (DBFIsRecordDeleted(hnd, i)) {  /* ignore records marked deleted, 2.2.0 RC 2 */
      offset++;
      continue;
    }
    if (multifields) agn_createseq(L, ncols);
    for (j=0; j < ncols; j++) {
      switch (fieldinfo[cols[j]]) {
        case FTString: {
          const char *result = DBFReadStringAttribute(hnd, i, cols[j], &iofailure, &ismarked);
          if (result == NULL) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": no string stored in database.", "xbase.readdbf");
          }
          else if (iofailure) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readdbf");
          }
          else if (ismarked) offset++;
          else
            lua_seqsetistring(L, -1, (multifields) ? j+1 : i+1-offset, result);
          break;
        }
        case FTDouble: {
          lua_Number result = DBFReadDoubleAttribute(hnd, i, cols[j], &iofailure, &ismarked);
          if (iofailure) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readdbf");
          }
          else if (ismarked) offset++;
          else
            lua_seqsetinumber(L, -1, (multifields) ? j+1 : i+1-offset, result);
          break;
        }
        case FTBinDouble: {
          lua_Number result = DBFReadBinDoubleAttribute(hnd, i, cols[j], &iofailure, &ismarked);
          if (iofailure) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readdbf");
          }
          else if (ismarked) offset++;
          else
            lua_seqsetinumber(L, -1, (multifields) ? j+1 : i+1-offset, result);
          break;
        }
        case FTFloat: {
          lua_Number result = DBFReadFloatAttribute(hnd, i, cols[j], &iofailure, &ismarked);
          if (iofailure) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readdbf");
          }
          else if (ismarked) offset++;
          else
            lua_seqsetinumber(L, -1, (multifields) ? j+1 : i+1-offset, result);
          break;
        }
        case FTLogical: {
          const char *result = DBFReadLogicalAttribute(hnd, i, cols[j], &iofailure, &ismarked);
          if (result == NULL) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": no logical value stored in database.", "xbase.readdbf");
          } else if (iofailure) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readdbf");
          }
          else if (ismarked) offset++;
          else
            lua_seqsetistring(L, -1, (multifields) ? j+1 : i+1-offset, result);
          break;
        }
        case FTDate: {
          const char *result = DBFReadDateAttribute(hnd, i, cols[j], &iofailure, &ismarked);
          if (result == NULL) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": no date value stored in database.", "xbase.readdbf");
          } else if (iofailure) {
            xfree(fieldinfo); xfree(cols);
            luaL_error(L, "Error in " LUA_QS ": could not successfully read date in database.", "xbase.readdbf");
          } else if (ismarked) offset++;
          else
            lua_seqsetistring(L, -1, (multifields) ? j+1 : i+1-offset, result);
          break;
        }
        default: {
          xfree(fieldinfo); xfree(cols);
          luaL_error(L, "Error in " LUA_QS ": unknown type of data.", "xbase.readdbf");
        }
      }
    }
    if (multifields) lua_seqseti(L, -2, i+1-offset);
  }
  xfree(fieldinfo); xfree(cols);
  if (fn != NULL) DBFClose(hnd);
  return 1;
}


/************************************************************************/
/*                              DBFClose()                              */
/************************************************************************/

int SHPAPI_CALL DBFClose (DBFHandle psDBF) {
  /* Write out header if not already written. */
  int result = 0;
  if (psDBF == NULL) return -1;
  if (psDBF->bNoHeader) DBFWriteHeader(psDBF);
  DBFFlushRecord(psDBF);
  /* Update last access date, and number of records if we have write access. */
  if (psDBF->bUpdated) {
    unsigned char abyHeader[32];
    Time64_T t = time(NULL);
    struct TM *stm;
    int yy, mm, dd;
    _fseeki64(psDBF->fp, 0, 0);
    fread(abyHeader, 32, 1, psDBF->fp);
    stm = gmtime64(&t);
    if (stm == NULL) {  /* invalid date ? */
      yy = 0; mm = 5; dd = 8;
    } else {
      yy = stm->tm_year;
      mm = stm->tm_mon+1;
      dd = stm->tm_mday;
    }
    abyHeader[1] = yy;	 /* YY */
    abyHeader[2] = mm;	 /* MM */
    abyHeader[3] = dd;	 /* DD */
    abyHeader[4] = psDBF->nRecords % 256;
    abyHeader[5] = (psDBF->nRecords/256) % 256;
    abyHeader[6] = (psDBF->nRecords/(256*256)) % 256;
    abyHeader[7] = (psDBF->nRecords/(256*256*256)) % 256;
    _fseeki64(psDBF->fp, 0, 0);
    fwrite(abyHeader, 32, 1, psDBF->fp);
  }
  /* Close, and free resources. */
  result = fclose(psDBF->fp);
  if (psDBF->panFieldOffset != NULL) {
    free(psDBF->panFieldOffset);
    free(psDBF->panFieldSize);
    free(psDBF->panFieldDecimals);
    free(psDBF->pachFieldType);
  }
  free(psDBF->pszHeader);
  free(psDBF->pszCurrentRecord);
  free(psDBF->filename);  /* 0.32.4 */
  free(psDBF->pszCodePage);  /* 2.1.6 */
  free(psDBF);
  if (pszStringField != NULL) {
    free(pszStringField);
    pszStringField = NULL;
    nStringFieldLen = 0;
  }
  return result;
}


static int xbase_close (lua_State *L) {
  DBFHandle *hnd;
  int result;
  hnd = aux_gethandle(L, 1, "xbase.close");
  result = DBFClose(*hnd);
  /* ignore closed files */
  if (*hnd != NULL) {  /* this will work */
    *hnd = NULL;
    xbase_gc(L);
  }
  lua_pushboolean(L, result == 0);
  return 1;
}


/************************************************************************/
/*                             DBFCreate()                              */
/*                                                                      */
/*      Create a new .dbf file.                                         */
/************************************************************************/

DBFHandle SHPAPI_CALL DBFCreate (const char *pszFilename) {
  DBFHandle	psDBF;
  FILE *fp;
  char *pszFullname, *pszBasename;
  int i;
  /* Compute the base (layer) name. If there is any extension on the passed in filename we will strip it off. */
  pszBasename = (char *)malloc((strlen(pszFilename) + 5) * sizeof(char));
  strcpy(pszBasename, pszFilename);
  for (i = strlen(pszBasename) - 1;
    i > 0 && pszBasename[i] != '.' && pszBasename[i] != '/'
          && pszBasename[i] != '\\';
    i--) {}
  if (pszBasename[i] == '.') pszBasename[i] = '\0';
  pszFullname = (char *)malloc((strlen(pszBasename) + 5) * sizeof(char));
  sprintf(pszFullname, "%s.dbf", pszBasename);
  free(pszBasename);
  /* Create the file. */
  fp = fopen(pszFullname, "wb");
  if (fp == NULL) {
    free(pszFullname);
    return NULL;
  }
  fputc(0, fp);
  fclose(fp);
  fp = fopen(pszFullname, "rb+");
  if (fp == NULL) {
    free(pszFullname);
    return NULL;
  }
  /* Create the info structure. */
  psDBF = (DBFHandle)malloc(sizeof(DBFInfo));
  psDBF->fp = fp;
  psDBF->nRecords = 0;
  psDBF->nFields = 0;
  psDBF->nRecordLength = 1;
  psDBF->nHeaderLength = 33;
  psDBF->panFieldOffset = NULL;
  psDBF->panFieldSize = NULL;
  psDBF->panFieldDecimals = NULL;
  psDBF->pachFieldType = NULL;
  psDBF->pszHeader = NULL;
  psDBF->nCurrentRecord = -1;
  psDBF->bCurrentRecordModified = FALSE;
  psDBF->pszCurrentRecord = NULL;
  psDBF->bNoHeader = TRUE;
  psDBF->filename = (char *)malloc(sizeof(char));  /* 0.32.4, 2.1.6 fix: just malloc, to be freed later in xbase.new via DBFClose */
  psDBF->pszCodePage = (char *)malloc(sizeof(char));  /* 2.1.6, just malloc, to be freed later in xbase.new via DBFClose */
  psDBF->iLanguageDriver = 0x00;
  free(pszFullname);
  return psDBF;
}


#define isNumber(t) (strcmp((t), "number") == 0 || strcmp((t), "Number") == 0 ||    strcmp((t), "N") == 0)
#define isFloat(t)  (strcmp((t), "float") == 0  || strcmp((t), "Float") == 0 ||     strcmp((t), "F") == 0)
#define isChar(t)   (strcmp((t), "string") == 0 || strcmp((t), "Character") == 0 || strcmp((t), "C") == 0)
#define isDate(t)   (strcmp((t), "date") == 0   || strcmp((t), "Date") == 0 ||      strcmp((t), "D") == 0)
#define isDouble(t) (strcmp((t), "double") == 0 || strcmp((t), "Double") == 0 ||    strcmp((t), "O") == 0)

static int xbase_new (lua_State *L) {
  const char *fn, *fieldname, *typename;
  int i, n, nargs, pop;
  DBFHandle hnd;
  fn = luaL_checkstring(L, 1);
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  hnd = DBFCreate(fn);
  if (nargs < 2)
    luaL_error(L, "Error in " LUA_QS ": need at least one field.", "xbase.new", fn);
  if (hnd == NULL)
    luaL_error(L, "Error in " LUA_QS ": creating " LUA_QS " failed.", "xbase.new", fn);
  hnd->dBaseVersion = 0x03;
  for (i=2; i <= nargs; i++) {
    pop = 3;
    if (!lua_ispair(L, i))
      luaL_error(L, "Error in " LUA_QS ": pair expected for argument #%d.", "xbase.new", i);
    agn_pairgeti(L, i, 1);  /* get lhs */
    if (lua_type(L, -1) != LUA_TSTRING)
      luaL_error(L, "Error in " LUA_QS ": left-hand side of pair must be a string.", "xbase.new");
    fieldname = agn_tostring(L, -1);
    if (strcmp(fieldname, "codepage") == 0) {
      int codepage;
      if (nargs == 2)
        luaL_error(L, "Error in " LUA_QS ": at least one field expected.", "xbase.new");
      agn_pairgeti(L, i, 2);  /* get rhs */
      if (lua_type(L, -1) != LUA_TNUMBER)
        luaL_error(L, "Error in " LUA_QS ": number for codepage expected.", "xbase.new");
      codepage = agn_tonumber(L, -1);
      if (codepage < 0 || codepage > 255)
        luaL_error(L, "Error in " LUA_QS ": codepage must be in [0, 255].", "xbase.new");
      hnd->iLanguageDriver = codepage;
      agn_poptoptwo(L);
      continue;
    }
    agn_pairgeti(L, i, 2);  /* get rhs */
    if (lua_ispair(L, -1)) {
      agn_pairgeti(L, -1, 1);  /* get lhs (2nd pair) */
      if (lua_type(L, -1) != LUA_TSTRING)
        luaL_error(L, "Error in " LUA_QS ": left-hand side of second pair must be a string.", "xbase.new");
      typename = agn_tostring(L, -1);
      agn_pairgeti(L, -2, 2);  /* get rhs (2nd pair) */
      if (lua_type(L, -1) != LUA_TNUMBER)
        luaL_error(L, "Error in " LUA_QS ": right-hand side of second pair must be a number.", "xbase.new");
      n = (int)agn_tonumber(L, -1);
      agn_poptop(L);  /* pop rhs of 2nd pair */
    } else if (lua_type(L, -1) == LUA_TSTRING) {
      typename = agn_tostring(L, -1);
      if (isNumber(typename))
        n = 15;  /* scale = number of digits following the decimal point */
      else if (isFloat(typename))
        n = 18;  /* scale = number of digits following the decimal point */
      else if (isChar(typename))
        n = 64;
      else if (isDate(typename))
        n = 8;  /* 2.1.6 */
      else if (isDouble(typename))
        n = 8;  /* 2.2.0 RC 3 */
      else n = 1;  /* Logical value */
      pop = 2;
    } else {
      typename = NULL; n = 0; /* to avoid compiler warnings */
      luaL_error(L, "Error in " LUA_QS ": right-hand side of pair must be a string or a pair.", "xbase.new");
    }
    if (isChar(typename)) {
      if (n < 1 || n > 254)
        luaL_error(L, "Error in " LUA_QS ": string size not in [1, 254].", "xbase.new");
      if (DBFAddField(hnd, fieldname, FTString, n, 0) == -1)
        luaL_error(L, "Error in " LUA_QS ": adding Character field to " LUA_QS " failed.", "xbase.new", fn);
      lua_pop(L, pop);
    } else if (isNumber(typename)) {
      if (n < 0 || n > 15)
        luaL_error(L, "Error in " LUA_QS ": scale not in [0, 15].", "xbase.new");
      if (DBFAddField(hnd, fieldname, FTDouble, 19, n) == -1)
        luaL_error(L, "Error in " LUA_QS ": adding Number field to " LUA_QS " failed.", "xbase.new", fn);
      lua_pop(L, pop);
    } else if (isFloat(typename)) {
      if (n < 0 || n > 18)
        luaL_error(L, "Error in " LUA_QS ": scale not in [0, 18].", "xbase.new");
      if (DBFAddField(hnd, fieldname, FTFloat, 20, n) == -1)
        luaL_error(L, "Error in " LUA_QS ": adding Float field to " LUA_QS " failed.", "xbase.new", fn);
      lua_pop(L, pop);
    } else if (strcmp(typename, "boolean") == 0 || strcmp(typename, "Logical") == 0 || strcmp(typename, "L") == 0) {  /* 2.2.0 RC 3 */
      if (DBFAddField(hnd, fieldname, FTLogical, 1, 0) == -1)
        luaL_error(L, "Error in " LUA_QS ": adding Logical field to " LUA_QS " failed.", "xbase.new", fn);
      lua_pop(L, pop);
    } else if (isDate(typename)) {
      if (DBFAddField(hnd, fieldname, FTDate, 8, 0) == -1)
        luaL_error(L, "Error in " LUA_QS ": adding Date field to " LUA_QS " failed.", "xbase.new", fn);
      lua_pop(L, pop);
    } else if (isDouble(typename)) {
      if (sizeof(uint64_t) != 8 || sizeof(lua_Number) != 8)
        luaL_error(L, "Error in " LUA_QS ": cannot represent binary Double field in " LUA_QS " .", "xbase.new", fn);
      if (DBFAddField(hnd, fieldname, FTBinDouble, 8, 0) == -1)
        luaL_error(L, "Error in " LUA_QS ": adding double field to " LUA_QS " failed.", "xbase.new", fn);
      lua_pop(L, pop);
    } else
      luaL_error(L, "Error in " LUA_QS ": unknown field type " LUA_QS " to be added to " LUA_QS ".",
        "xbase.new", typename, fn);
  }
  DBFClose(hnd);
  lua_pushnil(L);
  return 1;
}

/************************************************************************/
/*                            DBFAddField()                             */
/*                                                                      */
/*      Add a field to a newly created .dbf file before any records     */
/*      are written.                                                    */
/************************************************************************/

int SHPAPI_CALL DBFAddField (DBFHandle psDBF, const char *pszFieldName,
            DBFFieldType eType, int nWidth, int nDecimals) {
  char *pszFInfo;
  int i;
  /* Do some checking to ensure we can add records to this file. */
  if (psDBF->nRecords > 0)
    return -1;
  if (!psDBF->bNoHeader)
    return -1;
  if ((eType != FTDouble && eType != FTFloat) && nDecimals != 0)  /* 2.1.6 */
    return -1;
  if (nWidth < 1)
    return -1;
  /* SfRealloc all the arrays larger to hold the additional field information. */
  psDBF->nFields++;
  psDBF->panFieldOffset = (int *)
    SfRealloc(psDBF->panFieldOffset, sizeof(int) * psDBF->nFields);
  psDBF->panFieldSize = (int *)
    SfRealloc(psDBF->panFieldSize, sizeof(int) * psDBF->nFields);
  psDBF->panFieldDecimals = (int *)
    SfRealloc(psDBF->panFieldDecimals, sizeof(int) * psDBF->nFields);
  psDBF->pachFieldType = (char *)
    SfRealloc(psDBF->pachFieldType, sizeof(char) * psDBF->nFields);
  /* Assign the new field information fields. */
  psDBF->panFieldOffset[psDBF->nFields-1] = psDBF->nRecordLength;
  psDBF->nRecordLength += nWidth;
  psDBF->panFieldSize[psDBF->nFields-1] = nWidth;
  psDBF->panFieldDecimals[psDBF->nFields-1] = nDecimals;
  if (eType == FTLogical)
    psDBF->pachFieldType[psDBF->nFields-1] = 'L';
  else if (eType == FTString)
    psDBF->pachFieldType[psDBF->nFields-1] = 'C';
  /* else if (eType == FTInteger)
    psDBF->pachFieldType[psDBF->nFields-1] = 'I'; */
  else if (eType == FTFloat)
    psDBF->pachFieldType[psDBF->nFields-1] = 'F';  /* 2.1.6 */
  else if (eType == FTBinDouble)
    psDBF->pachFieldType[psDBF->nFields-1] = 'O';  /* 2.2.0 RC 3 */
  else if (eType == FTDate)
    psDBF->pachFieldType[psDBF->nFields-1] = 'D';  /* 2.1.6 */
  else
    psDBF->pachFieldType[psDBF->nFields-1] = 'N';
  /* Extend the required header information. */
  psDBF->nHeaderLength += 32;
  psDBF->bUpdated = FALSE;
  psDBF->pszHeader = (char *)SfRealloc(psDBF->pszHeader, psDBF->nFields*32);
  pszFInfo = psDBF->pszHeader + 32 * (psDBF->nFields-1);
  for (i = 0; i < 32; i++)
    pszFInfo[i] = '\0';
  if ((int) strlen(pszFieldName) < 10)
    strncpy(pszFInfo, pszFieldName, strlen(pszFieldName));
  else
    strncpy(pszFInfo, pszFieldName, 10);
  pszFInfo[11] = psDBF->pachFieldType[psDBF->nFields-1];
  if (eType == FTString) {
    pszFInfo[16] = nWidth % 256;
    pszFInfo[17] = nWidth / 256;
  } else {
    pszFInfo[16] = nWidth;
    pszFInfo[17] = nDecimals;
  }
  /* Make the current record buffer appropriately larger. */
  psDBF->pszCurrentRecord =
    (char *)SfRealloc(psDBF->pszCurrentRecord, psDBF->nRecordLength);
  return psDBF->nFields-1;
}

/************************************************************************/
/*                          DBFReadAttribute()                          */
/*                                                                      */
/*      Read one of the attribute fields of a record.                   */
/************************************************************************/

static void *DBFReadAttribute (DBFHandle psDBF, int hEntity, int iField, char chReqType, char *iofailure, char *ismarked) {  /* extended 2.2.0 RC 2 */
  int	nRecordOffset;
  unsigned char *pabyRec;
  void *pReturnField = NULL;
  static double dDoubleField;
  *ismarked = *iofailure = 0;
  /* Verify selection. */
  if (hEntity < 0 || hEntity >= psDBF->nRecords) return NULL;
  if (iField < 0 || iField >= psDBF->nFields) return NULL;
  /* Have we read the record ? */
  if (psDBF->nCurrentRecord != hEntity) {
    int i;
    DBFFlushRecord(psDBF);
    nRecordOffset = psDBF->nRecordLength * hEntity + psDBF->nHeaderLength;
    if (_fseeki64(psDBF->fp, nRecordOffset, 0) != 0) {
      fprintf(stderr, "Error in " LUA_QS ": _fseeki64(%d) failed on DBF file.\n",
                      "xbase", nRecordOffset);
      *iofailure = 1;
      return NULL;
    }
    /* make sure that the entire record is read, including embedded 0's that may be part of a
       binary Double, 2.2.0 RC 3 */
    for (i=0; i < psDBF->nRecordLength; i++) {
      if (fread(psDBF->pszCurrentRecord++, 1, 1, psDBF->fp) != 1) {
        fprintf(stderr, "Error in " LUA_QS ": fread(%d) failed on DBF file.\n",
          "xbase", psDBF->nRecordLength);
        *iofailure = 1;
        return NULL;
      }
    }
    psDBF->pszCurrentRecord -= psDBF->nRecordLength;
    /* if (fread(psDBF->pszCurrentRecord, psDBF->nRecordLength, 1, psDBF->fp) != 1) {
      fprintf(stderr, "Error in " LUA_QS ": fread(%d) failed on DBF file.\n",
                      "xbase", psDBF->nRecordLength);
      *iofailure = 1;
      return NULL;
    } */
    psDBF->nCurrentRecord = hEntity;
  }
  pabyRec = (unsigned char *) psDBF->pszCurrentRecord;
  if (*pabyRec == '*') *ismarked = 1;  /* record has been marked as deleted ?  Return it anyway. 2.2.0 RC 2 */
  /* Ensure our field buffer is large enough to hold this buffer. */
  if (psDBF->panFieldSize[iField]+1 > nStringFieldLen) {
    nStringFieldLen = psDBF->panFieldSize[iField]*2 + 10;
    pszStringField = (char *)SfRealloc(pszStringField, nStringFieldLen);
  }
  /* Extract the requested field. */
  /* strncpy(pszStringField,
    ((const char *)pabyRec) + psDBF->panFieldOffset[iField],
    psDBF->panFieldSize[iField]); */
  memcpy(pszStringField,  /* copy the entire record including embedded 0's that may constiture a binary Double, 2.2.0 RC 3*/
    ((const char *)pabyRec) + psDBF->panFieldOffset[iField],
    psDBF->panFieldSize[iField]);
  pszStringField[psDBF->panFieldSize[iField]] = '\0';
  pReturnField = pszStringField;
  /* Decode the field. */
  if (chReqType == 'N' || chReqType == 'F') {  /* 2.1.6 */
    dDoubleField = atof(pszStringField);
    pReturnField = &dDoubleField;
  } else if (chReqType == 'O') {  /* 2.2.0 RC 3 */
    uint64_t ulong;
    if (pszStringField[0] == '*') {  /* NULL ? */
      dDoubleField = 0;
      pReturnField = &dDoubleField;
    } else {
      memcpy(&ulong, pszStringField, sizeof(uint64_t));
      dDoubleField = tools_uint2double(ulong);
      pReturnField = &dDoubleField;
    }
  }
  /* Should we trim white space off the string attribute value ? */
#ifdef TRIM_DBF_WHITESPACE
  else {
    char *pchSrc, *pchDst;
    pchDst = pchSrc = pszStringField;
    while (*pchSrc == ' ') pchSrc++;
    while (*pchSrc != '\0') *(pchDst++) = *(pchSrc++);
    *pchDst = '\0';
    while( pchDst != pszStringField && *(--pchDst) == ' ') *pchDst = '\0';
  }
#endif
  return pReturnField;
}


/************************************************************************/
/*                        DBFReadDoubleAttribute()                      */
/*                                                                      */
/*      Read a double attribute.                                        */
/************************************************************************/

/* failure parameter added for Agena binding 0.32.4, 06.06.2010 */

double SHPAPI_CALL DBFReadDoubleAttribute (DBFHandle psDBF, int iRecord, int iField, char *iofailure, char *ismarked) {
  double *pdValue;
  pdValue = (double *)DBFReadAttribute(psDBF, iRecord, iField, 'N', iofailure, ismarked);
  if (pdValue == NULL)
    return 0.0;
  else
    return *pdValue;
}


double SHPAPI_CALL DBFReadFloatAttribute (DBFHandle psDBF, int iRecord, int iField, char *iofailure, char *ismarked) {  /* 2.1.6 */
  double *pdValue;
  pdValue = (double *)DBFReadAttribute(psDBF, iRecord, iField, 'F', iofailure, ismarked);
  if (pdValue == NULL)
    return 0.0;
  else
    return *pdValue;
}


double SHPAPI_CALL DBFReadBinDoubleAttribute (DBFHandle psDBF, int iRecord, int iField,
    char *iofailure, char *ismarked) {  /* 2.2.0 RC 3 */
  double *pdValue;
  pdValue = (double *)DBFReadAttribute(psDBF, iRecord, iField, 'O', iofailure, ismarked);
  if (pdValue == NULL)
    return 0.0;
  else
    return *pdValue;
}

/************************************************************************/
/*                        DBFReadStringAttribute()                      */
/*                                                                      */
/*      Read a string attribute.                                        */
/************************************************************************/

const char SHPAPI_CALL1(*)
DBFReadStringAttribute (DBFHandle psDBF, int iRecord, int iField, char *iofailure, char *ismarked) {
  return((const char *) DBFReadAttribute(psDBF, iRecord, iField, 'C', iofailure, ismarked));
}

/************************************************************************/
/*                        DBFReadStringAttribute()                      */
/*                                                                      */
/*      Read a string attribute.                                        */
/*                                                                      */
/* Agena 2.1.6                                                          */
/************************************************************************/

const char SHPAPI_CALL1(*) DBFReadDateAttribute (DBFHandle psDBF, int iRecord, int iField, char *iofailure, char *ismarked) {
  return((const char *) DBFReadAttribute(psDBF, iRecord, iField, 'D', iofailure, ismarked));
}

/************************************************************************/
/*                        DBFReadLogicalAttribute()                     */
/*                                                                      */
/*      Read a logical attribute.                                       */
/************************************************************************/

const char SHPAPI_CALL1(*)
DBFReadLogicalAttribute (DBFHandle psDBF, int iRecord, int iField, char *iofailure, char *ismarked) {
  return((const char *)DBFReadAttribute(psDBF, iRecord, iField, 'L', iofailure, ismarked));
}


static int xbase_readvalue (lua_State *L) {
  DBFHandle *hnd;
  int record, field, maxrecords, maxfields, fieldinfo;
  char iofailure, ismarked;
  record = agnL_checkinteger(L, 2);
  field = agnL_checkinteger(L, 3);
  hnd = aux_gethandle(L, 1, "xbase.readvalue");
  maxrecords = DBFGetRecordCount(*hnd);
  maxfields = DBFGetFieldCount(*hnd);
  if (maxrecords == 0 || maxfields == 0)
    luaL_error(L, "Error in " LUA_QS ": database is empty.", "xbase.readvalue");
  if (record < 1 || record > maxrecords)
    luaL_error(L, "Error in " LUA_QS ": record does not exist.", "xbase.readvalue");
  if (field < 1 || field > maxfields)
    luaL_error(L, "Error in " LUA_QS ": field does not exist.", "xbase.readvalue");
  field--; record--;
  fieldinfo = DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL);
  switch (fieldinfo) {
    case FTString: {
      const char *result;
      result = DBFReadStringAttribute(*hnd, record, field, &iofailure, &ismarked);
      if (result == NULL)
        luaL_error(L, "Error in " LUA_QS ": no string stored in database.", "xbase.readvalue");
      else if (iofailure)
        luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readvalue");
      else if (ismarked)
        lua_pushnil(L);
      else
        lua_pushstring(L, result);
      break;
    }
    case FTDouble: {
      lua_Number result;
      result = DBFReadDoubleAttribute(*hnd, record, field, &iofailure, &ismarked);  /* 2.2.0 RC 2 */
      if (iofailure)
        luaL_error(L, "Error in " LUA_QS ": could not read number in database.", "xbase.readvalue");
      else if (ismarked)
        lua_pushnil(L);
      else
        lua_pushnumber(L, result);
      break;
    }
    case FTFloat: {
      lua_Number result;
      result = DBFReadFloatAttribute(*hnd, record, field, &iofailure, &ismarked);
      if (iofailure)
        luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readvalue");
      else if (ismarked)
        lua_pushnil(L);
      else
        lua_pushnumber(L, result);
      break;
    }
    case FTBinDouble: {
      lua_Number result;
      result = DBFReadBinDoubleAttribute(*hnd, record, field, &iofailure, &ismarked);
      if (iofailure)
        luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readvalue");
      else if (ismarked)
        lua_pushnil(L);
      else
        lua_pushnumber(L, result);
      break;
    }
    case FTDate: {
      const char *result;
      result = DBFReadStringAttribute(*hnd, record, field, &iofailure, &ismarked);
      if (result == NULL)
        luaL_error(L, "Error in " LUA_QS ": no date stored in database.", "xbase.readvalue");
      else if (iofailure)
        luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readvalue");
      else if (ismarked)
        lua_pushnil(L);
      else
        lua_pushstring(L, result);
      break;
    }
    case FTLogical: {
      const char *result;
      result = DBFReadLogicalAttribute(*hnd, record, field, &iofailure, &ismarked);
      if (result == NULL)
        luaL_error(L, "Error in " LUA_QS ": no logical value stored in database.", "xbase.readvalue");
      else if (iofailure)
        luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.readvalue");
      else if (ismarked)
        lua_pushnil(L);
      else {
        switch (*result) {
          case 'Y': case 'y': case 'T': case 't':
            lua_pushtrue(L);
            break;
          case 'N': case 'n': case 'F': case 'f':
            lua_pushfalse(L);
            break;
          default:
            lua_pushfail(L);
        }
      }
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": unknown type of data.", "xbase.readvalue");
  }
  return 1;
}

/************************************************************************/
/*                         DBFIsAttributeNULL()                         */
/*                                                                      */
/*      Return TRUE if value for field is NULL.                         */
/*                                                                      */
/*      Contributed by Jim Matthews.                                    */
/************************************************************************/

int SHPAPI_CALL DBFIsAttributeNULL (DBFHandle psDBF, int iRecord, int iField) {
  const char *pszValue;
  char iofailure, ismarked;
  pszValue = DBFReadStringAttribute(psDBF, iRecord, iField, &iofailure, &ismarked);
  switch(psDBF->pachFieldType[iField]) {
    case 'N':
    case 'F':
    case 'O':  /* 2.2.0 RC 3 */
      /* NULL numeric fields have value "****************" */
      return pszValue[0] == '*';
    case 'D':
      /* NULL date fields have value "00000000" */
      return strncmp(pszValue, "00000000", 8) == 0;
    case 'L':
      /* NULL boolean fields have value "?" */
      return pszValue[0] == '?';
    default:
      /* empty string fields are considered NULL */
      return strlen(pszValue) == 0;
  }
}


static int xbase_isvoid (lua_State *L) {
  DBFHandle *hnd;
  int record, field, maxrecords, maxfields;
  record = agnL_checkinteger(L, 2);
  field = agnL_checkinteger(L, 3);
  hnd = aux_gethandle(L, 1, "xbase.isvoid");
  maxrecords = DBFGetRecordCount(*hnd);
  maxfields = DBFGetFieldCount(*hnd);
  if (maxrecords == 0 || maxfields == 0)
    luaL_error(L, "Error in " LUA_QS ": database is empty.", "xbase.isvoid");
  if (record < 1 || record > maxrecords)
    luaL_error(L, "Error in " LUA_QS ": record does not exist.", "xbase.isvoid");
  if (field < 1 || field > maxfields)
    luaL_error(L, "Error in " LUA_QS ": field does not exist.", "xbase.isvoid");
  lua_pushboolean(L, DBFIsAttributeNULL(*hnd, --record, --field));
  return 1;
}

/************************************************************************/
/*                          DBFGetFieldCount()                          */
/*                                                                      */
/*      Return the number of fields in this table.                      */
/************************************************************************/

int SHPAPI_CALL DBFGetFieldCount (DBFHandle psDBF) {
  return(psDBF->nFields);
}

/************************************************************************/
/*                       DBFGetNativeFieldType()                        */
/*                                                                      */
/*      Return the DBase field type for the specified field.            */
/*                                                                      */
/*      Value can be one of: 'C' (String), 'D' (Date), 'F' (Float),     */
/*                           'N' (Numeric, with or without decimal),    */
/*                           'L' (Logical),                             */
/*                           'M' (Memo: 10 digits .DBT block ptr)       */
/************************************************************************/

char SHPAPI_CALL DBFGetNativeFieldType (DBFHandle psDBF, int iField) {
  if (iField >=0 && iField < psDBF->nFields)
    return psDBF->pachFieldType[iField];
  return ' ';
}

/************************************************************************/
/*                         DBFGetRecordCount()                          */
/*                                                                      */
/*      Return the number of records in this table.                     */
/************************************************************************/

int SHPAPI_CALL DBFGetRecordCount (DBFHandle psDBF) {
  return(psDBF->nRecords);
}

/* assumes that table is on the top of the stack */

static void setintegerfield (lua_State *L, const char *key, int value) {
  lua_pushinteger(L, value);
  lua_setfield(L, -2, key);
}

/* assumes that table is on the top of the stack */

static void setstringfield (lua_State *L, const char *key, const char *value) {
  lua_pushstring(L, value);
  lua_setfield(L, -2, key);
}

/*
Code pages supported by dBASE III and Visual FoxPro

from: http://www.clicketyclick.dk/databases/xbase/format/dbf.html#DBF_NOTE_5_TARGET (dBASE III) and
      http://msdn.microsoft.com/en-us/library/8t45x02s%28v=vs.80%29.aspx  (Visual FoxPro)

(Foxpro) Code pages: These values follow the DOS / Windows Code Page values.
Value 	Description 	Code page
01h 	DOS USA	code page 437
02h 	DOS Multilingual (International MS-DOS)	code page 850
03h 	Windows ANSI	code page 1252
04h 	Standard Macintosh  code page 10000
64h 	EE MS-DOS (Eastern European MS-DOS)	code page 852
65h 	Nordic MS-DOS	code page 865
66h 	Russian MS-DOS	code page 866
67h 	Icelandic MS-DOS  code page 861
68h 	Kamenicky (Czech) MS-DOS  code page 895
69h 	Mazovia (Polish) MS-DOS   code page 620
6Ah 	Greek MS-DOS (437G)
6Bh 	Turkish MS-DOS  code page 857
78h     Traditional Chinese (Hong Kong SAR, Taiwan) Windows  code page 950
79h     Korean Windows  code page 949
7Ah     Chinese Simplified (PRC, Singapore) Windows  code page 936
7Bh     Japanese Windows  code page 932
7Ch     Thai Windows  code page 874
7Dh     Hebrew Windows  code page 1255
7Eh     Arabic Windows   code page 1256
96h 	Russian Macintosh  code page 10007
97h 	Eastern European Macintosh  code page 10029
98h 	Greek Macintosh  code page 10006
C8h 	Windows EE	(Eastern European Windows) code page 1250
C9h 	Russian Windows  code page 1251
CAh 	Turkish Windows  code page 1254
CBh 	Greek Windows  code page 1253
*/

static int xbase_attrib (lua_State *L) {
  DBFHandle *hnd;
  DBFInfo dbf;
  int i, nfields;
  char szTitle[12];
  unsigned char s[2];
  hnd = aux_gethandle(L, 1, "xbase.attrib");
  dbf = **hnd;
  lua_createtable(L, 0, 9);
  setstringfield(L, "filename", dbf.filename);
  nfields = DBFGetFieldCount(*hnd);
  setintegerfield(L, "fields", nfields);
  setintegerfield(L, "records", DBFGetRecordCount(*hnd));
  setintegerfield(L, "headerlength", dbf.nHeaderLength);
  setintegerfield(L, "recordlength", dbf.nRecordLength);
  setintegerfield(L, "lastmodified", dbf.lastmodified);
  setstringfield(L, "codepage", dbf.pszCodePage);  /* changed 2.1.6 */
  setintegerfield(L, "languagedriver", dbf.iLanguageDriver);  /* changed 2.1.6 */
  lua_pushstring(L, "fieldinfo");
  lua_newtable(L);
  lua_settable(L, -3);
  for (i=0; i < nfields; i++) {
    DBFFieldType eType;
    const char *pszTypeName = NULL;
    int nWidth = 0, nDecimals = 0;
    eType = DBFGetFieldInfo(*hnd, i, szTitle, &nWidth, &nDecimals);
    if (eType == FTString || eType == FTDate)  /* 2.1.7 fix */
      pszTypeName = "string";
    else if (eType == FTDouble || eType == FTFloat || eType == FTBinDouble)  /* 2.1.7 fix / 2.2.0 RC 3 */
      pszTypeName = "number";
    else if (eType == FTLogical)
      pszTypeName = "boolean";
    else if (eType == FTInvalid)
      pszTypeName = "unknown";
    lua_getfield(L, -1, "fieldinfo");
    lua_pushinteger(L, i+1);
    lua_createtable(L, 0, 4);
    setstringfield(L, "type", pszTypeName);
    s[0] = DBFGetNativeFieldType(*hnd, i);
    s[1] = '\0';  /* better sure than sorry */
    setstringfield(L, "nativetype", (const char *)s);
    setstringfield(L, "title", szTitle);
    setintegerfield(L, "width", nWidth);
    setintegerfield(L, "scale", nDecimals);
    lua_settable(L, -3);
    agn_poptop(L);
  }
  return 1;
}


static int xbase_header (lua_State *L) {  /* 2.2.0 */
  DBFHandle *hnd;
  DBFInfo dbf;
  int i, nfields;
  char szTitle[12];
  unsigned char s[2];
  hnd = aux_gethandle(L, 1, "xbase.attrib");
  dbf = **hnd;
  (void)dbf;  /* to avoid compiler warnings */
  nfields = DBFGetFieldCount(*hnd);
  agn_createseq(L, nfields);  /* field names */
  agn_createseq(L, nfields);  /* Agena types */
  agn_createseq(L, nfields);  /* dBASE types */
  for (i=0; i < nfields; i++) {
    DBFFieldType eType;
    const char *pszTypeName = NULL;
    int nWidth = 0, nDecimals = 0;
    eType = DBFGetFieldInfo(*hnd, i, szTitle, &nWidth, &nDecimals);
    if (eType == FTString || eType == FTDate)
      pszTypeName = "string";
    else if (eType == FTDouble || eType == FTFloat || eType == FTBinDouble)
      pszTypeName = "number";
    else if (eType == FTLogical)
      pszTypeName = "boolean";
    else if (eType == FTInvalid)
      pszTypeName = "unknown";
    lua_seqsetistring(L, -3, i+1, szTitle);
    lua_seqsetistring(L, -2, i+1, pszTypeName);
    s[0] = DBFGetNativeFieldType(*hnd, i);
    s[1] = '\0';  /* better sure than sorry */
    lua_seqsetistring(L, -1, i+1, (const char *)s);
  }
  return 3;
}


/************************************************************************/
/*                          DBFGetFieldInfo()                           */
/*                                                                      */
/*      Return any requested information about the field.               */
/************************************************************************/

DBFFieldType SHPAPI_CALL
DBFGetFieldInfo (DBFHandle psDBF, int iField, char * pszFieldName,
                 int * pnWidth, int * pnDecimals) {
  if (iField < 0 || iField >= psDBF->nFields) return(FTInvalid);
  if (pnWidth != NULL) *pnWidth = psDBF->panFieldSize[iField];
  if (pnDecimals != NULL) *pnDecimals = psDBF->panFieldDecimals[iField];
  if (pszFieldName != NULL) {
    int i;
    strncpy(pszFieldName, (char *) psDBF->pszHeader+iField*32, 11);
    pszFieldName[11] = '\0';
    for (i=10; i > 0 && pszFieldName[i] == ' '; i--) pszFieldName[i] = '\0';
  }
  if (psDBF->pachFieldType[iField] == 'L') return FTLogical;
  else if (psDBF->pachFieldType[iField] == 'D') return FTDate;  /* 2.1.6 */
  else if (psDBF->pachFieldType[iField] == 'N') return FTDouble;
  else if (psDBF->pachFieldType[iField] == 'F') return FTFloat;
  else if (psDBF->pachFieldType[iField] == 'O') return FTBinDouble;  /* 2.2.0 RC 3 */
  else return FTString;
}

/************************************************************************/
/*                         DBFWriteAttribute()                          */
/*									                                    */
/*	Write an attribute record to the file.				                */
/************************************************************************/

static int DBFWriteAttribute (DBFHandle psDBF, int hEntity, int iField, void * pValue) {
  int nRecordOffset, i, j, nRetResult = TRUE;
  unsigned char *pabyRec;
  char szSField[400], szFormat[20];
  /* Is this a valid record ? */
  if (hEntity < 0 || hEntity > psDBF->nRecords || hEntity == INT_MAX)  /* INT_MAX check added 0.32.4 */
    return FALSE;
  if (psDBF->bNoHeader) DBFWriteHeader(psDBF);
  /* Is this a brand new record ? */
  if (hEntity == psDBF->nRecords) {
    DBFFlushRecord(psDBF);
    psDBF->nRecords++;
    for (i = 0; i < psDBF->nRecordLength; i++)
      psDBF->pszCurrentRecord[i] = ' ';
    psDBF->nCurrentRecord = hEntity;
  }
  /* Is this an existing record, but different than the last one we accessed ? */
  if (psDBF->nCurrentRecord != hEntity) {
    DBFFlushRecord(psDBF);
    nRecordOffset = psDBF->nRecordLength * hEntity + psDBF->nHeaderLength;
    _fseeki64(psDBF->fp, nRecordOffset, 0);
    fread(psDBF->pszCurrentRecord, psDBF->nRecordLength, 1, psDBF->fp);
    psDBF->nCurrentRecord = hEntity;
  }
  pabyRec = (unsigned char *)psDBF->pszCurrentRecord;
  psDBF->bCurrentRecordModified = TRUE;
  psDBF->bUpdated = TRUE;
  /* Translate NULL value to valid DBF file representation. Contributed by Jim Matthews. */
  if (pValue == NULL) {
    switch(psDBF->pachFieldType[iField]) {
      case 'N':
      case 'F':
      case 'O':  /* 2.2.0 RC 3 */
        /* NULL numeric fields have value "****************" */
        memset((char *)(pabyRec+psDBF->panFieldOffset[iField]), '*',
                    psDBF->panFieldSize[iField]);
        break;
      case 'D':
        /* NULL date fields have value "00000000" */
        memset((char *)(pabyRec+psDBF->panFieldOffset[iField]), '0',
                    psDBF->panFieldSize[iField]);
        break;
      case 'L':
        /* NULL boolean fields have value "?" */
        memset((char *)(pabyRec+psDBF->panFieldOffset[iField]), '?',
                    psDBF->panFieldSize[iField]);
        break;
      default:
        /* empty string fields are considered NULL */
        memset((char *)(pabyRec+psDBF->panFieldOffset[iField]), '\0',
                    psDBF->panFieldSize[iField]);
        break;
    }
    return TRUE;
  }
  /* Assign all the record fields. */
  switch (psDBF->pachFieldType[iField]) {
    case 'N':
    case 'F':
      if (psDBF->panFieldDecimals[iField] == 0) {  /* integer ? */
        int	nWidth = psDBF->panFieldSize[iField];
        if (sizeof(szSField) - 2 < nWidth)
          nWidth = sizeof(szSField) - 2;
        sprintf(szFormat, "%%%dd", nWidth);
        sprintf(szSField, szFormat, (int) *((double *) pValue));
        if ((int)strlen(szSField) > psDBF->panFieldSize[iField]) {
          szSField[psDBF->panFieldSize[iField]] = '\0';
          nRetResult = FALSE;
        }
        strncpy((char *)(pabyRec+psDBF->panFieldOffset[iField]),
          szSField, strlen(szSField));
      } else {
        int nWidth = psDBF->panFieldSize[iField];
        if (sizeof(szSField) - 2 < nWidth)
          nWidth = sizeof(szSField) - 2;
        sprintf(szFormat, "%%%d.%df",
          nWidth, psDBF->panFieldDecimals[iField]);
        sprintf(szSField, szFormat, *((double *)pValue));
        if ((int) strlen(szSField) > psDBF->panFieldSize[iField]) {
          szSField[psDBF->panFieldSize[iField]] = '\0';
          nRetResult = FALSE;
        }
        strncpy((char *)(pabyRec+psDBF->panFieldOffset[iField]),
          szSField, strlen(szSField));
      }
      break;
    case 'O': { /* 2.2.0 RC 3 */
      uint64_t ulong;
      int nWidth = psDBF->panFieldSize[iField];
      if (sizeof(szSField) - 2 < nWidth)
        nWidth = sizeof(szSField) - 2;
      ulong = tools_double2uint(*((double *)pValue));
      memcpy(pabyRec+psDBF->panFieldOffset[iField], &ulong, sizeof(uint64_t));
      /*if ((int)strlen(szSField) > psDBF->panFieldSize[iField]) {
        szSField[psDBF->panFieldSize[iField]] = '\0';
        nRetResult = FALSE;
      }
      strncpy((char *)(pabyRec+psDBF->panFieldOffset[iField]),
        szSField, nWidth);*/
      break;
    }
    case 'L':
      if (psDBF->panFieldSize[iField] >= 1  &&
        (*(char*)pValue == 'F' || *(char*)pValue == 'T'))  /* 2.2.0 RC 3 */
         *(pabyRec+psDBF->panFieldOffset[iField]) = *(char*)pValue;
      break;
    default:
      if ((int) strlen((char *)pValue) > psDBF->panFieldSize[iField]) {
        j = psDBF->panFieldSize[iField];
        nRetResult = FALSE;
      } else {
        memset(pabyRec+psDBF->panFieldOffset[iField], ' ',
                    psDBF->panFieldSize[iField]);
        j = strlen((char *) pValue);
      }
      strncpy((char *)(pabyRec+psDBF->panFieldOffset[iField]), (char *)pValue, j);
      break;
  }
  return nRetResult;
}


/* helper function for write functions */
void aux_checkpositions (lua_State *L, DBFHandle hnd, int *record, int *field, int checkempty, const char *procname) {
  int actrecords, actfields;
  actrecords = DBFGetRecordCount(hnd);
  actfields = DBFGetFieldCount(hnd);
  *record = agnL_checkinteger(L, 2) - 1;
  if (actfields == 0 || (checkempty && actrecords == 0))
    luaL_error(L, "Error in " LUA_QS ": database is empty.", procname);
  if (*record < 0 || *record > actrecords)
    luaL_error(L, "Error in " LUA_QS ": invalid record given, must be in [1, %d].", procname, actrecords+1);
  *field = agnL_checkinteger(L, 3) - 1;
  if (*field < 0 || *field >= actfields)
    luaL_error(L, "Error in " LUA_QS ": invalid field given, must be in [1, %d].", procname, actfields);
}

/************************************************************************/
/*                      DBFWriteDoubleAttribute()                       */
/*                                                                      */
/*      Write a double attribute.                                       */
/************************************************************************/

int SHPAPI_CALL DBFWriteDoubleAttribute (DBFHandle psDBF, int iRecord, int iField, double dValue) {
  return DBFWriteAttribute(psDBF, iRecord, iField, (void *) &dValue);
}


static int xbase_writenumber (lua_State *L) {
  DBFHandle *hnd;
  int record, field;
  lua_Number val;
  hnd = aux_gethandle(L, 1, "xbase.writenumber");
  aux_checkpositions(L, *hnd, &record, &field, 0, "xbase.writenumber");
  val = agnL_checknumber(L, 4);
  if (DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL) == FTDouble)
    lua_pushboolean(L, DBFWriteDoubleAttribute(*hnd, record, field, val));
  else
    luaL_error(L, "Error in " LUA_QS ": number expected.", "xbase.writenumber");
  return 1;
}


static int xbase_writefloat (lua_State *L) {
  DBFHandle *hnd;
  int record, field;
  lua_Number val;
  hnd = aux_gethandle(L, 1, "xbase.writefloat");
  aux_checkpositions(L, *hnd, &record, &field, 0, "xbase.writefloat");
  val = agnL_checknumber(L, 4);
  if (DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL) == FTFloat)
    lua_pushboolean(L, DBFWriteDoubleAttribute(*hnd, record, field, val));
  else
    luaL_error(L, "Error in " LUA_QS ": number expected.", "xbase.writefloat");
  return 1;
}


static int xbase_writedouble (lua_State *L) {  /* 2.2.0 RC 3 */
  DBFHandle *hnd;
  int record, field;
  lua_Number val;
  hnd = aux_gethandle(L, 1, "xbase.writedouble");
  aux_checkpositions(L, *hnd, &record, &field, 0, "xbase.writedouble");
  val = agnL_checknumber(L, 4);
  if (DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL) == FTBinDouble)
    lua_pushboolean(L, DBFWriteDoubleAttribute(*hnd, record, field, val));
  else
    luaL_error(L, "Error in " LUA_QS ": number expected.", "xbase.writedouble");
  return 1;
}


/************************************************************************/
/*                      DBFWriteStringAttribute()                       */
/*                                                                      */
/*      Write a string attribute.                                       */
/************************************************************************/

int SHPAPI_CALL DBFWriteStringAttribute (DBFHandle psDBF, int iRecord, int iField,
    const char *pszValue) {
  return DBFWriteAttribute(psDBF, iRecord, iField, (void *)pszValue);
}


static int xbase_writestring (lua_State *L) {
  DBFHandle *hnd;
  int record, field;
  const char *val;
  hnd = aux_gethandle(L, 1, "xbase.writestring");
  aux_checkpositions(L, *hnd, &record, &field, 0, "xbase.writestring");
  val = luaL_checkstring(L, 4);
  if (DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL) == FTString)
    lua_pushboolean(L, DBFWriteStringAttribute(*hnd, record, field, val));
  else
    luaL_error(L, "Error in " LUA_QS ": string value expected.", "xbase.writestring");
  return 1;
}


static int xbase_writedate (lua_State *L) {
  DBFHandle *hnd;
  int record, field, dateval;
  const char *val;
  hnd = aux_gethandle(L, 1, "xbase.writedate");
  aux_checkpositions(L, *hnd, &record, &field, 0, "xbase.writedate");
  val = luaL_checkstring(L, 4);  /* 2.8.0 patch */
  dateval = atoi(val);
  if (dateval < 19000101 || dateval > 99991231)
    luaL_error(L, "Error in " LUA_QS ": date must be an integer in [19000101, 99991231].", "xbase.writedate");
  else if (strlen(val) != 8)
    luaL_error(L, "Error in " LUA_QS ": date of the format `YYYYMMDD` expected.", "xbase.writedate");
  if (DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL) == FTDate)
    lua_pushboolean(L, DBFWriteStringAttribute(*hnd, record, field, val));
  else
    luaL_error(L, "Error in " LUA_QS ": date value expected.", "xbase.writedate");
  return 1;
}


/************************************************************************/
/*                      DBFWriteNULLAttribute()                         */
/*                                                                      */
/*      Overwrite an attribute.                                         */
/************************************************************************/

static int xbase_purge (lua_State *L) {
  DBFHandle *hnd;
  int record, field;
  hnd = aux_gethandle(L, 1, "xbase.purge");
  aux_checkpositions(L, *hnd, &record, &field, 1, "xbase.purge");
  lua_pushboolean(L, DBFWriteAttribute(*hnd, record, field, NULL));
  return 1;
}


/************************************************************************/
/*                      DBFWriteLogicalAttribute()                      */
/*                                                                      */
/*      Write a logical attribute.                                      */
/************************************************************************/

int SHPAPI_CALL DBFWriteLogicalAttribute (DBFHandle psDBF, int iRecord, int iField, const char lValue) {
  return DBFWriteAttribute(psDBF, iRecord, iField, (void *)(&lValue));
}


static int xbase_writeboolean (lua_State *L) {
  DBFHandle *hnd;
  int record, field, val;
  hnd = aux_gethandle(L, 1, "xbase.writeboolean");
  aux_checkpositions(L, *hnd, &record, &field, 0, "xbase.writeboolean");
  val = (lua_isboolean(L, 4)) ? lua_toboolean(L, 4) : -1;
  if (DBFGetFieldInfo(*hnd, field, NULL, NULL, NULL) == FTLogical) {
    switch (val) {
      case 0:
        lua_pushboolean(L, DBFWriteLogicalAttribute(*hnd, record, field, 'F'));
        break;
      case 1:
        lua_pushboolean(L, DBFWriteLogicalAttribute(*hnd, record, field, 'T'));
        break;
      default:
        luaL_error(L, "Error in " LUA_QS ": true or false as fourth argument expected.", "xbase.writeboolean");
    }
  } else
    luaL_error(L, "Error in " LUA_QS ": boolean value expected.", "xbase.writeboolean");
  return 1;
}


static int xbase_lock (lua_State *L) {  /* optimised 2.2.0 RC 2 */
  size_t nargs;
  int hnd;
  DBFHandle *ud;
  DBFInfo dbf;
  off64_t start, size;
  hnd = 0;
  ud = aux_gethandle(L, 1, "xbase.lock");
  dbf = **ud;
  hnd = fileno(dbf.fp);
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  if (nargs == 1) {  /* lock entire file (in Windows lock 2^63 bytes only) */
    start = 0;
    size = 0;
  } else {
    /* lock from current file position */
    start = my_fpos(hnd);
    size = agnL_checknumber(L, 2);
    if (size < 0) luaL_error(L, "Error in " LUA_QS ": must lock at least one byte.", "xbase.lock");
  }
  lua_pushboolean(L, my_lock(hnd, start, size) == 0);
  return 1;
}


static int xbase_unlock (lua_State *L) {  /* optimised 2.2.0 RC 2 */
  size_t nargs;
  int hnd;
  DBFHandle *ud;
  DBFInfo dbf;
  off64_t start, size;
  hnd = 0;
  ud = aux_gethandle(L, 1, "xbase.unlock");
  dbf = **ud;
  hnd = fileno(dbf.fp);
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  if (nargs == 1) {  /* lock entire file (in Windows lock 2^63 bytes only) */
    start = 0;
    size = 0;
  } else {
    /* lock from current file position */
    start = my_fpos(hnd);
    size = agnL_checknumber(L, 2);
    if (size < 0) luaL_error(L, "Error in " LUA_QS ": must lock at least one byte.", "xbase.unlock");
  }
  lua_pushboolean(L, my_unlock(hnd, start, size) == 0);
  return 1;
}


static int xbase_record (lua_State *L) {
  DBFHandle *hnd;
  int nrecords, nfields, recordno, *fieldinfo, i;
  char iofailure, ismarked;
  const char *result;
  lua_Number val;
  hnd = aux_gethandle(L, 1, "xbase.record");
  recordno = agnL_checkinteger(L, 2);
  nrecords = DBFGetRecordCount(*hnd);
  nfields = DBFGetFieldCount(*hnd);
  if (recordno < 1 || recordno > nrecords)
    luaL_error(L, "Error in " LUA_QS ": requested record is out of range.", "xbase.record");
  if (nrecords == 0 || nfields == 0)
    luaL_error(L, "Error in " LUA_QS ": database is empty.", "xbase.record");
  recordno--;
  if (DBFIsRecordDeleted(*hnd, recordno)) {
    lua_pushnil(L);
    return 1;
  }
  fieldinfo = malloc(nfields * sizeof(int));
  if (fieldinfo == NULL)
    luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "xbase.record");
  for (i=0; i < nfields; i++) {
    fieldinfo[i] = DBFGetFieldInfo(*hnd, i, NULL, NULL, NULL);
  }
  agn_createseq(L, 1);
  for (i=0; i < nfields; i++) {
    switch (fieldinfo[i]) {
      case FTString: {
        result = DBFReadStringAttribute(*hnd, recordno, i, &iofailure, &ismarked);
        if (result == NULL) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": no string value stored in database.", "xbase.record");
        } else if (iofailure) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.record");
        } else
          lua_seqsetistring(L, -1, i+1, result);
        break;
      }
      case FTDate: {
        result = DBFReadDateAttribute(*hnd, recordno, i, &iofailure, &ismarked);
        if (result == NULL) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": no date stored in database.", "xbase.record");
        } else if (iofailure) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.record");
        } else
          lua_seqsetistring(L, -1, i+1, result);
        break;
      }
      case FTDouble: {
        val = DBFReadDoubleAttribute(*hnd, recordno, i, &iofailure, &ismarked);
        if (iofailure) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.record");
        } else
          lua_seqsetinumber(L, -1, i+1, val);
        break;
      }
      case FTBinDouble: {
        val = DBFReadBinDoubleAttribute(*hnd, recordno, i, &iofailure, &ismarked);
        if (iofailure) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.record");
        } else
          lua_seqsetinumber(L, -1, i+1, val);
        break;
      }
      case FTFloat: {
        val = DBFReadFloatAttribute(*hnd, recordno, i, &iofailure, &ismarked);
        if (iofailure) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.record");
        } else
          lua_seqsetinumber(L, -1, i+1, val);
        break;
      }
      case FTLogical: {
        result = DBFReadLogicalAttribute(*hnd, recordno, i, &iofailure, &ismarked);
        if (result == NULL) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": no logical value stored in database.", "xbase.record");
        } else if (iofailure) {
          xfree(fieldinfo);
          luaL_error(L, "Error in " LUA_QS ": I/O failed.", "xbase.record");
        } else {
          switch (*result) {  /* 2.1.6 patch */
            case 'Y': case 'y': case 'T': case 't':
              lua_pushtrue(L);
              lua_seqseti(L, -2, i+1);
              break;
            case 'N': case 'n': case 'F': case 'f':
              lua_pushfalse(L);
              lua_seqseti(L, -2, i+1);
              break;
            default:
              lua_pushfail(L);
              lua_seqseti(L, -2, i+1);
          }
        }
        break;
      }
      default: {
        xfree(fieldinfo);
        luaL_error(L, "Error in " LUA_QS ": unknown type of data.", "xbase.record");
      }
    }
  }
  free(fieldinfo);
  return 1;
}


static int xbase_filepos (lua_State *L) {
  int64_t result;
  DBFHandle *ud;
  DBFInfo dbf;
  ud = aux_gethandle(L, 1, "xbase.filepos");
  dbf = **ud;
  result = _ftelli64(dbf.fp);
  if (result == -1)
    luaL_error(L, "Error in " LUA_QS ": IO failure.", "xbase.filepos");
  lua_pushnumber(L, result);
  return 1;
}


/************************************************************************/
/*                         DBFIsRecordDeleted()                         */
/*                                                                      */
/*      Returns TRUE if the indicated record is deleted, otherwise      */
/*      it returns FALSE.                                               */
/************************************************************************/

int SHPAPI_CALL DBFIsRecordDeleted (DBFHandle psDBF, int iShape) {  /* changed Agena 2.2.0 RC 2 */
  /* Verify selection. */
  if (iShape < 0 || iShape >= psDBF->nRecords)
    return -2;  /* push fail */
  /* Have we read the record? */
  if (!DBFLoadRecord(psDBF, iShape))
    return -1;
  /* '*' means deleted. */
  return psDBF->pszCurrentRecord[0] == '*';
}


/* Returns true if a record has been marked to be deleted, false if a record has not been
   marked as such, and fail if the record number is invalid. */

static int xbase_ismarked (lua_State *L) {
  DBFHandle *hnd;
  int record, ismarked;
  hnd = aux_gethandle(L, 1, "xbase.ismarked");
  record = agn_checkinteger(L, 2) - 1;
  ismarked = DBFIsRecordDeleted(*hnd, record);
  if (ismarked == -2)
    luaL_error(L, "Error in " LUA_QS ": requested record out of range.", "xbase.ismarked");
  else
    agn_pushboolean(L, ismarked);
  return 1;
}

/************************************************************************/
/*                        DBFMarkRecordDeleted()                        */
/*  hDBF:		  The access handle for the file.                       */
/*  iShape:       The record index to update.                           */
/*  bIsDeleted:   TRUE to mark record deleted, or FALSE to undelete it. */
/************************************************************************/

int SHPAPI_CALL DBFMarkRecordDeleted (DBFHandle psDBF, int iShape, int bIsDeleted) {
  char chNewFlag;
  /* Verify selection. */
  if (iShape < 0 || iShape >= psDBF->nRecords) return FALSE;
  /* Is this an existing record, but different than the last one we accessed ? */
  if (!DBFLoadRecord(psDBF, iShape)) return FALSE;
  /* Assign value, marking record as dirty if it changes. */
  chNewFlag = (bIsDeleted) ? '*' : ' ';
  if (psDBF->pszCurrentRecord[0] != chNewFlag) {
    psDBF->bCurrentRecordModified = TRUE;
    psDBF->bUpdated = TRUE;
    psDBF->pszCurrentRecord[0] = chNewFlag;
  }
  return TRUE;
}


/* Marks the specified record as to be deleted. Returns true if a record has been marked successfully,
   and false otherwise. The actual data is not deleted. This  also means that `xbase.readvalue` returns
   the values that are still stored in the record. Use `xbase.purge` to delete every entry of a record. */

static int xbase_mark (lua_State *L) {
  DBFHandle *hnd;
  int record, delete;
  hnd = aux_gethandle(L, 1, "xbase.mark");
  record = agn_checkinteger(L, 2) - 1;
  delete = agnL_optboolean(L, 3, 1);
  agn_pushboolean(L, DBFMarkRecordDeleted(*hnd, record, delete) == TRUE);
  return 1;
}


static int xbase_records (lua_State *L) {
  DBFHandle *hnd;
  hnd = aux_gethandle(L, 1, "xbase.records");
  lua_pushinteger(L, DBFGetRecordCount(*hnd));
  return 1;
}


static int xbase_fields (lua_State *L) {
  DBFHandle *hnd;
  hnd = aux_gethandle(L, 1, "xbase.fields");
  lua_pushinteger(L, DBFGetFieldCount(*hnd));
  return 1;
}


static int xbase_isopen (lua_State *L) {
  if (lua_isnoneornil(L, 1))
    lua_pushfalse(L);
  else {
    DBFHandle *hnd;
    hnd = (DBFHandle *)luaL_checkudata(L, 1, "xbase");
    lua_pushboolean(L, *hnd != NULL);
  }
  return 1;
}


static int xbase_tostring (lua_State *L) {  /* modified 2.4.2 */
  lua_pushfstring(L, "xbase(%p)", lua_topointer(L, 1));
  return 1;
}


static int xbase_gc (lua_State *L) {
  (void)L;
  return 0;
}


static const struct luaL_Reg xbase_lib [] = {
  {"__tostring", xbase_tostring},
  {"__gc", xbase_gc},
  {NULL, NULL}
};



static const luaL_Reg xbase[] = {
  {"attrib", xbase_attrib},              /* 05.06.2010 */
  {"close", xbase_close},                /* 05.06.2010 */
  {"fields", xbase_fields},              /* 26.05.2014 */
  {"filepos", xbase_filepos},            /* 13.06.2010 */
  {"header", xbase_header},              /* 16.06.2014 */
  {"ismarked", xbase_ismarked},          /* 10.03.2014 / 26.05.2014 */
  {"isopen", xbase_isopen},              /* 26.05.2014 */
  {"isvoid", xbase_isvoid},              /* 13.06.2010 */
  {"lock", xbase_lock},                  /* 12.06.2010 */
  {"mark", xbase_mark},                  /* 10.03.2014 / 26.05.2014 */
  {"new", xbase_new},                    /* 05.06.2010 */
  {"open", xbase_open},                  /* 05.06.2010 */
  {"purge", xbase_purge},                /* 05.06.2010 */
  {"readdbf", xbase_readdbf},            /* 05.06.2010 */
  {"readvalue", xbase_readvalue},        /* 05.06.2010 */
  {"record", xbase_record},              /* 13.06.2010 */
  {"records", xbase_records},            /* 26.05.2014 */
  {"sync", xbase_sync},                  /* 05.06.2010 */
  {"unlock", xbase_unlock},              /* 12.06.2010 */
  {"writeboolean", xbase_writeboolean},  /* 05.06.2010 */
  {"writedate", xbase_writedate},        /* 10.03.2014 */
  {"writedouble", xbase_writedouble},    /* 31.05.2014 */
  {"writefloat", xbase_writefloat},      /* 03.04.2014 */
  {"writenumber", xbase_writenumber},    /* 05.06.2010 */
  {"writestring", xbase_writestring},    /* 05.06.2010 */
  {NULL, NULL}
};


/*
** Open xbase library
*/
LUALIB_API int luaopen_xbase (lua_State *L) {
  luaL_newmetatable(L, "xbase");
  luaL_register(L, NULL, xbase_lib);
  luaL_register(L, AGENA_XBASELIBNAME, xbase);
  lua_newtable(L);
  lua_setfield(L, -2, "openfiles");  /* table for information on all open files */
  return 1;
}

