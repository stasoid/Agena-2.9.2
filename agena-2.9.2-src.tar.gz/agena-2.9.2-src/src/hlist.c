/*
   hash string table functions

   core functions taken from Kernigham/Ritchie `Programming in C`, 2nd Ed., p. 138

   Initiated August 12, 2007; Alexander Walz
*/

#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#define hlist_c
#define LUA_LIB

#include "agena.h"
#include "agnxlib.h"
#include "agenalib.h"
#include "hlist.h"

#include "agnhlps.h"

#define AGENA_LIBVERSION	"hlist 1.0.0 for Agena as of October 26, 2014\n"

#define AGENA_HLISTLIBNAME "hlist"
LUALIB_API int (luaopen_hlist) (lua_State *L);

#define uchar(c)        ((unsigned char)(c))

unsigned int hash_old (const char *s, int n) {
  /* h = M*(h << N) + (*s<<P) - 63  with M = 38, N = 1, P = 1 (before P = 0)
     yield ~ 0.63263134774382 (after surnames cleaning in Jan 2008)
     compiled by Alexander Walz; 13 % faster than the ([(h*N) << P] + uchar(*s) - Q)) ^ R method  */
  unsigned int h = 0;
  while (*s)
    h = 38*(h << 1) + uchar(*s++) - 63;
  return h % n;
}


unsigned int hash (const char *s, int n) {
  /* Daniel J. Bernstein hash, method taken from: http://www.cse.yorku.ca/~oz/hash.html,
     collisions: 1.2707446386376 (496377 surnames) */
  unsigned long h = 5381;
  int c;
  while ((c = uchar(*s++)))
    h = ((h << 5) + h) + c;  /* hash * 33 + c */
  return h % n;
}


/* Daniel J. Bernstein hash, taken from: http://www.cse.yorku.ca/~oz/hash.html,
   collisions: 1.2707446386376 (496377 surnames) */
static int hlist_djbhash (lua_State *L) {
  const char *str = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned long h = 5381;
  int c;
  while ((c = uchar(*str++)))
    h = ((h << 5) + h) + c;  /* hash * 33 + c */
  lua_pushnumber(L, h % n);
  return 1;
}


/* Modified Daniel J. Bernstein hash,
   taken from: http://www.eternallyconfuzzled.com/tuts/algorithms/jsw_tut_hashing.aspx,
   collisions: 1.270045594805 (496377 surnames) */
static int hlist_djbhash2 (lua_State *L) {
  const char *str = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned long h = 5381;
  int c;
  while ((c = uchar(*str++)))
    h = 33 * h ^ c;
  lua_pushnumber(L, h % n);
  return 1;
}


/* Shift-Add-XOR hash, taken from: http://www.eternallyconfuzzled.com/tuts/algorithms/jsw_tut_hashing.aspx,
   collisions: 1.2696167953224 (496377 surnames) */
static int hlist_saxhash (lua_State *L) {
  const char *str = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned long h = 5381;
  int c;
  while ((c = uchar(*str++)))
    h ^= ( h << 5 ) + ( h >> 2 ) + c;
  lua_pushnumber(L, h % n);
  return 1;
}


/* Fowler/Noll/Vo hash, taken from: http://www.eternallyconfuzzled.com/tuts/algorithms/jsw_tut_hashing.aspx,
   collisions: 1.2710700375654 (496377 surnames) */
static int hlist_fnvhash (lua_State *L) {
  const char *str = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned long h = 2166136261UL;
  int c;
  while ((c = uchar(*str++)))
    h = ( h * 16777619 ) ^ c;
  lua_pushnumber(L, h % n);
  return 1;
}


/* Bob Jenkins' hash, taken from: http://www.eternallyconfuzzled.com/tuts/algorithms/jsw_tut_hashing.aspx,
   collisions: 1.2701495898179 (496377 surnames) */
#define hashsize(n) ( 1U << (n) )
#define hashmask(n) ( hashsize (n) - 1 )

#define mix(a,b,c) \
 { \
   a -= b; a -= c; a ^= ( c >> 13 ); \
   b -= c; b -= a; b ^= ( a << 8 ); \
   c -= a; c -= b; c ^= ( b >> 13 ); \
   a -= b; a -= c; a ^= ( c >> 12 ); \
   b -= c; b -= a; b ^= ( a << 16 ); \
   c -= a; c -= b; c ^= ( b >> 5 ); \
   a -= b; a -= c; a ^= ( c >> 3 ); \
   b -= c; b -= a; b ^= ( a << 10 ); \
   c -= a; c -= b; c ^= ( b >> 15 ); \
 }

static int hlist_jenhash (lua_State *L) {
  size_t l;
  const char *k = agn_checklstring(L, 1, &l);
  unsigned long n = agn_checknumber(L, 2);
  unsigned a, b;
  unsigned c = 16777551;
  unsigned len = l;
  unsigned length = len;
  a = b = 0x9e3779b9;
  while (len >= 12) {
    a += (k[0] + ((unsigned)k[1] << 8)
      + ((unsigned)k[2] << 16)
      + ((unsigned)k[3] << 24));
    b += (k[4] + ((unsigned)k[5] << 8)
      + ((unsigned)k[6] << 16)
      + ((unsigned)k[7] << 24));
    c += (k[8] + ((unsigned)k[9] << 8)
      + ((unsigned)k[10] << 16)
      + ((unsigned)k[11] << 24));
    mix(a, b, c);
    k += 12;
    len -= 12;
  }
  c += length;
  switch (len) {
    case 11: c += ((unsigned)k[10] << 24);
    case 10: c += ((unsigned)k[9] << 16);
    case 9 : c += ((unsigned)k[8] << 8);
    /* First byte of c reserved for length */
    case 8 : b += ((unsigned)k[7] << 24);
    case 7 : b += ((unsigned)k[6] << 16);
    case 6 : b += ((unsigned)k[5] << 8);
    case 5 : b += k[4];
    case 4 : a += ((unsigned)k[3] << 24);
    case 3 : a += ((unsigned)k[2] << 16);
    case 2 : a += ((unsigned)k[1] << 8);
    case 1 : a += k[0];
  }
  mix(a, b, c);
  lua_pushnumber(L, c % n);
  return 1;
}


/* taken from: http://stackoverflow.com/questions/628790/have-a-good-hash-function-for-a-c-hash-table,
   invented by from Paul Larson of Microsoft Research,
   collisions: 1.2681150349105 (496377 surnames) */
static int hlist_plhash (lua_State *L) {
  const char *s = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned h = 0;
  while (*s)
    h = h * 101 + (unsigned)*s++;
  lua_pushnumber(L, h % n);
  return 1;
}


/* written by sth,
   taken from http://stackoverflow.com/questions/628790/have-a-good-hash-function-for-a-c-hash-table,
   collisions: 1.2811778916885 (496377 surnames) */
static int hlist_sthhash (lua_State *L) {
  const char *s = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned h = 0;
  while (*s)
    h = (h << 6) ^ (h >> 26) ^ (unsigned)*s++;
  lua_pushnumber(L, h % n);
  return 1;
}


/* One-at-a-Time Hash hash, taken from the website `A Hash Function for Hash Table Lookup`. */
static int hlist_oaathash (lua_State *L) {
  unsigned long h = 0;
  const char *key = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  while (*key) {
    h += uchar(*key++);
    h += (h << 10);
    h ^= (h >> 6);
  }
  h += (h << 3);
  h ^= (h >> 11);
  h += (h << 15);
  lua_pushnumber(L, (h & hashmask(n)) % n);
  return 1;
}


/* public-domain re-implementation of ndbm database library hash */
static int hlist_sdbmhash (lua_State *L) {
  const char *s = agn_checkstring(L, 1);
  unsigned long n = agn_checknumber(L, 2);
  unsigned long h = 0;
  while (*s)
    h = uchar(*s++) + (h << 6) + (h << 16) - h;
  lua_pushnumber(L, h % n);
  return 1;
}


static int hlist_rawhash (lua_State *L) {
  const char *s = luaL_checkstring(L, 1);
  unsigned int n = agn_checknumber(L, 2);
  unsigned int h = 0;
  while (*s)
    h = 38*(h << 1) + uchar(*s++) - 63;
  lua_pushinteger(L, h % n);
  return 1;
}


nlist *lookup (lua_State *L, dlist *a, const char *s, int hashval) {
  nlist *np;
  for (np=a->hashtab[hashval]; np != NULL; np = np->next) {
    lua_rawgeti(L, LUA_REGISTRYINDEX, np->name);
    if (strcmp(s, lua_tostring(L, -1)) == 0) {
      agn_poptop(L);
      return np;
    }
    agn_poptop(L);
  }
  return NULL;
}


#define checklist(L, n) (dlist *)luaL_checkudata(L, n, "hlist")

/* initialize a list with the given number of indices;
  arg: integer */

static int isPrime (unsigned int n) {
  long long int x;
  x = (long long int)n;
  if (x < 4)
    return x > 1;
  else if (x % 2 == 0)  /* even number ? */
    return 0;
  else {
    long long int i;
    const long long int imax = (long long int)sqrt(x) + 1;
    for (i = 3; i <= imax; i += 2) {
      if (x % i == 0) return 0;
    }
    return 1;
  }
}

static int hlist_list (lua_State *L) {
  dlist *a;
  int n, i, nbytes;
  n = luaL_checkint(L, 1);
  luaL_argcheck(L, n >= 1, 1, "invalid size");
  if (n > 9223372036854775807)  /* max/min of type LONG LONG INT */
    luaL_error(L, "Error in " LUA_QS ": first argument is too large.", "lists.list");
  /* search the next prime number > n */
  while (!isPrime(n)) n++;
  nbytes = sizeof(dlist) + n*(sizeof(char *) + sizeof(nlist));
  a = (dlist *)lua_newuserdata(L, nbytes);
  a->size = n;
  for (i=0; i < n; i++) {
    a->hashtab[i] = NULL;
  }
  luaL_getmetatable(L, "hlist");
  lua_setmetatable(L, -2);
  return 1;
}


/* statistical information on a given list;
  arg: list */

static int hlist_attrib (lua_State *L) {
  dlist *a = checklist(L, 1);
  nlist *np;
  lua_newtable(L);
  int i, filled, freeplaces = 0, entries = 0;
  /* compute number of free keys and number of entries */
  for (i=0; i<a->size; i++) {
    if (a->hashtab[i] == NULL)
      freeplaces++;
    else {
      for (np=a->hashtab[i]; np != NULL; np = np->next) {
        entries++;
      }
    }
  }
  lua_pushstring(L, "free"); lua_pushinteger(L, freeplaces); lua_rawset(L, -3);
  lua_pushstring(L, "size"); lua_pushinteger(L, a->size); lua_rawset(L, -3);
  lua_pushstring(L, "yield"); filled = a->size-freeplaces;
    lua_pushnumber(L, filled/(double)a->size);
    lua_rawset(L, -3);
  lua_pushstring(L, "entries"); lua_pushinteger(L, entries); lua_rawset(L, -3);
  lua_pushstring(L, "filled"); lua_pushinteger(L, filled); lua_rawset(L, -3);
  lua_pushstring(L, "entriesperkey");
    lua_pushnumber(L, (filled != 0) ? (double)entries/filled : 0);
    lua_rawset(L, -3);
  return 1;
}

/* determine the size of a list = number of indices;
  arg: list */

static int hlist_sizeof (lua_State *L) {
  dlist *a = checklist(L, 1);
  lua_pushnumber(L, a->size);
  return 1;
}


/* list.assign: enter a string into a list;
  args: list, str */

static int hlist_include (lua_State *L) {
  size_t l;
  dlist *a = checklist(L, 1);
  char *name = (char *)luaL_checklstring(L, 2, &l);
  nlist *np;
  unsigned hashval;
  hashval = hash(name, a->size);
  if ((np=lookup(L, a, name, hashval)) == NULL) {
    np = (nlist *)malloc(sizeof(*np));
    if (np == NULL) {
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "hlist.athash");
      return 1;
    }
    lua_pushvalue(L, 2);
    np->name = luaL_ref(L, LUA_REGISTRYINDEX);
    np->next = a->hashtab[hashval];
    a->hashtab[hashval] = np;
  }
  lua_pushtrue(L);
  return 1;
}


/* list.read: check whether a string str exists in a list lst;
  args: list, str */

static int hlist_in (lua_State *L) {
  nlist *np;
  dlist *a = checklist(L, 1);
  const char *s = lua_tostring(L, 2);
  /* if arg #2 is not a string or number, the function will quit with the following check */
  if (!s) { lua_pushnil(L); return 1; }
  for (np=a->hashtab[hash(s, a->size)]; np != NULL; np = np->next) {
    lua_rawgeti(L, LUA_REGISTRYINDEX, np->name);
    if (strcmp(s, lua_tostring(L, -1)) == 0) {
      agn_poptop(L);
      lua_pushtrue(L);
      return 1;
    }
    agn_poptop(L);
  }
  lua_pushnil(L);
  return 1;
}

/* determine the hash index (an integer) to a given string in a list;
  args: list, str */

static int hlist_hash (lua_State *L) {
  dlist *a = checklist(L, 1);
  const char *s = luaL_checkstring(L, 2);
  lua_pushinteger(L, hash(s, a->size));
  return 1;
}

/* return the entries to a given hash index as a table;
  args: list, index */

static int hlist_athash (lua_State *L) {
  nlist *np, *h;
  dlist *a = checklist(L, 1);
  int index = luaL_checkint(L, 2);
  int c = 0;
  if (index < 0 || index >= a->size) {
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "hlist.athash", index);
    return 1;
  }
  h = a->hashtab[index];
  lua_newtable(L);
  if (h == NULL) {
    return 1;
  }
  for (np=h; np != NULL; np = np->next, c++) {
    lua_rawgeti(L, LUA_REGISTRYINDEX, np->name);
    lua_rawsetistring(L, -2, c, lua_tostring(L, -1));
    agn_poptop(L);
  }
  return 1;
}

/* convert a list to a table with all hash indices as keys and corresponding entries in a table;
  if a hash key does not exist, it is not included in the table;
  arg: list */

static int hlist_tohtable (lua_State *L) {
  nlist *np, *h;
  dlist *a = checklist(L, 1);
  size_t i, c;
  lua_createtable(L, 0, a->size);
  for (i=0; i < a->size; i++) {
    c = 0;
    h = a->hashtab[i];
    if (h != NULL) {
      lua_newtable(L);
      for (np=h; np != NULL; np = np->next, c++) {
        lua_rawgeti(L, LUA_REGISTRYINDEX, np->name);
        lua_rawsetistring(L, -2, c, lua_tostring(L, -1));
        agn_poptop(L);
      }
      lua_rawseti(L, -2, i);
    }
  }
  return 1;
}


static int hlist_totable (lua_State *L) {
  nlist *np, *h;
  dlist *a = checklist(L, 1);
  size_t i, c;
  lua_createtable(L, a->size, 0);
  c = 0;
  for (i = 0; i < a->size; i++) {
    h = a->hashtab[i];
    if (h != NULL) {
      for (np=h; np != NULL; np = np->next, c++) {
        lua_rawgeti(L, LUA_REGISTRYINDEX, np->name);
        lua_rawsetistring(L, -2, c, lua_tostring(L, -1));
        agn_poptop(L);
      }
    }
  }
  return 1;
}


/* delete a string from a list;
  args: list, string */

static int hlist_purge (lua_State *L) {
  nlist *np1, *np2;
  dlist *a = checklist(L, 1);
  const char *s = luaL_checkstring(L, 2);
  unsigned hashval = hash(s, a->size);
  for (np1 = a->hashtab[hashval], np2 = NULL;
    np1 != NULL;
    np2 = np1, np1 = np1->next) {
    lua_rawgeti(L, LUA_REGISTRYINDEX, np1->name);
    if (strcmp(s, lua_tostring(L, -1)) == 0) {  /* found a match */
      luaL_unref(L, LUA_REGISTRYINDEX, np1->name);
      if (np2 == NULL)  /* at the beginning? */
        a->hashtab[hashval] = np1->next;
      else  /* in the middle or at the end? */
        np2->next = np1->next;
      xfree(np1);
      lua_pushtrue(L);
      return 1;
    }
  }
  lua_pushfalse(L);
  return 1;
}


/* garbage collection */

static int hlist_gc (lua_State *L) {
  int i;
  nlist *np, *temp;
  dlist *a = checklist(L, 1);
  for (i=0; i < a->size; i++) {
    np = a->hashtab[i];
    while (np) {
      temp = np->next;
      luaL_unref(L, LUA_REGISTRYINDEX, np->name);
      xfree(np);
      np = temp;
    }
  }
  /* agena frees a automatically since it is a userdata */
  lua_pushnil(L);
  lua_setmetatable(L, 1);
  return 0;
}


static int hlist_list2string (lua_State *L) {
  dlist *a = checklist(L, 1);
  lua_pushfstring(L, "hlist(%d)", a->size);
  return 1;
}


static int hlist_emptykeys (lua_State *L) {
  dlist *a = checklist(L, 1);
  lua_newtable(L);
  int i, c = 0;
  /* compute number of free keys and number of entries */
  lua_newtable(L);
  for (i=0; i<a->size; i++) {
    if (a->hashtab[i] == NULL) {
      c++;
      lua_rawsetinumber(L, -1, c, i);
    }
  }
  return 1;
}


static const struct luaL_Reg hlist_lib [] = {
  {"__writeindex", hlist_include},
  {"__index", hlist_in},
  {"__tostring", hlist_list2string},
  {"__gc", hlist_gc},
  {"__size", hlist_sizeof},         /* August 14, 2007 */
  {"__in", hlist_in},               /* August 12, 2007 */
  {NULL, NULL}
};


static const luaL_Reg hlist[] = {
  {"attrib", hlist_attrib},         /* August 12, 2007 */
  {"hash", hlist_hash},             /* August 13, 2007 */
  {"include", hlist_include},       /* August 12, 2007 */
  {"list", hlist_list},             /* August 12, 2007 */
  {"purge", hlist_purge},           /* August 13, 2007 */
  {"djbhash", hlist_djbhash},       /* January 09, 2011 */
  {"djbhash2", hlist_djbhash2},     /* January 09, 2011 */
  {"saxhash", hlist_saxhash},       /* January 09, 2011 */
  {"fnvhash", hlist_fnvhash},       /* January 09, 2011 */
  {"jenhash", hlist_jenhash},       /* January 09, 2011 */
  {"oaathash", hlist_oaathash},     /* October 26, 2014 */
  {"sdbmhash", hlist_sdbmhash},     /* October 26, 2014 */
  {"plhash", hlist_plhash},         /* January 09, 2011 */
  {"sthhash", hlist_sthhash},       /* January 09, 2011 */
  {"athash", hlist_athash},         /* August 13, 2007 */
  {"tohtable", hlist_tohtable},     /* August 14, 2007 */
  {"totable", hlist_totable},       /* January 12, 2008 */
  {"emptykeys", hlist_emptykeys},   /* August 18, 2007 */
  {"rawhash", hlist_rawhash},       /* January 06, 2008 */
  {NULL, NULL}
};


/*
** Open lists library
*/
LUALIB_API int luaopen_hlist (lua_State *L) {
  luaL_newmetatable(L, "hlist");
  luaL_register(L, NULL, hlist_lib);
  lua_rawsetstringstring(L, -1, "initstring", AGENA_LIBVERSION);
  luaL_register(L, AGENA_HLISTLIBNAME, hlist);
  return 1;
}

/* ====================================================================== */


