/*
** $Id: utils.c, v 1.0.1 by Alexander Walz - Initiated: October 17, 2006
   Revision 08.08.2009 22:13:15
** See Copyright Notice in agena.h
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* instead of time.h: */
#include "agnt64.h"

/* the following package ini declarations must be included after `#include <` and before `include #` ! */

#define utils_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "iniparse.h"
#include "lobject.h"

#include "utils.h"  /* typedefs and checkarray macro */

#define uchar(c)        ((unsigned char)(c))

static int utils_singlesubs (lua_State *L) {  /* Agena 1.5.0 */
   size_t i, l;
   unsigned char token;
   luaL_Buffer b;
   const char *s = luaL_checklstring(L, 1, &l);
   luaL_buffinit(L, &b);
   if (lua_type(L, 2) == LUA_TSEQ) {
      for (i=0; i < l; i++) {
         lua_seqgeti(L, 2, uchar(s[i])+1);  /* push substitution on stack */
         token = uchar(luaL_checknumber(L, -1));
         luaL_addchar(&b, token);
         agn_poptop(L);
      }
   } else
      luaL_error(L, "Error in " LUA_QS ": sequence expected, got %s.", "utils.singlesubs",
                 luaL_typename(L, 2));
   luaL_pushresult(&b);
   return 1;
}

/*
----------------------------------------------------------------------------
  Internal utilities
----------------------------------------------------------------------------
*/

static void setfield (lua_State *L, const char *key, int value) {
  lua_pushinteger(L, value);
  lua_setfield(L, -2, key);
}


static void setboolfield (lua_State *L, const char *key, int value) {
  if (value < 0)  /* undefined? */
    return;  /* does not set field */
  lua_pushboolean(L, value);
  lua_setfield(L, -2, key);
}

/*
----------------------------------------------------------------------------
  Other functions
----------------------------------------------------------------------------
*/

static int utils_calendar (lua_State *L) {
  Time64_T seconds = luaL_opt(L, (time_t)agn_checknumber, 1, time(NULL));
  struct TM *stm;
  lua_createtable(L, 0, 9);  /* 9 = number of fields */
  if (seconds < 0) {  /* 0.31.3 patch */
    lua_pushfail(L);
    return 1;
  }
  stm = localtime64(&seconds);
  if (stm != NULL) {
    setfield(L, "sec", stm->tm_sec);
    setfield(L, "min", stm->tm_min);
    setfield(L, "hour", stm->tm_hour);
    setfield(L, "day", stm->tm_mday);
    setfield(L, "month", stm->tm_mon+1);
    setfield(L, "year", stm->tm_year+1900);
    setfield(L, "wday", stm->tm_wday+1);
    setfield(L, "yday", stm->tm_yday+1);
    setboolfield(L, "DST", stm->tm_isdst);
  } else
    lua_pushfail(L);
  return 1;
}


/* ******************************************************************
LICENCE:        Copyright (c) 2001 Bob Trower, Trantor Standard Systems Inc.

                Permission is hereby granted, free of charge, to any person
                obtaining a copy of this software and associated
                documentation files (the "Software"), to deal in the
                Software without restriction, including without limitation
                the rights to use, copy, modify, merge, publish, distribute,
                sublicense, and/or sell copies of the Software, and to
                permit persons to whom the Software is furnished to do so,
                subject to the following conditions:

                The above copyright notice and this permission notice shall
                be included in all copies or substantial portions of the
                Software.

                THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY
                KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
                WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
                PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS
                OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR
                OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
                OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
                SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

VERSION HISTORY:
                Bob Trower 08/04/01 -- Create Version 0.00.00B

******************************************************************** */

/*
** Translation Table as described in RFC1113
*/
static const char cb64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

/*
** Translation Table to decode (created by author)
*/
static const char cd64[]="|$$$}rstuvwxyz{$$$$$$$>?@ABCDEFGHIJKLMNOPQRSTUVW$$$$$$XYZ[\\]^_`abcdefghijklmnopq";

/*
** encodeblock
**
** encode 3 8-bit binary bytes as 4 '6-bit' characters
*/
void encodeblock( unsigned char in[3], unsigned char out[4], int len ) {
  out[0] = cb64[ in[0] >> 2 ];
  out[1] = cb64[ ((in[0] & 0x03) << 4) | ((in[1] & 0xf0) >> 4) ];
  out[2] = (unsigned char) (len > 1 ? cb64[ ((in[1] & 0x0f) << 2) | ((in[2] & 0xc0) >> 6) ] : '=');
  out[3] = (unsigned char) (len > 2 ? cb64[ in[2] & 0x3f ] : '=');
}


/*
** encode
**
** base64 encode a stream adding padding and line breaks as per spec.
*/

static int utils_encodeb64 (lua_State *L) {
  luaL_Buffer b;
  unsigned char in[3], out[4];
  size_t linesize;
  int i, len, blocksout = 0;
  const char *str = agn_checkstring(L, 1);
  linesize = agnL_optnumber(L, 2, 72);
  luaL_buffinit(L, &b);
  while (*str) {
    len = 0;
    for (i = 0; i < 3; i++) {
      in[i] = (unsigned char) *str;
      if (*str)
        len++;
      else {
        in[i] = 0;
        break;
      }
      str++;
    }
    if (len) {
      encodeblock(in, out, len);
      for (i = 0; i < 4; i++) {
        luaL_addchar(&b, out[i]);
      }
      blocksout++;
    }
    if (blocksout >= (linesize/4) || *str == '\0') {
      if (blocksout) {
        /* luaL_addchar(&b, '\r'); */  /* Linux base64 only works in ignore mode when encountering CRs */
        luaL_addchar(&b, '\n');
      }
      blocksout = 0;
    }
  }
  luaL_pushresult(&b);
  return 1;
}

/*
** decodeblock
**
** decode 4 '6-bit' characters into 3 8-bit binary bytes
*/
void decodeblock( unsigned char in[4], unsigned char out[3] )
{
    out[ 0 ] = (unsigned char ) (in[0] << 2 | in[1] >> 4);
    out[ 1 ] = (unsigned char ) (in[1] << 4 | in[2] >> 2);
    out[ 2 ] = (unsigned char ) (((in[2] << 6) & 0xc0) | in[3]);
}

/*
** decode
**
** decode a base64 encoded stream discarding padding, line breaks and noise
*/
static int utils_decodeb64 (lua_State *L) {
  luaL_Buffer b;
  unsigned char in[4], out[3], v;
  int i, len;
  const char *str = agn_checkstring(L, 1);
  luaL_buffinit(L, &b);
  while (*str) {
    for (len=0, i = 0; i < 4 && *str; i++) {
      v = 0;
      while (*str && v == 0) {
        v = (unsigned char) *str++;
        v = (unsigned char) ((v < 43 || v > 122) ? 0 : cd64[ v - 43 ]);
        if (v) {
          v = (unsigned char) ((v == '$') ? 0 : v - 61);
        }
      }
      if (*str) {
        len++;
        if (v) {
          in[i] = (unsigned char)(v - 1);
        }
      }
      else {
        in[i] = 0;
        break;
      }
    }
    if (len) {
      decodeblock(in, out);
      for (i = 0; i < len - 1; i++) {
        luaL_addchar(&b, out[i]);
      }
    }
  }
  luaL_pushresult(&b);
  return 1;
}


static int utils_checkdate (lua_State *L) {
  int year, month, day, hour, minute, second;
  size_t nops;
  year = month = day = hour = minute = second = 0;  /* to prevent compiler warnings */
  switch (lua_type(L, 1)) {
    case LUA_TTABLE: {  /* 1.12.3 */
      nops = agn_size(L, 1);
      if (nops < 3)
        luaL_error(L, "Error in " LUA_QS ": table must contain at least three values.", "utils.checkdate");
      year = agn_getinumber(L, 1, 1);
      month = agn_getinumber(L, 1, 2);
      day = agn_getinumber(L, 1, 3);
      hour = (nops > 3) ? agn_getinumber(L, 1, 4) : 0;
      minute = (nops > 4) ? agn_getinumber(L, 1, 5) : 0;
      second = (nops > 5) ? agn_getinumber(L, 1, 6) : 0;
      break;
    }
    case LUA_TSEQ: {  /* 1.12.3 */
      nops = agn_seqsize(L, 1);
      if (nops < 3)
        luaL_error(L, "Error in " LUA_QS ": sequence must contain at least three values.", "utils.checkdate");
      year = lua_seqgetinumber(L, 1, 1);
      month = lua_seqgetinumber(L, 1, 2);
      day = lua_seqgetinumber(L, 1, 3);
      hour = (nops > 3) ? lua_seqgetinumber(L, 1, 4) : 0;
      minute = (nops > 4) ? lua_seqgetinumber(L, 1, 5) : 0;
      second = (nops > 5) ? lua_seqgetinumber(L, 1, 6) : 0;
      break;
    }
    case LUA_TNUMBER: {
      nops = lua_gettop(L);
      if (nops < 3)
        luaL_error(L, "Error in " LUA_QS ": expected at leat three arguments of type number.", "utils.checkdate");
      year = agn_checknumber(L, 1);
      month = agn_checknumber(L, 2);
      day = agn_checknumber(L, 3);
      hour = (nops > 3) ? agn_checknumber(L, 4) : 0;
      minute = (nops > 4) ? agn_checknumber(L, 5) : 0;
      second = (nops > 5) ? agn_checknumber(L, 6) : 0;
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": expected a table, sequence or at least three numbers.", "utils.checkdate");
  }
  agn_pushboolean(L, tools_checkdatetime(year, month, day, hour, minute, second));
  return 1;
}


/* Reads a traditional initialisation file and returns its contents as a table. Initialisation files
   supported look like the following:

#
# This is an example of an ini file
#
; Pizzas

Taxi=Pizza Cab
Agena=

[Pizza] ; <- this is a section name

Ham       = yes;  <- and this is a key~value pair
Mushrooms = true ;
Capres    = 0
Cheese    = "Non" ;
Price = 3.99
Preis=3,99

A line beginning with a hash (#), followed optionally by one or more characters, is completely ignored.
In a line, any text starting with a semicolon is also skipped. Key~value pairs may be separated by
one or more whitespaces.

The result is a table.

The file is parsed from top to bottom. As long as no section name has been given (here `[Pizza]`),
any key~value pairs encountered are entered into the table as such.

If a section name is given, then a subtable of the form section ~ [key ~ value pairs] is stored to the
resulting main table.

If a key is given, but now value, then the corresponding value will be the empty string. Values may
also be enclosed in double quotes, but double quotes will be stripped of during import.

By default, any number values are automatically transformed to numbers, and Boolean values 'true',
'false', or 'fail' are converted to Booleans, and all other values are returned as strings. You may
prevent any conversion by passing the convert=false option.

If the option 'comma'=true is given, then all floating point values containing a decimal comma are
converted to a representation with a decimal dot. Default is comma=false.

The option sections=true reads only the section names in the ini file and returns them in the order
of occurrence in a table array. Default is sections=false.

The results of reading the above ini file will look as follows if no option is given:

[Agena ~ , Taxi ~ 'Pizza Cab', Pizza ~ [Capres ~ 0, Cheese ~ Non, Ham ~ yes, Mushrooms ~ TRUE, Preis ~ 3.99, Price ~ 3,99]]

 */

static void aux_pushkeyvaluepair (lua_State *L, const char *key, char *value, int convert, int comma) {
  lua_pushstring(L, key);
  if (value == NULL)
    lua_pushundefined(L);
  else {
    if (convert) {
      lua_Number num;
      int result;
      if (comma)  /* convert a string representing a number with a decimal comma to a number with a decimal dot */
        tools_commatodot(value, &result);
      if (luaO_str2d(value, &num))  /* convert any number including 1k's, 1M's, etc., to a lua_Number */
        lua_pushnumber(L, num);
      else if (strcmp(value, "true") == 0)  /* process Booleans */
        lua_pushtrue(L);
      else if (strcmp(value, "false") == 0)
        lua_pushfalse(L);
      else if (strcmp(value, "fail") == 0)
        lua_pushfail(L);
      else  /* push data as a string */
        lua_pushstring(L, value);
    } else  /* push anything as a string */
      lua_pushstring(L, value);
    lua_rawset(L, -3);
  }
}

static int utils_readini (lua_State *L) { /* 2.3.0 RC 2 */
  dictionary *ini;
  size_t i, nargs, sections;
  int err, flag, convert, comma;
  const char *filename;
  char *key, *value, *cursection, *pos;
  filename = agn_checkstring(L, 1);
  convert = 1;
  comma = sections = 0;
  ini = iniparser_load(filename);
  if (ini == NULL) {
    luaL_error(L, "Error in " LUA_QS ": could not find or load %s.", "utils.readini", filename);
  }
  nargs = lua_gettop(L);
  for (i=2; i <= nargs; i++) {
    if (lua_ispair(L, i)) {
      const char *Key;
      agn_pairgeti(L, i, 1);
      if (!lua_isstring(L, -1)) {
        agn_poptop(L);
        luaL_error(L, "Error in " LUA_QS ": invalid option.", "utils.readini");
      }
      Key = lua_tostring(L, -1);
      if (strcmp(Key, "convert") == 0) {
        agn_pairgeti(L, i, 2);
        convert = !agn_isfalse(L, -1);
        agn_poptop(L);  /* remove value */
      } else if (strcmp(Key, "comma") == 0) {
        agn_pairgeti(L, i, 2);
        comma = agn_istrue(L, -1);
        agn_poptop(L);  /* remove value */
      } else if (strcmp(Key, "sections") == 0) {
        agn_pairgeti(L, i, 2);
        sections = agn_istrue(L, -1);
        agn_poptop(L);  /* remove value */
      } else
        luaL_error(L, "Error in " LUA_QS ": unknwon option %s.", "utils.readini", Key);
      agn_poptop(L);  /* remove key */
    }
  }
  lua_createtable(L, 0, ini->n);
  cursection = NULL;
  flag = 0;
  for (i=0; i < ini->n; i++) {
    key = ini->key[i];
    if (key) {
      if ((pos = strchr(key, ':')) == NULL) { /* we got a new section */
        if (flag) xfree(cursection);  /* free formerly read section name */
        flag = 1;
        cursection = substr(key, 0, strlen(key) - 1, &err);
        if (err != 0) {
          agn_poptop(L);  /* pop table */
          dictionary_del(ini);
          luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "utils.readini");
        };
        if (sections > 0) {
          lua_rawsetistring(L, -1, sections++, cursection);
        } else {
          lua_pushstring(L, cursection);
          lua_createtable(L, 0, 1);
          lua_rawset(L, -3);
        }
        continue;
      }
      if (sections > 0) continue;
      value = dictionary_get(ini, key, NULL);
      key = pos + 1;
      if (cursection != NULL) {
        lua_getfield(L, -1, cursection);
        if (lua_isnil(L, -1)) {  /* field does not exist ? */
          agn_poptoptwo(L);  /* pop null and table */
          dictionary_del(ini);
          luaL_error(L, "Error in " LUA_QS ": could not create key~value pair.", "utils.readini");
        } else {  /* subtable is now on top of stack */
          aux_pushkeyvaluepair(L, key, value, convert, comma);
          agn_poptop(L);  /* pop subtable */
        }
      } else {  /* no section encountered yet */
        aux_pushkeyvaluepair(L, key, value, convert, comma);  /* and leave main table on top of the stack */
      }
    }
  }
  if (flag) xfree(cursection);
  dictionary_del(ini);
  return 1;
}


static const luaL_Reg utils[] = {
  {"calendar", utils_calendar},           /* added on April 07, 2007 */
  {"checkdate", utils_checkdate},         /* added on Januray 31, 2013 */
  {"singlesubs", utils_singlesubs},       /* added on September 07, 2011 - added on August 05, 2007 */
  {"decodeb64", utils_decodeb64},         /* added on May 27, 2012 */
  {"encodeb64", utils_encodeb64},         /* added on May 27, 2012 */
  {"readini", utils_readini},              /* added on September 24, 2014 */
  {NULL, NULL}
};


/*
** Open utils library
*/
LUALIB_API int luaopen_utils (lua_State *L) {
  luaL_register(L, AGENA_UTILSLIBNAME, utils);
  return 1;
}

/* ====================================================================== */

