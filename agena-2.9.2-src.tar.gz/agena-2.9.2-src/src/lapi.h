/*
** $Id: lapi.h,v 2.2 2005/04/25 19:24:10 roberto Exp $
** Auxiliary functions from Lua/Agena API
** See Copyright Notice in agena.h
*/

#ifndef lapi_h
#define lapi_h


#include "lobject.h"

LUAI_FUNC void luaA_pushobject (lua_State *L, const TValue *o);
LUA_API TValue   *index2adr (lua_State *L, int idx);
LUA_API GCObject *index2gco (lua_State *L, int idx);  /* 2.9.1 */

#endif
