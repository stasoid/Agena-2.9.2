/*
** $Id: lstrlib.c,v 1.132 2006/04/26 20:41:19 roberto Exp $
** Standard library for string operations and pattern-matching
** See Copyright Notice in agena.h
*/


#include <ctype.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>
#include <math.h>   /* HUGE_VAL */

#define lstrlib_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "agncmpt.h"
#include "agnhlps.h"
#include "ldebug.h"  /* for luaG_runerror */
#include "lstrlib.h"
#include "lundump.h"
#include "lucase.def"

/* macro to `unsign' a character */
#define uchar(c)        ((unsigned char)(c))

/* see share/ascii.xls */

static const unsigned char tools_charmap[257] = {
/* Dec, HX, Chr      __UPPER|__LOWER|__DIGIT|__HEXAD|__PRINT|__PUNCT|__CNTRL|__BLANK */
/*  -1, -1, EOF */   __0____|__0____|__0____|__0____|__0____|__0____|__0____|__0____,
/* 000, 00, NUL */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 001, 01, SOH */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 002, 02, STX */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 003, 03, ETX */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 004, 04, EOT */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 005, 05, ENQ */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 006, 06, NAK */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 007, 07, BEL */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 008, 08, BS  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 009, 09, TAB */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__BLANK,
/* 010, 0a, LF  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__BLANK,
/* 011, 0b, VT  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__BLANK,
/* 012, 0c, FF  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__BLANK,
/* 013, 0d, CR  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__BLANK,
/* 014, 0e, SI  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 015, 0f, SO  */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 016, 10,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 017, 11,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 018, 12,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 019, 13,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 020, 14,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 021, 15,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 022, 16,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 023, 17,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 024, 18,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 025, 19,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 026, 1a,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 027, 1b,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 028, 1c,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 029, 1d,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 030, 1e,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 031, 1f,     */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 032, 20, SP  */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__BLANK,
/* 033, 21, !   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 034, 22, "   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 035, 23, #   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 036, 24, $   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 037, 25, %   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 038, 26, &   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 039, 27, '   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 040, 28, (   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 041, 29, )   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 042, 2a, *   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 043, 2b, +   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 044, 2c, ,   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 045, 2d, -   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 046, 2e, .   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 047, 2f, /   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 048, 30, 0   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 049, 31, 1   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 050, 32, 2   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 051, 33, 3   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 052, 34, 4   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 053, 35, 5   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 054, 36, 6   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 055, 37, 7   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 056, 38, 8   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 057, 39, 9   */   __0____|__0____|__DIGIT|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 058, 3a, :   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 059, 3b, ;   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 060, 3c, <   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 061, 3d, =   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 062, 3e, >   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 063, 3f, ?   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 064, 40, @   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 065, 41, A   */   __UPPER|__0____|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 066, 42, B   */   __UPPER|__0____|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 067, 43, C   */   __UPPER|__0____|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 068, 44, D   */   __UPPER|__0____|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 069, 45, E   */   __UPPER|__0____|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 070, 46, F   */   __UPPER|__0____|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 071, 47, G   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 072, 48, H   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 073, 49, I   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 074, 4a, J   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 075, 4b, K   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 076, 4c, L   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 077, 4d, M   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 078, 4e, N   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 079, 4f, O   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 080, 50, P   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 081, 51, Q   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 082, 52, R   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 083, 53, S   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 084, 54, T   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 085, 55, U   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 086, 56, V   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 087, 57, W   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 088, 58, X   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 089, 59, Y   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 090, 5a, Z   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 091, 5b, [   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 092, 5c, \   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 093, 5d, ]   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 094, 5e, ^   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 095, 5f, _   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 096, 60, `   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 097, 61, a   */   __0____|__LOWER|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 098, 62, b   */   __0____|__LOWER|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 099, 63, c   */   __0____|__LOWER|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 100, 64, d   */   __0____|__LOWER|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 101, 65, e   */   __0____|__LOWER|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 102, 66, f   */   __0____|__LOWER|__0____|__HEXAD|__PRINT|__0____|__0____|__0____,
/* 103, 67, g   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 104, 68, h   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 105, 69, i   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 106, 6a, j   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 107, 6b, k   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 108, 6c, l   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 109, 6d, m   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 110, 6e, n   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 111, 6f, o   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 112, 70, p   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 113, 71, q   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 114, 72, r   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 115, 73, s   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 116, 74, t   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 117, 75, u   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 118, 76, v   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 119, 77, w   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 120, 78, x   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 121, 79, y   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 122, 7a, z   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 123, 7b, {   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 124, 7c, |   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 125, 7d, }   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 126, 7e, ~   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 127, 7f, DEL */   __0____|__0____|__0____|__0____|__0____|__0____|__CNTRL|__0____,
/* 128, 80, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 129, 81, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 130, 82, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 131, 83, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 132, 84, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 133, 85, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 134, 86, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 135, 87, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 136, 88, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 137, 89, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 138, 8a, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 139, 8b, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 140, 8c, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 141, 8d, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 142, 8e, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 143, 8f, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 144, 90, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 145, 91, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 146, 92, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 147, 93, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 148, 94, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 149, 95, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 150, 96, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 151, 97, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 152, 98, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 153, 99, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 154, 9a, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 155, 9b, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 156, 9c, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 157, 9d, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 158, 9e, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 159, 9f, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 160, a0, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 161, a1, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 162, a2, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 163, a3, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 164, a4, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 165, a5, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 166, a6, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 167, a7, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 168, a8, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 169, a9, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 170, aa, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 171, ab, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 172, ac, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 173, ad, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 174, ae, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 175, af, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 176, b0, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 177, b1, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 178, b2, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 179, b3, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 180, b4, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 181, b5, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 182, b6, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 183, b7, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 184, b8, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 185, b9, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 186, ba, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 187, bb, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 188, bc, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 189, bd, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 190, be, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 191, bf, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 192, c0, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 193, c1, -   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 194, c2, -   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 195, c3, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 196, c4, -   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 197, c5, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 198, c6, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 199, c7, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 200, c8, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 201, c9, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 202, ca, -   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 203, cb, -   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 204, cc, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 205, cd, -   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 206, ce, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 207, cf, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 208, d0, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 209, d1, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 210, d2, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 211, d3, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 212, d4, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 213, d5, i   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 214, d6, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 215, d7, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 216, d8, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 217, d9, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 218, da, +   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 219, db, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 220, dc, _   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 221, dd, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 222, de, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 223, df, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 224, e0, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 225, e1, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 226, e2, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 227, e3, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 228, e4, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 229, e5, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 230, e6, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 231, e7, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 232, e8, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 233, e9, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 234, ea, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 235, eb, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 236, ec, �   */   __0____|__LOWER|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 237, ed, �   */   __UPPER|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 238, ee, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 239, ef, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 240, f0, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 241, f1, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 242, f2, =   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 243, f3, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 244, f4, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 245, f5, �   */   __0____|__0____|__0____|__0____|__PRINT|__PUNCT|__0____|__0____,
/* 246, f6, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 247, f7, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 248, f8, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 249, f9, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 250, fa, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 251, fb, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 252, fc, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 253, fd, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 254, fe, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____,
/* 255, ff, �   */   __0____|__0____|__0____|__0____|__PRINT|__0____|__0____|__0____};


ptrdiff_t posrelat (ptrdiff_t pos, size_t len) {
  /* relative string position: negative means back from end */
  /* return (pos>=0) ? pos : (ptrdiff_t)len+pos+1; */
  /* Lua 5.1.3 patch 9 */
  if (pos < 0) pos += (ptrdiff_t)len + 1;
  return (pos >= 0) ? pos : 0;
}


static int str_reverse (lua_State *L) {
  size_t l;
  luaL_Buffer b;
  const char *s = luaL_checklstring(L, 1, &l);
  luaL_buffinit(L, &b);
  while (l--) luaL_addchar(&b, s[l]);
  luaL_pushresult(&b);
  return 1;
}


static int str_repeat (lua_State *L) {
  size_t l;
  luaL_Buffer b;
  const char *s = luaL_checklstring(L, 1, &l);
  int n = agnL_checkint(L, 2);
  luaL_buffinit(L, &b);
  while (n-- > 0)
    luaL_addlstring(&b, s, l);
  luaL_pushresult(&b);
  return 1;
}


static int str_tochars (lua_State *L) {
  int i, n, c;
  luaL_Buffer b;
  luaL_buffinit(L, &b);
  if (lua_isseq(L, 1)) {  /* 2.6.1 extension */
    n = agn_seqsize(L, 1);
    for (i=1; i <= n; i++) {
      c = agn_seqgetinumber(L, 1, i);
      if (uchar(c) != c)
        luaL_error(L, "Error in " LUA_QS ": invalid value at index %d.", "strings.tochars", i);
      if (c == 0) break;  /* 2.6.1, embedded zero ? */
      luaL_addchar(&b, uchar(c));
    }
  } else {
    n = lua_gettop(L);  /* number of arguments */
    luaL_checkstack(L, n, "too many arguments");  /* 2.6.1 */
    for (i=1; i <= n; i++) {
      c = agnL_checkint(L, i);
      luaL_argcheck(L, uchar(c) == c, i, "invalid value");
      if (c == 0) break;  /* 2.6.1, embedded zero ? */
      luaL_addchar(&b, uchar(c));
    }
  }
  luaL_pushresult(&b);
  return 1;
}


static int str_tobytes (lua_State *L) {
  size_t i, l;
  const char *str = luaL_checklstring(L, 1, &l);
  agn_createseq(L, l);
  for (i=0; i < l; i++) {
    lua_seqsetinumber(L, -1, i+1, cast_num(uchar(str[i])));
  }
  return 1;
}


static int writer (lua_State *L, const void* b, size_t size, void* B) {  /* reintroduced 1.6.0 */
  (void)L;
  luaL_addlstring((luaL_Buffer*) B, (const char *)b, size);
  return 0;
}


static int str_dump (lua_State *L) {  /* reintroduced 1.6.0 */
  luaL_Buffer b;
  luaL_checktype(L, 1, LUA_TFUNCTION);
  if (lua_iscfunction(L, 1))
    luaL_error(L, "Error in `strings.dump`: cannot dump C library functions.");  /* 1.6.1 */
  lua_settop(L, 1);
  luaL_buffinit(L,&b);
  if (lua_dump(L, writer, &b) != 0)
    luaL_error(L, "Error in `strings.dump`: unable to dump given function.");  /* 1.6.1 */
  luaL_pushresult(&b);
  return 1;
}


/*
** {======================================================
** PATTERN MATCHING
** =======================================================
*/


#define CAP_UNFINISHED   (-1)
#define CAP_POSITION   (-2)
#define L_ESC      '%'


static int check_capture (MatchState *ms, int l) {
  l -= '1';
  if (l < 0 || l >= ms->level || ms->capture[l].len == CAP_UNFINISHED)
    return luaL_error(ms->L, "invalid capture index.");
  return l;
}


static int capture_to_close (MatchState *ms) {
  int level = ms->level;
  for (level--; level>=0; level--)
    if (ms->capture[level].len == CAP_UNFINISHED) return level;
  return luaL_error(ms->L, "invalid pattern capture.");
}


const char *classend (MatchState *ms, const char *p) {
  switch (*p++) {
    case L_ESC: {
      if (*p == '\0')
        luaL_error(ms->L, "malformed pattern (ends with " LUA_QL("%%") ").");
      return p+1;
    }
    case '[': {
      if (*p == '^') p++;
      do {  /* look for a `]' */
        if (*p == '\0')
          luaL_error(ms->L, "malformed pattern (missing " LUA_QL("]") ").");
        if (*(p++) == L_ESC && *p != '\0')
          p++;  /* skip escapes (e.g. `%]') */
      } while (*p != ']');
      return p+1;
    }
    default: {
      return p;
    }
  }
}


static int isvowel (int c) {  /* 1.10.0 */
  switch (tolower(c)) {
    case 'a': case 'e': case 'i': case 'o': case 'u': case 'y': return 1;
    default: return 0;
  }
}

static int isconsonant (int c) {  /* 1.10.0 */
  int x = tolower(c);
  return ((
    (x > 'a' && x < 'e') || (x > 'e' && x < 'i') ||
    (x > 'i' && x < 'o') || (x > 'o' && x < 'u') ||
    (x > 'u' && x < 'y') || (x == 'z')) ? 1 : 0);
}

static int match_class (int c, int cl) {
  int res;
  switch (tolower(cl)) {
    case 'a' : res = isalpha(c); break;
    case 'c' : res = iscntrl(c); break;
    case 'd' : res = isdigit(c); break;
    case 'k' : res = isconsonant(c); break;
    case 'l' : res = islower(c); break;
    case 'p' : res = ispunct(c); break;
    case 's' : res = isspace(c); break;
    case 'u' : res = isupper(c); break;
    case 'v' : res = isvowel(c); break;
    case 'w' : res = isalnum(c); break;
    case 'x' : res = isxdigit(c); break;
    case 'z' : res = (c == 0); break;
    default: return (cl == c);
  }
  return (islower(cl) ? res : !res);
}


int matchbracketclass (int c, const char *p, const char *ec) {
  int sig = 1;
  if (*(p+1) == '^') {
    sig = 0;
    p++;  /* skip the `^' */
  }
  while (++p < ec) {
    if (*p == L_ESC) {
      p++;
      if (match_class(c, uchar(*p)))
        return sig;
    }
    else if ((*(p+1) == '-') && (p+2 < ec)) {
      p+=2;
      if (uchar(*(p-2)) <= c && c <= uchar(*p))
        return sig;
    }
    else if (uchar(*p) == c) return sig;
  }
  return !sig;
}


int singlematch (int c, const char *p, const char *ep) {
  switch (*p) {
    case '.': return 1;  /* matches any char */
    case L_ESC: return match_class(c, uchar(*(p+1)));
    case '[': return matchbracketclass(c, p, ep-1);
    default:  return (uchar(*p) == c);
  }
}


const char *matchbalance (MatchState *ms, const char *s,
                                   const char *p) {
  if (*p == 0 || *(p+1) == 0)
    luaL_error(ms->L, "unbalanced pattern.");
  if (*s != *p) return NULL;
  else {
    int b = *p;
    int e = *(p+1);
    int cont = 1;
    while (++s < ms->src_end) {
      if (*s == e) {
        if (--cont == 0) return s+1;
      }
      else if (*s == b) cont++;
    }
  }
  return NULL;  /* string ends out of balance */
}


const char *max_expand (MatchState *ms, const char *s,
                                 const char *p, const char *ep, int mode) {
  ptrdiff_t i = 0;  /* counts maximum expand for item */
  while ((s+i)<ms->src_end && singlematch(uchar(*(s+i)), p, ep))
    i++;
  /* keeps trying to match with the maximum repetitions */
  while (i>=0) {
    const char *res = match(ms, (s+i), ep+1, mode);
    if (res) return res;
    i--;  /* else didn't match; reduce 1 repetition to try again */
  }
  return NULL;
}


const char *min_expand (MatchState *ms, const char *s,
                                 const char *p, const char *ep, int mode) {
  for (;;) {
    const char *res = match(ms, s, ep+1, mode);
    if (res != NULL)
      return res;
    else if (s<ms->src_end && singlematch(uchar(*s), p, ep))
      s++;  /* try with one more repetition */
    else return NULL;
  }
}


const char *start_capture (MatchState *ms, const char *s,
                                    const char *p, int what, int mode) {
  const char *res;
  int level = ms->level;
  if (level >= LUA_MAXCAPTURES) luaL_error(ms->L, "too many captures.");
  ms->capture[level].init = s;
  ms->capture[level].len = what;
  ms->level = level+1;
  if ((res=match(ms, s, p, mode)) == NULL)  /* match failed? */
    ms->level--;  /* undo capture */
  return res;
}


const char *end_capture (MatchState *ms, const char *s,
                                  const char *p, int mode) {
  int l = capture_to_close(ms);
  const char *res;
  ms->capture[l].len = s - ms->capture[l].init;  /* close capture */
  if ((res = match(ms, s, p, mode)) == NULL)  /* match failed? */
    ms->capture[l].len = CAP_UNFINISHED;  /* undo capture */
  return res;
}


const char *match_capture (MatchState *ms, const char *s, int l) {
  size_t len;
  l = check_capture(ms, l);
  len = ms->capture[l].len;
  if ((size_t)(ms->src_end-s) >= len &&
      memcmp(ms->capture[l].init, s, len) == 0)
    return s+len;
  else return NULL;
}
/* mode = 1: call from Lua API, mode = 0: call from VM (for properly issueing errors from either API or VM) */

const char *match (MatchState *ms, const char *s, const char *p, int mode) {
  init: /* using goto's to optimize tail recursion */
  switch (*p) {
    case '(': {  /* start capture */
      if (*(p+1) == ')')  /* position capture? */
        return start_capture(ms, s, p+2, CAP_POSITION, mode);
      else
        return start_capture(ms, s, p+1, CAP_UNFINISHED, mode);
    }
    case ')': {  /* end capture */
      return end_capture(ms, s, p+1, mode);
    }
    case L_ESC: {
      switch (*(p+1)) {
        case 'b': {  /* balanced string? */
          s = matchbalance(ms, s, p+2);
          if (s == NULL) return NULL;
          p+=4; goto init;  /* else return match(ms, s, p+4); */
        }
        case 'f': {  /* frontier? */
          const char *ep; char previous;
          p += 2;
          if (*p != '[') {
            if (mode)
              luaL_error(ms->L, "missing " LUA_QL("[") " after "
                               LUA_QL("%%f") " in pattern.");
            else
              luaG_runerror(ms->L, "missing " LUA_QL("[") " after "
                               LUA_QL("%%f") " in pattern.");
          }
          ep = classend(ms, p);  /* points to what is next */
          previous = (s == ms->src_init) ? '\0' : *(s-1);
          if (matchbracketclass(uchar(previous), p, ep-1) ||
             !matchbracketclass(uchar(*s), p, ep-1)) return NULL;
          p=ep; goto init;  /* else return match(ms, s, ep); */
        }
        default: {
          if (isdigit(uchar(*(p+1)))) {  /* capture results (%0-%9)? */
            s = match_capture(ms, s, uchar(*(p+1)));
            if (s == NULL) return NULL;
            p+=2; goto init;  /* else return match(ms, s, p+2) */
          }
          goto dflt;  /* case default */
        }
      }
    }
    case '\0': {  /* end of pattern */
      return s;  /* match succeeded */
    }
    case '$': {
      if (*(p+1) == '\0')  /* is the `$' the last char in pattern? */
        return (s == ms->src_end) ? s : NULL;  /* check end of string */
      else goto dflt;
    }
    default: dflt: {  /* it is a pattern item */
      const char *ep = classend(ms, p);  /* points to what is next */
      int m = s<ms->src_end && singlematch(uchar(*s), p, ep);
      switch (*ep) {
        case '?': {  /* optional */
          const char *res;
          if (m && ((res=match(ms, s+1, ep+1, mode)) != NULL))
            return res;
          p=ep+1; goto init;  /* else return match(ms, s, ep+1); */
        }
        case '*': {  /* 0 or more repetitions */
          return max_expand(ms, s, p, ep, mode);
        }
        case '+': {  /* 1 or more repetitions */
          return (m ? max_expand(ms, s+1, p, ep, mode) : NULL);
        }
        case '-': {  /* 0 or more repetitions (minimum) */
          return min_expand(ms, s, p, ep, mode);
        }
        default: {
          if (!m) return NULL;
          s++; p=ep; goto init;  /* else return match(ms, s+1, ep); */
        }
      }
    }
  }
}


const char *lmemfind (const char *s1, size_t l1,
                               const char *s2, size_t l2) {
  if (l2 == 0) return s1;  /* empty strings are everywhere */
  else if (l2 > l1) return NULL;  /* avoids a negative `l1' */
  else {
    const char *init;  /* to search for a `*s2' inside `s1' */
    l2--;  /* 1st char will be checked by `memchr' */
    l1 = l1-l2;  /* `s2' cannot be found after that */
    while (l1 > 0 && (init = (const char *)memchr(s1, *s2, l1)) != NULL) {
      init++;   /* 1st char is already checked */
      if (memcmp(init, s2+1, l2) == 0)
        return init-1;
      else {  /* correct `l1' and `s1' to try again */
        l1 -= init-s1;
        s1 = init;
      }
    }
    return NULL;  /* not found */
  }
}


static void push_onecapture (MatchState *ms, int i, const char *s,
                                                    const char *e) {
  if (i >= ms->level) {
    if (i == 0)  /* ms->level == 0, too */
      lua_pushlstring(ms->L, s, e - s);  /* add whole match */
    else
      luaL_error(ms->L, "invalid capture index.");
  }
  else {
    ptrdiff_t l = ms->capture[i].len;
    if (l == CAP_UNFINISHED) luaL_error(ms->L, "unfinished capture.");
    if (l == CAP_POSITION)
      lua_pushinteger(ms->L, ms->capture[i].init - ms->src_init + 1);
    else
      lua_pushlstring(ms->L, ms->capture[i].init, l);
  }
}


static int push_captures (MatchState *ms, const char *s, const char *e) {
  int i;
  int nlevels = (ms->level == 0 && s) ? 1 : ms->level;
  luaL_checkstack(ms->L, nlevels, "too many captures");
  for (i = 0; i < nlevels; i++)
    push_onecapture(ms, i, s, e);
  return nlevels;  /* number of strings pushed */
}


static int str_find_aux (lua_State *L, int find) {
  size_t l1, l2;
  const char *s = agn_checklstring(L, 1, &l1);
  const char *p = agn_checklstring(L, 2, &l2);
  ptrdiff_t init = posrelat(agnL_optinteger(L, 3, 1), l1) - 1;
  if (init < 0) init = 0;
  else if ((size_t)(init) > l1) init = (ptrdiff_t)l1;
  if (find && (lua_toboolean(L, 4) ||  /* explicit request? */
      strpbrk(p, SPECIALS) == NULL)) {  /* or no special characters? */
    /* do a plain search */
    const char *s2 = lmemfind(s+init, l1-init, p, l2);
    if (s2) {
      lua_pushinteger(L, s2-s+1);
      lua_pushinteger(L, s2-s+l2);
      return 2;
    }
  }
  else {
    MatchState ms;
    int anchor = (*p == '^') ? (p++, 1) : 0;
    const char *s1=s+init;
    ms.L = L;
    ms.src_init = s;
    ms.src_end = s+l1;
    do {
      const char *res;
      ms.level = 0;
      if ((res=match(&ms, s1, p, 1)) != NULL) {
        if (find) {
          lua_pushinteger(L, s1-s+1);  /* start */
          lua_pushinteger(L, res-s);   /* end */
          return push_captures(&ms, NULL, 0) + 2;
        }
        else
          return push_captures(&ms, s1, res);
      }
    } while (s1++ < ms.src_end && !anchor);
  }
  lua_pushnil(L);  /* not found */
  return 1;
}


static int str_find (lua_State *L) {
  return str_find_aux(L, 1);
}


static int str_match (lua_State *L) {
  return str_find_aux(L, 0);
}


static int gmatch_aux (lua_State *L) {
  MatchState ms;
  size_t ls;
  const char *s = lua_tolstring(L, lua_upvalueindex(1), &ls);
  const char *p = lua_tostring(L, lua_upvalueindex(2));
  const char *src;
  ms.L = L;
  ms.src_init = s;
  ms.src_end = s+ls;
  for (src = s + (size_t)lua_tointeger(L, lua_upvalueindex(3));
       src <= ms.src_end;
       src++) {
    const char *e;
    ms.level = 0;
    if ((e = match(&ms, src, p, 1)) != NULL) {
      lua_Integer newstart = e-s;
      if (e == src) newstart++;  /* empty match? go at least one position */
      lua_pushinteger(L, newstart);
      lua_replace(L, lua_upvalueindex(3));
      return push_captures(&ms, src, e);
    }
  }
  return 0;  /* not found */
}


static int gmatch (lua_State *L) {
  luaL_checkstring(L, 1);
  luaL_checkstring(L, 2);
  lua_settop(L, 2);
  lua_pushinteger(L, 0);
  lua_pushcclosure(L, gmatch_aux, 3);
  return 1;
}


static int gfind_nodef (lua_State *L) {
  return luaL_error(L, LUA_QL("string.gfind") " was renamed to "
                       LUA_QL("string.gmatch") ".");
}


static void add_s (MatchState *ms, luaL_Buffer *b, const char *s,
                                                   const char *e) {
  size_t l, i;
  const char *news = lua_tolstring(ms->L, 3, &l);
  for (i = 0; i < l; i++) {
    if (news[i] != L_ESC)
      luaL_addchar(b, news[i]);
    else {
      i++;  /* skip ESC */
      if (!isdigit(uchar(news[i])))
        luaL_addchar(b, news[i]);
      else if (news[i] == '0')
          luaL_addlstring(b, s, e - s);
      else {
        push_onecapture(ms, news[i] - '1', s, e);
        luaL_addvalue(b);  /* add capture to accumulated result */
      }
    }
  }
}


static void add_value (MatchState *ms, luaL_Buffer *b, const char *s,
                                                       const char *e) {
  lua_State *L = ms->L;
  switch (lua_type(L, 3)) {
    case LUA_TNUMBER:
    case LUA_TSTRING: {
      add_s(ms, b, s, e);
      return;
    }
    case LUA_TFUNCTION: {
      int n;
      lua_pushvalue(L, 3);
      n = push_captures(ms, s, e);
      lua_call(L, n, 1);
      break;
    }
    case LUA_TTABLE: {
      push_onecapture(ms, 0, s, e);
      lua_gettable(L, 3);
      break;
    }
  }
  if (!lua_toboolean(L, -1)) {  /* nil or false? */
    agn_poptop(L);
    lua_pushlstring(L, s, e - s);  /* keep original text */
  }
  else if (!agn_isstring(L, -1))
    luaL_error(L, "invalid replacement value (a %s).", luaL_typename(L, -1));
  luaL_addvalue(b);  /* add result to accumulator */
}


static int str_gsub (lua_State *L) {
  size_t srcl;
  const char *src = luaL_checklstring(L, 1, &srcl);
  const char *p = luaL_checkstring(L, 2);
  int tr = lua_type(L, 3);  /* 5.1.3 patch */
  int max_s = agnL_optinteger(L, 4, srcl+1);
  int anchor = (*p == '^') ? (p++, 1) : 0;
  int n = 0;
  MatchState ms;
  luaL_Buffer b;
  luaL_argcheck(L, tr == LUA_TNUMBER || tr == LUA_TSTRING ||  /* 5.1.2 patch */
                   tr == LUA_TFUNCTION || tr == LUA_TTABLE, 3,
                      "string, procedure, or table expected");
  luaL_buffinit(L, &b);
  ms.L = L;
  ms.src_init = src;
  ms.src_end = src+srcl;
  while (n < max_s) {
    const char *e;
    ms.level = 0;
    e = match(&ms, src, p, 1);
    if (e) {
      n++;
      add_value(&ms, &b, src, e);
    }
    if (e && e>src) /* non empty match? */
      src = e;  /* skip it */
    else if (src < ms.src_end)
      luaL_addchar(&b, *src++);
    else break;
    if (anchor) break;
  }
  luaL_addlstring(&b, src, ms.src_end-src);
  luaL_pushresult(&b);
  lua_pushinteger(L, n);  /* number of substitutions */
  return 2;
}

/* }====================================================== */


/* maximum size of each formatted item (> len(format('%99.99f', -1e308))) */
#define MAX_ITEM   512
/* valid flags in a format specification */
#define FLAGS   "-+ #0"
/*
** maximum size of each format specification (such as '%-099.99d')
** (+10 accounts for %99.99x plus margin of error)
*/
#define MAX_FORMAT   (sizeof(FLAGS) + sizeof(LUA_INTFRMLEN) + 10)


static void addquoted (lua_State *L, luaL_Buffer *b, int arg, int lua) {
  size_t l;
  const char *s = luaL_checklstring(L, arg, &l);
  if (lua) luaL_addchar(b, '"');  /* 0.9.2, 2.4.5 */
  while (l--) {
    switch (*s) {
      case '"': case '\\': case '\n': {
        luaL_addchar(b, '\\');
        luaL_addchar(b, *s);
        break;
      }
      case '\r': {
        luaL_addlstring(b, "\\r", 2);
        break;
      }
      case '\0': {
        luaL_addlstring(b, "\\000", 4);
        break;
      }
      default: {
        luaL_addchar(b, *s);
        break;
      }
    }
    s++;
  }
  if (lua) luaL_addchar(b, '"');  /* 0.9.2, 2.4.5 */
}

static const char *scanformat (lua_State *L, const char *strfrmt, char *form) {
  const char *p = strfrmt;
  while (*p != '\0' && strchr(FLAGS, *p) != NULL) p++;  /* skip flags - Lua 5.1.2 patch */
  if ((size_t)(p - strfrmt) >= sizeof(FLAGS))
    luaL_error(L, "invalid format (repeated flags).");
  if (isdigit(uchar(*p))) p++;  /* skip width */
  if (isdigit(uchar(*p))) p++;  /* (2 digits at most) */
  if (*p == '.') {
    p++;
    if (isdigit(uchar(*p))) p++;  /* skip precision */
    if (isdigit(uchar(*p))) p++;  /* (2 digits at most) */
  }
  if (isdigit(uchar(*p)))
    luaL_error(L, "invalid format (width or precision too long).");
  *(form++) = '%';
  strncpy(form, strfrmt, p - strfrmt + 1);
  form += p - strfrmt + 1;
  *form = '\0';
  return p;
}


static void addintlen (char *form) {
  size_t l = strlen(form);
  char spec = form[l - 1];
  strcpy(form + l - 1, LUA_INTFRMLEN);
  form[l + sizeof(LUA_INTFRMLEN) - 2] = spec;
  form[l + sizeof(LUA_INTFRMLEN) - 1] = '\0';
}


static void changespec (char *form, int isnumber) {  /* 2.4.5 */
  size_t l = strlen(form);
  char spec = form[l - 1];
  if (!isnumber) spec = 'F';
  form[l - 1] = tolower(spec);
}


static int str_format (lua_State *L) {
  int top = lua_gettop(L);
  int arg = 1;
  size_t sfl;
  const char *strfrmt = luaL_checklstring(L, arg, &sfl);
  const char *strfrmt_end = strfrmt + sfl;
  luaL_Buffer b;
  luaL_buffinit(L, &b);
  while (strfrmt < strfrmt_end) {
    if (*strfrmt != L_ESC)
      luaL_addchar(&b, *strfrmt++);
    else if (*++strfrmt == L_ESC)
      luaL_addchar(&b, *strfrmt++);  /* %% */
    else { /* format item */
      char form[MAX_FORMAT];  /* to store the format (`%...') */
      char buff[MAX_ITEM];  /* to store the formatted item */
      if (++arg > top)  /* Lua 5.1.4 patch 7 */
        luaL_argerror(L, arg, "no value");
      strfrmt = scanformat(L, strfrmt, form);
      switch (*strfrmt++) {
        case 'c': {
          sprintf(buff, form, (int)agn_checknumber(L, arg));
          break;
        }
        case 'd':  case 'i': {
          addintlen(form);
          sprintf(buff, form, (LUA_INTFRM_T)agn_checknumber(L, arg));
          break;
        }
        case 'D': {  /* 2.4.5 */
          int isnumber = lua_isnumber(L, arg);
          changespec(form, isnumber);
          addintlen(form);
          if (isnumber)
            sprintf(buff, form, (LUA_INTFRM_T)agn_tonumber(L, arg));
          else
            sprintf(buff, form, (double)AGN_NAN);
          break;
        }
        case 'o':  case 'u':  case 'x':  case 'X': {
          addintlen(form);
          sprintf(buff, form, (unsigned LUA_INTFRM_T)agn_checknumber(L, arg));
          break;
        }
        case 'e':  case 'E': case 'f':
        case 'g': case 'G': {
          sprintf(buff, form, (double)agn_checknumber(L, arg));
          break;
        }
        case 'F': {  /* 2.4.5 */
          int isnumber = lua_isnumber(L, arg);
          changespec(form, isnumber);
          if (isnumber)
            sprintf(buff, form, (double)agn_tonumber(L, arg));
          else
            sprintf(buff, form, (double)AGN_NAN);
          break;
        }
        case 'a': {
          addquoted(L, &b, arg, 0);
          continue;  /* skip the 'addsize' at the end */
        }
        case 'q': {
          addquoted(L, &b, arg, 1);
          continue;  /* skip the 'addsize' at the end */
        }
        case 's': {
          size_t l;
          const char *s = luaL_checklstring(L, arg, &l);
          if (!strchr(form, '.') && l >= 100) {
            /* no precision and string is too long to be formatted;
               keep original string */
            lua_pushvalue(L, arg);
            luaL_addvalue(&b);
            continue;  /* skip the `addsize' at the end */
          }
          else {
            sprintf(buff, form, s);
            break;
          }
        }
        default: {  /* also treat cases `pnLlh' */
          return luaL_error(L, "invalid option " LUA_QL("%%%c") " to "
                               LUA_QL("format") ".", *(strfrmt - 1));
        }
      }
      luaL_addlstring(&b, buff, strlen(buff));
    }
  }
  luaL_pushresult(&b);
  return 1;
}


/*************************************************************************/
/* functions added 0.5.3 and later                                       */
/*************************************************************************/

/* 0.20.0, April 10, 2009; extended January 23, 2010, 0.30.4; modified September 10, 2011, 1.5.0;
   tuned and Valgrind-fixed 1.6.0 */
static int str_isabbrev (lua_State *L) {
  size_t p_len, s_len;
  int pos;
  MatchState ms;
  const char *s, *s1, *p;
  const char *res;
  s = agn_checklstring(L, 1, &s_len);
  p = agn_checklstring(L, 2, &p_len);
  if (p_len == 0 || s_len == 0) {
    /* bail out if string or pattern is empty or if pattern is longer or equal in size */
    lua_pushfalse(L);
    return 1;
  }
  if (lua_toboolean(L, 3) ||  /* explicit request? */
      strpbrk(p, SPECIALS) == NULL) {  /* or no special characters? Agena 1.3.2 */
    pos = strncmp(s, p, p_len);
    lua_pushboolean(L, pos == 0 && p_len < s_len);
    return 1;
  }
  p++;
  s1 = s;
  ms.L = L;
  ms.src_init = s;
  ms.src_end = s + s_len;
  ms.level = 0;
  if ((res = match(&ms, s1, p, 1)) != NULL)
    lua_pushtrue(L);
  else
    lua_pushfalse(L);
  return 1;
}


/* modified September 10, 2011, 1.5.0; tuned and Valgrind-fixed 1.6.0 */

static int str_isending (lua_State *L) {
  size_t p_len, s_len;
  MatchState ms;
  const char *s, *s1, *p;
  s = agn_checklstring(L, 1, &s_len);
  p = agn_checklstring(L, 2, &p_len);
  if (p_len == 0 || s_len == 0) {
    /* bail out if string or pattern is empty or if pattern is longer or equal in size */
    lua_pushfalse(L);
    return 1;
  }
  if (lua_toboolean(L, 3) ||  /* explicit request? */
      strpbrk(p, SPECIALS) == NULL) {  /* or no special characters?  Agena 1.3.2 */
    s = s + s_len - p_len;
    lua_pushboolean(L, strstr(s, p) == s && p_len < s_len);  /* Agena 1.6.0 */
    return 1;
  }
  s1 = s;
  ms.L = L;
  ms.src_init = s;
  ms.src_end = s + s_len;
  do {
    const char *res;
    ms.level = 0;
    if ((res = match(&ms, s1, p, 1)) != NULL) {
      lua_pushtrue(L);
      return 1;
    }
  } while (s1++ < ms.src_end);
  lua_pushfalse(L);
  return 1;
}


static int str_ismagic (lua_State *L) {  /* October 12, 2006; tuned December 16, 2007; changed November 01, 2008,
  optimised January 15, 2011; changed December 27, 2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {  /* 2.3.4 fix */
    lua_pushtrue(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if ( tools_alphadia[uchar(*s) + 1] & (__ALPHA | __DIACR) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushfalse(L);
  return 1;
}


static int str_islatin (lua_State *L) {  /* October 12, 2006; tuned December 16, 2007 */
  unsigned char token;
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    token = uchar(*s);
    if ((token < 'a' || token > 'z') && (token < 'A' || token > 'Z')) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_islatinnumeric (lua_State *L) {  /* based upon isAlphaNumeric; June 13, 2009 */
  unsigned char token;
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    token = uchar(*s);
    if ((token < 'a' || token > 'z') && (token < 'A' || token > 'Z') && ((token < '0' || token > '9'))) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isnumber (lua_State *L) {  /* April 22, 2007; tuned December 16, 2007 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (uchar(*s) < '0' || uchar(*s) > '9') {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isfloat (lua_State *L) {  /* January 23, 2010, 0.30.4; tweaked January 15, 2011, 1.3.2 */
  size_t l;
  const char *s = agn_checklstring(L, 1, &l);
  struct lconv *cv = localeconv();
  char decpoint = (cv ? cv->decimal_point[0] : '.');
  int flag = 1;
  for ( ; *s != '\0'; s++) {
    if (uchar(*s) < '0' || uchar(*s) > '9') {
      if (uchar(*s) == decpoint && flag && !(l == 1))
        flag = 0;
      else {
        lua_pushfalse(L);
        return 1;
      }
    }
  }
  lua_pushboolean(L, flag == 0);
  return 1;
}


static int str_isnumeric (lua_State *L) {  /* 26.08.2012, Agena 1.7.7 */
  agn_pushboolean(L, tools_isnumericstring(agn_checkstring(L, 1)));
  return 1;
}


static int str_iscenumeric (lua_State *L) {  /* 26.08.2012, Agena 1.7.7 */
  size_t l;
  const char *s = agn_checklstring(L, 1, &l);
  int flag = 1;
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (uchar(*s) < '0' || uchar(*s) > '9') {
      if (uchar(*s) == ',' && flag && !(l == 1))
        flag = 0;
      else {
        lua_pushfalse(L);
        return 1;
      }
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isnumberspace (lua_State *L) {  /* June 29, 2007; tuned December 16, 2007 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ;*s != '\0'; s++) {
    if ((uchar(*s) < '0' || uchar(*s) > '9') && uchar(*s) != ' ') {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isspace (lua_State *L) {  /* Agena 1.8.0, September 25, 2012 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ;*s != '\0'; s++) {
    if (uchar(*s) != ' ') {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isisospace (lua_State *L) {  /* 31.12.2012 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!isISOspace(*s)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isblank (lua_State *L) {  /* Agena 1.8.0, September 25, 2012; extended 2.3.4, December 27, 2014 */
  const char *s = agn_checkstring(L, 1);
  int option = agnL_optboolean(L, 2, 0);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  if (option) {
    for ( ; *s != '\0'; s++) {
      if (!(tools_charmap[uchar(*s) + 1] & __BLANK)) {
        lua_pushfalse(L);
        return 1;
      }
    }
  } else {
    for ( ; *s != '\0'; s++) {
      if (!(uchar(*s) == ' ' || uchar(*s) == '\t')) {
        lua_pushfalse(L);
        return 1;
      }
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_ishex (lua_State *L) {  /* 2.3.4, December 27, 2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!(tools_charmap[uchar(*s) + 1] & __HEXAD)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isalpha (lua_State *L) {  /* October 12, 2006, extended May 17, 2007; tuned December 16, 2007;
  changed November 01, 2008; changed December 27, 2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if ( !(tools_alphadia[uchar(*s) + 1] & (__ALPHA | __DIACR)) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isspec (lua_State *L ) {  /* 1.10.6, 11.04.2013; 2.3.4, 26.12.2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!(tools_charmap[uchar(*s) + 1] & __PUNCT)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_iscontrol (lua_State *L ) {  /* 2.3.4, 27.12.2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!(tools_charmap[uchar(*s) + 1] & __CNTRL)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isprintable (lua_State *L ) {  /* 2.3.4, 27.12.2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!(tools_charmap[uchar(*s) + 1] & __PRINT)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isalphaspec (lua_State *L) {  /* 1.10.6, 11.04.2013; 2.3.4, 26.12.2014 */
  const char *s = agn_checkstring(L, 1);
  unsigned short int token = uchar(*s) + 1;
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!( (tools_charmap[token] & __PUNCT) ||
           (tools_alphadia[token] & (__ALPHA | __DIACR)) ) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isisoalpha (lua_State *L) {  /* December 31, 2012 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!isISOalpha(*s)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isalphaspace (lua_State *L) {  /* June 28, 2007; tuned December 16, 2007; changed 2.3.4, 26.12.2014 */
  unsigned short int token;
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    token = uchar(*s);
    if ( !( (tools_alphadia[token + 1] & ( __ALPHA | __DIACR)) || token == ' ' ) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_islowerlatin (lua_State *L) {  /* April 30, 2007; tuned December 16, 2007 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (uchar(*s) < 'a' || uchar(*s) > 'z') {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isloweralpha (lua_State *L) {  /* November 09, 2008; changed December 27, 2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if ( !(tools_charmap[uchar(*s) + 1] & __LOWER) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isisolower (lua_State *L) {  /* December 31, 2012 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!isISOlower(*s)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isupperlatin (lua_State *L) {  /* 0.21.0, April 19, 2009 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (uchar(*s) < 'A' || uchar(*s) > 'Z') {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isupperalpha (lua_State *L) {  /* 0.21.0, April 19, 2009; 2.3.4 December 27, 2014 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if ( !(tools_charmap[uchar(*s) + 1] & __UPPER) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isisoupper (lua_State *L) {  /* 31.12.2012 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!isISOupper(*s)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isalphanumeric (lua_State *L) {  /* October 12, 2006; extended May 17, 2007; tuned December 16, 2007; 2.3.4 December 27, 2014 */
  unsigned short int token;
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    token = uchar(*s);
    if ( !( (tools_alphadia[token + 1] & ( __ALPHA | __DIACR )) || (token >= '0' && token <= '9') ) ) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_isisoprint (lua_State *L) {  /* 31.12.2012 */
  const char *s = agn_checkstring(L, 1);
  if (*s == '\0') {
    lua_pushfalse(L);
    return 1;
  }
  for ( ; *s != '\0'; s++) {
    if (!isISOprint(*s)) {
      lua_pushfalse(L);
      return 1;
    }
  }
  lua_pushtrue(L);
  return 1;
}


static int str_rtrim (lua_State *L) {
  size_t l;
  const char *s = agn_checklstring(L, 1, &l);
  const char *d = luaL_optstring(L, 2, " ");
  while (l > 0 && uchar(s[l-1]) == *d) l--;
  lua_pushlstring(L, s, l);
  return 1;
}


static int str_ltrim (lua_State *L) {
  const char *s = agn_checkstring(L, 1);
  const char *d = luaL_optstring(L, 2, " ");
  /* 0.13.4 patch; do not optimize `while (*s == ' ') s++` to `while (*s++ == ' ')` ! */
  while (*s == *d) s++;
  lua_pushstring(L, s);
  return 1;
}


/* 1.11.2, delete leading and trailing white spaces or the given given leading o trailing character */
static int str_lrtrim (lua_State *L) {
  const char *s, *d;
  size_t l;
  s = agn_checklstring(L, 1, &l);
  d = luaL_optstring(L, 2, " ");
  while (*s == *d) {s++; l--;};  /* remove leading spaces */
  while (l > 0 && uchar(s[l-1]) == *d) l--;   /* remove trailing spaces */
  lua_pushlstring(L, s, l);
  return 1;
}


static int str_isolower (lua_State *L) {  /* 31.12.2012 */
  luaL_Buffer b;
  const char *s = luaL_checkstring(L, 1);
  luaL_buffinit(L, &b);
  while (*s != '\0') { luaL_addchar(&b, toISOlower(*s)); s++; };
  luaL_pushresult(&b);
  return 1;
}


static int str_isoupper (lua_State *L) {  /* 31.12.2012 */
  luaL_Buffer b;
  const char *s = luaL_checkstring(L, 1);
  luaL_buffinit(L, &b);
  while (*s != '\0') { luaL_addchar(&b, toISOupper(*s)); s++; }
  luaL_pushresult(&b);
  return 1;
}


/* Applies a function f to the ASCII value of each character in string str and returns a new string. The function
   must return an integer in the range 0 .. 255, otherwise an error is issued. */

static int str_transform (lua_State *L) {  /* 31.12.2012 */
  luaL_Buffer b;
  const char *s;
  lua_Number x;
  int firstarg;
  firstarg = lua_type(L, 1);
  luaL_typecheck(L, firstarg == LUA_TFUNCTION, 1, "procedure expected", firstarg);
  s = luaL_checkstring(L, 2);
  luaL_buffinit(L, &b);
  while (*s != '\0') {
    lua_pushvalue(L, 1);  /* push function */
    lua_pushinteger(L, *s);
    lua_call(L, 1, 1);
    if (!agn_isnumber(L, -1))
      luaL_error(L, "Error in " LUA_QS ": function must return a number, got %s.", "strings.transform",
        luaL_typename(L, -1));
    x = agn_tonumber(L, -1);
    agn_poptop(L);
    if (x < 0 || x > 255 || ISFLOAT(x))
      luaL_error(L, "Error in " LUA_QS ": function must return an integer in 0 .. 255.", "strings.transform");
    luaL_addchar(&b, x);
    s++;
  }
  luaL_pushresult(&b);
  return 1;
}


static int str_hits (lua_State *L) {
  size_t l1, l2;
  const char *s1;
  const char *src = agn_checklstring(L, 1, &l1);
  const char *p = agn_checklstring(L, 2, &l2);
  size_t n = 0;
  int init = 0;
  if (l2 == 0) {  /* else infinite loop */
    lua_pushnumber(L, 0);
    return 1;
  }
  if (lua_toboolean(L, 3) ||  /* Agena 1.3.2: explicit request? */
      strpbrk(p, SPECIALS) == NULL) {  /* or no special characters? */
    while (1) {
      s1 = lmemfind(src+init, l1-init, p, l2);
      if (s1) {
        init += (s1-(src+init)) + l2;
        n++;
      } else
        break;
    }
  } else {  /* Agena 1.3.2 */
    int anchor;
    MatchState ms;
    anchor = (*p == '^') ? (p++, 1) : 0;
    s1 = src;
    ms.L = L;
    ms.src_init = src;
    ms.src_end = src + l1;
    do {
      const char *res;
      ms.level = 0;
      if ((res=match(&ms, s1, p, 1)) != NULL) n++;
    } while (s1++ < ms.src_end && !anchor);
  }
  lua_pushnumber(L, (lua_Number)n);
  return 1;
}


/* 0.14.0 as of April 08, 2009, inspired by the REXX function `words`; the Regina REXX interpreter
   features a very elegant and shorter C implementation, but it is not faster. */
static int str_words (lua_State *L) {
  size_t i, len;
  int c, flag;
  const char *s = agn_checklstring(L, 1, &len);
  const char *d = luaL_optstring(L, 2, " ");
  flag = lua_toboolean(L, 3);  /* changed 1.5.1: explicit request to ignore succeeding delimitors ? */
  i = c = 0;
  while (flag && *s == *d) { s++; i++; }  /* skip leading delimitors */
  if ((i == len-1 && i != 0) || len == 0)  /* string consists entirely of delimitors or is empty ? */
    c = -1;  /* do not count anything */
  else {
    for (; *s != '\0'; i++, s++) {
      if (*s == *d) {
        if (flag && *(s+1) != *d) { c++; continue; };
        if (!flag) c++;
      }
    }
    s--;  /* step back one character */
    /* if it ends with a delimitor, decrement c because it was already counted in the loop above */
    if (flag && *s == *d) c--;
  }
  lua_pushnumber(L, c+1);
  return 1;
}


/* 0.20.0, inspired by the REXX function `delstr`; patched 1.10.0 */
static int str_remove (lua_State *L) {
  size_t pos, origlen;
  long int offset, nchars;
  const char *orig;
  orig = agn_checklstring(L, 1, &origlen);
  pos = posrelat(agnL_checkint(L, 2), origlen) - 1;  /* 2nd argument is the position */
  nchars = agnL_optinteger(L, 3, 1);  /* number of characters to be deleted, Agena 1.10.0 */
  if (nchars < 1)
    luaL_error(L, "in " LUA_QL("strings.remove") ": third argument must be positive.");
  if (pos < 0 || pos >= origlen)
    luaL_error(L, "in " LUA_QL("strings.remove") ": index %d out of range.", pos + 1);
  offset = pos + nchars;
  if (offset > origlen) offset = origlen;  /* avoid invalid accesses beyond the lenght of the string */
  /* directly writing the string is slower, e.g. using concat and substr(l) ! */
  lua_pushlstring(L, orig, pos);  /* push left part of original string */
  lua_pushstring(L, orig+offset);  /* push rest of original string */
  lua_concat(L, 2);
  return 1;
}


/* 1.2.0, inspired by the REXX function `delstr` (i.e. its counterpart `delstr`) */
static int str_include (lua_State *L) {
  size_t pos, origlen, newstrlen;
  const char *orig, *newstr;
  orig = agn_checklstring(L, 1, &origlen);
  pos = posrelat(agnL_checkint(L, 2), origlen);  /* 2nd argument is the position */
  newstr = agn_checklstring(L, 3, &newstrlen);
  if (pos < 1 || pos > origlen + 1)  /* 1.5.0 patch */
    luaL_error(L, "in " LUA_QL("strings.include") ": index %d out of range.", pos);
  /* directly writing the string is slower, e.g. using concat and substr(l) ! */
  lua_pushlstring(L, orig, pos-1);  /* push left part of original string */
  lua_pushlstring(L, newstr, newstrlen);
  lua_pushstring(L, orig+pos-1);  /* push rest of original string */
  lua_concat(L, 3);
  return 1;
}


/* 1.5.1, 14.11.2011, exract the given fields in the given order from a string;
   extended 2.0.0 RC4 to support sequences */
static int str_fields (lua_State *L) {
  const char *e, *s, *s1, *sep;
  int flag, isseq;
  size_t c, i, nargs, n, l1, l2, init;
  lua_Integer *inds, index;
  c = init = n = 0;  /* position of token in string */
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  if (nargs < 2)
    luaL_error(L, "in " LUA_QL("strings.fields") ": expected at least two arguments.");
  s = agn_checklstring(L, 1, &l1);
  if ((flag = agn_isstring(L, nargs)))
    sep = agn_tostring(L, nargs);
  else
    sep = " ";
  if (nargs == 2 && flag)
    luaL_error(L, "in " LUA_QL("strings.fields") ": expected at least one index.");
  l2 = strlen(sep);
  isseq = lua_isseq(L, 2);  /* 2.0.0 RC4 */
  if (isseq) {
    nargs = agn_seqsize(L, 2);
    if (nargs == 0)
      luaL_error(L, "in " LUA_QL("strings.fields") ": expected at least one index in sequence.");
  } else
    nargs =  nargs - flag - 1;  /* if last argument is an optional delimiter, do not process it */
  agn_createseq(L, nargs);
  if (l2 == 0 || strcmp(s, sep) == 0) return 1;  /* delimter is the empty string or delimiter has not been found in string ?  */
  while (1) {  /* determine number of words */
    s1 = lmemfind(s+init, l1-init, sep, l2);
    if (s1) {
      init += (s1-(s+init)) + l2;
      n++;
    } else
      break;
  }
  n++;
  /* put all indices passed in the call into an array (this may not be an ellegant implementation but it saves memory) */
  inds = agn_malloc(L, nargs*sizeof(lua_Integer), "strings.fields", NULL);  /* 1.9.1 */
  if (isseq) {
    for (i=1; i <= nargs; i++) {
      index = lua_seqgetinumber(L, 2, i);
      if (index < 0) index += n + 1;
      if (index <= 0 || index > n)
        luaL_error(L, "in " LUA_QL("strings.fields") ": index %d out of range.", index);
      inds[i-1] = index;
      lua_pushstring(L, "");  /* fill sequence with empty strings for it might be later be filled in non-ascending field order */
      lua_seqseti(L, -2, i);
    }
  } else {
    for (i=1; i <= nargs; i++) {
      index = agn_checkinteger(L, i+1);
      if (index < 0) index += n + 1;
      if (index <= 0 || index > n)
        luaL_error(L, "in " LUA_QL("strings.fields") ": index %d out of range.", index);
      inds[i-1] = index;
      lua_pushstring(L, "");  /* fill sequence with empty strings for it might be later be filled in non-ascending field order */
      lua_seqseti(L, -2, i);
    }
  }
  /* collect all matching tokens into a sequence */
  while ((e=strstr(s, sep)) != NULL) {
    c++;
    for (i=0; i < nargs; i++) {
      if (inds[i] == c) {
        lua_pushlstring(L, s, e-s);
        lua_seqseti(L, -2, i+1);
      }
    }
    s = e + l2;
  }
  /* process last token */
  if (strlen(s) != 0) {  /* not the empty string ? */
    c++;
    for (i=0; i < nargs; i++) {
      if (inds[i] == c) {
        lua_seqsetistring(L, -1, i+1, s);
      }
    }
  }
  /* now return the respective fields */
  xfree(inds);
  return 1;
}



/*************************************************************************************************
  Implementation of Damerau-Levenshtein Distance, a blend of code written by
  Lorenzo Seidenari (sixmoney [guess-what] virgilio [guess-what] it) and Anders Sewerin Johansen
  Agena 1.6.0, May 18, 2012
**************************************************************************************************/

/* the minimum of three values */
static int minimum (int a, int b, int c) {
  int min = a;
  if (b < min) min = b;
  if (c < min) min = c;
  return min;
}


static int str_dleven (lua_State *L) {
  /* Step 1 */
  int k, i, j, cost, *d, distance;
  size_t n, m;
  const char *s = agn_checklstring(L, 1, &n);
  const char *t = agn_checklstring(L, 2, &m);
  distance = 0;
  if (n != 0 && m != 0) {
    m++;
    n++;
    d = agn_malloc(L, (sizeof(int))*(m*n), "strings.dleven", NULL);  /* 1.9.1 */
    /* Step 2 */
    for (k=0; k < n; k++) d[k]=k;
    for (k=0; k < m; k++) d[k*n]=k;
    /* Step 3 and 4 */
    for (i=1; i < n; i++) {
      for (j=1; j < m; j++) {
        /* Step 5 */
        if (s[i-1] == t[j-1])
          cost = 0;
        else
          cost = 1;
        /* Step 6 */
        distance = minimum(d[(j - 1)*n + i] + 1, d[j*n + i - 1] + 1, d[(j - 1)*n + i - 1] + cost);
        /* Step 6A: Cover transposition, in addition to deletion, insertion and substitution. This step is taken from:
           Berghel, Hal ; Roach, David : "An Extension of Ukkonen's Enhanced Dynamic Programming ASM Algorithm"
           (http://www.acm.org/~hlb/publications/asm/asm.html) */
        if (i > 2 && j > 2) {
          /* int trans = d[(i-2)*(j-2)] + 1; */
          int trans = d[(j - 2)*n+(i - 2)] + 1;
          if (s[i - 2] != t[j - 1]) trans++;
          if (s[i - 1] != t[j - 2]) trans++;
          if (distance > trans) distance = trans;
        }
        d[j*n+i] = distance;
      }
    }
    distance = d[n*m - 1];
    xfree(d);
    lua_pushinteger(L, distance);
  }
  else {  /* undefined means that one or both strings are empty. */
    lua_pushnumber(L, AGN_NAN);  /* 2.4.5 change */
  }
  return 1;
}

/* Creates a dynamically allocated copy of a string, changing the encoding from ISO-8859-15 to UTF-8. */

static int str_toutf8 (lua_State *L) {
  char *r;
  r = latin9_to_utf8(agn_checkstring(L, 1));
  if (r == NULL)
    luaL_error(L, "in " LUA_QL("strings.toutf8") ": memory allocation error.");
  lua_pushstring(L, (const char*)r);
  xfree(r);
  return 1;
}


/* Creates a dynamically allocated copy of a string, changing the encoding from UTF-8 to ISO-8859-1/15.
   Unsupported code points are ignored. */

static int str_tolatin (lua_State *L) {
  char *r;
  r = utf8_to_latin9(agn_checkstring(L, 1));
  if (r == NULL)
    luaL_error(L, "in " LUA_QL("strings.tolatin") ": memory allocation error.");
  lua_pushstring(L, (const char*)r);
  xfree(r);
  return 1;
}


/* detects that the given string is in UTF-8 encoding */

static int str_isutf8 (lua_State *L) {
  int flag;
  const char *str;
  str = agn_checkstring(L, 1);
  flag = 0;
  lua_pushboolean(L, is_utf8(str));
  while (*str != '\0') {
    if ((*str & 0xc0) == 0x80) { flag = 1; break; }
    str++;
  }
  lua_pushboolean(L, flag);
  return 2;
}


/* determines the size of an UTF-8 string */

static int str_utf8size (lua_State *L) {
  lua_pushnumber(L, size_utf8(agn_checkstring(L, 1)));
  return 1;
}


static int str_glob (lua_State *L) {  /* extended 2.3.4 */
  char *str, *pat;
  int insensitive;
  str = (char *)agn_checkstring(L, 1);
  pat = (char *)agn_checkstring(L, 2);
  insensitive = agnL_optboolean(L, 3, 0);
  if (insensitive) {
    size_t i;
    for (i=0; i < strlen(str); i++) str[i] = tools_lowercase[uchar(str[i])];
    for (i=0; i < strlen(pat); i++) pat[i] = tools_lowercase[uchar(pat[i])];
  }
  agn_pushboolean(L, glob((const char*)pat, (const char*)str));
  return 1;
}


/* str_capitalise: The function is 30% faster than an Agena implementation. */

static int str_capitalise (lua_State *L) {  /* 1.10.0 */
  const char *str;
  size_t size;
  char r[2];
  str = agn_checklstring(L, 1, &size);
  if (size == 0) {
    lua_pushstring(L, "");
    return 1;
  }
  r[0] = tools_uppercase[uchar(*str)]; r[1] = '\0';
  if (size == 1)
    lua_pushstring(L, r);
  else {
    str++;
    /* the following statements are 5 % faster than calling agnhlps.c/concat */
    lua_pushstring(L, r);
    lua_pushstring(L, str);
    lua_concat(L, 2);
  }
  return 1;
}


/* 1.10.2, just to play around, remains undocumented, call strings.hash(str, << x -> x shift 5 + x >>, numberofwords, 5381); */
static int str_hash (lua_State *L) {
  const char *str;
  int c;
  unsigned long size, h;
  str = agn_checkstring(L, 1);
  luaL_argcheck(L, lua_type(L, 1) == LUA_TFUNCTION, 2, "procedure expected");
  size = agn_checknumber(L, 3);
  h = agnL_optnumber(L, 4, 5381);
  while ((c = uchar(*str++))) {
    lua_pushvalue(L, 2);
    lua_pushnumber(L, h);
    lua_call(L, 1, 1);
    if (!agn_isnumber(L, -1))
      luaL_error(L, "Error in " LUA_QS ": function return is not a number.", "strings.hash");
    h = agn_tonumber(L, -1) + c;
    agn_poptop(L);
  }
  lua_pushnumber(L, h);
  lua_pushnumber(L, h % size);
  return 2;
}


static int str_separate (lua_State *L) {
  size_t c, l;
  const char *string, *delim;
  char *result, *str;
  string = agn_checkstring(L, 1);
  delim = agn_checklstring(L, 2, &l);
  if (l == 0) {
    lua_pushfail(L);
    return 1;
  }
  str = strdup(string);
  if (str == NULL) {
    luaL_error(L, "Error in " LUA_QS ": memory allocation failed.", "strings.separate");
  }
  result = strtok(str, delim);
  if (result == NULL) {
    lua_pushfail(L);
    goto bailout;
  }
  c = 1;
  agn_createseq(L, 10);
  lua_seqsetistring(L, -1, c, result);
  while ((result = strtok(NULL, delim)) != NULL)
    lua_seqsetistring(L, -1, ++c, result);

bailout:
  xfree(str);
  return 1;
}


/* strings.diffs: returns the differences between two strings: substitutions, transpositions, deletions,
   and insertions.

   By default, both strings must contains at least three characters. You may change this by passing any other
   positive number as the optional third argument. The function returns `fail` if at least one of the strings
   consists of less characters.

   If any fourth argument is given, the return is a sequence of strings describing the respective difference
   found, otherwise the returns is the number of the differences encountered.

   written July 24, 2007; tuned December 15, 2007; patched January 05, 2008 with correct determination of diffs,
   patched October 10, 2011 for correct results with equal sized strings; extended 2.4.5, March 08, 2015 */

static int str_diffs (lua_State *L) {
  size_t i, j, last, noffsets, option, nstr1, nstr2, c;
  const char *str1 = agn_checklstring(L, 1, &nstr1);
  const char *str2 = agn_checklstring(L, 2, &nstr2);
  int minNumber = luaL_optint(L, 3, 3);
  if (minNumber < 1)
    luaL_error(L, "Error in " LUA_QS ": third argument must be positive.", "strings.diffs");
  option = lua_gettop(L) > 3;
  if (nstr1 < minNumber || nstr2 < minNumber) {
    lua_pushfail(L);
    return 1;
  }
  last = (nstr1 > nstr2) ? nstr2 : nstr1;
  i = j = noffsets = c = 0;
  if (option) agn_createseq(L, 0);
  while (i < last && j < last) {  /* both i and j must be checked ! Invalid subscripts and crashes otherwise */
    if (uchar(str1[i]) != uchar(str2[j])) {
      if (uchar(str1[i+1]) == uchar(str2[j]) && uchar(str1[i]) == uchar(str2[j+1])) {
        /* transposition */
        i += 2; j += 2; c++;
        if (option) lua_seqsetistring(L, -1, c, "transposition");
        continue;
      }
      else if (uchar(str1[i+1]) == uchar(str2[j])) {
        /* insertion */
        i += 2; j++; c++;
        if (option) lua_seqsetistring(L, -1, c, "insertion");
        noffsets++;
        continue;
      }
      else if (uchar(str1[i]) == uchar(str2[j+1])) {
        /* deletion */
        i++; j += 2; c++;
        if (option) lua_seqsetistring(L, -1, c, "deletion");
        noffsets++;
        continue;
      }
      else if (uchar(str1[i+1]) == uchar(str2[j+1])) {
        /* substitution */
        i += 2; j += 2; c++;
        if (option) lua_seqsetistring(L, -1, c, "substitution");
        continue;
      } else {  /* should not happen */
        c++;
        if (option) lua_seqsetistring(L, -1, c, "other");
      }
    }
    i++; j++;
  }
  if (option && nstr1 != nstr2) {  /* lua_seqsetistring is a multiline-macro */
    for (i=0; i < abs(nstr1 - nstr2); i++)
      lua_seqsetistring(L, -1, ++c, "deletion");
  } else
    lua_pushnumber(L, c + ((nstr1 - nstr2 == 0) ? 0 : abs(nstr1 - nstr2) - noffsets));  /* October 10, 2011 */
  return 1;
}


/* Table of characters: decimal, hex, character
	65, 41 a	66, 42 b	67, 43 c	68, 44 d	69, 45 e	70, 46 f	71, 47 g
	72, 48 h	73, 49 i	74, 4A j	75, 4B k	76, 4C l	77, 4D m	78, 4E n
	79, 4F o	80, 50 p	81, 51 q	82, 52 r	83, 53 s	84, 54 t	85, 55 u
	86, 56 v	87, 57 w	88, 58 x	89, 59 y	90, 5A z

   Phonetic mapping (not downward-compatible to Soundex since w is regarded a vowel):

   'a', 'e', 'i', 'o', 'u', 'y', 'h', diacritics -> '#'
   'b', 'p'                                      -> 'P'
   'f', 'v', 'w'                                 -> 'F'
   'd', 't'                                      -> 'T'
   'm', 'n'                                      -> 'N'
   'l'                                           -> 'L'
   'r'                                           -> 'R'
   'j'                                           -> 'J'
   'c', 'k', 'q', 'g'                            -> 'K'
   's', 'z', 'x'                                 -> 'S' */

static unsigned char phQmap[256] = {
   0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,  /* 0 .. 7*/
   0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,  /* 8 .. 15 */
   0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,  /* 16 .. 23 */
   0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f,  /* 24 .. 31 */
   0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27,  /* 32 .. 39 */
   0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f,  /* 40 .. 47 */
   0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,  /* 48 .. 55 */
   0x38, 0x39, 0x3a, 0x3b, 0x3c, 0x3d, 0x3e, 0x3f,  /* 56 .. 63 */
   0x40, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,  /* 64 .. 71 */
   0x48, 0x49, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f,  /* 72 .. 79 */
   0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57,  /* 80 .. 87 */
   0x58, 0x59, 0x5a, 0x5b, 0x5c, 0x5d, 0x5e, 0x5f,  /* 88 .. 95 */
   0x60, 0x23, 0x50, 0x4b, 0x54, 0x23, 0x46, 0x4b,  /* 96 .. 103 */
/* 096`  097a  098b  099c  100d  101e  102f  103g */
   0x23, 0x23, 0x4a, 0x4b, 0x4c, 0x4e, 0x4e, 0x23,  /* 104 .. 111 */
/* 104h  105i  106j  107k  108l  109m  110n  111o */
   0x50, 0x4b, 0x52, 0x53, 0x54, 0x23, 0x46, 0x46,  /* 112 .. 119 */
/* 112p  113q  114r  115s  116t  117u  118v  119w */
   0x53, 0x23, 0x53, 0x7b, 0x7c, 0x7d, 0x7e, 0x7f,  /* 120 .. 127 */
/* 120x  121y  122z  123{  124|  125}  126~  127� */
   0x40, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x40,  /* 128 .. 135 */
/* 128�  129�  130�  131�  132�  133�  134�  135� */
   0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23,  /* 136 .. 143 */
/* 136�  137�  138�  139�  140�  141�  142�  143� */
   0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23,  /* 144 .. 151 */
/* 144�  145�  146�  147�  148�  149�  150�  151� */
   0x23, 0x23, 0x23, 0x23, 0x9c, 0x9d, 0x9e, 0x9f,  /* 152 .. 159 */
/* 152�  153�  154�  155�  156�  157�  158�  159� */
   0x23, 0x23, 0x23, 0x23, 0xa4, 0xa5, 0xa6, 0xa7,  /* 160 .. 167 */
/* 160�  161�  162�  163�  164�  165�  166�  167� */
   0xa8, 0xa9, 0xaa, 0xab, 0xac, 0xad, 0xae, 0xaf,  /* 168 .. 175 */
/* 168�  169�  170�  171�  172�  173�  174�  175� */
   0xb0, 0xb1, 0xb2, 0xb3, 0xb4, 0x23, 0x23, 0x23,  /* 176 .. 183 */
/* 176�  177�  178�  179�  180�  181�  182�  183� */
   0xb8, 0xb9, 0xba, 0xbb, 0xbc, 0xbd, 0xbe, 0xbf,  /* 184 .. 191 */
/* 184�  185�  186�  187+  188+  189�  190�  191+ */
   0xc0, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0x23, 0x23,  /* 192 .. 199 */
/* 192+  193-  194-  195+  196-  197+  198�  199� */
   0xc8, 0xc9, 0xca, 0xcb, 0xcc, 0xcd, 0xce, 0xcf,  /* 200 .. 207 */
/* 200+  201+  202-  203-  204�  205-  206+  207� */
   0xe8, 0xe8, 0x23, 0x23, 0x23, 0x23, 0x23, 0x23,  /* 208 .. 215 */
/* 208�  209�  210�  211�  212�  213i  214�  215� */
   0x23, 0xd9, 0xda, 0xdb, 0xdc, 0xdd, 0x23, 0xdf,  /* 216 .. 223 */
/* 216�  217+  218+  219�  220_  221�  222�  223� */
   0x23, 0x53, 0x23, 0x23, 0x23, 0x23, 0xe6, 0xe8,  /* 224 .. 231 */
/* 224�  225�  226�  227�  228�  229�  230�  231� */
   0xe8, 0x23, 0x23, 0x23, 0x23, 0x23, 0xee, 0xef,  /* 232 .. 239 */
/* 232�  233�  234�  235�  236�  237�  238�  239� */
   0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,  /* 240 .. 247 */
/* 240�  241�  242=  243�  244�  245�  246�  247� */
   0xf8, 0xf9, 0xfa, 0xfb, 0xfc, 0xfd, 0xfe, 0xff   /* 248 .. 255 */
/* 248�  249�  250�  251�  252�  253�  254�  255 */
};


static int str_phonetiqs (lua_State *L) {  /* October 18, 2008; extended 2.4.5, March 09, 2015 */
  size_t l, i, pos;
  int maxlen, novowels;
  unsigned char c;
  const char *str;
  char *result;
  str = agn_checklstring(L, 1, &l);
  novowels = agnL_optboolean(L, 2, 1);
  maxlen = luaL_optinteger(L, 3, l);
  if (maxlen < 1 || maxlen > l)
    luaL_error(L, "Error in " LUA_QS ": second argument %d is out-of-range.", "strings.phonetiqs", maxlen);
  result = (char *)malloc(sizeof(char)*(l + 1));
  for (i=0; i < l; i++)
    result[i] = phQmap[uchar(str[i])];
  result[i] = '\0';
  pos = 0;
  /* this is faster than comparing and inserting a value into the array in only one loop */
  for (i=1; i < l; i++) {
    c = result[i];
    if (((novowels && c != '#') || !novowels) && (c != result[i-1])) result[++pos] = c;
  }
  result[++pos] = '\0';
  lua_pushlstring(L, result, (pos < maxlen) ? pos : maxlen);
  xfree(result);
  return 1;
}


static const luaL_Reg strlib[] = {
  {"capitalise", str_capitalise},         /* added on February 28, 2013 */
  {"dleven", str_dleven},                 /* added on October 10, 2011 */
  {"diffs", str_diffs},                   /* added on March 08, 2015 */
  {"dump", str_dump},
  {"fields", str_fields},                 /* added on November 13, 2011 */
  {"find", str_find},
  {"format", str_format},
  {"gfind", gfind_nodef},
  {"glob", str_glob},                     /* added on February 20, 2013 */
  {"gmatch", gmatch},
  {"gsub", str_gsub},
  {"hash", str_hash},                     /* added March 20, 2013 */
  {"hits", str_hits},                     /* added on January 26, 2008 */
  {"include", str_include},               /* added on December 22, 2010 */
  {"isabbrev", str_isabbrev},             /* added on April 10, 2009 */
  {"isalpha", str_isalpha},               /* added on December 17, 2006 */
  {"isalphanumeric", str_isalphanumeric}, /* added on December 17, 2006 */
  {"isalphaspec", str_isalphaspec},       /* added on April 11, 2013 */
  {"isalphaspace", str_isalphaspace},     /* added on June 27, 2007 */
  {"isblank", str_isblank},               /* added on September 25, 2012 */
  {"iscontrol", str_iscontrol},           /* added on December 27, 2014 */
  {"iscenumeric", str_iscenumeric},       /* added on August 26, 2012 */
  {"isending", str_isending},             /* added on April 10, 2009 */
  {"isfloat", str_isfloat},               /* added on January 23, 2010 */
  {"ishex", str_ishex},                   /* added on December 27, 2014 */
  {"isisoalpha", str_isisoalpha},         /* added on December 31, 2012 */
  {"isisolower", str_isisolower},         /* added on December 31, 2012 */
  {"isisoprint", str_isisoprint},         /* added on December 31, 2012 */
  {"isisospace", str_isisospace},         /* added on December 31, 2012 */
  {"isisoupper", str_isisoupper},         /* added on December 31, 2012 */
  {"islatin", str_islatin},               /* added on December 18, 2006 */
  {"islatinnumeric", str_islatinnumeric}, /* added on June 13, 2009 */
  {"isloweralpha", str_isloweralpha},     /* added on November 09, 2008 */
  {"islowerlatin", str_islowerlatin},     /* added on April 30, 2007 */
  {"isolower", str_isolower},             /* added on December 31, 2012 */
  {"isoupper", str_isoupper},             /* added on December 31, 2012 */
  {"ismagic", str_ismagic},               /* added on October 14/15, 2006 */
  {"isnumber", str_isnumber},             /* added on April 22, 2007 */
  {"isnumeric", str_isnumeric},           /* added on August 26, 2012 */
  {"isnumberspace", str_isnumberspace},   /* added on June 29, 2007 */
  {"isprintable", str_isprintable},       /* added on December 27, 2014 */
  {"isspace", str_isspace},               /* added on September 25, 2012 */
  {"isspec", str_isspec},                 /* added on April 11, 2013 */
  {"isupperalpha", str_isupperalpha},     /* added on April 19, 2009 */
  {"isupperlatin", str_isupperlatin},     /* added on April 19, 2009 */
  {"isutf8", str_isutf8},                 /* added on January 04, 2013 */
  {"lrtrim", str_lrtrim},                 /* added on April 30, 2013 */
  {"ltrim", str_ltrim},                   /* added on June 24, 2008 */
  {"match", str_match},
  {"phonetiqs", str_phonetiqs},           /* added on March 09, 2015 */
  {"remove", str_remove},                 /* added on April 10, 2009 */
  {"repeat", str_repeat},
  {"reverse", str_reverse},
  {"rtrim", str_rtrim},                   /* added on June 24, 2008 */
  {"separate", str_separate},             /* added on June 24, 2013 */
  {"tobytes", str_tobytes},
  {"tochars", str_tochars},
  {"tolatin", str_tolatin},               /* added on January 04, 2013 */
  {"toutf8", str_toutf8},                 /* added on January 04, 2013 */
  {"utf8size", str_utf8size},             /* added on January 04, 2013 */
  {"transform", str_transform},           /* added on January 03, 2013 */
  {"words", str_words},                   /* added on April 07, 2009 */
  {NULL, NULL}
};


static void createmetatable (lua_State *L) {
  lua_createtable(L, 0, 1);  /* create metatable for strings */
  lua_pushliteral(L, "");  /* dummy string */
  lua_pushvalue(L, -2);
  lua_setmetatable(L, -2);  /* set string metatable */
  agn_poptop(L);  /* pop dummy string */
  lua_pushvalue(L, -2);  /* string library... */
  lua_setfield(L, -2, "__index");  /* ...is the __index metamethod */
  agn_poptop(L);  /* pop metatable */
}


/*
** Open string library
*/
LUALIB_API int luaopen_string (lua_State *L) {
  luaL_register(L, LUA_STRLIBNAME, strlib);
  createmetatable(L);
  return 1;
}

