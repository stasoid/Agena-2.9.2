#ifndef loadlib_h
#define loadlib_h

void fastloader_C (lua_State *L, const char *filename, const char *name, int *success, int printerror);
const char *pushnexttemplate (lua_State *L, const char *path);

#endif
