/* This library implements a single-linked list using userdata.

   Attempts to directly store references to Lua TValues and barrier them with various methods to protect them
   from the garbage collector failed. The elegant luaL_ref mechanism in Lua 5.1, however, is very fast.

   The underlying singly-linked list implementation has been taken from Martin Broadhurst's exemplary website
   http://www.martinbroadhurst.com/data-structures.html */

#define llist_c
#define LUA_LIB

#include <stdlib.h>

#include "agena.h"
#include "agnxlib.h"
#include "agenalib.h"
#include "lapi.h"

#define checkllist(L, n)      (Slist *)luaL_checkudata(L, n, "llist")
#define checkllistnode(L, n)  (Slnode *)luaL_checkudata(L, n, "llistnode")


#if !(defined(LUA_DOS) || defined(__OS2__) || defined(LUA_ANSI))
#define AGENA_LLISTLIBNAME "llist"
LUALIB_API int (luaopen_llist) (lua_State *L);
#endif


typedef struct Slnode {
  int data;  /* reference created by luaL_ref into the registry storing the Lua value */
  struct Slnode *next;
} Slnode;

typedef struct {
  Slnode *head;
  Slnode *tail;
  size_t size;
} Slist;


Slnode *sl_createnode (lua_State *L, int idx) {
  Slnode *node = malloc(sizeof(Slnode));
  if (node) {
    lua_pushvalue(L, idx);  /* put value into the registry */
    node->data = luaL_ref(L, LUA_REGISTRYINDEX);  /* store reference to value */
    node->next = NULL;
  }
  return node;
}

void sl_empty (Slist *list) {
  Slnode *node, *temp;
  node = list->head;
  while (node != NULL) {
    temp = node->next;
    xfree(node);
    node = temp;
  }
}

/*void sl_delete (Slist *list) {  // Agena frees lists automatically !
  if (list) {
    sl_empty(list);
    xfree(list);
  }
}*/

void sl_append (Slist *list, Slnode *node) {
  if (list->head == NULL) {  /* at the very first node */
    list->head = node;
    list->tail = node;
  } else {
    list->tail->next = node;
    list->tail = node;
  }
  list->size++;
}

void sl_prepend (Slist *list, Slnode *node) {
  if (list->tail == NULL) {  /* at the very first node */
    list->head = node;
    list->tail = node;
  } else {
    node->next = list->head;
    list->head = node;
  }
  list->size++;
}

void sl_removehead (Slist *list) {
  if (list->head) {
    Slnode *temp = list->head;
    list->head = list->head->next;
    if (list->head == NULL) {  /* list is now empty */
      list->tail = NULL;
    }
    xfree(temp);
    list->size--;
    if (list->size == 1) {
      list->tail = list->head;
    }
  }
}

/* static void sl_removetail (Slist *list) {
  if (list->tail) {
    MBsnode *current, *previous = NULL;
    current = list->head;
    while (current->next) {
      previous = current;
      current = current->next;
    }
    xfree(current->data);
    xfree(current);
    if (previous) {
      previous->next = NULL;
      list->tail = previous;
    } else { // List is now empty
      list->head = NULL;
      list->tail = NULL;
    }
    list->size--;
    if (list->size == 1) {
      list->head = list->tail;
    }
  }
} */


static int llist_list (lua_State *L) {  /* create a new userdata slist  */
  size_t i, nargs;
  Slist *list;
  Slnode *node;
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  list = (Slist *)lua_newuserdata(L, sizeof(Slist));
  if (list) {
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
  } else
    luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.list");
  luaL_getmetatable(L, "llist");  /* assign the metatable defined below to the userdata */
  lua_setmetatable(L, -2);
  lua_pushstring(L, "llist");
  agn_setutype(L, -2, -1);
  agn_poptop(L);  /* delete string 'llist' */
  for (i=1; i <= nargs; i++) {
    lua_lock(L);
    node = sl_createnode(L, i);
    if (node == NULL)
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.list");
    sl_append(list, node);
    lua_unlock(L);
  }
  return 1;
}


static int llist_append (lua_State *L) {
  Slist *list;
  Slnode *node;
  size_t nargs, i;
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  if (lua_gettop(L) < 2)
    luaL_error(L, "Error in " LUA_QS ": need at least an llist and a value.", "llist.append");
  list = (Slist *)checkllist(L, 1);
  for (i=2; i <= nargs; i++) {
    lua_lock(L);
    node = sl_createnode(L, i);
    if (node == NULL)
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.append");
    sl_append(list, node);
    lua_unlock(L);
  }
  return 0;
}


static int llist_prepend (lua_State *L) {
  Slist *list;
  Slnode *node;
  size_t i, nargs;
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  if (lua_gettop(L) < 2)
    luaL_error(L, "Error in " LUA_QS ": need at least an llist and a value.", "llist.prepend");
  list = (Slist *)checkllist(L, 1);
  for (i=2; i <= nargs; i++) {
    lua_lock(L);
    node = sl_createnode(L, i);
    if (node == NULL)
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.prepend");
    sl_prepend(list, node);
    lua_unlock(L);
  }
  return 0;
}


static int llist_put (lua_State *L) {
  Slist *list;
  Slnode *newnode;
  int idx;
  if (lua_gettop(L) != 3)
    luaL_error(L, "Error in " LUA_QS ": need an llist, an index, and any value.", "llist.put");
  lua_lock(L);
  list = (Slist *)checkllist(L, 1);
  idx = luaL_checkint(L, 2);
  if (idx < 1 || idx > list->size + 1)
    luaL_error(L, "Error in " LUA_QS ": index %d is out of range.", "llist.put", idx);
  newnode = sl_createnode(L, 3);
  if (newnode == NULL)
    luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.put");
  if (list->size + 1 == idx) {
    sl_append(list, newnode);
  } else {
    size_t i;
    Slnode *node, *previous;
    previous = NULL;
    node = list->head;
    for (i=1; i < idx; i++) {
      previous = node;
      node = node->next;
    }
    if (node == list->head) {
      if (list->tail == NULL) {  /* Adding the first node */
        list->head = newnode;
        list->tail = newnode;
      } else {
		newnode->next = list->head;
		list->head = newnode;
	  }
    } else {
      newnode->next = node;
      previous->next = newnode;
    }
    list->size++;
  }
  return 0;
}


static void sl_remove (Slist *list, Slnode *node, Slnode *previous) {
  if (node == list->head) {
    sl_removehead(list);
  } else {
    previous->next = node->next;
    list->size--;
    if (list->size == 1) {
	  list->tail = list->head;
    } else if (node == list->tail) {
	  list->tail = previous;
    }
    xfree(node);
  }
}

static int llist_purge (lua_State *L) {
  Slist *list;
  Slnode *previous, *node;
  int idx;
  size_t i;
  if (lua_gettop(L) != 2)
    luaL_error(L, "Error in " LUA_QS ": need an llist and an index.", "llist.purge");
  lua_lock(L);
  list = (Slist *)checkllist(L, 1);
  idx = luaL_checkint(L, 2);
  if (idx < 1 || idx > list->size)
    luaL_error(L, "Error in " LUA_QS ": index %d is out of range.", "llist.purge", idx);
  previous = NULL;
  node = list->head;
  for (i=1; i < idx; i++) {
    previous = node;
    node = node->next;
  }
  luaL_unref(L, LUA_REGISTRYINDEX, node->data);
  sl_remove(list, node, previous);
  return 0;
}


/* Creates a new userdata slist node, assigns a metatable to it, and leaves the new userdata node on the top of the stack. */
static int llist_node (lua_State *L, Slnode *node, int meta) {
  Slnode **newnode;
  if (node == NULL) {
    lua_pushnil(L);
  }
  else {
    lua_lock(L);
    /* see answer on nabble.com by Michal Kottman, Aug 27, 2011; 8:03 pm on `Re: Struggling with userdata concept`
       at http://lua.2524044.n2.nabble.com/Struggling-with-userdata-concepts-td6732223.html */
    newnode = (Slnode **)lua_newuserdata(L, sizeof(Slnode *));
    *newnode = node; /* store the pointer inside the userdata */
    if (*newnode) {
      (*newnode)->data = node->data;
      (*newnode)->next = node->next;
    } else
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.node");
    lua_pushvalue(L, meta);  /* push metatable */
    if (!lua_istable(L, -1)) {
      agn_poptop(L);  /* pop newuserdata */
      luaL_error(L, "Error in " LUA_QS ": userdata metatable does not exist.", "llist.node");
    }
    agn_setudmetatable(L, -2);
    lua_unlock(L);
  }
  return 1;  /* pushed node lightuserdata on stack */
}


static int iterate (lua_State *L) {
  Slnode *node;
  void *upval;
  int i, flag, offset;
  flag = 0;
  upval = lua_touserdata(L, lua_upvalueindex(2));  /* leave this here, otherwise Agena would crash */
  if (upval == NULL) {
    lua_pushnil(L);
    return 1;
  }
  offset = lua_tointeger(L, 1);
  if (agn_istrue(L, lua_upvalueindex(3))) {  /* we got the very first traversal, but the list might still be empty ... */
    int pos;
    Slist *list = (Slist *)upval;
    if (list->head == NULL) {  /* ... list is empty ?  Do not change Boolean first position flag */
      lua_pushnil(L);
      return 1;
    }
    llist_node(L, list->head, lua_upvalueindex(1));  /* create a userdata node */
    lua_replace(L, lua_upvalueindex(2));             /* make it an upvalue */
    lua_pushfalse(L);                                /* flag so that this if branch is never entered again */
    lua_replace(L, lua_upvalueindex(3));
    node = *(Slnode **)lua_touserdata(L, lua_upvalueindex(2));  /* get freshly created userdata node */
    pos = lua_tointeger(L, lua_upvalueindex(4));
    for (i=1; i < pos + offset && node != NULL; i++) {
      node = node->next;
      flag = 1;
    }
  } else {
    node = *(Slnode **)upval;
    for (i=0; i < offset + 1 && node != NULL; i++)
      node = node->next;
    flag = 1;
  }
  if (node == NULL)
    lua_pushnil(L);
  else
    lua_rawgeti(L, LUA_REGISTRYINDEX, node->data);
  if (flag) {  /* do not create a node for list->head again */
    llist_node(L, node, lua_upvalueindex(1));
    lua_replace(L, lua_upvalueindex(2));  /* update node userdata upvalue */
  }
  return 1;
}


static int llist_iterate (lua_State *L) {
  int pos;
  (void)checkllist(L, 1);  /* prevent compiler warnings */
  pos = luaL_optint(L, 2, 1);
  if (pos < 1)
    luaL_error(L, "Error in " LUA_QS ": start index must be positive.", "llist.iterate");
  luaL_getmetatable(L, "llistnode");
  if (!lua_istable(L, -1)) {
    agn_poptop(L);  /* pop anything */
    luaL_error(L, "Error in " LUA_QS ": userdata metatable does not exist.", "llist.iterate");
  }
  lua_pushvalue(L, 1);
  lua_pushtrue(L);
  lua_pushinteger(L, pos);
  lua_pushcclosure(L, &iterate, 4);
  return 1;
}


static int llist_replicate (lua_State *L) {
  Slist *source, *target;
  Slnode *node, *newnode;
  source = checkllist(L, 1);
  target = (Slist *)lua_newuserdata(L, sizeof(Slist));
  if (target) {
    target->head = NULL;
    target->tail = NULL;
    target->size = 0;
  } else
    luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.replicate");
  luaL_getmetatable(L, "llist");  /* assign the metatable defined below to the userdata */
  lua_setmetatable(L, -2);
  lua_pushstring(L, "llist");
  agn_setutype(L, -2, -1);
  agn_poptop(L);  /* delete string 'llist' */
  for (node = source->head; node != NULL; node = node->next) {
    lua_rawgeti(L, LUA_REGISTRYINDEX, node->data);
    lua_lock(L);
    newnode = sl_createnode(L, -1);
    if (newnode == NULL)
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.replicate");
    sl_append(target, newnode);
    agn_poptop(L);
    lua_unlock(L);
  }
  return 1;
}


static int llist_getsize (lua_State *L) {  /* return the number of allocated slots in the userdata numeric array */
  Slist *list = checkllist(L, 1);
  lua_pushnumber(L, list->size);
  return 1;
}


static int llist_getitem (lua_State *L) {  /* get the value at the given index position */
  size_t i, index;
  Slnode *node;
  Slist *list = checkllist(L, 1);
  index = luaL_checkint(L, 2);
  if (index < 1 || index > list->size) {
    lua_pushnil(L);
    return 1;
  }
  node = list->head;
  for (i=1; i < index; i++) {
    node = node->next;
  }
  lua_rawgeti(L, LUA_REGISTRYINDEX, node->data);
  return 1;
}


static int llist_in (lua_State *L) {
  Slist *list;
  Slnode *node, *tail;
  int r, nargs;
  nargs = lua_gettop(L);
  if (nargs != 2)
    luaL_error(L, "Error in " LUA_QS ": need two arguments.", "llist.__in");
  list = checkllist(L, 2);
  if ((tail = list->tail) != NULL) {  /* at first check last element */
    lua_rawgeti(L, LUA_REGISTRYINDEX, tail->data);
    if (lua_equal(L, 1, -1)) {
      agn_poptop(L);
      lua_pushtrue(L);
      return 1;
    }
    agn_poptop(L);
  }
  r = 0;
  for (node = list->head; node != NULL; node = node->next) {
    lua_rawgeti(L, LUA_REGISTRYINDEX, node->data);
    if ((r = lua_equal(L, 1, -1))) {
      agn_poptop(L);
      break;
    }
    agn_poptop(L);
  }
  lua_pushboolean(L, r);
  return 1;
}


static int llist_eq (lua_State *L) {
  Slist *list1, *list2;
  Slnode *node1, *node2;
  int r, nargs;
  nargs = lua_gettop(L);
  r = 1;
  if (nargs != 2)
    luaL_error(L, "Error in " LUA_QS ": need two arguments.", "llist.__eq");
  list1 = checkllist(L, 1);
  list2 = checkllist(L, 2);
  if (list1->size != list2->size)
    r = 0;
  else {
    for (node1 = list1->head, node2 = list2->head; node1 != NULL && node2 != NULL;
         node1 = node1->next, node2 = node2->next) {
      lua_rawgeti(L, LUA_REGISTRYINDEX, node1->data);
      lua_rawgeti(L, LUA_REGISTRYINDEX, node2->data);
      if ((r = lua_rawequal(L, -1, -2)) == 0) {
        agn_poptoptwo(L);
        break;
      }
      agn_poptoptwo(L);
    }
  }
  lua_pushboolean(L, r);
  return 1;
}


static int llist_aeq (lua_State *L) {
  Slist *list1, *list2;
  Slnode *node1, *node2;
  int r, nargs;
  nargs = lua_gettop(L);
  r = 1;
  if (nargs != 2)
    luaL_error(L, "Error in " LUA_QS ": need two arguments.", "llist.__aeq");
  list1 = checkllist(L, 1);
  list2 = checkllist(L, 2);
  if (list1->size != list2->size)
    r = 0;
  else {
    for (node1 = list1->head, node2 = list2->head; node1 != NULL && node2 != NULL;
         node1 = node1->next, node2 = node2->next) {
      lua_rawgeti(L, LUA_REGISTRYINDEX, node1->data);
      lua_rawgeti(L, LUA_REGISTRYINDEX, node2->data);
      if ((r = lua_rawaequal(L, -1, -2)) == 0) {
        agn_poptoptwo(L);
        break;
      }
      agn_poptoptwo(L);
    }
  }
  lua_pushboolean(L, r);
  return 1;
}


static int llist_setitem (lua_State *L) {  /* set a value at the given index position */
  size_t i, idx;
  Slnode *node;
  if (lua_gettop(L) != 3)
    luaL_error(L, "Error in " LUA_QS ": need an llist, an index, and a value.", "llist.__writeindex");
  Slist *list = checkllist(L, 1);
  idx = luaL_checkint(L, 2);
  if (idx < 1 || idx > list->size + 1) {
    lua_pushnil(L);
    return 0;
  }
  if (list->size + 1 == idx) {
    node = sl_createnode(L, 3);
    if (node == NULL)
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "llist.__writeindex");
    sl_append(list, node);
  } else {  /* replace existing item */
    node = list->head;
    for (i=1; i < idx; i++) {
      node = node->next;
    }
    luaL_unref(L, LUA_REGISTRYINDEX, node->data);  /* delete reference to former value */
    lua_pushvalue(L, 3);  /* enter substitute into the registry */
    node->data = luaL_ref(L, LUA_REGISTRYINDEX);
  }
  return 0;
}


static int llist_tostring (lua_State *L) {  /* at the console, the array is formatted as follows: */
  (void)checkllist(L, 1);
  lua_pushfstring(L, "llist(%p)", lua_topointer(L, 1));
  return 1;
}


static int llist_gc (lua_State *L) {  /* garbage collect deleted userdata */
  (void)L;
  Slist *list = checkllist(L, 1);
  Slnode *node = list->head;
  while (node) {
    luaL_unref(L, LUA_REGISTRYINDEX, node->data);
    node = node->next;
  }
  sl_empty(list);
  lua_pushnil(L);
  lua_setmetatable(L, 1);
  return 0;
}


static int llist_nodegc (lua_State *L) {  /* garbage collect deleted userdata */
  (void)L;
  lua_pushnil(L);
  lua_setmetatable(L, 1);
  return 0;
}


static const struct luaL_Reg llist_llistlib [] = {  /* metamethods for linked lists `n' */
  {"__index", llist_getitem},       /* n[p], with p the index, counting from 1 */
  {"__writeindex", llist_setitem},  /* n[p] := value, with p the index, counting from 1 */
  {"__size", llist_getsize},        /* retrieve the number of entries in `n' */
  {"__tostring", llist_tostring},   /* for output at the console, e.g. print(n) */
  {"__in", llist_in},               /* `in` operator for linked lists */
  {"__gc", llist_gc},               /* please do not forget garbage collection */
  {"__eq", llist_eq},               /* metamethod for `=` operator */
  {"__aeq", llist_aeq},             /* metamethod for `~=` operator */
  {NULL, NULL}
};


static const struct luaL_Reg llist_llistnodelib [] = {  /* metamethods for nodes */
  {"__gc", llist_nodegc},           /* needed for llist.iterate */
  {NULL, NULL}
};


static const luaL_Reg llistlib[] = {
  {"append", llist_append},
  {"iterate", llist_iterate},
  {"list", llist_list},
  {"prepend", llist_prepend},
  {"purge", llist_purge},
  {"put", llist_put},
  {"replicate", llist_replicate},
  {NULL, NULL}
};


/*
** Open llist library
*/
LUALIB_API int luaopen_llist (lua_State *L) {
  /* metamethods for linked lists */
  luaL_newmetatable(L, "llist");
  luaL_register(L, NULL, llist_llistlib);
  /* metamethod for the nodes (for `llist.iterate`) */
  luaL_newmetatable(L, "llistnode");
  luaL_register(L, NULL, llist_llistnodelib);
  /* register library */
  luaL_register(L, AGENA_LLISTLIBNAME, llistlib);
  return 1;
}

