/* Compilation of functions published at http:www.mymathlib.com provided by RLH */

#ifndef rlhmath_h
#define rlhmath_h

double Ei (double x);
double Ein (double x);

#endif
