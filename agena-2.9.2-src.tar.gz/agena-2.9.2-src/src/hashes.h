/* include file for hlist library (string hash functions) */

#ifndef hlist_h
#define hlist_h

typedef struct nlist {
   struct nlist *next;
   int name;
} nlist;


typedef struct dlist {
   int size;
   nlist *hashtab[1];
} dlist;


nlist *lookup (lua_State *L, dlist *a, const char *s, int hashval);
unsigned int hash (const char *s, int len);

#endif