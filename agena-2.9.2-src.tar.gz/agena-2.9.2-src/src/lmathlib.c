/*
** $Id: lmathlib.c,v 1.67 2005/08/26 17:36:32 roberto Exp $
** Standard mathematical library
** See Copyright Notice in agena.h
*/


#include <stdlib.h>
#include <math.h>

#ifdef X86ASM  /* 2.4.0 */
#include "x86math.h"
#endif

#define lmathlib_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "agnt64.h"
#include "agncmpt.h"  /* for trunc and isfinite, and FLT_EVAL_METHOD constant, and off64* types */
#include "lobject.h"
#include "cephes.h"

#undef PHI
#define PHI      ((1.0 + sqrt(5.0))/2.0)


static int math_min (lua_State *L) {
  int n = lua_gettop(L);  /* number of arguments */
  lua_Number dmin = agn_checknumber(L, 1);
  int i;
  for (i=2; i <= n; i++) {
    lua_Number d = agn_checknumber(L, i);
    if (d < dmin)
      dmin = d;
  }
  lua_pushnumber(L, dmin);
  return 1;
}


static int math_max (lua_State *L) {
  int n = lua_gettop(L);  /* number of arguments */
  lua_Number dmax = agn_checknumber(L, 1);
  int i;
  for (i=2; i <= n; i++) {
    lua_Number d = agn_checknumber(L, i);
    if (d > dmax)
      dmax = d;
  }
  lua_pushnumber(L, dmax);
  return 1;
}


static LUAI_UINT32 m_w = 10;  /* must not be zero */
static LUAI_UINT32 m_z = 7;   /* must not be zero */

static int math_random (lua_State *L) {
  /* the `%' avoids the (rare) case of r == 1, and is needed also because on some systems (SunOS!) `rand()' may return
     a value larger than RAND_MAX;
     RNG algorithm taken from http://en.wikipedia.org/wiki/Random_number_generation, written by George Marsaglia.
     0.32.2, 22.05.2010 */
  lua_Number r;
  int nargs, mode;
  nargs = lua_gettop(L);
  mode = (nargs > 0 && lua_type(L, nargs) == LUA_TBOOLEAN);  /* 2.8.3 fix */
  if (mode) {  /* suggested by Slobodan, 2.5.1: create really random numbers */
    Time64_T tgmt = time(NULL);
    m_w = (tgmt + m_w) % 113 + 1;
    m_z = (tgmt + m_z) % 113 + 1;
  }
  m_z = 36969 * (m_z & 65535) + (m_z >> 16);
  m_w = 18000 * (m_w & 65535) + (m_w >> 16);
  r = (lua_Number)((m_z << 16) + m_w)/(lua_Number)(2*(double)LUAI_MAXINT32);  /* 32-bit result */
  switch (nargs - mode) {  /* check number of arguments */
    case 0: {  /* no arguments */
      lua_pushnumber(L, r);  /* Number between 0 and 1 */
      break;
    }
    case 1: {  /* only upper limit */
      int u = agnL_checkint(L, 1);
      luaL_argcheck(L, 1 <= u, 1, "interval is empty");
      lua_pushnumber(L, floor(r*u) + 1);  /* int between 1 and `u' */
      break;
    }
    case 2: {  /* lower and upper limits */
      int l = agnL_checkint(L, 1);
      int u = agnL_checkint(L, 2);
      luaL_argcheck(L, l <= u, 2, "interval is empty");
      lua_pushnumber(L, floor(r*(u - l + 1)) + l);  /* int between `l' and `u' */
      break;
    }
    default: return luaL_error(L, "Error in " LUA_QS ": wrong number of arguments (0, 1, or 2 required).", "math.random");
  }
  return 1;
}


static int math_randomseed (lua_State *L) {  /* changed 0.32.2, 23.05.2010 */
  lua_Number w, z;
  w = agnL_checkint(L, 1);
  z = agnL_checkint(L, 2);
  if (w <= 0 || z <= 0)
    luaL_error(L, "Error in " LUA_QS ": both values must be positive. Seeds not changed.", "math.randomseed");
  m_w = (LUAI_UINT32)w;
  m_z = (LUAI_UINT32)z;
  lua_pushinteger(L, m_w);
  lua_pushinteger(L, m_z);
  return 2;
}



static int math_isprime (lua_State *L) {  /* patched 0.27.0; tuned 0.30.3; extended 1.0.6 */
  long long int x;
  lua_Number n;
  n = agnL_checknumber(L, 1);
  if (n > 9223372036854775807.0 || n < -9223372036854775808.0)  /* max/min of type LONG LONG INT */
    luaL_error(L, "Error in " LUA_QS ": number too big or too small.", "math.isprime");
  if (ISFLOAT(n))  /* 2.3.0 RC2 eCS */
    luaL_error(L, "Error in " LUA_QS ": integer expected.", "math.isprime");
  x = (long long int)n;
  if (x < 4)
    lua_pushboolean(L, x > 1);
  else if (x % 2 == 0)  /* even number ? */
    lua_pushboolean(L, 0);
  else {
    long long int i;
    const long long int imax = (long long int)sqrt(x) + 1;
    for (i = 3; i <= imax; i += 2) {
      if (x % i == 0) {
        lua_pushfalse(L);
        return 1;
      }
    }
    lua_pushtrue(L);
  }
  return 1;
}


static int math_prevprime (lua_State *L) {  /* 0.33.2, fixed and extended 1.0.6 */
  long long int x;
  lua_Number n;
  n = agnL_checknumber(L, 1);
  if (n > 9223372036854775807.0 || n < -9223372036854775808.0)  /* max/min of type LONG LONG INT */
    luaL_error(L, "Error in " LUA_QS ": number too big or too small.", "math.prevprime");
  if (ISFLOAT(n))  /* 2.3.0 RC2 eCS */
    luaL_error(L, "Error in " LUA_QS ": integer expected.", "math.prevprime");
  x = (long long int)n;
  if (x < 3)
    lua_pushfail(L);
  else if (x == 3)
    lua_pushinteger(L, 2);
  else if (x < 6)
    lua_pushinteger(L, 3);
  else {
    unsigned long long int n, b, i;
    b = (x % 2 == 0) ? x - 1 : x - 2;
    for (i=b; ; i = i - 2) {
      n = 3;
      while (n * n < i && i % n != 0)
        n += 2;
      if (i % n != 0) break;
    }
    lua_pushnumber(L, i);  /* Agena 1.0.6 */
  }
  return 1;
}


static int math_nextprime (lua_State *L) {  /* 0.33.2, extended 1.0.6 */
  long long int x;
  lua_Number n;
  n = agnL_checknumber(L, 1);
  if (n > 9223372036854775807.0 || n < -9223372036854775808.0)  /* max/min of type LONG LONG INT */
    luaL_error(L, "Error in " LUA_QS ": number too big or too small.", "math.nextprime");
  if (ISFLOAT(n))  /* 2.3.0 RC2 eCS */
    luaL_error(L, "Error in " LUA_QS ": integer expected.", "math.nextprime");
  x = (long long int)n;
  if (x < 2)
    lua_pushinteger(L, 2);
  else if (x < 3)  /* patched Agena 1.0.6 */
    lua_pushinteger(L, 3);
  else {
    unsigned long long int n, b, i;
    b = (x % 2 == 0) ? x + 1 : x + 2;
    for (i=b; ; i = i + 2) {
      n = 3;
      while (n * n < i && i % n != 0)
        n += 2;
      if (i % n != 0) break;
    }
    lua_pushnumber(L, i);  /* Agena 1.0.6 */
  }
  return 1;
}


/* constant found in Cephes Math Library Release 2.8, June, 2000 by Stephen L. Moshier
   file sin.c (and fixed it) */
#define P64800   (4.8481368110953599358991410e-6)  /* = (Pi/180)/3600 */

/* converts degrees to radians */
static int math_toradians (lua_State *L) {
  lua_Number m, s;
  m = agnL_optnumber(L, 2, 0);
  s = agnL_optnumber(L, 3, 0);
  lua_pushnumber(L,
    ((agn_checknumber(L, 1)*60.0 + m)*60.0 + s)*P64800
  );
  return 1;
}


/* converts sexagesimal to decimal */
static int math_todecimal (lua_State *L) {
  lua_Number h, m, s, sgn;
  int isneg;
  h = agn_checknumber(L, 1);
  m = agnL_optnumber(L, 2, 0);
  s = agnL_optnumber(L, 3, 0);
  isneg = h < 0;
  sgn = (isneg) ? -1 : 1;  /* 2.2.0 patch */
  h = (isneg) ? -h : h;
  lua_pushnumber(L, sgn*(h + m/60 + s/3600));
  return 1;
}


static int math_nextafter (lua_State *L) {
  lua_Number x, y;
  x = agn_checknumber(L, 1);
  y = agn_checknumber(L, 2);
  lua_pushnumber(L, sun_nextafter(x, y));
  return 1;
}


lua_Number getnumber (lua_State *L, int idx, int n, const char *str) {
  lua_Number r;
  agn_pairgeti(L, idx, n);
  if (lua_type(L, -1) != LUA_TNUMBER) {
    agn_poptop(L);  /* clear stack, Agena 1.1.0 */
    luaL_error(L, "Error in " LUA_QS ": expected a pair of numbers as %s argument.", "math.norm", str);
  }
  r = agn_tonumber(L, -1);
  agn_poptop(L);
  return r;
}


static int math_norm (lua_State *L) {
  lua_Number x, a1, a2, b1, b2;
  int t3;
  x = agn_checknumber(L, 1);
  if (!lua_ispair(L, 2))
    luaL_error(L, "Error in " LUA_QS ": expected a pair of numbers as second argument.", "math.norm");
  a1 = getnumber(L, 2, 1, "second");
  a2 = getnumber(L, 2, 2, "second");
  if (x < a1 || x > a2)
    luaL_error(L, "Error in " LUA_QS ": first argument out of range.", "math.norm");
  if (a1 > a2)  /* 2.2.1 */
    luaL_error(L, "Error in " LUA_QS ": left border greater than right border in second argument.", "math.norm");
  t3 = lua_type(L, 3);
  if (t3 == LUA_TNONE) {
    b1 = 0;
    b2 = 1;
  }
  else if (t3 == LUA_TPAIR) {
    b1 = getnumber(L, 3, 1, "third");
    b2 = getnumber(L, 3, 2, "third");
    if (b1 > b2)  /* 2.2.1 */
      luaL_error(L, "Error in " LUA_QS ": left border greater than right border in third argument.", "math.norm");
  }
  else {
    b1 = 0; b2 = 0;  /* just to prevent compiler warnings */
    luaL_error(L, "Error in " LUA_QS ": expected a pair of numbers as third argument.", "math.norm");
  }
  lua_pushnumber(L, b1 + (x-a1) * (b2-b1)/(a2-a1));  /* 2.2.1 fix */
  return 1;
}


/* Converts an integer to a `floating point byte`, represented as (eeeeexxx), where the real value
   is (1xxx) * 2^(eeeee - 1) if eeeee <> 0 and (xxx) otherwise. This function is used to transport
   numbers to the Lua/Agena virtual machine. See also: math.fpbtoint */
static int math_inttofpb (lua_State *L) {  /* 2.3.1 */
  int x;
  x = agn_checkinteger(L, 1);
  if (x < 0)
    luaL_error(L, "Error in " LUA_QS ": expected a positive integer.", "math.inttofpb");
  lua_pushinteger(L, luaO_int2fb(x));
  return 1;
}


/* Converts a `floating point byte` generated by math.inttofpb back. This function is used to
   evaluate numbers transported to the Lua/Agena virtual machine. Please note that
   math.inttofpb(math.fpbtoint(x)) does not return x. */
static int math_fpbtoint (lua_State *L) {  /* 2.3.1 */
  int x;
  x = agn_checkinteger(L, 1);
  lua_pushinteger(L, luaO_fb2int(x));
  return 1;
}


/* Returns, returns smallest exponent to 2 equals or greater than x, i.e. ilog2(x - 1) + 1 */
static int math_ceillog2 (lua_State *L) {  /* 2.3.1 */
  int x;
  x = agn_checkinteger(L, 1);
  if (x < 1)  /* 2.3.3 improvement */
    lua_pushundefined(L);
  else
    lua_pushinteger(L, (luaO_log2(x - 1) + 1));
  return 1;
}

/* Rounds up to the next highest power of 2, taken from:
   http://graphics.stanford.edu/~seander/bithacks.html#RoundUpPowerOf2 */
static int math_ceilpow2 (lua_State *L) {  /* 2.3.3 */
  int x;
  x = agn_checkinteger(L, 1);
  if (x < 0)
    lua_pushundefined(L);
  else {
    unsigned int v = x;
    v--;
    v |= v >> 1;
    v |= v >> 2;
    v |= v >> 4;
    v |= v >> 8;
    v |= v >> 16;
    v++;
    v += (v == 0);
    lua_pushinteger(L, v);
  }
  return 1;
}


/* Taken from: http://graphics.stanford.edu/~seander/bithacks.html#InterleaveTableLookup

Interleaves the bits of integers x and y, so that all of the bits of x are in the even
positions and y in the odd; the function can be used to linearising 2D integer coordinates,
combining x and y into a single integer that can be compared easily has the property that
a number is usually close to another if their x and y values are close. */
static const unsigned short MortonTable256[256] = {
  0x0000, 0x0001, 0x0004, 0x0005, 0x0010, 0x0011, 0x0014, 0x0015,
  0x0040, 0x0041, 0x0044, 0x0045, 0x0050, 0x0051, 0x0054, 0x0055,
  0x0100, 0x0101, 0x0104, 0x0105, 0x0110, 0x0111, 0x0114, 0x0115,
  0x0140, 0x0141, 0x0144, 0x0145, 0x0150, 0x0151, 0x0154, 0x0155,
  0x0400, 0x0401, 0x0404, 0x0405, 0x0410, 0x0411, 0x0414, 0x0415,
  0x0440, 0x0441, 0x0444, 0x0445, 0x0450, 0x0451, 0x0454, 0x0455,
  0x0500, 0x0501, 0x0504, 0x0505, 0x0510, 0x0511, 0x0514, 0x0515,
  0x0540, 0x0541, 0x0544, 0x0545, 0x0550, 0x0551, 0x0554, 0x0555,
  0x1000, 0x1001, 0x1004, 0x1005, 0x1010, 0x1011, 0x1014, 0x1015,
  0x1040, 0x1041, 0x1044, 0x1045, 0x1050, 0x1051, 0x1054, 0x1055,
  0x1100, 0x1101, 0x1104, 0x1105, 0x1110, 0x1111, 0x1114, 0x1115,
  0x1140, 0x1141, 0x1144, 0x1145, 0x1150, 0x1151, 0x1154, 0x1155,
  0x1400, 0x1401, 0x1404, 0x1405, 0x1410, 0x1411, 0x1414, 0x1415,
  0x1440, 0x1441, 0x1444, 0x1445, 0x1450, 0x1451, 0x1454, 0x1455,
  0x1500, 0x1501, 0x1504, 0x1505, 0x1510, 0x1511, 0x1514, 0x1515,
  0x1540, 0x1541, 0x1544, 0x1545, 0x1550, 0x1551, 0x1554, 0x1555,
  0x4000, 0x4001, 0x4004, 0x4005, 0x4010, 0x4011, 0x4014, 0x4015,
  0x4040, 0x4041, 0x4044, 0x4045, 0x4050, 0x4051, 0x4054, 0x4055,
  0x4100, 0x4101, 0x4104, 0x4105, 0x4110, 0x4111, 0x4114, 0x4115,
  0x4140, 0x4141, 0x4144, 0x4145, 0x4150, 0x4151, 0x4154, 0x4155,
  0x4400, 0x4401, 0x4404, 0x4405, 0x4410, 0x4411, 0x4414, 0x4415,
  0x4440, 0x4441, 0x4444, 0x4445, 0x4450, 0x4451, 0x4454, 0x4455,
  0x4500, 0x4501, 0x4504, 0x4505, 0x4510, 0x4511, 0x4514, 0x4515,
  0x4540, 0x4541, 0x4544, 0x4545, 0x4550, 0x4551, 0x4554, 0x4555,
  0x5000, 0x5001, 0x5004, 0x5005, 0x5010, 0x5011, 0x5014, 0x5015,
  0x5040, 0x5041, 0x5044, 0x5045, 0x5050, 0x5051, 0x5054, 0x5055,
  0x5100, 0x5101, 0x5104, 0x5105, 0x5110, 0x5111, 0x5114, 0x5115,
  0x5140, 0x5141, 0x5144, 0x5145, 0x5150, 0x5151, 0x5154, 0x5155,
  0x5400, 0x5401, 0x5404, 0x5405, 0x5410, 0x5411, 0x5414, 0x5415,
  0x5440, 0x5441, 0x5444, 0x5445, 0x5450, 0x5451, 0x5454, 0x5455,
  0x5500, 0x5501, 0x5504, 0x5505, 0x5510, 0x5511, 0x5514, 0x5515,
  0x5540, 0x5541, 0x5544, 0x5545, 0x5550, 0x5551, 0x5554, 0x5555
};


static int math_morton (lua_State *L) {  /* 2.3.3 */
  unsigned short x, y;   /* Interleave bits of x and y, so that all of the
    bits of x are in the even positions and y in the odd; unsigned int z = 0;
    z gets the resulting Morton Number. */
  unsigned int z;
  x = agn_checknumber(L, 1);
  y = agn_checknumber(L, 2);
  z = MortonTable256[y >> 8] << 17 |
    MortonTable256[x >> 8]   << 16 |
    MortonTable256[y & 0xFF] <<  1 |
    MortonTable256[x & 0xFF];
  lua_pushnumber(L, z);
  return 1;
}


/* Returns a value equivalent to exp(x) - 1, with x a number. It is computed in a way that is accurate even
   if x is near 0, since exp(~0) and 1 are nearly equal. See also: math.lnplusone.

From: http://en.cppreference.com/w/cpp/numeric/math/expm1

   Parameters
arg 	- 	value of floating-point or Integral type
Return value

If no errors occur earg
-1 is returned.

If a range error due to overflow occurs, +HUGE_VAL, +HUGE_VALF, or +HUGE_VALL is returned.

If a range error occurs due to underflow, the correct result (after rounding) is returned.
Error handling

Errors are reported as specified in math_errhandling

If the implementation supports IEEE floating-point arithmetic (IEC 60559),

    If the argument is �0, it is returned, unmodified
    If the argument is -?, -1 is returned
    If the argument is +?, +? is returned
    If the argument is NaN, NaN is returned

Notes

The functions std::expm1 and std::log1p are useful for financial calculations, for example, when calculating small daily interest rates: (1+x)n
-1 can be expressed as std::expm1(n * std::log1p(x)). These functions also simplify writing accurate inverse hyperbolic functions.

For IEEE-compatible type double, overflow is guaranteed if 709.8 < arg */
static int math_expminusone (lua_State *L) {  /* 2.3.3 */
  lua_pushnumber(L, expm1(agn_checknumber(L, 1)));
  return 1;
}


/* Returns a value equivalent to ln(1 + x), with x a number. It is computed in a way that is accurate even
   if x is near zero.

   Example: ln(1.0000000000000001) -> 0, math.lnplus1(0.0000000000000001)
   -> 1e-016. See also: math.expminusone.

From: http://en.cppreference.com/w/cpp/numeric/math/log1p

If no errors occur ln(1+arg) is returned.

If a domain error occurs, an implementation-defined value is returned (NaN where supported)

If a pole error occurs, -HUGE_VAL, -HUGE_VALF, or -HUGE_VALL is returned.

If a range error occurs due to underflow, the correct result (after rounding) is returned.
Error handling

Errors are reported as specified in math_errhandling

Domain error occurs if arg is less than -1.

Pole error may occur if arg is -1.

If the implementation supports IEEE floating-point arithmetic (IEC 60559),

    If the argument is �0, it is returned unmodified
    If the argument is -1, -infinity is returned and FE_DIVBYZERO is raised.
    If the argument is less than -1, NaN is returned and FE_INVALID is raised.
    If the argument is +infinity, +infinity is returned
    If the argument is NaN, NaN is returned

Some Notes:

The functions std::expm1 and std::log1p are useful for financial calculations, for example, when calculating small daily interest rates: (1+x)n
-1 can be expressed as std::expm1(n * std::log1p(x)). These functions also simplify writing accurate inverse hyperbolic functions. */
static int math_lnplusone (lua_State *L) {  /* 2.3.3 */
  lua_Number x = agn_checknumber(L, 1);
  if (x <= -1)
    lua_pushundefined(L);
  else
    lua_pushnumber(L, log1p(x));
  return 1;
}


/* Returns `false` if at least one of its arguments is `undefined`, and `true` otherwise. */

static int math_isordered (lua_State *L) {  /* 2.3.3 */
  lua_pushboolean(L, !isunordered(agn_checknumber(L, 1), agn_checknumber(L, 2)));
  return 1;
}


/* Returns a number with the magnitude of x and the sign of y. It is a plain binding to
   C's copysign function and does not postprocess its result. */
static int math_copysign (lua_State *L) {  /* 2.3.3 */
  lua_pushnumber(L, copysign(agn_checknumber(L, 1), agn_checknumber(L, 2)));
  return 1;
}


static int math_signbit (lua_State *L) {  /* 2.4.2 */
  lua_pushboolean(L, signbit(agn_checknumber(L, 1)) != 0);
  return 1;
}


/* Returns the inverse hyperbolic cosine of the number x and returns a number. It works
   in the real domain only. */
static int math_arccosh (lua_State *L) {  /* 2.3.3 */
  lua_pushnumber(L, acosh(agn_checknumber(L, 1)));  /* log(x + luai_numsign(x) * sqrt(x*x - 1))) */
  return 1;
}


/* The function adds x and y using Kahan-Ozawa round-off error prevention and returns two numbers: the sum of x and y plus the updated value of the correction variable. The correction variable q should be 0 at first invocation.
A typical usage should look like:

x, q -> 0;
y := 0.1;
while x < 1 do
   x, q := math.koadd(x, y, q)
od;
print(s, q);

*/
static int math_koadd (lua_State *L) {  /* 2.4.1, // Kahan-Ozawa summation, gets argument x and correction value q, return new x and q */
  volatile lua_Number q, s, sold, u, v, w, x, t;
  s = agn_checknumber(L, 1);
  x = agn_checknumber(L, 2);  /* value to be added to first argument */
  q = agnL_optnumber(L, 3, 0);
  v = x - q;
  sold = s;
  s += v;
  if (fabs(x) < fabs(q)) {
    t = x;
    x = -q;
    q = t;
  }
  u = (v - x) + q;
  if (fabs(sold) < fabs(v)) {
    t = sold;
    sold = v;
    v = t;
  }
  w = (s - sold) - v;
  q = u + w;
  /* s now contains sumdata */
  lua_pushnumber(L, s);
  lua_pushnumber(L, q);
  return 2;
}


/* Emulates Matlab's `eps` function and returns the relative spacing between |x| and its next larger
   number in the machine�s floating point system. On x86 machines and with C doubles,
   eps() and eps(1) return 2.2204460492503e-016 = 2 ^(-52), and eps(2) returns 4.4408920985006e-016
   = 2 ^(-51). 2.4.2 */
static int math_eps (lua_State *L) {  /* 2.4.2, five times faster than an Agena implementation */
  lua_Number x = fabs(luaL_optnumber(L, 1, 1));
  lua_pushnumber(L, sun_nextafter(x, HUGE_VAL) - x);
  return 1;
}


static int math_gethigh (lua_State *L) {  /* 2.4.5, based on the 0.27.0 operator */
  LUAI_INT32 hx;
  GET_HI(hx, agn_checknumber(L, 1));
  lua_pushnumber(L, hx);
  return 1;
}


static int math_getlow (lua_State *L) {  /* 2.4.5, based on the 0.27.0 operator */
  LUAI_UINT32 lx;
  GET_LO(lx, agn_checknumber(L, 1));
  lua_pushnumber(L, lx);
  return 1;
}


static int math_sethigh (lua_State *L) {  /* 2.4.5, based on the 0.27.0 operator */
  lua_Number x, y;
  LUAI_UINT32 lx;
  x = agn_checknumber(L, 1);
  y = agn_checknumber(L, 2);
  GET_LO(lx, x);
  /* using something like SET_HI setting only the higher byte does not work */
  INSERT_WORDS(x, y, lx);
  lua_pushnumber(L, x);
  return 1;
}


static int math_setlow (lua_State *L) {  /* 2.4.5, based on the 0.27.0 operator */
  lua_Number x, y;
  LUAI_INT32 hx;
  x = agn_checknumber(L, 1);
  y = agn_checknumber(L, 2);
  GET_HI(hx, x);
  /* using something like SET_LO setting only the lower byte does not work */
  INSERT_WORDS(x, hx, y);
  lua_pushnumber(L, x);
  return 1;
}


/* Returns a sequence with all the bytes of a number x in Little Endian order. */
static int math_tobytes (lua_State *L) {  /* 2.6.1, extended 2.9.0 */
#ifdef LUA_DOS
  lua_pushfail(L);
#else
  lua_Number x;
  int i, size;
  unsigned char *dst;
  dst = NULL;
  x = agn_checknumber(L, 1);
  size = luaL_optint(L, 2, sizeof(lua_Number)) ;
  if (!(size == sizeof(int32_t) || size == sizeof(lua_Number)))
    luaL_error(L, "Error in " LUA_QS ": second argument must either be %d or %d.",
      "math.tobytes", sizeof(int32_t), sizeof(lua_Number));
  switch (size) {
    case sizeof(lua_Number): {
      uint64_t u;
      u = tools_double2uint(x);
      dst = (unsigned char *)&u;
      break;
    }
    case sizeof(int32_t): {  /* do not cast to uint64_t since Linux for PPC would return wrong results otherwise */
      uint32_t u;
      u = tools_int32_t2uint32_t((int32_t)x);
      dst = (unsigned char *)&u;
      break;
    }
    default:
      lua_assert(0);
  }
  agn_createseq(L, size);
  for (i=0; i < size; i++)
    lua_seqsetinumber(L, -1, i + 1, dst[i]);
#endif
  return 1;
}

/* Takes a sequence r of numbers representing bytes and converts it into an Agena number. Regardless of your platform,
   the order of bytes in r is assumed to be Little Endian.

   See: http://stackoverflow.com/questions/2182002/convert-big-endian-to-little-endian-in-c-without-using-provided-func,
   answer by dreamlax. */
static int math_tonumber (lua_State *L) {  /* 2.6.1 */
  int i, size;
  luaL_argcheck(L, lua_isseq(L, 1), 1, "sequence expected");
  size = agn_seqsize(L, 1);
  if (!(size == sizeof(int32_t) || size == sizeof(lua_Number)))
    luaL_error(L, "Error in " LUA_QS ": expected a sequence of %d or %d values.",
      "math.tonumber", sizeof(int32_t), sizeof(lua_Number));
  union {
    lua_Number x;
    int32_t i;
    unsigned char c[size];
  } dst;
  for (i=0; i < size; i++) {
#if BYTE_ORDER != BIG_ENDIAN
    dst.c[i] = (unsigned char)agn_seqgetinumber(L, 1, i + 1);
#else
    dst.c[size - 1 - i] = (unsigned char)agn_seqgetinumber(L, 1, i + 1);
#endif
  }
  lua_pushnumber(L, (size == sizeof(lua_Number)) ? dst.x : dst.i);
  return 1;
}


/* formerly implemented in Agena as: math.ndigits := << n :: number -> entier(ln(n)/ln(10) + 1) >>; */

static int math_ndigits (lua_State *L) {  /* 2.7.0 */
  lua_Number x;
  x = agn_checknumber(L, 1);
  if (x < 0)
    x = -x;
  if (x < 1)
    lua_pushnumber(L, 1);
  else
    lua_pushinteger(L, log10(x) + 1);
  return 1;
}


/* Splits an integer x to the base b into its digits and returns them in a sequence, with the highest-order digit
   as the first element and the lowest-order digit as the last element. Any sign of x is ignored. By default, the base
   is 10, but you may choose any other positive base.

   Example: b := 256; > math.decompose(15 * b^2 + 7 * b + 1, 256): -> seq(15, 7, 1) */

static int math_decompose (lua_State *L) {  /* 2.7.0 */
  lua_Integer x, base;
  size_t c, i;
  x = agn_checkinteger(L, 1);
  base = agnL_optinteger(L, 2, 10);
  if (base < 1)
    luaL_error(L, "Error in " LUA_QS ": second argument must be a positive integer.", "math.decompose");
  agn_createseq(L, 0);  /* we chose a sequence instead of a register for the number of digits in non-base10 numbers
                           cannot always be correctly be determined with C's log function due to round-off errors. */
  c = 0;
  if (x < 0) x = -x;
  if (x == 0) {
    lua_seqsetinumber(L, -1, ++c, 0);
  } else {
    while (x > 0) {
      lua_seqsetinumber(L, -1, ++c, x % base);
      x = x / base;
    }
  }
  /* reverse order of sequence */
  for (i=1; i <= c / 2; i++) {
    lua_seqgeti(L, -1, i);
    lua_seqgeti(L, -2, c - i + 1);
    /* swap */
    lua_seqseti(L, -3, i);  /* and pop value */
    lua_seqseti(L, -2, c - i + 1);  /* and pop value */
  }
  return 1;
}


/* Based on http://stackoverflow.com/questions/6862684/converting-from-decimal-degrees-to-degrees-minutes-seconds-tenths,
   solution #4 proposed by user807566.

   Do not use the formula math.dms := proc(x :: number) is local f := frac(x)*60; return int(x) + int(f)/100 + frac(f)/100 end;
   or any version also detecting the sign of x for it is prone to slight rounding errors in loops with fractional step sizes. */
static int math_dms (lua_State *L) {   /* rewritten in C, 2.8.3, 25 percent faster than the former - inprecise - Agena version */
   long long int deg, min, sec, sign;  /* do not use int or long int due to possible overflows */
   lua_Number x = agn_checknumber(L, 1);
   if (x < 0) {
     x = -x;
     sign = -1;
   } else
     sign = 1;
   sec = floor(3600.0*x + 0.5);
   deg = sec / 3600;
   sec = fabs(fmod(sec, 3600.0));
   min = sec / 60;
   sec = fmod(sec, 60);
   lua_pushnumber(L, sign*((lua_Number)deg + (lua_Number)min/100.0 + (lua_Number)sec/10000.0));
   return 1;
}


/* 2.8.4, see http://stackoverflow.com/questions/13975745/the-fastest-way-to-get-current-quadrant-of-an-angle,
   solution #2 posted by Vincent Mimoun-Prat.
   The function returns the quadrant of an angle given in radians and returns an integer in [1, 4]. */
static int math_quadrant (lua_State *L) {
  lua_Number angle = fmod(agn_checknumber(L, 1)/RADIANS_PER_DEGREE, 360.0);  /* [0..360) if angle is positive, (-360..0] if negative */
  if (angle < 0) angle += 360.0;  /* back to [0..360) */
  lua_pushnumber(L, fmod(trunc(angle/90), 4) + 1);  /* the quadrant */
  return 1;
}


static int math_fdim (lua_State *L) {
  lua_pushnumber(L, fdim(agn_checknumber(L, 1), agn_checknumber(L, 2)));
  return 1;
}


static int math_fdima (lua_State *L) {  /* 2.8.5 */
  lua_Number x, y, a;
  x = agn_checknumber(L, 1);
  y = agn_checknumber(L, 2);
  a = agnL_optnumber(L, 3, 0);
  if (isnan(x) || isnan(y))
    lua_pushundefined(L);
  /* else if (a == 0) */ /* no difference in speed when checking for a = 0 */
  /*   lua_pushnumber(L, fdim(x, y)); */
  else
    lua_pushnumber(L, x >= y ? x - y : a);
  return 1;
}


static int math_isminuszero (lua_State *L) {  /* 2.8.4 */
  lua_Number x = agn_checknumber(L, 1);
  lua_pushboolean(L, x == 0 && signbit(x) != 0);
  return 1;
}


/* Returns its argument x if -|t| <= x <= |t|, else returns sign(x) * |t|. Four times faster than the Agena implementation. */
static int math_symtrunc (lua_State *L) {  /* 2.8.4, idea taken from web article `fdim C99 - C in a Nutshell` at
                                              https://www.safaribooksonline.com/library/view/c-in-a/0596006977/re59.html */
  lua_Number x, t, sign;
  int option;
  x = agn_checknumber(L, 1);
  t = agn_checknumber(L, 2);
  option = agnL_optboolean(L, 3, 0);
  if (!option && t < 0) t = -t;
  sign = copysign(t, x);                 /* save the sign ... */
  x = copysign(x, t);                    /* ... then use only positive values */
  x = t - fdim(t, x);                    /* trim excess beyond 1.0 */
  lua_pushnumber(L, copysign(x, sign));  /* restore sign */
  return 1;
}


static int math_rint (lua_State *L) {  /* 2.8.6 */
  lua_pushnumber(L, rint(agn_checknumber(L, 1)));
  return 1;
}


/* 2.9.0, returns -1 if its numeric argument x is -infinity, +1 if its numeric argument x is +infinity,
  or 0 if neither.

  There seems to be a bug in MingW/GCC's version of isinf: it also returns +1 for -infinity, so an alternative
  has been implemented which is 3 percent faster than copysign(1, x) * fabs(isinf(x));
  (fpclassify(x) == FP_INFINITE) * copysign(1, x) is not faster */

static int math_isinfinity (lua_State *L) {
  lua_Number x = agn_checknumber(L, 1);
  lua_pushnumber(L, (x == -HUGE_VAL || x == HUGE_VAL) * copysign(1, x) );
  return 1;
}


static const luaL_Reg mathlib[] = {
  {"arccosh", math_arccosh},              /* added on December 04, 2014 */
  {"ceillog2", math_ceillog2},            /* added on November 21, 2014 */
  {"ceilpow2", math_ceilpow2},            /* added on November 27, 2014 */
  {"copysign", math_copysign},            /* added on December 04, 2014 */
  {"decompose", math_decompose},          /* added on June 05, 2015 */
  {"dms", math_dms},                      /* added on July 27, 2015 */
  {"eps", math_eps},                      /* added on February 09, 2015 */
  {"expminusone", math_expminusone},      /* added on December 02, 2014 */
  {"fdim", math_fdim},                    /* added on August 03, 2015 */
  {"fdima", math_fdima},                  /* added on August 30, 2015 */
  {"fpbtoint", math_fpbtoint},            /* added on November 21, 2014 */
  {"gethigh", math_gethigh},              /* 0.27.0 / 2.4.5, function added on March 05, 2015 */
  {"getlow", math_getlow},                /* 0.27.0 / 2.4.5, function added on March 05, 2015 */
  {"inttofpb", math_inttofpb},            /* added on November 21, 2014 */
  {"isinfinity", math_isinfinity},        /* added on October 19, 2015 */
  {"isminuszero", math_isminuszero},      /* added on August 12, 2015 */
  {"isordered", math_isordered},          /* added on December 02, 2014 */
  {"isprime", math_isprime},              /* added on August 19, 2007 */
  {"koadd", math_koadd},                  /* added on February 01, 2015 */
  {"lnplusone", math_lnplusone},          /* added on December 02, 2014 */
  {"max", math_max},
  {"min", math_min},
  {"morton", math_morton},                /* added on November 27, 2014 */
  {"ndigits", math_ndigits},              /* added on June 06, 2015 */
  {"nextafter", math_nextafter},          /* added on August 17, 2009 */
  {"nextprime", math_nextprime},          /* added on June 24, 2010 */
  {"norm", math_norm},                    /* added on May 22, 2010 */
  {"prevprime", math_prevprime},          /* added on June 24, 2010 */
  {"quadrant", math_quadrant},            /* added on August 02, 2015 */
  {"random", math_random},
  {"randomseed", math_randomseed},
  {"rint", math_rint},                    /* added on September 28, 2015 */
  {"sethigh", math_sethigh},              /* 0.27.0 / 2.4.5, function added on March 05, 2015 */
  {"setlow", math_setlow},                /* 0.27.0 / 2.4.5, function added on March 05, 2015 */
  {"signbit", math_signbit},              /* added on February 08, 2015 */
  {"symtrunc", math_symtrunc},            /* added on August 14, 2015 */
  {"tobytes", math_tobytes},              /* added on May 24, 2015 */
  {"todecimal", math_todecimal},          /* added on August 25, 2013 */
  {"tonumber", math_tonumber},            /* added on May 25, 2015 */
  {"toradians", math_toradians},          /* added on January 21, 2008 */
  {NULL, NULL}
};


/*
** Open math library
*/
LUALIB_API int luaopen_math (lua_State *L) {
  luaL_register(L, LUA_MATHLIBNAME, mathlib);
  lua_pushnumber(L, PHI);      /* added 0.5.0 */
  lua_setfield(L, -2, "Phi");  /* added 0.5.0 */
  return 1;
}

