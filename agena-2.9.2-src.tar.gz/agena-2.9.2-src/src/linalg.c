/*
** $Id: linalg.c, initiated September 04, 2008 $
** Linear Algebra library
** See Copyright Notice in agena.h
*/


#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef X86ASM  /* 2.4.0 */
#include "x86math.h"
#endif

#define linalg_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "agncmpt.h"  /* for trunc in Linux */


#if !(defined(LUA_DOS) || defined(__OS2__) || defined(LUA_ANSI))
#define AGENA_LINALGLIBNAME "linalg"
LUALIB_API int (luaopen_linalg) (lua_State *L);
#endif


/* checks whether the two arguments are vectors of the same dimension, modified Agena 1.4.3/1.5.0 */
#define checkvectors(L,a,b,p) { \
  if (!(agn_istableutype(L, (a), "vector") && agn_istableutype(L, (b), "vector")) ) \
    luaL_error(L, "Error in " LUA_QS ": two vectors expected.", (p)); \
  lua_getfield(L, (a), "dim"); \
  sizea = agn_checknumber(L, -1); \
  agn_poptop(L); \
  lua_getfield(L, (b), "dim"); \
  sizeb = agn_checknumber(L, -1); \
  agn_poptop(L); \
  if (sizea != sizeb) \
    luaL_error(L, "vectors of different size."); \
}


/* checks whether the argument is a vector, modified Agena 1.4.3/1.5.0 */
#define checkvector(L,a,p) { \
  if (!(agn_istableutype(L, (a), "vector")) ) \
    luaL_error(L, "Error in " LUA_QS ": vector expected, got %s.", (p), lua_typename(L, lua_type((L), (a)))); \
  lua_getfield(L, (a), "dim"); \
  size = agn_checknumber(L, -1); \
  agn_poptop(L); \
}

static int checkVector (lua_State *L, int idx, const char *procname) {  /* 2.1.4, proper error message added */
  int size;
  checkvector(L, idx, procname);
  return size;
}

/* Checks whether an object at stack index idx is an Agena matrix.

   If retdims is not 0, assigns its dimensions to p and q, and also puts the dimension pair onto the stack. It returns an error
   if issquare is not 0 and the dimensions are not the same.

   If retdims is 0, the the function does not change the stack. */

static void linalg_auxcheckmatrix (lua_State *L, int idx, int retdims, int issquare, const char *procname, int *p, int *q) {
  if (!agn_istableutype(L, idx, "matrix"))
    luaL_error(L, "Error in " LUA_QS ": matrix expected, got %s.", procname, luaL_typename(L, idx));  /* Agena 1.8.1 */
  else if (retdims) {
    lua_getfield(L, idx, "dim");  /* pushes dimensions onto the stack */
    if (!lua_ispair(L, -1))
      luaL_error(L, "Error in " LUA_QS ": invalid matrix received, missing dimensions.", procname);  /* Agena 1.8.1 */
    agn_pairgeti(L, -1, 1);
    *p = agn_checkinteger(L, -1);
    agn_pairgeti(L, -2, 2);
    *q = agn_checkinteger(L, -1);
    agn_poptoptwo(L);  /* pop left and right value */
    if (issquare && ( *p != *q ))
      luaL_error(L, "Error in " LUA_QS ": square matrix expected.", procname);  /* Agena 1.8.1 */
  }
}


/* Set dimensions of a matrix. The matrix must be at the top of the stack. The two remove
   statements at the end of the macro remove left and right operand nargs since agn_creatpair
   does not remove the two upper values. Optimised 2.1.3 */
#define setmatrixdims(L, a, b) { \
  lua_pushstring(L, "dim"); \
  lua_pushnumber(L, (a)); \
  lua_pushnumber(L, (b)); \
  agn_createpair(L, -2, -1); \
  lua_remove(L, -2); lua_remove(L, -2); \
  lua_rawset(L, -3); \
}


/* Set dimensions of a vector. The vector must be at the top of the stack. */
#define setvectordim(L, a) { \
  lua_pushstring(L, "dim"); \
  lua_pushnumber(L, a); \
  lua_rawset(L, -3); \
}


/* Set metatable to a vector or matrix. o either is the string "vmt" or "mmt".
   The vector must be at the top of the stack. */
#define setmetatable(L, o) { \
  lua_getglobal(L, "linalg"); \
  lua_getfield(L, -1, o); \
  lua_setmetatable(L, -3); \
  agn_poptop(L); \
}

/* set vector attributes: user-defined type, metatable, and dimension to a vector
   which must be at the top of the stack */
#define setvattribs(L, a) { \
  lua_pushstring(L, "vector"); \
  agn_setutype(L, -2, -1); \
  agn_poptop(L); \
  setmetatable(L, "vmt"); \
  setvectordim(L, (a)); \
}


/* set matrix attributes: user-defined type, metatable, and dimensions to a matrix
   which must be at the top of the stack */
#define setmattribs(L, a, b) { \
  lua_pushstring(L, "matrix"); \
  agn_setutype(L, -2, -1); \
  agn_poptop(L); \
  setmetatable(L, "mmt"); \
  setmatrixdims(L, (a), (b)); \
}


/* creates an array a with size n, FREE it ! */
#define createarray(a, n, procname) { \
  if ((n) < 1) \
    luaL_error(L, "Error in " LUA_QS ": table or sequence with at least one entry expected.", (procname)); \
  (a) = malloc((n)*sizeof(lua_Number)); \
  if ((a) == NULL) \
    luaL_error(L, "Error in " LUA_QS ": memory allocation failed.", (procname)); \
}


/* expects an m x n C matrix array and puts an Agena matrix at the top of the stack. Creates a sparse matrix
   if at least one element in the C array is zero. */
static int creatematrix (lua_State *L, lua_Number *a, int m, int n) {
  /* create new matrix with the elements of C `matrix` a */
  int i, j;
  lua_Number item;
  lua_createtable(L, m, 1);
  for (i=0; i < m; i++) {
    lua_createtable(L, n, 1);  /* create new vector */
    for (j=0; j < n; j++) {
      item = a[i*n + j];
      if (item != 0) lua_rawsetinumber(L, -1, j + 1, item);  /* create sparse matrix if possible */
    }
    setvattribs(L, n);
    lua_rawseti(L, -2, i + 1);
  }
  setmattribs(L, m, n);
  return 1;
}


static int createrawmatrix (lua_State *L, int m, int n) {
  /* create new Agena matrix with preallocated row vectors */
  int i;
  lua_createtable(L, m, 1);
  for (i=0; i < m; i++) {
    lua_createtable(L, n, 1);    /* create new row vector */
    setvattribs(L, n);
    lua_rawseti(L, -2, i + 1);   /* and set it to new matrix */
  }
  setmattribs(L, m, n);
  return 1;
}


/* expects a vector of dimension n and puts an Agena vector at the top of the stack. 2.1.3 */
static int createvector (lua_State *L, lua_Number *a, int n) {
  /* create new vector with the elements of C array a */
  int i;
  lua_createtable(L, n, 1);
  for (i=0; i < n; i++) {
    if (a[i] != 0) lua_rawsetinumber(L, -1, i + 1, a[i]);  /* 2.1.4: create sparse vector if possible */
  }
  setvattribs(L, n);
  return 1;
}


/* expects an m x n-Agena matrix of n-dimensional row vectors at index idx and creates a C matrix array a. The
   function leaves the stack untouched. 2.1.3
   gaps: allows to prefill #gaps columns at the right end of the m x n matrix with zeros even if the row vector
   has less elements than needed. */
static void fillmatrix (lua_State *L, int idx, lua_Number *a, int m, int n, int gaps, const char *procname) {
  int i, j;
  for (i=0; i < m; i++) {
    lua_rawgeti(L, idx, i + 1);  /* push row vector on stack */
    if (checkVector(L, -1, procname) + gaps != n)
      luaL_error(L, "Error in " LUA_QS ": row vector has wrong dimension.", procname);
    for (j=0; j < n; j++)
      a[i*n + j] = agn_getinumber(L, -1, j + 1);
    agn_poptop(L);  /* pop row vector */
  }
}


/* expects an n-dimensional Agena row vector at index idx and creates a C array a. The function leaves
   the stack untouched. */
static void fillvector (lua_State *L, int idx, lua_Number *a, int n, const char *procname) {
  int i;
  if (checkVector(L, idx, procname) != n)
    luaL_error(L, "Error in " LUA_QS ": vector has wrong dimension.", procname);
  for (i=0; i < n; i++)
    a[i] = agn_getinumber(L, idx, i + 1);
}


/* Add two vectors. The result is a new vector. Tuned 2.1.3 */
static int linalg_add (lua_State *L) {
  int i, sizea, sizeb;
  checkvectors(L, 1, 2, "linalg.add");
  lua_createtable(L, sizea, 1);
  /* now traverse vectors */
  for (i=1; i <= sizea; i++)
    lua_rawsetinumber(L, -1, i, agn_getinumber(L, 1, i) + agn_getinumber(L, 2, i));  /* store result to new sequence */
  /* set attributes */
  setvattribs(L, sizea);
  return 1;
}


/* Subtract two vectors. The result is a new vector. Tuned 2.1.3 */
static int linalg_sub (lua_State *L) {
  int i, sizea, sizeb;
  checkvectors(L, 1, 2, "linalg.sub");
  lua_createtable(L, sizea, 1);
  /* now traverse vectors */
  for (i=1; i <= sizea; i++)
    lua_rawsetinumber(L, -1, i, agn_getinumber(L, 1, i) - agn_getinumber(L, 2, i));  /* store result to new sequence */
  /* set attributes */
  setvattribs(L, sizea);
  return 1;
}


static int linalg_scalarmul (lua_State *L) {  /* tuned & extended 2.1.3 */
  int i, size, nidx, vidx;
  lua_Number n, a;
  n = 0;  /* to avoid compiler warning */
  if (lua_isnumber(L, 1) && agn_istableutype(L, 2, "vector")) {
    nidx = 1; vidx = 2;
  } else if (agn_istableutype(L, 1, "vector") && lua_isnumber(L, 2)) {
    vidx = 1; nidx = 2;
  } else {
    nidx = vidx = 0;  /* to avoid compiler warnings */
    luaL_error(L, "Error in " LUA_QS ": number and vector expected.", "linalg.scalarmul");
  }
  n = agn_tonumber(L, nidx);
  lua_getfield(L, vidx, "dim");
  size = agn_checknumber(L, -1);  /* Agena 1.4.3/1.5.0 */
  agn_poptop(L);
  lua_createtable(L, size, 1);
  /* now traverse vector */
  for (i=0; i < size; i++) {
    a = agn_getinumber(L, vidx, i+1);
    lua_rawsetinumber(L, -1, i+1, n*a);  /* store result to new vector */
  }
  /* set attributes */
  setvattribs(L, size);
  return 1;
}


static int linalg_dotprod (lua_State *L) {  /* 2.1.3 */
  int i, sizea, sizeb;
  lua_Number s;
  checkvectors(L, 1, 2, "linalg.dotprod");
  s = 0;
  /* now traverse vectors */
  for (i=1; i <= sizea; i++)
    s += agn_getinumber(L, 1, i) * agn_getinumber(L, 2, i);
  lua_pushnumber(L, s);
  return 1;
}


/* Recursive definition of determinate using expansion by minors. Taken from:
   http://paulbourke.net/miscellaneous/determinant and adapted to one-dimensional C matrix array */
static lua_Number determinant (lua_State *L, lua_Number *a, int n) {  /* 2.1.3 */
  lua_Number det = 0;
  if (n == 1) { /* shouldn't get used */
    det = a[0];
  } else if (n == 2) {
    det = a[0] * a[3] - a[2] * a[1];
  } else {
    int i, j, j1, j2, nn, sign;
    lua_Number *m;
    det = 0;
    sign = 1;
    nn = n - 1;
    for (j1=0; j1 < n; j1++) {
      createarray(m, nn * nn, "linalg.det");
      for (i=1; i < n; i++) {
        j2 = 0;
        for (j=0; j < n; j++) {
          if (j == j1) continue;
          m[(i-1)*nn + j2] = a[i*n + j];
          j2++;
        }
      }
      det += sign * a[j1] * determinant(L, m, nn);
      sign = -sign;
      xfree(m);
    }
  }
  return(det);
}

static int linalg_det (lua_State *L) {  /* 2.1.3 */
  int m, n;
  lua_Number *a;
  m = n = 0;  /* just to prevent compiler warnings */
  linalg_auxcheckmatrix(L, 1, 1, 1, "linalg.det", &m, &n);
  agn_poptop(L);  /* pop the dimension pair of the matrix */
  createarray(a, n * n, "linalg.det");
  fillmatrix(L, 1, a, n, n, 0, "linalg.det");
  lua_pushnumber(L, determinant(L, a, n));
  xfree(a);
  return 1;
}


/* Find the cofactor matrix of a square matrix, the result is returned in b
   Source: http://paulbourke.net/miscellaneous/Determinant of a square matrix.htm,
   written by Paul Bourke; modified for Agena */
static void cofactor (lua_State *L, lua_Number *a, int n, lua_Number *b) {
  int i, j, ii, jj, i1, j1, nn;
  lua_Number det, *c;
  nn = n - 1;
  createarray(c, nn * nn, "linalg.inverse");
  for (j=0; j < n; j++) {
    for (i=0; i < n; i++) { /* form the adjoint a_ij */
      i1 = 0;
      for (ii=0; ii < n; ii++) {
        if (ii == i) continue;
        j1 = 0;
        for (jj=0; jj < n; jj++) {
          if (jj == j) continue;
          c[i1*nn + j1] = a[ii*n + jj];
          j1++;
        }
        i1++;
      }
      det = determinant(L, c, nn);  /* calculate the determinate */
      b[i*n + j] = tools_intpow(-1, i + j + 2) * det;  /* fill in the elements of the cofactor */
    }
  }
  xfree(c);
}

/* Transpose of a square matrix, do it in place
   Source: http://paulbourke.net/miscellaneous/Determinant of a square matrix.htm,
   written by Paul Bourke; modified for Agena */
static void transpose (lua_Number *a, int n) {
  int i, j;
  lua_Number tmp;
  for (i=1; i < n; i++) {
    for (j=0; j < i; j++) {
      tmp = a[i*n + j];
      a[i*n + j] = a[j*n + i];
      a[j*n + i] = tmp;
    }
  }
}


static int linalg_inverse (lua_State *L) {  /* 2.1.3 */
  int i, j, m, n;
  lua_Number det, *a, *b;
  linalg_auxcheckmatrix(L, 1, 1, 1, "linalg.inverse", &m, &n);
  agn_poptop(L);
  createarray(a, n * n, "linalg.inverse");
  createarray(b, n * n, "linalg.inverse");
  fillmatrix(L, 1, a, n, n, 0, "linalg.inverse");
  det = determinant(L, a, n);
  cofactor(L, a, n, b);
  transpose(b, n);  /* create adjoint matrix, in place, the adjoint matrix is the transpose of the cofactor matrix. */
  for (i=0; i < n; i++) {
    for (j=0; j < n; j++) b[i*n + j] = b[i*n + j] / det;
  }
  creatematrix(L, b, n, n);
  xfree(a); xfree(b);
  return 1;
}


static int linalg_transpose (lua_State *L) {  /* 2.1.3 */
  int m, n;
  lua_Number *a;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.transpose", &m, &n);
  agn_poptop(L);
  createarray(a, m * n, "linalg.transpose");
  fillmatrix(L, 1, a, m, n, 0, "linalg.transpose");
  if (m == n) {
    transpose(a, n);
    creatematrix(L, a, n, n);
  } else {
    lua_Number *b;
    int i, j, c;
    createarray(b, m * n, "linalg.transpose");
    c = 0;
    for (j=0; j < n; j++) {
      for (i=0; i < m; i++) {
        b[c++] = a[i*n + j];
      }
    }
    creatematrix(L, b, n, m);
    xfree(b);
  }
  xfree(a);
  return 1;
}


static int linalg_mmul (lua_State *L) {  /* 2.1.3 */
  int i, j, k, m, n, p, q;
  lua_Number *a, *b, s;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.mmul", &m, &n);
  linalg_auxcheckmatrix(L, 2, 1, 0, "linalg.mmul", &p, &q);
  agn_poptoptwo(L);  /* pop the two dimension pairs of the matrices */
  if (n != p)
    luaL_error(L, "Error in " LUA_QS ": incompatible dimensions, must get an m x n- & an n x p-matrix.", "linalg.mmul");
  createarray(a, m * n, "linalg.mmul");
  createarray(b, p * q, "linalg.mmul");
  fillmatrix(L, 1, a, m, n, 0, "linalg.mmul");
  fillmatrix(L, 2, b, p, q, 0, "linalg.mmul");
  createrawmatrix(L, m, q);
  for (i=0; i < m; i++) {  /* for each row in A */
    lua_rawgeti(L, -1, i + 1);  /* push row vector of the resulting matrix and avoid too many pushes ... */
    for (k=0; k < q; k++) {  /* for each column in B */
      s = 0;
      for (j=0; j < n; j++) {   /* for each element in A */
        s += a[i*n + j] * b[j*q + k];
      }
      lua_rawsetinumber(L, -1, k + 1, s);  /* ... and set its respective element */
    }
    agn_poptop(L);  /* pop row vector */
  }
  xfree(a); xfree(b);
  return 1;
}


static void meq (lua_State *L, int (*fn)(lua_Number, lua_Number, lua_Number), int geteps) {  /* 2.1.3, can compare normal with sparse matrices */
  int i, j, m, n, p, q, flag;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.meq", &m, &n);
  linalg_auxcheckmatrix(L, 2, 1, 0, "linalg.meq", &p, &q);
  agn_poptoptwo(L);  /* pop the two dimension pairs of the matrices A and B */
  flag = 1;
  if (m != p || n != q)
    lua_pushfalse(L);
  else {  /* matrices have same dimensions */
    lua_Number eps;
    eps = agn_getepsilon(L);
    for (i=1; i <= m; i++) {
      lua_rawgeti(L, 1, i);  /* push row vector of A */
      lua_rawgeti(L, 2, i);  /* push row vector of B */
      for (j=1; j <= n; j++) {  /* now compare each item */
        if (!fn(agn_getinumber(L, -2, j), agn_getinumber(L, -1, j), eps)) {
          flag = 0;
          agn_poptoptwo(L);  /* pop both row vectors */
          goto endofmeq;  /* exit both loops in case of inequality */
        }
      }
      agn_poptoptwo(L);  /* pop both row vectors */
    }  /* end of for i */
  }
endofmeq:
  lua_pushboolean(L, flag);
}

static int equal (lua_Number x, lua_Number y, lua_Number eps) {  /* strict equality, eps does not matter */
  return x == y;
}


static int linalg_maeq (lua_State *L) {  /* 2.1.3 */
  meq(L, tools_approx, 1);
  return 1;
}


static int linalg_meeq (lua_State *L) {  /* 2.1.4 */
  meq(L, equal, 0);
  return 1;
}


static int linalg_trace (lua_State *L) {  /* 2.1.4, uses Kahan-Ozawa summation */
  int i, m, n;
  lua_Number q, s, sold, u, v, w, x, t;
  linalg_auxcheckmatrix(L, 1, 1, 1, "linalg.trace", &m, &n);
  agn_poptop(L);  /* pop dimension pair of matrix A */
  s = q = 0;
  for (i=1; i <= m; i++) {
    lua_rawgeti(L, 1, i);  /* push row vector of A */
    x = agn_getinumber(L, -1, i);  /* get i-th element */
    v = x - q;
    sold = s;
    s = s + v;
    if (fabs(x) < fabs(q)) {
      t = x;
      x = -q;
      q = t;
    }
    u = (v - x) + q;
    if (fabs(sold) < fabs(v)) {
      t = sold;
      sold = v;
      v = t;
    }
    w = (s - sold) - v;
    q = u + w;
    agn_poptop(L);  /* pop row vector */
  }
  lua_pushnumber(L, s);
  return 1;
}


static int linalg_getdiagonal (lua_State *L) {  /* 2.1.4 */
  int i, m, n;
  linalg_auxcheckmatrix(L, 1, 1, 1, "linalg.getdiagonal", &m, &n);
  agn_poptop(L);  /* pop dimension pair of matrix A */
  agn_createtable(L, m, 1);
  for (i=1; i <= m; i++) {
    lua_rawgeti(L, 1, i);  /* push row vector of A */
    lua_rawsetinumber(L, -2, i, agn_getinumber(L, -1, i));
    agn_poptop(L);  /* pop row vector */
  }
  setvattribs(L, m);
  return 1;
}


static int linalg_diagonal (lua_State *L) {  /* 2.1.4 */
  int i, size;
  checkvector(L, 1, "linalg.diagonal");
  createrawmatrix(L, size, size);
  for (i=1; i <= size; i++) {  /* for each row in A */
    lua_rawgeti(L, -1, i);  /* push row vector of new matrix */
    lua_rawsetinumber(L, -1, i, agn_getinumber(L, 1, i));  /* ... and set its respective element */
    agn_poptop(L);  /* pop row vector of A and row vector of new matrix */
  }
  return 1;
}


static int linalg_vaeq (lua_State *L) {  /* 2.1.3 */
  int i, size;
  lua_Number eps;
  size = checkVector(L, 1, "linalg.veq");
  if (size != checkVector(L, 2, "linalg.veq")) {
    lua_pushfalse(L);
    return 1;
  }
  eps = agn_getepsilon(L);
  for (i=1; i <= size && tools_approx(agn_getinumber(L, 1, i), agn_getinumber(L, 2, i), eps); i++);
  lua_pushboolean(L, i > size);
  return 1;
}


static int linalg_veeq (lua_State *L) {  /* 2.1.4 */
  int i, size;
  size = checkVector(L, 1, "linalg.veq");
  if (size != checkVector(L, 2, "linalg.veq")) {
    lua_pushfalse(L);
    return 1;
  }
  for (i=1; i <= size && agn_getinumber(L, 1, i) == agn_getinumber(L, 2, i); i++);
  lua_pushboolean(L, i > size);
  return 1;
}


/* Gau� Elimination with Pivoting, 2.1.3, modified 2.1.5

   Merge of code taken from:
   - http://www.dailyfreecode.com/code/basic-gauss-elimination-method-gauss-2949.aspx posted by Alexander Evans, and
   - http://paulbourke.net/miscellaneous/gausselim published by Paul Bourke;
   modified for Agena.

   At completion, a will hold the upper triangular matrix, and x the solution vector. */

static int gsolve (lua_Number *a, int n, lua_Number *x, lua_Number eps) {
  int i, j, k, maxrow, nn, issingular;
  lua_Number tmp, max;
  nn = n + 1;
  issingular = 0;
  for (j=0; j < n; j++) {  /* modified, for (j=0; j < n-1; j++) { */
    max = fabs(a[j*nn + j]);
    maxrow = j;
    for (i=j+1; i < n; i++)  /* find the row with the largest first value */
      if (fabs(a[i*nn + j]) > max) {
         max = a[i*nn + j];
         maxrow = i;
      }
    /*  if (maxrow != j) { */
    for (k=j; k < n+1; k++) {  /* swap the maxrow and jth row */
      tmp = a[j*nn + k];
      a[j*nn + k] = a[maxrow*nn + k];
      a[maxrow*nn + k] = tmp;
     }
    /* } */
    if (issingular == 0 && fabs(a[j*nn + j]) < eps) issingular = 1; /* statement added to detect singular matrices */
    for (i=j+1; i < n; i++) {  /* eliminate the ith element of the jth row */
      tmp = a[i*nn + j] / a[j*nn + j];
      for (k=n; k >= j; k--)
        a[i*nn + k] -=  a[j*nn + k] * tmp;
    }
  }
  for (j=n-1; j >= 0; j--) {  /* do the back substitution */
    tmp = 0;
    for (k=j+1; k < n; k++)
      tmp += a[j*nn + k] * x[k];
    x[j] = (a[j*nn + n] - tmp) / a[j*nn + j];
  }
  return issingular;
}

static int linalg_gsolve (lua_State *L) {  /* 2.1.3 */
  int i, m, n, nargs, retut, iszero, isundefined;
  lua_Number *a, *x, eps;
  nargs = lua_gettop(L);
  retut = (lua_isboolean(L, nargs) && lua_toboolean(L, nargs) == 1);
  if (retut == 1) nargs--;  /* return upper triangular matrix, as well. */
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.gsolve", &m, &n);
  agn_poptop(L);  /* pop dimension pair of the matrix */
  eps = agn_getepsilon(L);
  if (nargs == 1) {
    if (m + 1 != n)
      luaL_error(L, "Error in " LUA_QS ": matrix has wrong dimensions.", "linalg.gsolve");
  } else if (nargs == 2) {
    if (m != n)
      luaL_error(L, "Error in " LUA_QS ": expected a square matrix.", "linalg.gsolve");
    if (n != checkVector(L, 2, "linalg.gsolve"))
      luaL_error(L, "Error in " LUA_QS ": expected matrix and vector with equal dimensions.", "linalg.gsolve");
    n++;
  } else
    luaL_error(L, "Error in " LUA_QS ": one or two arguments expected.", "linalg.gsolve");
  createarray(a, m*n, "linalg.gsolve");
  createarray(x, m, "linalg.gsolve");
  if (nargs == 1)
    fillmatrix(L, 1, a, m, n, 0, "linalg.gsolve");
  else {  /* augment square matrix with vector */
    int i;
    lua_Number *b;
    createarray(b, m, "linalg.gsolve");
    fillmatrix(L, 1, a, m, n, 1, "linalg.gsolve");
    fillvector(L, 2, b, m, "linalg.gsolve");
    for (i=0; i < m; i++) a[i*n + m] = b[i];
    xfree(b);
  }
  gsolve(a, m, x, eps);
  iszero = 1; isundefined = 0;
  /* now inspect augmented row reduced echelon matrix */
  for (i=0; i < n - 1; i++) {
    if (!tools_approx(a[(m - 1)*n + i], 0, eps)) {
      iszero = 0;
      break;
    }
  }
  for (i=0; i < n; i++) {
    if (tools_isnan(a[(m - 1)*n + i])) {
      isundefined = 1;
      break;
    }
  }
  if (isundefined)  /* example: m := matrix([1, 1, 1], [2, 2, 5], [4, 4, 8]), b := vector(-1, -8, -14) */
    lua_pushfail(L);
  else if (iszero) {
    lua_pushnumber(L, tools_approx(a[(m - 1)*n + (n - 1)], 0, eps) ? HUGE_VAL : AGN_NAN);  /* infinite number of solutions or no solution */
  } else
    createvector(L, x, m);
  if (retut) creatematrix(L, a, m, n);  /* return upper triangular matrix, too. */
  xfree(a); xfree(x);
  return 1 + retut;
}


static int linalg_vector (lua_State *L) {
  int i, nops, type;
  nops = lua_gettop(L);
  if (nops == 0)
    luaL_error(L, "Error in " LUA_QS ": at least one argument expected.", "linalg.vector");
  luaL_checkstack(L, nops, "too many elements");
  type = lua_type(L, 1);
  if (nops == 2 && type == LUA_TNUMBER && lua_type(L, 2) == LUA_TTABLE) {  /* Maple-like syntax */
    int c, key;
    c = 0;
    nops = agnL_checkinteger(L, 1);
    lua_newtable(L);
    lua_pushnil(L);
    while (lua_next(L, 2) != 0) {
      c++;
      luaL_argcheck(L, lua_type(L, -1) == LUA_TNUMBER && lua_type(L, -2) == LUA_TNUMBER, c,
        "expected a number in " LUA_QL("linalg.vector"));
      key = (int)agn_tonumber(L, -2);
      if (key < 1 || key > nops)
        luaL_error(L, "Error in " LUA_QS ": table index out of range.", "linalg.vector");
      lua_rawset2(L, -3);  /* deletes only the value, but not the key */
    }
    if (c > nops)
      luaL_error(L, "Error in " LUA_QS ": more entries passed than given dimension.", "linalg.vector");
  } else if (type == LUA_TNUMBER) {  /* assume all arguments are numbers */
    lua_createtable(L, nops, 1);
    for (i=1; i <= nops; i++) {
      lua_rawsetinumber(L, -1, i, agn_checknumber(L, i));
    }
  } else if (type == LUA_TTABLE) {
    nops = luaL_getn(L, 1);
    if (nops == 0)
      luaL_error(L, "Error in " LUA_QS ": at least one table value expected.", "linalg.vector");
    lua_createtable(L, nops, 1);
    for (i=1; i <= nops; i++) {
      lua_rawgeti(L, 1, i);
      lua_rawsetinumber(L, -2, i, agn_checknumber(L, -1));
      agn_poptop(L);
    }
  } else if (type == LUA_TSEQ && agn_isutypeset(L, 1) == 0) {  /* a sequence and no user-defined type set ? */
    nops = agn_seqsize(L, 1);
    if (nops == 0)
      luaL_error(L, "Error in " LUA_QS ": at least one sequence value expected.", "linalg.vector");
    lua_createtable(L, nops, 1);
    for (i=1; i <= nops; i++) {
      lua_seqgeti(L, 1, i);
      lua_rawsetinumber(L, -2, i, agn_checknumber(L, -1));
      agn_poptop(L);
    }
  } else
    luaL_error(L, "Error in " LUA_QS ": numbers, a table, or sequence expected.", "linalg.vector");
  /* set vector attributes */
  setvattribs(L, nops);
  return 1;
}


static int linalg_zero (lua_State *L) {  /* changed 2.1.3 */
  int i, n;
  n = agn_checknumber(L, 1);
  lua_createtable(L, n, 1);
  for (i=1; i <= n; i++)
    lua_rawsetinumber(L, -1, i, 0);
  /* set vector attributes */
  setvattribs(L, n);
  return 1;
}


static int linalg_identity (lua_State *L) {  /* optimised 2.1.3 */
  int i, n;
  n = agn_checkinteger(L, 1);
  if (n < 1)
    luaL_error(L, "Error in " LUA_QS ": positive integer expected.", "linalg.identity");
  createrawmatrix(L, n, n);
  for (i=1; i <= n; i++) {
    lua_rawgeti(L, -1, i);
    lua_rawsetinumber(L, -1, i, 1);
    agn_poptop(L);
  }
  return 1;
}


static int linalg_checkvector (lua_State *L) {
  int i, nargs, dim, olddim;
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments for " LUA_QL("linalg.checkvector"));
  olddim = 0;
  for (i=1; i <= nargs; i++) {
    if (!agn_istableutype(L, i, "vector")) {
      if (i > 1) lua_pop(L, i-1);  /* drop dimensions accumulated so far */
      luaL_error(L, "Error in " LUA_QS ": vector expected, got %s.", "linalg.checkvector", luaL_typename(L, i));
    }
    lua_getfield(L, i, "dim");
    if (nargs != 1) {
      dim = agn_checknumber(L, -1);
      if (i == 1) olddim = dim;
      if (olddim == dim)
        olddim = dim;
      else {
        lua_pop(L, i);  /* drop dimensions accumulated so far */
        luaL_error(L, "Error in " LUA_QS ": vectors of different dimension." LUA_QS, "linalg.checkvector");
      }
    }
  }
  return nargs;  /* return all dimensions */
}


static int linalg_isvector (lua_State *L) {
  int i, nargs;
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments for " LUA_QL("linalg.isvector"));
  for (i=1; i <= nargs; i++) {
    if (agn_istableutype(L, i, "vector") == 0) {
      lua_pushboolean(L, 0);
      return 1;
    }
  }
  lua_pushboolean(L, 1);
  return 1;
}


static int linalg_checkmatrix (lua_State *L) {
  int i, nargs, retdims, p, q;
  retdims = p = q = 0;
  nargs = lua_gettop(L);
  if (nargs < 1)
    luaL_error(L, "Error in " LUA_QS ": got no argument.", "linalg.checkmatrix");
  luaL_checkstack(L, nargs, "too many arguments for " LUA_QL("linalg.checkmatrix"));
  if (lua_isboolean(L, nargs) && agn_istrue(L, nargs)) {  /* Agena 1.6.0 */
    if (nargs > 1) nargs--; retdims = 1;
  }
  for (i=1; i <= nargs; i++)
    linalg_auxcheckmatrix(L, i, retdims, 0, "linalg.checkmatrix", &p, &q);
  return retdims * nargs;
}


static int linalg_ismatrix (lua_State *L) {
  int i, nargs;
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments " LUA_QL("linalg.ismatrix"));
  for (i=1; i <= nargs; i++) {
    if (agn_istableutype(L, i, "matrix") == 0) {
      lua_pushboolean(L, 0);
      return 1;
    }
  }
  lua_pushboolean(L, 1);
  return 1;
}


static int linalg_vzip (lua_State *L) {  /* extended 0.30.2 */
  int i, j, sizea, sizeb, nargs;
  luaL_checktype(L, 1, LUA_TFUNCTION);
  checkvectors(L, 2, 3, "linalg.vzip");
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments");
  lua_createtable(L, sizea, 1);
  /* now traverse vector */
  for (i=1; i <= sizea; i++) {
    lua_pushvalue(L, 1);      /* push function; FIXME: can be optimized */
    lua_pushnumber(L, i);
    lua_gettable(L, 2);
    lua_pushnumber(L, i);
    lua_gettable(L, 3);
    for (j=4; j <= nargs; j++) {
      lua_pushvalue(L, j);
    }
    lua_call(L, nargs-1, 1);  /* call function with nargs-1 arguments and one result */
    lua_rawseti(L, -2, i);    /* store result to new vector */
  }
  setvattribs(L, sizea);
  return 1;
}


static int linalg_vmap (lua_State *L) {
  int i, j, nargs, size;
  luaL_checktype(L, 1, LUA_TFUNCTION);
  nargs = lua_gettop(L);
  luaL_checkstack(L, nargs, "too many arguments for " LUA_QL("linalg.vmap"));
  checkvector(L, 2, "linalg.vmap");
  lua_createtable(L, size, 1);
  /* now traverse vector */
  for (i=1; i <= size; i++) {
    lua_pushvalue(L, 1);      /* push function; FIXME: can be optimized */
    lua_pushnumber(L, i);
    lua_gettable(L, 2);
    for (j=3; j <= nargs; j++)
      lua_pushvalue(L, j);
    lua_call(L, nargs-1, 1);  /* call function with nargs-1 argument and one result */
    lua_rawseti(L, -2, i);    /* store result to new vector */
  }
  setvattribs(L, size);
  return 1;
}


static int linalg_setvelem (lua_State *L) {  /* linalg.setvelem(v, key, value) */
  lua_Number dim, key;
  dim = checkVector(L, 1, "linalg.setvelem");  /* 2.1.4 */
  lua_pushvalue(L, 2);  /* push key */
  key = agn_checkinteger(L, -1);  /* 2.1.4 fix */
  if (key < 1 || key > dim) {
    agn_poptop(L);  /* pop key */
    luaL_error(L, "Error in " LUA_QS ": index %d out of range 1:%d.", "linalg.setvelem", (int)key, (int)dim);
  }
  lua_pushvalue(L, 3);  /* push value */
  lua_rawset(L, 1);     /* now conduct assignment */
  return 0;
}


/* Returns a copy of matrix A with each element in row idx multiplied by the number x. */
static int linalg_mulrow (lua_State *L) {  /* 2.1.4 */
  int i, m, n, idx;
  lua_Number x, *a;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.mulrow", &m, &n);
  agn_poptop(L);
  idx = agn_checkinteger(L, 2) - 1;
  if (idx < 0 || idx >= m)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "linalg.mulrow", idx + 1);
  x = agn_checknumber(L, 3);
  createarray(a, m * n, "linalg.mulrow");
  fillmatrix(L, 1, a, m, n, 0, "linalg.mulrow");
  for (i=0; i < n; i++) a[idx*n + i] *= x;
  creatematrix(L, a, m, n);
  xfree(a);
  return 1;
}


/* Returns a copy of matrix A with each element in row idx2 exchanged by the sum of this element and the respective
   element in row idx1 multiplied by the number x. */
static int linalg_mulrowadd (lua_State *L) {  /* 2.1.4 */
  int i, m, n, idx1, idx2;
  lua_Number x, *a;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.mulrowadd", &m, &n);
  agn_poptop(L);
  idx1 = agn_checkinteger(L, 2) - 1;
  if (idx1 < 0 || idx1 >= m)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range with second argument.", "linalg.mulrowadd", idx1 + 1);
  idx2 = agn_checkinteger(L, 3) - 1;
  if (idx2 < 0 || idx2 >= m)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range with third argument.", "linalg.mulrowadd", idx2 + 1);
  x = agn_checknumber(L, 4);
  createarray(a, m * n, "linalg.mulrowadd");
  fillmatrix(L, 1, a, m, n, 0, "linalg.mulrowadd");
  for (i=0; i < n; i++) a[idx2*n + i] += a[idx1*n + i]*x;
  creatematrix(L, a, m, n);
  xfree(a);
  return 1;
}


/* taken from: http://www.mymathlib.com/matrices/linearsystems/doolittle.html, file
   provided by RLH, Copyright � 2004 RLH. All rights reserved.

   Given the n�n matrix A, Doolittle_LU_Decomposition_with_Pivoting uses Doolittle's algorithm
   with pivoting to decompose a row interchanged version of A into the product of a unit lower
   triangular matrix and an upper triangular matrix. The non-diagonal lower triangular part of
   the unit lower triangular matrix is returned in the lower triangular part of A and the upper
   triangular part of the upper triangular matrix is returned in the upper triangular part of A.

   Upon completion the ith element of the array pivot contains the row interchanged with row i
   when k = i, k being the k in the description of the algorithm above. The array pivot should
   be dimensioned at least n in the calling routine.  Doolittle_LU_Decomposition returns -1 or 1
   if the decomposition was successful and returns 0 if the matrix is singular. */

static int Doolittle_LU_Decomposition_with_Pivoting (lua_Number *A, lua_Number *pivot, int n) {
  int i, j, k, d;
  lua_Number *p_k, *p_row, *p_col, max;
  d = 1;
  p_col = NULL;
  /* for each row and column, k = 0, ..., n-1, */
  for (k=0, p_k=A; k < n; p_k += n, k++) {
    /* find the pivot row */
    pivot[k] = k;
    max = fabs(*(p_k + k));
    for (j=k + 1, p_row=p_k + n; j < n; j++, p_row += n) {
      if ( max < fabs(*(p_row + k)) ) {
        max = fabs(*(p_row + k));
        pivot[k] = j;
        p_col = p_row;
      }
    }
    /* and if the pivot row differs from the current row, then interchange the two rows. */
    if (pivot[k] != k) {
      for (j=0; j < n; j++) {
        max = *(p_k + j);
        *(p_k + j) = *(p_col + j);
        *(p_col + j) = max;
      }
      d = -d;
    }
    /* and if the matrix is singular, return error */
    if (*(p_k + k) == 0) return 0;  /* modified for Agena */
    /* otherwise find the lower triangular matrix elements for column k. */
    for (i=k+1, p_row=p_k + n; i < n; p_row += n, i++) {
      *(p_row + k) /= *(p_k + k);
    }
    /* update remaining matrix */
    for (i=k+1, p_row=p_k + n; i < n; p_row += n, i++) {
      for (j=k+1; j < n; j++)
        *(p_row + j) -= *(p_row + k) * *(p_k + j);
    }
  }
  for (i=0; i < n; i++) pivot[i] += 1;  /* convert from C to Agena indices */
  return d;  /* return row interchange indicator, modified for Agena */
}

static int linalg_ludecomp (lua_State *L) {  /* 2.1.4, fixed 2.2.0 RC 3 */
  int m, n, nn, c;
  lua_Number *a, *p;
  linalg_auxcheckmatrix(L, 1, 1, 1, "linalg.ludecomp", &m, &n);
  agn_poptop(L);
  nn = luaL_optinteger(L, 2, m);
  if (nn < 1 || nn > m)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "linalg.ludecomp", nn);
  createarray(a, nn * nn, "linalg.ludecomp");
  createarray(p, nn, "linalg.ludecomp");
  fillmatrix(L, 1, a, nn, nn, 0, "linalg.ludecomp");
  if ((c = Doolittle_LU_Decomposition_with_Pivoting(a, p, nn)) == 0) {
    xfree(a); xfree(p);  /* 2.2.0 RC 3 */
    luaL_error(L, "Error in " LUA_QS ": singular matrix encountered.", "linalg.ludecomp");
  }
  creatematrix(L, a, nn, nn);
  createvector(L, p, nn);
  lua_pushinteger(L, c);
  xfree(a); xfree(p);
  return 3;
}


static int linalg_submatrix (lua_State *L) {  /* 2.1.4 */
  int m, n, i, j;
  lua_Number x, a, b, c, d;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.submatrix", &m, &n);
  agn_poptop(L);
  a = c = 1;
  b = n; d = m;
  if (lua_ispair(L, 2)) {
    lua_pushvalue(L, 2);
    agn_pairgetnumbers(L, "linalg.submatrix", -1, &a, &b);
  }
  else if (lua_isnumber(L, 2))
    a = b = agn_tonumber(L, 2);
  else
    luaL_error(L, "Error in " LUA_QS ": pair or number expected for second argument, got %s.",
      "linalg.submatrix", luaL_typename(L, 2));
  if (a > b)
    luaL_error(L, "Error in " LUA_QS ": left-hand side of pair greater than right-hand side.", "linalg.submatrix");
  if (ISFLOAT(a) || ISFLOAT(b))
    luaL_error(L, "Error in " LUA_QS ": index is not an integer.", "linalg.submatrix");
  if (a < 1 || a > n)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "linalg.submatrix", (int)a);
  if (b < 1 || b > n)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "linalg.submatrix", (int)b);
  if (lua_gettop(L) == 3) {
    if (lua_ispair(L, 3)) {
      lua_pushvalue(L, 3);
      agn_pairgetnumbers(L, "linalg.submatrix", -1, &c, &d);
    } else if (lua_isnumber(L, 3)) {
      c = d = (int)agn_tonumber(L, 3);
    } else
      luaL_error(L, "Error in " LUA_QS ": pair or number expected for third argument, got %s.",
        "linalg.submatrix", luaL_typename(L, 3));
  }
  if (c > d)
    luaL_error(L, "Error in " LUA_QS ": left-hand side of pair greater than right-hand side.", "linalg.submatrix");
  if (ISFLOAT(c) || ISFLOAT(d))
    luaL_error(L, "Error in " LUA_QS ": index is not an integer.", "linalg.submatrix");
  if (c < 1 || c > m)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "linalg.submatrix", (int)c);
  if (d < 1 || d > m)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "linalg.submatrix", (int)d);
  if (a != b) {
    createrawmatrix(L, d - c + 1, b - a + 1);
    for (i=c; i <= d; i++) {  /* for each row vector */
      lua_rawgeti(L, -1, i - c + 1);  /* push row vector of new matrix */
      lua_rawgeti(L, 1, i);   /* push row vector of original matrix */
      for (j=a; j <= b; j++) {
        x = agn_getinumber(L, -1, j);
        if (x != 0) lua_rawsetinumber(L, -2, j - a + 1, x);  /* set component to new matrix */
      }
      agn_poptoptwo(L);
    }
  } else {
    lua_createtable(L, d - c + 1, 1);
    for (i=c; i <= d; i++) {  /* for each row vector */
      lua_rawgeti(L, 1, i);   /* push row vector of original matrix */
      x = agn_getinumber(L, -1, a);  /* get a-th component */
      if (x != 0) lua_rawsetinumber(L, -2, i - c + 1, x);  /* set component to new matrix */
      agn_poptop(L);
    }
    setvattribs(L, d - c + 1);
  }
  return 1;
}


/* 2.1.5, code taken from http://rosettacode.org/wiki/Reduced_row_echelon_form#C.23 and adapted for Agena. */
static int rref (double *a, int m, int n, lua_Number eps) {
  int i, j, k, lead, r, issingular;
  lua_Number temp, div, sub;
  lead = 0;
  issingular = 0;
  for (r=0; r < m; r++) {
    if (n <= lead) break;
    i = r;
    temp = fabs(a[i*n + i]);  /* added detection of singular matrices */
    for (j=i+1; j < m; j++) {
      if (fabs(a[j*n + i] > temp)) {
        temp = fabs(a[j*n + i]);
      }
    }
    if (temp < eps) issingular = 1;
    while (a[i*n + lead] == 0) {
      i++;
      if (i == m) {
        i = r;
        lead++;
        if (n == lead) {
          lead--;
          break;
        }
      }
    }
    for (j = 0; j < n; j++) {
      temp = a[r*n + j];
      a[r*n + j] = a[i*n + j];
      a[i*n + j] = temp;
    }
    div = a[r*n + lead];
    if (fabs(div) > eps)  /* modified */
      for (j = 0; j < n; j++) a[r*n + j] /= div;
    for (j = 0; j < m; j++) {
      if (j != r) {  /* modified */
        sub = a[j*n + lead];
        for (k = 0; k < n; k++) a[j*n + k] -= (sub * a[r*n + k]);
      }
    }
    lead++;
  }
  for (i=0; i < m; i++) {  /* modified, cancel out values very close to zero, leave these statements here ! */
    for (j=0; j < n; j++) {
      if (fabs(a[i*n + j]) < eps) a[i*n + j] = 0;
    }
  }
  return issingular;
}

static void subfillobjects (lua_State *L, int nargs, lua_Number *a, int m, int n, const char *procname) {
  if (nargs == 1)
    fillmatrix(L, 1, a, m, n, 0, procname);
  else {  /* augment square matrix with vector */
    int i;
    lua_Number *b;
    createarray(b, m, procname);
    fillmatrix(L, 1, a, m, n, 1, procname);
    fillvector(L, 2, b, m, procname);
    for (i=0; i < m; i++) a[i*n + m] = b[i];
    xfree(b);
  }
}

static int linalg_rref (lua_State *L) {  /* 2.1.5 */
  int m, n, issingular, nargs;
  lua_Number *a, eps;
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.rref", &m, &n);
  agn_poptop(L);
  nargs = lua_gettop(L);
  eps = agn_geteps(L);
  if (nargs == 2) {
    if (m != checkVector(L, 2, "linalg.rref"))
      luaL_error(L, "Error in " LUA_QS ": expected matrix and vector with equal dimensions.", "linalg.rref");
    n++;
  } else if (nargs != 1)
    luaL_error(L, "Error in " LUA_QS ": one or two arguments expected.", "linalg.rref");
  createarray(a, m * n, "linalg.rref");
  subfillobjects(L, nargs, a, m, n, "linalg.rref");
  issingular = rref(a, m, n, eps);
  creatematrix(L, a, m, n);
  xfree(a);
  if (issingular) lua_pushfail(L);
  return 1 + issingular;
}


static void backward_substitution (lua_Number *a, lua_Number *x, int m, int n, lua_Number eps) {
  int i, j;
  lua_Number q;
  for (i=m - 1; i >= 0; i--) {
    q = 0;
    for (j=i + 1; j < m; j++)
      q += a[i*n + j] * x[j];
    x[i] = (a[i*n + (n-1)] - q)/a[i*n + i];
  }
}

/* See: https://vismor.com/documents/network_analysis/matrix_algorithms/S5.SS1.php
   by Timothy Vismor */
static void forward_substitution (lua_Number *a, lua_Number *x, int m, int n, lua_Number eps) {
  int i, j;
  for (i=0; i < m; i++) {
    if (fabs(a[i*n + (n-1)]) < eps) continue;
    x[i] = a[i*n + (n-1)]/a[i*n + i];
    for (j=i + 1; j < m; j++) {
      a[j*n + (n-1)] -= x[i]*a[j*n + i];
    }
  }
}

static int isuppertriangular (lua_Number *a, int m, int n, lua_Number eps) {
  int i, j;
  for (i=0; i < m; i++) {  /* check main diagonal */
    if (fabs(a[i*n + i]) < eps) return 0;
    for (j=0; j < i - 1; j++) {  /* check lower half */
      if (fabs(a[i*n + j]) >= eps) return 0;
    }
  }
  return 1;
}

static int islowertriangular (lua_Number *a, int m, int n, lua_Number eps) {
  int i, j;
  for (i=0; i < m; i++) {  /* check main diagonal */
    if (fabs(a[i*n + i]) < eps) return 0;
    for (j=i+1; j < m; j++) {  /* check upper half */
      if (fabs(a[i*n + j]) >= eps) return 0;
    }
  }
  return 1;
}

static void subcheckdims(lua_State *L, int nargs, int m, int *n, const char *procname) {
  if (nargs == 1) {
    if (m + 1 != *n)
      luaL_error(L, "Error in " LUA_QS ": matrix has wrong dimensions.", procname);
  } else if (nargs == 2) {
    if (m != *n)
      luaL_error(L, "Error in " LUA_QS ": expected a square matrix.", procname);
    if (*n != checkVector(L, 2, "linalg.backsub"))
      luaL_error(L, "Error in " LUA_QS ": expected matrix and vector with equal dimensions.", procname);
    (*n)++;
  } else
    luaL_error(L, "Error in " LUA_QS ": one or two arguments expected.", procname);
}

static int linalg_backsub (lua_State *L) {
  int m, n, nargs;
  lua_Number *a, *x, eps;
  nargs = lua_gettop(L);
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.backsub", &m, &n);
  agn_poptop(L);  /* pop dimension pair of the matrix */
  eps = agn_geteps(L);
  subcheckdims(L, nargs, m, &n, "linalg.backsub");
  createarray(a, m*n, "linalg.backsub");
  createarray(x, m, "linalg.backsub");
  subfillobjects(L, nargs, a, m, n, "linalg.backsub");
  if (!isuppertriangular(a, m, n, eps)) {
    xfree(a); xfree(x);
    luaL_error(L, "Error in " LUA_QS ": matrix is not upper triangular.", "linalg.backsub");
  }
  backward_substitution(a, x, m, n, eps);
  createvector(L, x, m);
  xfree(a); xfree(x);
  return 1;
}


static int linalg_forsub (lua_State *L) {
  int m, n, nargs;
  lua_Number *a, *x, eps;
  nargs = lua_gettop(L);
  linalg_auxcheckmatrix(L, 1, 1, 0, "linalg.forsub", &m, &n);
  agn_poptop(L);  /* pop dimension pair of the matrix */
  eps = agn_geteps(L);
  subcheckdims(L, nargs, m, &n, "linalg.forsub");
  createarray(a, m*n, "linalg.forsub");
  createarray(x, m, "linalg.forsub");
  subfillobjects(L, nargs, a, m, n, "linalg.forsub");
  if (!islowertriangular(a, m, n, eps)) {
    xfree(a); xfree(x);
    luaL_error(L, "Error in " LUA_QS ": matrix is not lower triangular.", "linalg.forsub");
  }
  forward_substitution(a, x, m, n, eps);
  createvector(L, x, m);
  xfree(a); xfree(x);
  return 1;
}


static const luaL_Reg linalglib[] = {
  {"add", linalg_add},                      /* added on September 04, 2008 */
  {"backsub", linalg_backsub},              /* added on March 06, 2014 */
  {"checkmatrix", linalg_checkmatrix},      /* added on September 06, 2008 */
  {"checkvector", linalg_checkvector},      /* added on September 06, 2008 */
  {"det", linalg_det},                      /* added on February 19, 2014 */
  {"diagonal", linalg_diagonal},            /* added on February 26, 2014 */
  {"getdiagonal", linalg_getdiagonal},      /* added on February 26, 2014 */
  {"dotprod", linalg_dotprod},              /* added on February 14, 2014 */
  {"forsub", linalg_forsub},                /* added on March 07, 2014 */
  {"identity", linalg_identity},            /* added on September 06, 2008 */
  {"inverse", linalg_inverse},              /* added on February 21, 2014 */
  {"ismatrix", linalg_ismatrix},            /* added on September 06, 2008 */
  {"isvector", linalg_isvector},            /* added on September 06, 2008 */
  {"gsolve", linalg_gsolve},                /* added on February 17, 2014 */
  {"ludecomp", linalg_ludecomp},            /* added on February 27, 2014 */
  {"maeq", linalg_maeq},                    /* added on February 17, 2014 */
  {"meeq", linalg_meeq},                    /* added on February 27, 2014 */
  {"mmul", linalg_mmul},                    /* added on February 14, 2014 */
  {"mulrow", linalg_mulrow},                /* added on February 26, 2014 */
  {"mulrowadd", linalg_mulrowadd},          /* added on February 26, 2014 */
  {"rref", linalg_rref},                    /* added on March 05, 2014 */
  {"scalarmul", linalg_scalarmul},          /* added on September 04, 2008 */
  {"setvelem", linalg_setvelem},            /* added on December 20, 2008 */
  {"sub", linalg_sub},                      /* added on September 04, 2008 */
  {"submatrix", linalg_submatrix},          /* added on March 02, 2014 */
  {"trace", linalg_trace},                  /* added on February 26, 2014 */
  {"transpose", linalg_transpose},          /* added on February 21, 2014 */
  {"vector", linalg_vector},                /* added on September 04, 2008 */
  {"vaeq", linalg_vaeq},                    /* added on February 21, 2014 */
  {"veeq", linalg_veeq},                    /* added on February 27, 2014 */
  {"vmap", linalg_vmap},                    /* added on December 19, 2008 */
  {"vzip", linalg_vzip},                    /* added on December 19, 2008 */
  {"zero", linalg_zero},                    /* added on September 06, 2008 */
  {NULL, NULL}
};


/*
** Open linalg library
*/
LUALIB_API int luaopen_linalg (lua_State *L) {
  luaL_register(L, AGENA_LINALGLIBNAME, linalglib);
  return 1;
}

