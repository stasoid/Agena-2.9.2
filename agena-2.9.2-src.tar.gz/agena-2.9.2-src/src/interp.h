/* Taken from the university website http://www.pcs.cnu.edu/~bbradie/ with the title:

											An Introduction to Numerical Analysis
											  with Applications to the Physical,
													Natural and Social Sciences

Provided or written by Professor Brian Bradie, Department of Mathematics, Christopher Newport University, VA.

There were no copyright notices on the site. Thus, Agena's MIT licence is _not_ applicable to this source code file
`interp.h`. */


#ifndef interp_h
#define interp_h

double  neville (int, double*, double*, double);
double  *divdiff (int, double*, double*);
double  nf_eval (int, double*, double*, double);
int     cubic_nak (int, double*, double*, double*, double*, double*);
int     cubic_clamped (int, double*, double*, double*, double*, double*, double, double);
double  spline_eval (int, double*, double*, double*, double*, double*, double);

#endif
