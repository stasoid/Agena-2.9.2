/*
** $Id: lreglib.c,v 1.38 2005/10/23 17:38:15 roberto Exp $
** Library for Register Manipulation
** See Copyright Notice in agena.h
*/


#include <stddef.h>

#define lreglib_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"


static int reg_settop (lua_State *L) {  /* 2.3.0 RC 3 */
  int r;
  luaL_argcheck(L, lua_isreg(L, 1), 1, "register expected");
  lua_pushvalue(L, 2);
  /* agnReg_settop checks the 2nd argument automatically and would return false in case of a wrong type */
  r = agn_regsettop(L, 1);
  lua_pushboolean(L, r);
  return 1;
}


static int reg_reduce (lua_State *L) {  /* 2.3.0 RC 3 */
  int nil;
  luaL_argcheck(L, lua_isreg(L, 1), 1, "register expected");
  nil = agnL_optboolean(L, 3, 1);
  lua_pushboolean(L, agn_regreduce(L, 1, agn_checkinteger(L, 2), nil));
  return 1;
}


static int reg_extend (lua_State *L) {  /* 2.3.0 RC 3 */
  luaL_argcheck(L, lua_isreg(L, 1), 1, "register expected");
  lua_pushboolean(L, agn_regextend(L, 1, agn_checkinteger(L, 2)));
  return 1;
}

/* }====================================================== */

static const luaL_Reg reg_funcs[] = {
  {"extend", reg_extend},                 /* added October 15, 2014 */
  {"reduce", reg_reduce},                 /* added October 15, 2014 */
  {"settop", reg_settop},                 /* added October 14, 2014 */
  {NULL, NULL}
};


LUALIB_API int luaopen_register (lua_State *L) {
  luaL_register(L, AGENA_REGLIBNAME, reg_funcs);
  return 1;
}

