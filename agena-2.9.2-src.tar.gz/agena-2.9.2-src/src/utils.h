/* utils.h file */

/* stringarray C structure; August 05, 2007 */

#ifdef COMPAT14

typedef struct dataa {
  const char *entry;
  size_t len;
} dataa;


typedef struct stringarray {
  int size;
#ifndef __cplusplus
  dataa data[1];
#else
  dataa *data;
#endif
} stringarray;


#define checkarray(L, n) (stringarray *)luaL_checkudata(L, n, "stringarray")

#endif
