/*
** $Id: lcomplex.h v 0.1, based on ltable.h v2.10 2006/01/10 13:13:06 roberto Exp $
** Agena Complex Numbers
** See Copyright Notice in agena.h
*/

#ifndef lcomplex_h
#define lcomplex_h

#include "lobject.h"

#ifndef PROPCMPLX

#include "agnconf.h"  /* for definition of I */
#include <complex.h>
#define complexreal(t)     (creal((t->value.c)))
#define compleximag(t)     (cimag((t->value.c)))

#else

#define complexreal(t)     (t->value.c[0])
#define compleximag(t)     (t->value.c[1])
#define agnCmplx_create(z,re,im) { \
  z[0] = (re); \
  z[1] = (im); \
}

#endif

#endif

