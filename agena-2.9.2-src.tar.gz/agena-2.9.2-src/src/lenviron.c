/*
** $Id: lenviron.c,v 1.00 17.12.2010 alex Exp $
** library to query the Agena environment
** See Copyright Notice in agena.h
*/


#include <stdlib.h>
#include <string.h>
#include <float.h>
#include <math.h>

#define lenviron_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "lobject.h"

#include "agncmpt.h"

static void getfunc (lua_State *L, int opt) {  /* Lua 5.1.2 patch */
  if (lua_isfunction(L, 1)) lua_pushvalue(L, 1);
  else {
    lua_Debug ar;
    int level = opt ? agnL_optinteger(L, 1, 1) : agnL_checkint(L, 1);  /* Lua 5.1.2 patch */
    luaL_argcheck(L, level >= 0, 1, "level must be non-negative");
    if (lua_getstack(L, level, &ar) == 0)
      luaL_argerror(L, 1, "invalid level");
    lua_getinfo(L, "f", &ar);
    if (lua_isnil(L, -1))
      luaL_error(L, "Error in " LUA_QS ": no function environment for tail call at level %d.",
                    "environ.getfunc", level);
  }
}


static int environ_getfenv (lua_State *L) {  /* moved from Lua's baselib to the environ package */
  getfunc(L, 1); /* Lua 5.1.2 patch */
  if (lua_iscfunction(L, -1))  /* is a C function? */
    lua_pushvalue(L, LUA_GLOBALSINDEX);  /* return the thread's global env. */
  else
    lua_getfenv(L, -1);
  return 1;
}


static int environ_setfenv (lua_State *L) {
  luaL_checktype(L, 2, LUA_TTABLE);
  getfunc(L, 1);  /* Lua 5.1.2 patch */
  lua_pushvalue(L, 2);
  if (agn_isnumber(L, 1) && agn_tonumber(L, 1) == 0) {
    /* change environment of current thread */
    lua_pushthread(L);
    lua_insert(L, -2);
    lua_setfenv(L, -2);
    return 0;
  }
  else if (lua_iscfunction(L, -2) || lua_setfenv(L, -2) == 0)
    luaL_error(L,
          LUA_QL("environ.setfenv") " cannot change environment of given object.");
  return 1;
}


static int environ_userinfo (lua_State *L) {  /* 0.22.3, June 14, 2009, changed 1.6.4 */
  lua_Number a, b;
  int i, exception, type;
  luaL_checktype(L, 1, LUA_TFUNCTION);
  a = agn_checknumber(L, 2);
  type = agnL_gettablefield(L, "environ", "infolevel", "environ.userinfo", 1);  /* 1.6.4 */
  if (type != LUA_TTABLE) {
    agn_poptop(L);  /* remove "infolevel" (or "environ" if table environ does not exist) */
    return 0;  /* infolevel not assigned or not a table */
  }
  lua_pushvalue(L, 1);  /* push function */
  lua_rawget(L, -2);  /* function is popped and the infolevel value is put on top of the stack */
  b = agn_tonumberx(L, -1, &exception);
  agn_poptoptwo(L);  /* pop value and "infolevel" */
  if (a <= b && !exception) {
    for (i=3; i <= lua_gettop(L); i++) {
      lua_pushvalue(L, i);
      agnL_printnonstruct(L, -1);
      agn_poptop(L);
    }
    fflush(stdout);
  }
  return 0;
}


static int environ_used (lua_State *L) {  /* 0.27.2 */
  static const char *const opts[] = {"bytes", "kbytes", "mbytes", "gbytes", NULL};
  int power = agnL_checkoption(L, 1, "kbytes", opts);
  lua_pushnumber(L, agn_usedbytes(L)/tools_intpow(1024, power));
  return 1;
}


static int environ_collectgarbage (lua_State *L) {
  static const char *const opts[] = {"stop", "restart", "collect",
    "count", "step", "setpause", "setstepmul", "status", NULL};
  static const int optsnum[] = {LUA_GCSTOP, LUA_GCRESTART, LUA_GCCOLLECT,
    LUA_GCCOUNT, LUA_GCSTEP, LUA_GCSETPAUSE, LUA_GCSETSTEPMUL, LUA_GCSTATUS};  /* extended 2.2.5 */
  int o = luaL_checkoption(L, 1, "collect", opts);
  int ex = agnL_optinteger(L, 2, 0);
  int res = lua_gc(L, optsnum[o], ex);
  switch (optsnum[o]) {
    case LUA_GCCOUNT: {
      int b = lua_gc(L, LUA_GCCOUNTB, 0);
      lua_pushnumber(L, res + ((lua_Number)b/1024));
      return 1;
    }
    case LUA_GCSTEP: case LUA_GCSTATUS: {  /* 2.2.5, GCSTATUS: true = gc active, false = gc stopped */
      lua_pushboolean(L, res);
      return 1;
    }
    default: {
      lua_pushnumber(L, res);
      return 1;
    }
  }
}


int environ_restart (lua_State *L) { /* added 0.4.0 */
  const char *path;
  int islibname, resetlibname, type;
  islibname = resetlibname = 0;
  resetlibname = agn_getlibnamereset(L); /* 0.26.0, also reset mainlibname and libname to its original value ? */
  path = NULL;  /* to prevent compiler warnings */
  agn_poptop(L);
  /* first, delete readlib'bed packages from package.loaded; 0.26.0, changed 2.9.1 */
  lua_getfield(L, LUA_REGISTRYINDEX, "_READLIBBED");
  if (lua_isset(L, -1)) {
    lua_getfield(L, LUA_REGISTRYINDEX, "_LOADED");
    if (lua_istable(L, -1)) {
      lua_pushvalue(L, LUA_REGISTRYINDEX);
      lua_pushnil(L);
      while (lua_usnext(L, -4) != 0) {  /* delete readlibbed packages from package.loaded */
        /* package name is on the top of the stack */
        /* delete possible metatable */
        lua_pushvalue(L, -2);  /* duplicate package name */
        lua_pushnil(L);
        lua_settable(L, -5);  /* delete metatable from registry */
        /* delete package name from _LOADED */
        lua_pushnil(L);
        lua_settable(L, -5);
      }
      agn_poptop(L);  /* remove registry */
    }
    /* delete _READLIBBED set and create a new one */
    lua_pushstring(L, "_READLIBBED");
    agn_createset(L, 0);
    lua_settable(L, LUA_REGISTRYINDEX);
    agn_poptop(L);  /* pop registry field `_LOADED' */
  }
  agn_poptop(L); /* delete registry field `_READLIBBED' */
  /* second, save environ.onexit function, 2.7.0 */
  type = agnL_gettablefield(L, "environ", "onexit", "restart", 0);
  if (type != LUA_TFUNCTION)
    agn_poptop(L);  /* pop whatever */
  else  /* assign environ.onexit to temporary name */
    lua_setfield(L, LUA_GLOBALSINDEX, "_environonexit");  /* and pop function */
  /* third, delete all global vars except _origG and libname */
  lua_getfield(L, LUA_GLOBALSINDEX, "_G");  /* get _G on stack */
  if (!lua_istable(L, -1)) {  /* Agena 1.7.1 fix */
    fprintf(stderr, "Warning in " LUA_QS  ": " LUA_QS " is missing or not a table, no restart possible.\n", "restart", "_G");
    fflush(stderr);
    agn_poptop(L);
    return 0;
  }
  lua_pushnil(L);
  while (lua_next(L, -2) != 0) {
    islibname = (strcmp(lua_tostring(L, -2), "libname") == 0 || strcmp(lua_tostring(L, -2), "mainlibname") == 0);  /* 0.28.2 */
    if (((strcmp(lua_tostring(L, -2), "_origG") != 0 && strcmp(lua_tostring(L, -2), "_G") != 0
        && strcmp(lua_tostring(L, -2), "_environonexit") != 0) && !islibname) || (resetlibname && islibname)) {
      lua_pushnil(L);
      /* delete key in Agena environment */
      lua_setfield(L, LUA_GLOBALSINDEX, lua_tostring(L, -3));
    }
    agn_poptop(L);  /* pop value */
  }
  agn_poptop(L); /* delete _G from stack */
  /* get _origG on stack */
  lua_getfield(L, LUA_GLOBALSINDEX, "_origG");
  if (!lua_istable(L, -1)) {
    fprintf(stderr, "Warning in " LUA_QS  ": " LUA_QS " is missing or not a table, no restart possible.\n", "restart", "_origG");
    fflush(stderr);
    agn_poptop(L);
    return 0;
  }
  /* set all values in _origG into environment */
  lua_pushnil(L);
  while (lua_next(L, -2) != 0) {
    lua_pushvalue(L, -2); /* key */
    lua_pushvalue(L, -2); /* value */
    lua_setfield(L, LUA_GLOBALSINDEX, lua_tostring(L, -2));  /* set key in Agena environment */
    agn_poptoptwo(L);  /* delete copied key and value */
  }
  agn_poptop(L);  /* pop _origG from stack, 0.26.0 patch */
  /* make Agena assign _G properly in the restarted environment. */
  lua_pushvalue(L, LUA_GLOBALSINDEX);
  lua_setglobal(L, "_G");
  /* reset package.readlibbed */
  /*lua_getglobal(L, "package");
  if (lua_istable(L, -1)) {
    agn_createset(L, 0);
    lua_setfield(L, -2, "readlibbed");
  }
  agn_poptop(L); */ /* pop `package' */
  if (resetlibname) agnL_setLibname(L, 0, agn_getdebug(L));
  /* get libname */
  lua_getglobal(L, "libname");
  if (!lua_isstring(L, -1))  /* 1.7.4 */
    luaL_error(L, "Error in " LUA_QS ": " LUA_QS " could not be determined.", "restart", "libname");
  else
    path = lua_tostring(L, -1);
  if (path == NULL) {
    fprintf(stderr, "Warning in " LUA_QS ": " LUA_QS " could not be determined, initialisation\nunsuccessful.\n",
      "restart", "libname");
    fflush(stderr);
  }
  else
    agnL_initialise(L, agn_getnoini(L), agn_getdebug(L), agn_getnomainlib(L));  /* 0.24.0, 2.8.6 */
  agn_poptop(L);  /* drop libname */
  /* get mainlibname (assigned through library.agn at start-up), 0.28.2 */
  if (!agn_getnomainlib(L)) {  /* 2.8.6 */
    lua_getglobal(L, "mainlibname");
    if (!lua_isstring(L, -1))  /* 1.7.4 */
      luaL_error(L, "Error in " LUA_QS ": " LUA_QS " could not be determined.", "restart", "mainlibname");  /* 1.9.4 fix */
    else
      path = lua_tostring(L, -1);
    if (path == NULL) {
      fprintf(stderr, "Warning in " LUA_QS ": " LUA_QS " could not be determined.\n", "restart", "mainlibname");
      fflush(stderr);
    }
    agn_poptop(L);  /* drop mainlibname */
  }
  /* restore environ.onexit, 2.7.0 */
  lua_getglobal(L, "environ");
  if (lua_istable(L, -1)) {
    lua_getglobal(L, "_environonexit");
    lua_setfield(L, -2, "onexit");
  } else {
    agn_poptop(L);  /* pop whatever */
    luaL_error(L, "Error in " LUA_QS ": " LUA_QS " table could not be determined.", "restart", "environ");
  }
  agn_poptop(L);  /* pop `environ' table from stack */
  lua_pushnil(L);  /* delete temporary _environonexit variable */
  lua_setglobal(L, "_environonexit");
  /* finally, conduct a garbage collection */
  lua_gc(L, LUA_GCCOLLECT, 0);
  return 0;
}


static int environ_pointer (lua_State *L) {
  if (lua_topointer(L, 1) == NULL)
    lua_pushfail(L);
  else
    lua_pushfstring(L, "%p", lua_topointer(L, 1));
  return 1;
}


static void getobjutype (lua_State *L) {
  lua_pushstring(L, "utype");
  if (agn_getutype(L, 1)) {
    lua_rawset(L, -3);
  } else {
    lua_pushfail(L);
    lua_rawset(L, -3);
  }
}

/* http://www.lua.org/pil/17.html: `The weakness of a table is given by the field __mode of its metatable.` */
static void isweak (lua_State *L) {
  if (lua_getmetatable(L, 1) != 0) {
    lua_pushstring(L, "weak");  /* in Lua, the corresponding index is `__mode` */
    lua_getfield(L, -2, "__weak");
    if (lua_isstring(L, -1)) {
      lua_rawset(L, -4);
    } else {
      agn_poptop(L);
      lua_pushfail(L);
      lua_rawset(L, -4);
    }
    agn_poptop(L);
  } else {
    lua_rawsetstringboolean(L, -1, "weak", -1);
  }
}

static int environ_attrib (lua_State *L) {  /* added 0.10.0 */
  switch (lua_type(L, 1)) {
    case LUA_TTABLE: {
      size_t a[9];
      lua_newtable(L);
      agn_tablestate(L, 1, a, 1);
      lua_rawsetstringnumber(L,  -1, "array_assigned", a[0]);
      lua_rawsetstringnumber(L,  -1, "hash_assigned", a[1]);
      lua_rawsetstringboolean(L, -1, "array_hasholes", a[2]);
      lua_rawsetstringboolean(L, -1, "nulls_assigned", a[5]);
      lua_rawsetstringnumber(L,  -1, "array_allocated", a[3]);
      lua_rawsetstringnumber(L,  -1, "hash_allocated", a[4]);
      lua_rawsetstringnumber(L,  -1, "bytes", agn_getstructuresize(L, 1));
      lua_rawsetstringboolean(L, -1, "metatable", a[6]);  /* 2.3.0 RC 3 */
      lua_rawsetstringboolean(L, -1, "dummynode", a[7]);  /* 2.3.0 RC 4 */
      lua_rawsetstringnumber(L,  -1, "length", a[8]);  /* 2.3.0 RC 4 */
      getobjutype(L);
      isweak(L);
      break;
    }
    case LUA_TSET: {
      size_t a[3];
      lua_newtable(L);
      agn_sstate(L, 1, a);
      lua_rawsetstringnumber(L,  -1, "hash_assigned", a[0]);
      lua_rawsetstringnumber(L,  -1, "hash_allocated", a[1]);
      lua_rawsetstringboolean(L, -1, "metatable", a[2]);  /* 2.3.0 RC 3 */
      lua_rawsetstringnumber(L,  -1, "bytes", agn_getstructuresize(L, 1));
      getobjutype(L);
      isweak(L);
      break;
    }
    case LUA_TSEQ: {  /* corrected 2.3.0 RC 3 */
      size_t a[3];
      lua_newtable(L);
      agn_seqstate(L, 1, a);
      lua_rawsetstringnumber(L,  -1, "size", a[0]);
      lua_rawsetstringnumber(L,  -1, "maxsize", a[1]);
      lua_rawsetstringboolean(L, -1, "metatable", a[2]);  /* 2.3.0 RC 3 */
      lua_rawsetstringnumber(L,  -1, "bytes", agn_getstructuresize(L, 1));
      getobjutype(L);
      isweak(L);
      break;
    }
    case LUA_TREG: {  /* 2.3.0 RC 3 */
      size_t a[3];
      lua_newtable(L);
      agn_regstate(L, 1, a);
      lua_rawsetstringnumber(L,  -1, "top", a[0]);
      lua_rawsetstringnumber(L,  -1, "size", a[1]);
      lua_rawsetstringboolean(L, -1, "metatable", a[2]);
      lua_rawsetstringnumber(L,  -1, "bytes", agn_getstructuresize(L, 1));
      getobjutype(L);  /* 2.7.0 */
      isweak(L);
      break;
    }
    case LUA_TPAIR: {
      size_t a[1];
      lua_newtable(L);
      agn_pairstate(L, 1, a);
      lua_rawsetstringboolean(L, -1, "metatable", a[0]);  /* 2.3.0 RC 3 */
      lua_rawsetstringnumber(L,  -1, "bytes", agn_getstructuresize(L, 1));
      getobjutype(L);
      isweak(L);
      break;
    }
    case LUA_TFUNCTION: {
      int a;
      lua_newtable(L);
      lua_pushstring(L, "rtableWritemode");
      /* returns the mode of a remember table:
         1 = true:  function has a remember table and RETURN statement can update the rtable,
         0 = false: has a remember table and RETURN statement canNOT update the rtable,
         2 = fail:  function has no remember table at all
         (-1:       object is not a function) */
      a = agn_getrtablewritemode(L, 1);
      if (a == 2)
        lua_pushfail(L);
      else
        lua_pushboolean(L, a);
      lua_rawset(L, -3);
      lua_rawsetstringboolean(L, -1, "C", agn_getfunctiontype(L, 1));
      lua_rawsetstringnumber(L, -1, "bytes", agn_getstructuresize(L, 1));
      getobjutype(L);
      /* true if `idx` is a C function, false if `idx` is an Agena function */
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": structure or procedure expected, got %s.", "environ.attrib",
        luaL_typename(L, 1));
  }
  return 1;
}


#define unknown(L)  luaL_error(L, "Error in " LUA_QS ": unknown setting " LUA_QS ".", "environ.kernel", lua_tostring(L, -1));

void processoption (lua_State *L, void (*f)(lua_State *, int), int i, const char *option) {  /* 0.32.0 */
  agn_pairgeti(L, i, 2);  /* get right-hand side */
  if (lua_isboolean(L, -1)) {
    (*f)(L, lua_toboolean(L, -1));
    lua_remove(L, -2);  /* remove left-hand side, leave right-hand side (boolean) on stack */
  } else {
    int type = lua_type(L, -1);
    agn_poptoptwo(L);  /* clear stack, 2.8.6 fix */
    luaL_error(L, "Error in " LUA_QS ": boolean for " LUA_QS " option expected, got %s.", "environ.kernel", option,
      lua_typename(L, type));
  }
}


/* leaves either a set of the names (i.e. table keys) of all loaded values or `undefined` on stack. */
static void aux_getloaded (lua_State *L) {
  lua_getfield(L, LUA_REGISTRYINDEX, "_LOADED");
  if (!lua_istable(L, -1)) {
    agn_poptop(L);
    lua_pushundefined(L);
  } else {
    agn_createset(L, 0);
    lua_pushnil(L);
    while (lua_next(L, -3)) {
      lua_pushvalue(L, -2);
      lua_sinsert(L, -4);
      agn_poptop(L);  /* pop table value */
    }
  }
  lua_remove(L, -2);  /* remove _LOADED */
}


static void aux_getreadlibbed (lua_State *L) {
  lua_getfield(L, LUA_REGISTRYINDEX, "_READLIBBED");
  if (!lua_isset(L, -1)) {
    agn_poptop(L);
    lua_pushundefined(L);
  }
}

static int environ_kernel (lua_State *L) {  /* 0.27.0 */
  int i, nargs;
  const char *setting;
  nargs = lua_gettop(L);
  if (nargs == 0) {  /* 2.6.1 */
    lua_createtable(L, 0, 17);
    lua_rawsetstringboolean(L, -1, "signedbits", agn_getbitwise(L));
    lua_rawsetstringboolean(L, -1, "emptyline", agn_getemptyline(L));
    lua_rawsetstringboolean(L, -1, "libnamereset", agn_getlibnamereset(L));
    lua_rawsetstringboolean(L, -1, "longtable", agn_getlongtable(L));
    lua_rawsetstringboolean(L, -1, "debug", agn_getdebug(L));
    lua_rawsetstringboolean(L, -1, "gui", agn_getgui(L));
    lua_rawsetstringboolean(L, -1, "zeroedcomplex", agn_getzeroedcomplex(L));
    lua_rawsetstringboolean(L, -1, "promptnewline", agn_getpromptnewline(L));
    lua_rawsetstringnumber(L,  -1, "digits", agn_getdigits(L));
    lua_rawsetstringnumber(L,  -1, "eps", agn_getepsilon(L));
    lua_rawsetstringnumber(L,  -1, "regsize", agn_getregsize(L));
    lua_rawsetstringstring(L,  -1, "pathsep", LUA_PATHSEP);
    lua_rawsetstringnumber(L,  -1, "buffersize", agn_getbuffersize(L));
    lua_rawsetstringboolean(L, -1, "kahanozawa", agn_getkahanozawa(L));
    lua_rawsetstringboolean(L, -1, "skipinis", agn_getnoini(L));
    lua_rawsetstringboolean(L, -1, "skipmainlib", agn_getnomainlib(L));
    /* insert readlibbed set */
    lua_pushstring(L, "readlibbed");
    aux_getreadlibbed(L);
    lua_rawset(L, -3);
    /* push tables.indices(_LOADED) */
    lua_pushstring(L, "loaded");
    aux_getloaded(L);
    lua_rawset(L, -3);  /* insert 'loaded' ~ set into result */
#ifndef LUA_DOS
    agn_getround(L);
    lua_setfield(L, -2, "rounding");
#endif
    nargs = 1;
  } else {
    for (i=1; i <= nargs; i++) {
      if (lua_ispair(L, i)) {
        agn_pairgeti(L, i, 1);  /* get left-hand side */
        if (lua_type(L, -1) != LUA_TSTRING) {
          int type = lua_type(L, -1);
          agn_poptop(L);  /* clear stack */
          luaL_error(L, "Error in " LUA_QS ": string expected for left-hand side, got %s.", "environ.kernel",
            lua_typename(L, type));
        }
        setting = lua_tostring(L, -1);
        if (strcmp(setting, "signedbits") == 0) {
          processoption(L, agn_setbitwise, i, "signedbits");
        } else if (strcmp(setting, "kahanozawa") == 0) {
          processoption(L, agn_setkahanozawa, i, "kahanozawa");
        } else if (strcmp(setting, "emptyline") == 0) {
          processoption(L, agn_setemptyline, i, "emptyline");
        } else if (strcmp(setting, "libnamereset") == 0) {  /* 0.32.0 */
          processoption(L, agn_setlibnamereset, i, "libnamereset");
        } else if (strcmp(setting, "longtable") == 0) {  /* 0.32.0 */
          processoption(L, agn_setlongtable, i, "longtable");
        } else if (strcmp(setting, "debug") == 0) {  /* 0.32.2a */
          processoption(L, agn_setdebug, i, "debug");
        } else if (strcmp(setting, "skipinis") == 0) {  /* 2.8.6 */
          processoption(L, agn_setnoini, i, "skipinis");
        } else if (strcmp(setting, "skipmainlib") == 0) {  /* 2.8.6 */
          processoption(L, agn_setnomainlib, i, "skipmainlib");
        } else if (strcmp(setting, "gui") == 0) {  /* 0.32.2a */
          processoption(L, agn_setgui, i, "gui");
        } else if (strcmp(setting, "zeroedcomplex") == 0) {  /* 1.7.6 */
          processoption(L, agn_setzeroedcomplex, i, "zeroedcomplex");
        } else if (strcmp(setting, "promptnewline") == 0) {  /* 1.7.6 */
          processoption(L, agn_setpromptnewline, i, "promptnewline");
        } else if (strcmp(setting, "digits") == 0) {
          agn_pairgeti(L, i, 2);  /* get right-hand side */
          if (agn_isnumber(L, -1)) {
            lua_Number x = agn_tonumber(L, -1);
            agn_setdigits(L, x);
            lua_remove(L, -2);  /* remove left-hand side, leave right-hand side (number) on stack */
          } else {
            int type = lua_type(L, -1);
            agn_poptoptwo(L);  /* clear stack, 2.8.6 fix */
            luaL_error(L, "Error in " LUA_QS ": number for `digits` option expected,\ngot %s.", "environ.kernel",
              lua_typename(L, type));
          }
        } else if (strcmp(setting, "regsize") == 0) {  /* 2.3.0 RC 3 */
          agn_pairgeti(L, i, 2);  /* get right-hand side */
          if (agn_isnumber(L, -1)) {
            lua_Number x = agn_tonumber(L, -1);
            agn_setregsize(L, x);
            lua_remove(L, -2);  /* remove left-hand side, leave right-hand side (number) on stack */
          } else {
            int type = lua_type(L, -1);
            agn_poptoptwo(L);  /* clear stack, 2.8.6 fix */
            luaL_error(L, "Error in " LUA_QS ": number for `regsize` option expected,\ngot %s.", "environ.kernel",
              lua_typename(L, type));
          }
        } else if (strcmp(setting, "eps") == 0) {  /* 2.1.4 */
          agn_pairgeti(L, i, 2);  /* get right-hand side */
          if (agn_isnumber(L, -1)) {
            lua_Number x = agn_tonumber(L, -1);
            if (x < 0)
              luaL_error(L, "Error in " LUA_QS ": non-negative number for `eps` option expected,\ngot %lf.", "environ.kernel", x);
            agn_setepsilon(L, x);
            lua_remove(L, -2);  /* remove left-hand side, leave right-hand side (number) on stack */
          } else {
            int type = lua_type(L, -1);
            agn_poptoptwo(L);  /* clear stack, 2.8.6 fix */
            luaL_error(L, "Error in " LUA_QS ": non-negative number for `eps` option expected,\ngot %s.", "environ.kernel",
              lua_typename(L, type));
          }
        }
        else if (strcmp(setting, "buffersize") == 0)  /* 2.2.0 */
          processoption(L, agn_setbuffersize, i, "buffersize");
#ifndef LUA_DOS
        else if (strcmp(setting, "rounding") == 0) {  /* 2.8.6 */
          agn_pairgeti(L, i, 2);  /* get right-hand side */
          if (agn_isstring(L, -1)) {
            const char *what = lua_tostring(L, -1);
            if (!agn_setround(L, what)) {
              agn_poptoptwo(L);
              luaL_error(L, "Error in " LUA_QS ": invalid setting `%s` for `rounding` option,\nor other error.", "environ.kernel", what);
            }
            lua_remove(L, -2);  /* remove left-hand side, leave right-hand side (string) on stack */
          } else {
            int type = lua_type(L, -1);
            agn_poptoptwo(L);  /* clear stack */
            luaL_error(L, "Error in " LUA_QS ": string for `rounding` option expected,\ngot %s.", "environ.kernel",
              lua_typename(L, type));
          }
        }
#endif
        else
          unknown(L);
      } else if (agn_isstring(L, i)) {  /* return settings only */
        setting = lua_tostring(L, i);
        if (strcmp(setting, "signedbits") == 0)
          lua_pushboolean(L, agn_getbitwise(L));
        else if (strcmp(setting, "emptyline") == 0)
          lua_pushboolean(L, agn_getemptyline(L));
        else if (strcmp(setting, "libnamereset") == 0)  /* 0.32.0 */
          lua_pushboolean(L, agn_getlibnamereset(L));
        else if (strcmp(setting, "longtable") == 0)  /* 0.32.0 */
          lua_pushboolean(L, agn_getlongtable(L));
        else if (strcmp(setting, "debug") == 0)  /* 0.32.0 */
          lua_pushboolean(L, agn_getdebug(L));
        else if (strcmp(setting, "gui") == 0)  /* 0.33.3 */
          lua_pushboolean(L, agn_getgui(L));
        else if (strcmp(setting, "zeroedcomplex") == 0)  /* 1.7.6 */
          lua_pushboolean(L, agn_getzeroedcomplex(L));
        else if (strcmp(setting, "promptnewline") == 0)  /* 1.7.6 */
          lua_pushboolean(L, agn_getpromptnewline(L));
        else if (strcmp(setting, "digits") == 0)  /* modified 2.3.0 RC 3 */
          lua_pushinteger(L, agn_getdigits(L));
        else if (strcmp(setting, "eps") == 0)  /* 2.1.4 */
          lua_pushnumber(L, agn_getepsilon(L));
        else if (strcmp(setting, "regsize") == 0)  /* 2.3.0 RC 3 */
          lua_pushnumber(L, agn_getregsize(L));
        /* read-only settings */
        else if (strcmp(setting, "minlong") == 0)  /* 2.1.9 */
          lua_pushnumber(L, LUAI_MININT32);
        else if (strcmp(setting, "maxlong") == 0)  /* 2.1.9 */
          lua_pushnumber(L, LUAI_MAXINT32);
        else if (strcmp(setting, "maxulong") == 0)  /* 2.3.1, XXX change agnconf.h if you change the definition of unsigned long int ! */
          lua_pushnumber(L, ULONG_MAX);
        else if (strcmp(setting, "pathsep") == 0)  /* 2.1.9 */
          lua_pushstring(L, LUA_PATHSEP);
        else if (strcmp(setting, "buffersize") == 0)  /* 2.2.0 */
          lua_pushnumber(L, agn_getbuffersize(L));
        else if (strcmp(setting, "kahanozawa") == 0)  /* 2.2.0 */
          lua_pushboolean(L, agn_getkahanozawa(L));   /* 2.4.2 */
#ifndef LUA_DOS
        else if (strcmp(setting, "rounding") == 0)  /* 2.8.6 */
          agn_getround(L);
#endif
        else if (strcmp(setting, "skipinis") == 0)  /* 2.8.6 */
          lua_pushboolean(L, agn_getnoini(L));
        else if (strcmp(setting, "skipmainlib") == 0)  /* 2.8.6 */
          lua_pushboolean(L, agn_getnomainlib(L));
        else if (strcmp(setting, "readlibbed") == 0)  /* 2.9.1 */
          aux_getreadlibbed(L);
        else if (strcmp(setting, "loaded") == 0)  /* 2.9.1 */
          aux_getloaded(L);
        else
          unknown(L);
      } else
        luaL_error(L, "Error in " LUA_QS ": pair or string expected, got %s.", "environ.kernel",
          luaL_typename(L, i));
    }
  }
  return nargs;
}


static int environ_system (lua_State *L) {  /* 2.9.2 moved from debug package */
  lua_createtable(L, 0, 5);
  /* create a table for C types */
  lua_pushstring(L, "Ctypes");
  lua_createtable(L, 0, 7);
  lua_rawsetstringnumber(L, -1, "char", sizeof(char));
  lua_rawsetstringnumber(L, -1, "int", sizeof(int));
  lua_rawsetstringnumber(L, -1, "long", sizeof(long));
  lua_rawsetstringnumber(L, -1, "longlong", sizeof(long long int));
  lua_rawsetstringnumber(L, -1, "int32_t", sizeof(int32_t));
  lua_rawsetstringnumber(L, -1, "int64_t", sizeof(int64_t));  /* 2.9.0 */
  lua_rawsetstringnumber(L, -1, "float", sizeof(float));
  lua_rawsetstringnumber(L, -1, "double", sizeof(double));
  /* now set C types to main table */
  lua_rawset(L, -3);
  /* minimum and maximum numeric values, 2.9.0 */
  lua_pushstring(L, "numberranges");
  lua_createtable(L, 0, 7);
#ifdef LLONG_MIN
  lua_rawsetstringnumber(L,  -1, "minlonglong", LLONG_MIN);
#endif
#ifdef LLONG_MAX
  lua_rawsetstringnumber(L,  -1, "maxlonglong", LLONG_MAX);
#endif
#ifdef ULLONG_MAX
  lua_rawsetstringnumber(L,  -1, "maxulonglong", ULLONG_MAX);
#endif
  lua_rawsetstringnumber(L,  -1, "minlong", LUAI_MININT32);
  lua_rawsetstringnumber(L,  -1, "maxlong", LUAI_MAXINT32);
  lua_rawsetstringnumber(L,  -1, "maxulong", ULONG_MAX);
  lua_rawsetstringnumber(L,  -1, "maxdouble", DBL_MAX);
  lua_rawsetstringnumber(L,  -1, "mindouble", DBL_MIN);

  /* now set values to main table */
  lua_rawset(L, -3);
  /* determine endianness */
  lua_pushstring(L, "endianness");
  switch (tools_endian()) {
    case 0: lua_pushstring(L, "little endian"); break;
    case 1: lua_pushstring(L, "big endian"); break;
    default: lua_pushstring(L, "unknown");
  }
  lua_rawset(L, -3);
  lua_pushstring(L, "OS");
  /* determine operating system */
#ifdef LUA_DOS
  lua_pushstring(L, "DOS");
#elif __linux__
  lua_pushstring(L, "Linux");
#elif (defined(__SVR4) && defined (__sun))
  lua_pushstring(L, "Sun Solaris");
#elif __unix__
  lua_pushstring(L, "UNIX");
#elif defined(_WIN32) || defined(__WIN32__) || defined(WIN32) || defined(_Windows)
  lua_pushstring(L, "Windows");
#elif __OS2__
  lua_pushstring(L, "OS/2");
#elif __BEOS__
  lua_pushstring(L, "BEOS");
#elif __APPLE__
  lua_pushstring(L, "Apple");
#else
  lua_pushstring(L, "unknown");
#endif
  lua_rawset(L, -3);
  /* determine hardware */
  lua_pushstring(L, "hardware");
#ifdef __i386
  lua_pushstring(L, "i386");
#elif __amd64
  lua_pushstring(L, "AMD64");
#elif __sparc
  lua_pushstring(L, "Sun Sparc");
#elif __MACTYPES__
  lua_pushstring(L, "Mac");
#else
  lua_pushstring(L, "unknown");
#endif
  lua_rawset(L, -3);
  return 1;
}


static const luaL_Reg environlib[] = {
  {"attrib", environ_attrib},                 /* added April 20, 2008 */
  {"gc", environ_collectgarbage},             /* formerly {"collectgarbage", ...},  changed 0.4.0 */
  {"getfenv", environ_getfenv},
  {"kernel", environ_kernel},                 /* added 27.08.2009 */
  {"pointer", environ_pointer},               /* added May 22, 2009 */
  {"setfenv", environ_setfenv},
  {"system", environ_system},                 /* moved from debug library November 01, 2015 */
  {"used", environ_used},
  {"userinfo", environ_userinfo},             /* added June 14, 2009 */
  {"__RESTART", environ_restart},             /* added December 16, 2006 */
  {NULL, NULL}
};


/*
** Open environ library
*/
LUALIB_API int luaopen_environ (lua_State *L) {
  luaL_register(L, AGENA_ENVIRONLIBNAME, environlib);
  /* new in 0.32.0 */
  lua_rawsetstringnumber(L, -1, "minlong", LUAI_MININT32);  /* deprecate */
  lua_rawsetstringnumber(L, -1, "maxlong", LUAI_MAXINT32);  /* deprecate */
  /* lua_rawsetstringnumber(L, -1, "unsignedmaxlong", (LUAI_UINT32));  XXX compiler error: 1.6.0 */
  lua_rawsetstringnumber(L, -1, "buffersize", LUAL_BUFFERSIZE);     /* 0.25.0, deprecate */
  lua_rawsetstringnumber(L, -1, "maxpathlength", PATH_MAX-1);       /* 1.6.0 */
  lua_rawsetstringstring(L, -1, "pathsep", LUA_PATHSEP);  /* 0.26.0 */
  /* set number of lines to be printed at once at table output */
  lua_rawsetstringnumber(L, -1, "more", 40);
  /* set protected names for `with` function */
  lua_pushstring(L, "withprotected");
  agn_createset(L, 2);
  lua_sinsertstring(L, -1, "next");
  lua_sinsertstring(L, -1, "print");
  lua_rawset(L, -3);
  return 1;
}

