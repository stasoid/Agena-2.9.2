/*
** $Id: loslib.c,v 1.19 2006/04/26 18:19:49 roberto Exp $
** Standard Operating System library
** See Copyright Notice in agena.h
*/

#include <errno.h>
#include <locale.h>
#include <stdlib.h>
#include <string.h>
#include <sys/timeb.h>  /* ftime, for milliseconds */

/* instead of time.h: */
#include "agnt64.h"

#include "sofa.h"

#include <sys/stat.h> /* for mkdir, stat */

/* for os.fstat to determine correct sizes of files > 4 GB */
#ifdef _WIN32
  #undef stat
  #define stat  _stati64
  #undef fstat
  #define fstat _fstati64
  #undef wstat
  #define wstat _wstati64
#elif defined (__SVR4) && defined (__sun)
  #undef stat
  #define stat stat64
  #undef lstat
  #define lstat lstat64
  #include <utmpx.h>  /* for getutxent in os.uptime */
  #include <sys/mount.h>  /* for umount2, 2.8.5 fix */
#elif defined(__unix__) && !defined(LUA_DOS)
  #undef _FILE_OFFSET_BITS
  #define _FILE_OFFSET_BITS	64
#endif


#if _WIN32
/* If you need Win32 API features newer than Win95 and WinNT then you must
 * define WINVER before including windows.h or any other method of including
 * the windef.h header. */
#define WINVER 0x0500  /* 2.3.0 RC 3 */

#include <windows.h>  /* for os_memstate */
#include <io.h>       /* for access */
#include <ctype.h>    /* for toupper */
#include <process.h>  /* for getpid & getppid */
#include <errno.h>     /* symlink */
#include <ole2.h>      /* symlink */
#include <shlobj.h>    /* symlink */
#include <winbase.h>   /* MemoryStatusEx */
#include <winioctl.h>  /* for os.cdrom */
#include <tchar.h>     /* for os.cdrom */
#include <mmsystem.h>  /* for MCI functions, see os.cdrom */
#include <wingdi.h>    /* for colour depth, GetDeviceCaps */
#include <PowrProf.h>  /* for SetSuspendState */

#endif


/* This OS2 header must be placed before including unistd, utsname, ncurses,
   otherwise GCC will not compile successfully. 0.13.3 */
#ifdef __OS2__
#define INCL_DOS
#define INCL_DOSERRORS
#define INCL_NOPM
#define INCL_DOSPROCESS  /* for DosBeep */
#define INCL_DOSFILEMGR
#include <os2.h>     /* for memory status queries */
#endif


#if defined(__unix__) || defined(__OS2__) || defined(__APPLE__) || defined(__HAIKU__)
#include <unistd.h>       /* for access and sleep */
#include <sys/utsname.h>  /* for uname */
#endif

#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__)
#include <signal.h>       /* for signal and alarm */
#endif

#ifdef __APPLE__
  #include <mach/mach.h>
  #include <mach/mach_time.h>
  #include <sys/sysctl.h>
  #include <crt_externs.h>  /* for os.environ */
  #include <stdint.h>
  #include <sys/types.h>
  #include <sys/sysctl.h>
  #include <sys/mount.h>   /* for os.unmount */
  #include <time.h>        /* for os.uptime */
  #define environ (*_NSGetEnviron())      /* for os.environ */
  #include <CoreServices/CoreServices.h>  /* for os.terminate */
  #include <Carbon/Carbon.h>              /* for os.terminate */
#elif defined(__unix__) || defined(__OS2__)
  extern char **environ;  /* for os.environ */
#endif

#if (defined(__linux__))  /* for uptime and CD-ROM function(s) */
  #include <fcntl.h>
  #include <linux/cdrom.h>
  #include <sys/ioctl.h>
  #include <sys/types.h>
  #include <sys/mount.h>
  /* for os.uptime */
  #include <linux/unistd.h>       /* for _syscallX macros/related stuff */
  #include <linux/kernel.h>       /* for struct sysinfo */
  #include <sys/sysinfo.h>
  /* for os.cdrom */
  #include <linux/cdrom.h>
#endif

#if (defined(_WIN32) || defined(__unix__) || defined(__APPLE__) || defined(LUA_DOS))
#include <utime.h>  /* for utime() */
#endif


#include <dirent.h>  /* used by io_ls function */
#include <errno.h>   /* used by io_ls function */

#define loslib_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "agnconf.h"  /* for LUA_TMPNAMBUFSIZE */
#include "agnhlps.h"  /* do not change the order of this #include statement ! */

#ifdef __OS2__
#include <ctype.h>
#else
#include "lvm.h"
#endif

#if defined(__APPLE__) || defined(__unix__)  /* 2.4.0, 2.8.5 fix: UNIX: umount2 */
#include "agncmpt.h"
#endif


static int os_pushresult (lua_State *L, int i, const char *filename, const char *procname) {
  int en = errno;  /* calls to Lua API may change this value */
  if (i == -1) {  /* function failed ? */
    luaL_error(L, "Error in " LUA_QS " with " LUA_QS ": %s ", procname, filename, strerror(en));  /* Agena 1.2 */
    return 0;
  }
  else {
    lua_pushtrue(L);
    return 1;
  }
}


static void setboolean (lua_State *L, const char *key, unsigned int value) {
  lua_pushstring(L, key);
  lua_pushboolean(L, value);
  lua_settable(L, -3);
}


static void setstring (lua_State *L, const char *key, const char *value) {
  lua_pushstring(L, key);
  lua_pushstring(L, value);
  lua_rawset(L, -3);
}


static void setnumber (lua_State *L, const char *key, lua_Number value) {
  lua_pushstring(L, key);
  lua_pushnumber(L, value);
  lua_rawset(L, -3);
}


static int os_execute (lua_State *L) {
  if (system(NULL) == 0)  /* 1.9.1 */
    luaL_error(L, "Error in " LUA_QS ": command processor is not available.", "os.execute");
  lua_pushinteger(L, system(luaL_optstring(L, 1, NULL)));
  return 1;
}


/* even when deleting 100k or more files, accepting tables, sets, or sequences of file names did not speed up this function at
   least on a MacBook Pro manufactured in 2011 running Mac OS 10.7 */
static int os_remove (lua_State *L) {
  const char *filename = agn_checkstring(L, 1);
  if (access(filename, 00|04) != -1)  /* 0.26.0 patch */
    return os_pushresult(L, remove(filename), filename, "os.remove");  /* Agena 1.9.5 fix */
  else {
    luaL_error(L, "Error in " LUA_QS " with " LUA_QS ": file or directory does not exist.", "os.remove", filename);  /* Agena 1.2 */
    return 0;
  }
}


static int os_move (lua_State *L) {
  const char *fromname = agn_checkstring(L, 1);
  const char *toname = agn_checkstring(L, 2);
  if (access(fromname, 00|04) != -1)  /* 0.26.0 patch */
    return os_pushresult(L, rename(fromname, toname), fromname, "os.move");  /* Agena 1.9.5 */
  else {
    luaL_error(L, "Error in " LUA_QS " with " LUA_QS ": file or directory does not exist.", "os.move", fromname);  /* Agena 1.2 */
    return 0;
  }
}


static int os_tmpname (lua_State *L) {
  char buff[LUA_TMPNAMBUFSIZE];
  int err;
  lua_tmpnam(buff, err);
  if (err)
    return luaL_error(L, "Error in " LUA_QS ": unable to generate a unique filename.", "os.tmpname");
  lua_pushstring(L, buff);
  return 1;
}




static int os_getenv (lua_State *L) {
/* tested in Windows, Mac OS X, Solaris 10, Linux, OS/2, DOS */
#if defined(_WIN32)
  /* 2.8.6, taken from lua_sys package written by Nodir Temirkhodjaev, <nodir.temir@gmail.com> */
  unsigned int len;
  const char *name = luaL_checkstring(L, 1);
  len = GetEnvironmentVariableA(name, NULL, 0);
  if (len) {
    char *buf = malloc(len);
    if (buf && GetEnvironmentVariableA(name, buf, len) == len - 1) {
      lua_pushlstring(L, buf, len - 1);
      free(buf);
      return 1;
    }
    free(buf);
  }
  lua_pushnil(L);
  /*  written by * Copyright 2007 Mark Edgar < medgar at gmail com >,
  taken from http://lua-ex-api.googlecode.com/svn/trunk/w32api/ex.c
  const char *nam = luaL_checkstring(L, 1);
  char sval[256], *val;
  size_t len = GetEnvironmentVariable(nam, val = sval, sizeof sval);
  if (sizeof sval < len)
    len = GetEnvironmentVariable(nam, val = lua_newuserdata(L, len), len);
  if (len == 0)
    lua_pushnil(L);
  else
    lua_pushlstring(L, val, len); */
#else
  lua_pushstring(L, getenv(luaL_checkstring(L, 1)));  /* if NULL, lua_pushstring returns null */
#endif
  return 1;
}


/* code originally written by * Copyright 2007 Mark Edgar < medgar at gmail com >,
   taken from http://lua-ex-api.googlecode.com/svn/trunk/w32api/ex.c;
   extension by Alexander Walz, tested in Windows, Mac OS X, Solaris 10, Linux, OS/2, DOS */
static int os_setenv (lua_State *L) {  /* Agena 1.0.2 */
#ifdef _WIN32
  int r;
#endif
  const char *nam, *val;
  nam = luaL_checkstring(L, 1);
  val = NULL;
  if (lua_gettop(L) != 2)
    luaL_error(L, "Error in " LUA_QS ": expected two arguments.", "os.setenv");
  if (strlen(nam) > 32766)
    luaL_error(L, "Error in " LUA_QS ": first argument too long.", "os.setenv");
  if (lua_isnoneornil(L, 2)) {
    /* 2.8.6: delete environment variable */
  } else if (agn_isstring(L, 2) || agn_isnumber(L, 2)) {
    val = lua_tostring(L, 2);
#if defined(_WIN32)
    /* 2.8.6 patch; contrary to the MSDN documentation, SetEnvironmentVariable crashed if given a string longer than 32766 chars (with MinGW/GCC) */
    if (strlen(val) > 32766)
      luaL_error(L, "Error in " LUA_QS ": second argument too long.", "os.setenv");
#endif
  } else
    return luaL_argerror(L, 2, "string, number, or null expected");
#if defined(_WIN32)
  r = SetEnvironmentVariable(luaL_checkstring(L, 1), val);
  if (!r)
    luaL_error(L, "Error in " LUA_QS ": %s.", "os.setenv", GetLastError());
  else
    lua_pushtrue(L);
#else
  int err = 0;
  val = lua_tostring(L, 2);
  #ifdef LUA_DOS
  err = setenv(nam, val, 1);
  #elif !defined(__APPLE__)
  err = (val ? setenv(nam, val, 1) : unsetenv(nam));  /* if val is NULL, the environment variable is deleted */
  #else
  if (val == 0)
    unsetenv(nam);  /* unsetenv is of type void in Mac OS X */
  else
    err = setenv(nam, val, 1);
  #endif
  if (err == -1)
    luaL_error(L, "Error in " LUA_QS ": could not %s environment variable.", "os.setenv",
      val == 0 ? "unset" : "set");
  lua_pushtrue(L);
#endif
  return 1;
}


static int os_environ (lua_State *L) {  /* Agena 1.0.2,
  written by * Copyright 2007 Mark Edgar < medgar at gmail com >,
  taken from http://lua-ex-api.googlecode.com/svn/trunk/w32api/ex.c */

/* tested in Windows, Mac OS X, Solaris 10, Linux, OS/2, DOS */
#if defined(_WIN32)
  const char *nam, *val, *end;
  const char *envs = GetEnvironmentStrings();
  if (!envs) {
    luaL_error(L, "Error in " LUA_QS ": could not get environment.", "os.environ");
  }
  lua_newtable(L);
  for (nam = envs; *nam; nam = end + 1) {
    end = strchr(val = strchr(nam, '=') + 1, '\0');
    if (val - nam - 1 != 0) {  /* do not enter entry of the key is the empty string */
      lua_pushlstring(L, nam, val - nam - 1);
      lua_pushlstring(L, val, end - val);
      lua_settable(L, -3);
    }
  }
#elif defined(__unix__) || defined(__APPLE__) || defined(__OS2__)  /* works in DOS, too */
  const char *nam, *val, *end;
  const char **env;
  lua_newtable(L);
  for (env = (const char **)environ; (nam = *env); env++) {
    end = strchr(val = strchr(nam, '=') + 1, '\0');
    lua_pushlstring(L, nam, val - nam - 1);
    lua_pushlstring(L, val, end - val);
    lua_settable(L, -3);
  }
#else
  lua_pushfail(L);
#endif
  return 1;
}


/*
** {======================================================
** Time/Date operations
** { year=%Y, month=%m, day=%d, hour=%H, min=%M, sec=%S,
**   wday=%w+1, yday=%j, isdst=? }
** =======================================================
*/

static void setfield (lua_State *L, const char *key, int value) {
  lua_pushinteger(L, value);
  lua_setfield(L, -2, key);
}

static void setboolfield (lua_State *L, const char *key, int value) {
  if (value < 0)  /* undefined? */
    return;  /* does not set field */
  lua_pushboolean(L, value);
  lua_setfield(L, -2, key);
}

static int getboolfield (lua_State *L, const char *key) {
  int res;
  lua_getfield(L, -1, key);
  res = lua_isnil(L, -1) ? -1 : lua_toboolean(L, -1);
  agn_poptop(L);
  return res;
}


static int getfield (lua_State *L, const char *key, int d) {
  int res;
  lua_getfield(L, -1, key);
  if (agn_isnumber(L, -1))
    res = (int)lua_tointeger(L, -1);
  else {
    if (d < 0)
      return luaL_error(L, "field " LUA_QS " missing in date table.", key);
    res = d;
  }
  agn_poptop(L);
  return res;
}


static int os_date (lua_State *L) {
  struct TM *stm;
#if defined(_WIN32) || defined(__unix__) || defined(__APPLE__)
  struct timeb tp;
#elif defined(__OS2__)
  DATETIME tp;
#endif
  int msecs, ye, mo, da, ho, mi, se;
  const char *s;
  Time64_T t = luaL_opt(L, (Time64_T)agnL_checknumber, 2, time(NULL));
  s = luaL_optstring(L, 1, "%c");
  if (*s == '!') {  /* UTC? */
    stm = gmtime64(&t);
    s++;  /* skip `!' */
  }
  else
    stm = localtime64(&t);
  msecs = -1;
  /* 1.11.7, get milliseconds */
  #ifdef _WIN32
  ftime(&tp);
  msecs = tp.millitm;
  #elif defined(__unix__) || defined(__APPLE__)
  if (ftime(&tp) == 0)  /* set milliseconds only when query has been successful */
    msecs = tp.millitm;
  #elif defined (__OS2__)  /* 2.3.0 RC 2 eCS extension */
    DosGetDateTime(&tp);
    msecs = tp.hundredths;
  #endif
  if (stm == NULL) { /* invalid date? */
    lua_pushnil(L);
    return 1;
  }
  ye = stm->tm_year+1900;
  mo = stm->tm_mon+1;
  da = stm->tm_mday;
  ho = stm->tm_hour;
  mi = stm->tm_min;
  se = stm->tm_sec;
  if (lua_gettop(L) == 0) {
    char *rstr, *year, *month, *day, *hour, *minute, *second, *msecond;
    year    = tools_dtoa(ye);
    month   = tools_dtoa(mo);
    day     = tools_dtoa(da);
    hour    = tools_dtoa(ho);
    minute  = tools_dtoa(mi);
    second  = tools_dtoa(se);
    msecond = tools_dtoa(msecs);
    if (msecs != -1)
      rstr = concat(year, "/",
         (mo < 10 ? "0" : ""), month, "/",
         (da < 10 ? "0" : ""), day, " ",
         (ho < 10 ? "0" : ""), hour, ":",
         (mi < 10 ? "0" : ""), minute, ":",
         (se < 10 ? "0" : ""), second, ".",
         (msecs > 99 ? "" : (msecs > 9 ? "0" : "00")),
         msecond, NULL);
    else
      rstr = concat(year, "/",
         (mo < 10 ? "0" : ""), month, "/",
         (da < 10 ? "0" : ""), day, " ",
         (ho < 10 ? "0" : ""), hour, ":",
         (mi < 10 ? "0" : ""), minute, ":",
         (se < 10 ? "0" : ""), second, NULL);
    lua_pushstring(L, rstr);
    xfree(rstr); xfree(year); xfree(month); xfree(day); xfree(hour); xfree(minute); xfree(second); xfree(msecond);
  }
  else if (strcmp(s, "*t") == 0) {
    lua_createtable(L, 0, 10);  /* 9 = number of fields */
    setfield(L, "sec", se);
    setfield(L, "min", mi);
    setfield(L, "hour", ho);
    setfield(L, "day", da);
    setfield(L, "month", mo);
    setfield(L, "year", ye);
    setfield(L, "wday", stm->tm_wday+1);
    setfield(L, "yday", stm->tm_yday+1);
    setboolfield(L, "isdst", stm->tm_isdst);
    if (msecs != -1)
      setfield(L, "msec", msecs);  /* set milliseconds */
  }
  else {  /* Lua 5.1.2 patch, patched Agena 1.12.4 */
    char cc[3];
    luaL_Buffer b;
    cc[0] = '%'; cc[2] = '\0';
    luaL_buffinit(L, &b);
    for (; *s; s++) {
      if (*s != '%' || *(s + 1) == '\0')  /* no conversion specifier? */
        luaL_addchar(&b, *s);  /* add character to resulting string */
      else {
        size_t reslen;
        char buff[256];  /* should be big enough for any conversion result */
        cc[1] = *(++s);
        /* see: http://www.gnu.org/software/libc/manual/html_node/Formatting-Calendar-Time.html */
        reslen = strftime(buff, sizeof(buff), cc, stm);
        luaL_addlstring(&b, buff, reslen);
      }
    }
    luaL_pushresult(&b);
  }
  return 1;
}


static int os_time (lua_State *L) {
  Time64_T t;  /* 1.12.4 */
  int msecs, r;
#if defined(_WIN32) || defined(__unix__) || defined(__APPLE__)
  struct timeb tp;
#elif defined(__OS2__)
  DATETIME tp;
#endif
  r = 1;
  if (lua_isnoneornil(L, 1))  /* called without args? */
    t = time(NULL);  /* get current time */
  else {
    struct TM ts;  /* 1.12.4 */
    switch (lua_type(L, 1)) {
      case LUA_TTABLE: {
        lua_settop(L, 1);  /* make sure table is at the top */
        ts.tm_sec = getfield(L, "sec", 0);
        ts.tm_min = getfield(L, "min", 0);
        ts.tm_hour = getfield(L, "hour", 12);
        ts.tm_mday = getfield(L, "day", -1);
        ts.tm_mon = getfield(L, "month", -1) - 1;
        ts.tm_year = getfield(L, "year", -1) - 1900;
        ts.tm_isdst = getboolfield(L, "isdst");
        t = mktime64(&ts);  /* Agena 1.8.0 */
        break;
      }
      case LUA_TSEQ: {
        size_t nops;
        lua_settop(L, 1);  /* make sure sequence is at the top */
        nops = agn_seqsize(L, 1);
        if (nops < 3)
          luaL_error(L, "Error in " LUA_QS ": expected a sequence of at least three numbers.", "os.time");
        ts.tm_year = lua_seqgetinumber(L, 1, 1) - 1900;
        ts.tm_mon = lua_seqgetinumber(L, 1, 2) - 1;
        ts.tm_mday = lua_seqgetinumber(L, 1, 3);
        ts.tm_hour = nops > 3 ? lua_seqgetinumber(L, 1, 4) : 0;
        ts.tm_min = nops > 4 ? lua_seqgetinumber(L, 1, 5) : 0;
        ts.tm_sec = nops > 5 ? lua_seqgetinumber(L, 1, 6) : 0;
        if (nops > 6) {
          lua_seqgeti(L, 1, 7);
          if (lua_isboolean(L, -1)) {
            ts.tm_isdst = lua_toboolean(L, -1) > 0;
            agn_poptop(L);
          } else {
            agn_poptop(L);
            luaL_error(L, "Error in " LUA_QS ": seventh element in sequence must be a boolean.", "os.time");
          }
        } else
          ts.tm_isdst = 0;
        t = mktime64(&ts);
        break;
      }
      default: {
        t = time(NULL);  /* to avoid compiler warnings */
        luaL_error(L, "Error in " LUA_QS ": first argument must either be a table or sequence.", "os.time");
      }
    }
  }
  msecs = -1;
  /* 1.11.7, get milliseconds */
  #ifdef _WIN32
  ftime(&tp);
  msecs = tp.millitm;
  #elif defined(__unix__) || defined(__APPLE__)
  if (ftime(&tp) == 0)  /* set milliseconds only when query has been successful */
    msecs = tp.millitm;
  #elif defined(__OS2__)  /* 2.3.0 RC 2 eCS extension */
    DosGetDateTime(&tp);
    msecs = tp.hundredths;
  #endif
  if (t == (Time64_T)(-1))  /* 2.1.3 */
    lua_pushnil(L);
  else {
    lua_pushnumber(L, (lua_Number)t);
    if (msecs != -1) {
      lua_pushnumber(L, msecs);
      r = 2;
    }
  }
  return r;
}


static int os_difftime (lua_State *L) {
  lua_pushnumber(L, difftime((Time64_T)(agnL_checknumber(L, 1)),  /* 2.1.3 */
                             (Time64_T)(agnL_optnumber(L, 2, 0))));  /* 2.1.3 */
  return 1;
}

/* }====================================================== */


static int os_setlocale (lua_State *L) {
  static const int cat[] = {LC_ALL, LC_COLLATE, LC_CTYPE, LC_MONETARY,
                      LC_NUMERIC, LC_TIME};
  static const char *const catnames[] = {"all", "collate", "ctype", "monetary",
     "numeric", "time", NULL};
  const char *l = luaL_optstring(L, 1, NULL);
  int op = luaL_checkoption(L, 2, "all", catnames);
  lua_pushstring(L, setlocale(cat[op], l));
  return 1;
}


static int os_exit (lua_State *L) {  /* 2.9.2, inspired by Dubiousjim's Lua 5.1 power patch
  published at http://lua-users.org/wiki/LuaPowerPatches. */
  int status = agnL_optinteger(L, 1, EXIT_SUCCESS);
  if (agnL_optboolean(L, 2, 0)) lua_close(L);
  exit(status);
  return 0;  /* to avoid warnings */
}


/* determine information on available memory on Windows platforms, 0.5.3, September 15, 2007;
   extended in 0.12.2 on September 29, 2008 to work in UNIX; extended to fully support OS/2 in 0.13.3;
   extended to support Mac OS X in 0.31.3 */


#if defined(_WIN32) || (defined(__unix__) && !defined(LUA_DOS)) || defined(__OS2__) || defined(__HAIKU__)  || defined(__APPLE__)
static int os_memstate (lua_State *L) {
#if defined(__APPLE__)  /* 2.4.0 change */
  lua_Number div;
#else
  long long AvailPhys, TotalPhys, div;
#endif
#if defined(_WIN32)
  long long AvailVirtual, TotalVirtual, AvailPageFile, TotalPageFile;
  struct WinVer winversion;
  SYSTEM_INFO si;
#elif __OS2__
  APIRET result;
  ULONG memInfo[5];
  ULONG memInfoPageSize[1];
#elif defined(__APPLE__)
  vm_size_t pagesize;
  vm_statistics_data_t vminfo;
  mach_port_t system;
  unsigned int c;
  int sysmask[2];
  size_t length;
  uint64_t memsize;
  lua_Number f;
#endif
  static const char *const unit[] = {"bytes", "kbytes", "mbytes", "gbytes", NULL};
  div = tools_intpow(1024, agnL_checkoption(L, 1, "bytes", unit));
#if defined(_WIN32)
  if (getWindowsVersion(&winversion) < 7) {
    MEMORYSTATUS memstat;  /* 2.3.0 RC 3 */
    memstat.dwLength = sizeof(MEMORYSTATUS);
    GlobalMemoryStatus(&memstat);
    AvailPhys = (long)memstat.dwAvailPhys;
    TotalPhys = (long)memstat.dwTotalPhys;
    AvailVirtual = (long)memstat.dwAvailVirtual;
    TotalVirtual = (long)memstat.dwTotalVirtual;
    AvailPageFile = (long)memstat.dwAvailPageFile;
    TotalPageFile = (long)memstat.dwTotalPageFile;
  } else {  /* 2.3.0 RC 3 extension */
    MEMORYSTATUSEX memstat;
    memstat.dwLength = sizeof(MEMORYSTATUSEX);
    GlobalMemoryStatusEx(&memstat);
    AvailPhys = (DWORDLONG)memstat.ullAvailPhys;
    TotalPhys = (DWORDLONG)memstat.ullTotalPhys;
    AvailVirtual = (DWORDLONG)memstat.ullAvailVirtual;
    TotalVirtual = (DWORDLONG)memstat.ullTotalVirtual;
    AvailPageFile = (DWORDLONG)memstat.ullAvailPageFile;
    TotalPageFile = (DWORDLONG)memstat.ullTotalPageFile;
  }
  GetSystemInfo(&si);  /* get dwPageSize (in bytes), 2.6.1 */
  /* long MemoryLoad = (long)memstat.dwMemoryLoad; */
  /* int Length = (int)memstat.dwLength; */
  lua_newtable(L);
  setnumber(L, "freephysical", (lua_Number)(AvailPhys)/div);
  setnumber(L, "totalphysical", (lua_Number)(TotalPhys)/div);
  setnumber(L, "freevirtual", (lua_Number)(AvailVirtual)/div);
  setnumber(L, "totalvirtual", (lua_Number)(TotalVirtual)/div);    /* 0.26.0 patch */
  setnumber(L, "freepagefile", (lua_Number)(AvailPageFile)/div);   /* 2.3.2 extension */
  setnumber(L, "totalpagefile", (lua_Number)(TotalPageFile)/div);  /* 2.3.2 extension */
  setnumber(L, "pagesize", (lua_Number)(si.dwPageSize)/div);       /* 2.6.1 extension */
#elif (defined(__unix__) && !defined(LUA_DOS)) || defined(__HAIKU__) /* for DJGPP */
  AvailPhys = sysconf(_SC_AVPHYS_PAGES) * sysconf(_SC_PAGESIZE);
  TotalPhys = sysconf(_SC_PHYS_PAGES) * sysconf(_SC_PAGESIZE);
  lua_newtable(L);
  setnumber(L, "freephysical", (lua_Number)(AvailPhys)/div);
  setnumber(L, "totalphysical", (lua_Number)(TotalPhys)/div);
  setnumber(L, "pagesize", (lua_Number)(sysconf(_SC_PAGESIZE))/div);
#elif defined(__OS2__)
  /* see: http://www.edm2.com/os2api/Dos/DosQuerySysInfo.html */
  result = DosQuerySysInfo(QSV_TOTPHYSMEM, QSV_MAXSHMEM,
      &memInfo[0], sizeof(memInfo));
  AvailPhys = 0;
  TotalPhys = 0;
    /* sysconf(_SC_AVPHYS_PAGES) * sysconf(_SC_PAGESIZE); does not work for
      the _SC* names are not defined in GCC unistd.h */
  lua_newtable(L);
  if (result != 0) {  /* 2.6.1 */
    setnumber(L, "totalphysical", AGN_NAN);
    setnumber(L, "freevirtual", AGN_NAN);
    setnumber(L, "resident", AGN_NAN);
    setnumber(L, "maxprmem", AGN_NAN);
    setnumber(L, "maxshmem", AGN_NAN);
  } else {
    setnumber(L, "totalphysical", (lua_Number)memInfo[0]/div);
    setnumber(L, "freevirtual", (lua_Number)memInfo[2]/div);
    setnumber(L, "resident", (lua_Number)memInfo[1]/div);
    setnumber(L, "maxprmem", (lua_Number)memInfo[3]/div);  /* QSV_MAXPRMEM = Maximum number of bytes available for this process RIGHT NOW. 2.3.2 eCS extension. */
    setnumber(L, "maxshmem", (lua_Number)memInfo[4]/div);  /* QSV_MAXSHMEM = Maximum number of shareable bytes available RIGHT NOW. 2.3.2 eCS extension. */
  }
  result = DosQuerySysInfo(QSV_PAGE_SIZE, QSV_PAGE_SIZE,  /* 2.6.1 */
      &memInfoPageSize[0], sizeof(memInfoPageSize));
  if (result != 0)
    setnumber(L, "pagesize", AGN_NAN);
  else
    setnumber(L, "pagesize", (lua_Number)memInfoPageSize[0]/div);
#elif defined(__APPLE__)
  sysmask[0] = CTL_HW;
  sysmask[1] = HW_MEMSIZE;
  length = sizeof(memsize);
  memsize = 0L;
  lua_newtable(L);
  c = HOST_VM_INFO_COUNT;
  system = mach_host_self();
  pagesize = 0;  /* 2.3.3 fix */
  if (host_page_size(system, &pagesize) != KERN_SUCCESS) pagesize = 4096;
  f = pagesize/div;
  if (host_statistics(system, HOST_VM_INFO, (host_info_t)(&vminfo), &c) != KERN_SUCCESS) {
    setnumber(L, "freephysical", AGN_NAN);
    setnumber(L, "active", AGN_NAN);
    setnumber(L, "inactive", AGN_NAN);
    setnumber(L, "speculative", AGN_NAN);
    setnumber(L, "wireddown", AGN_NAN);
    setnumber(L, "reactivated", AGN_NAN);
  }
  else {
    setnumber(L, "freephysical", ((vminfo.free_count - vminfo.speculative_count)) * f);
    setnumber(L, "active", vminfo.active_count * f);
    setnumber(L, "inactive", vminfo.inactive_count * f);
    setnumber(L, "speculative", vminfo.speculative_count * f);
    setnumber(L, "wireddown", vminfo.wire_count * f);
    setnumber(L, "reactivated", vminfo.reactivations * f);
  }
  if (sysctl(sysmask, 2, &memsize, &length, NULL, 0 ) == -1)
    setnumber(L, "totalphysical", AGN_NAN);
  else
    setnumber(L, "totalphysical", memsize/div);
  setnumber(L, "pagesize", pagesize/div);  /* 2.6.1 */
#else
  lua_pushfail(L);
#endif
  return 1;
}
#endif


/* get the current Windows login name, 0.5.3, September 15, 2007;
   extended 0.12.2, October 12, 2008; changed to support OS/2 0.13.3 */

static int os_login (lua_State *L) {
#if defined(_WIN32)
  char buffer[257];
  DWORD len = 256;
  if (GetUserName(buffer, &len)) {  /* Agena 1.6.0 */
    buffer[len] = '\0';
    lua_pushstring(L, buffer);
  } else
    lua_pushfail(L);
#elif defined(__unix__) || defined(__OS2__) || defined(__APPLE__) || defined(__HAIKU__)
  char *LoginName;
  LoginName = getlogin();
  if (LoginName == NULL)
    lua_pushfail(L);
  else
    lua_pushstring(L, LoginName);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* get the Windows computer name, 0.5.3, September 15, 2007;
   improved in 0.13.3, extended 2.3.0 RC 2 */

static int os_computername (lua_State *L) {
#if defined(_WIN32)
  char buffer[257];
  DWORD len = 256;
  if (GetComputerName(buffer, &len)) {  /* Agena 1.6.0 */
    buffer[len] = '\0';
    lua_pushstring(L, buffer);
  } else
    lua_pushfail(L);
#elif defined(__unix__) || defined(__APPLE__) || defined(__HAIKU__)
  /* does not work with OS/2: needs a file `TCPIP32` (as does bash). If not
     present, Agena does not start. */
  char buffer[256];
  if (gethostname(buffer, sizeof buffer) == 0)
    lua_pushstring(L, buffer);
  else
    lua_pushfail(L);
#elif defined(__OS2__)  /* 2.3.0 RC 2 eCS extension */
  const char *str = getenv("HOSTNAME");
  lua_pushstring(L, str);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* return amount of free memory; extended 0.12.2, 28.09.2008; OS/2 addon
   August 07, 2009, OS X addon 0.31.3 March 28, 2010 */
static int os_freemem (lua_State *L) {
#if defined(_WIN32) || (defined(__unix__) && !defined(LUA_DOS)) || defined(__OS2__) || defined(__APPLE__) || defined(__HAIKU__)
  lua_Number div;
  static const char *const unit[] = {"bytes", "kbytes", "mbytes", "gbytes", NULL};
  div = tools_intpow(1024, agnL_checkoption(L, 1, "bytes", unit));
#if defined(_WIN32)
  MEMORYSTATUS memstat;
#elif __OS2__
  APIRET result;
  ULONG memInfo[3];
#elif defined(__APPLE__)
  vm_size_t pagesize;
  vm_statistics_data_t vminfo;
  mach_port_t system;
  unsigned int c;
#endif
#if defined(_WIN32)
  memstat.dwLength = sizeof(MEMORYSTATUS);
  GlobalMemoryStatus(&memstat);
  lua_pushnumber(L, (lua_Number)memstat.dwAvailPhys/div);
#elif defined(__unix__) && !defined(LUA_DOS) || defined(__HAIKU__)  /* excludes DJGPP */
  lua_pushnumber(L, (lua_Number)(sysconf(_SC_AVPHYS_PAGES) * sysconf(_SC_PAGESIZE))/div);
#elif defined (__OS2__)
  result = DosQuerySysInfo(QSV_TOTPHYSMEM, QSV_TOTAVAILMEM,
      &memInfo[0], sizeof(memInfo));
  if (result != 0)  /* return free virtual memory */
    lua_pushfail(L);
  else
    lua_pushnumber(L, (lua_Number)(memInfo[2])/div);
#elif defined(__APPLE__)
  c = HOST_VM_INFO_COUNT;
  system = mach_host_self();
  pagesize = 0;  /* 2.3.3 fix */
  if (host_page_size(mach_host_self(), &pagesize) != KERN_SUCCESS) pagesize = 4096;
  if (host_statistics(system, HOST_VM_INFO, (host_info_t)(&vminfo), &c) != KERN_SUCCESS)
    lua_pushfail(L);
  else
    lua_pushnumber(L, (uint64_t)(vminfo.free_count - vminfo.speculative_count) * pagesize/div);
#endif
#else
  lua_pushfail(L);
#endif
  return 1;
}


static int os_listcore (lua_State *L) {
  DIR *dir;
  struct dirent *entry;
  int i, isdir, isfile, islink, nops, push, hasfa;
  const char *path, *option, *fn, *pattern;
  char *tbf;  /* to be FREED after string has been pushed on the stack */
#ifndef _WIN32
  struct stat o;
  mode_t mode;
#else
  DWORD mode;
#endif
  isdir = isfile = islink = hasfa = 0;
  pattern = NULL;  /* 1.9.4 */
  if (lua_isnoneornil(L, 1)) {  /* no arguments ?  Agena 1.6.0 Valgrind */
    char *buffer;
    buffer = (char *)malloc((PATH_MAX+1)*sizeof(char));
    if (buffer == NULL)  /* Agena 1.6.0 Valgrind */
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "os.listcore");
    if (tools_cwd(buffer) != 0)  /* tools_cwd frees buffer in case of errors */
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "os.listcore");
    lua_pushstring(L, buffer);  /* create a duplicate */
    path = agn_checkstring(L, -1);
    agn_poptop(L);  /* pop buffer */
    xfree(buffer);  /* Agena 1.6.0 Valgrind */
  } else
    path = agn_checkstring(L, 1);
  path = (const char *)charreplace((char *)path, '\\', '/', 1);
  nops = lua_gettop(L);
  for (i=2; i <= nops; i++) {
    option = luaL_checkstring(L, i);
    if (strcmp(option, "files") == 0) { isfile = 1; hasfa = 1; }
    else if (strcmp(option, "dirs") == 0) { isdir = 1; hasfa = 1; }
    else if (strcmp(option, "links") == 0) { islink = 1; hasfa = 1; }
    else pattern = option;
  }
  dir = opendir(path);
  if (dir == NULL) {
    lua_pushnil(L);
    lua_pushstring(L, strerror(errno));
    return 2;
  }
  lua_newtable(L);
  i = 1;
  while ((entry = readdir(dir)) != NULL) {
    push = nops <= 1 || pattern != NULL;
    fn = entry->d_name;
    if (strcmp(fn, ".") == 0 || strcmp(fn, "..") == 0 || (pattern != NULL && glob(pattern, fn) == 0)) continue;  /* 1.9.4 */
    if (hasfa) {  /* do not create `//...`, 0.31.4, tuned 1.9.5 */
      lua_pushstring(L, (strcmp(path, "/") == 0) ? (tbf = concat("/", fn, NULL)) : (tbf = concat(path, "/", fn, NULL)));  /* free memory, 1.10.4 */
      xfree(tbf);
#ifdef _WIN32
      mode = GetFileAttributes(agn_tostring(L, -1));
      if (mode != INVALID_FILE_ATTRIBUTES)
        push = ((mode & FILE_ATTRIBUTE_DIRECTORY) && isdir) ||
               (!(mode & FILE_ATTRIBUTE_DIRECTORY) && isfile) ||
               ((mode & FILE_ATTRIBUTE_REPARSE_POINT) && islink);
      agn_poptop(L);
    }
#else
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
      if (lstat(agn_tostring(L, -1), &o) == 0) {  /* 1.12.1 */
#else
      if (stat(agn_tostring(L, -1), &o) == 0) {
#endif
        mode = o.st_mode;
        push = (
               (S_ISDIR(mode) && isdir)
               || (S_ISREG(mode) && isfile)
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
               || (S_ISLNK(mode) && islink)
#endif
             );
      }
      agn_poptop(L);
    }
#endif
    if (push) {
      lua_rawsetistring(L, -1, i++, fn);  /* 1.9.5 */
    }
  }
  closedir(dir);
  return 1;
}


#ifdef _WIN32
int issymlink (const char *fn) {
  DWORD mode = GetFileAttributes(fn);
  return (mode & FILE_ATTRIBUTE_REPARSE_POINT) == 1024;
}
#endif


static int os_fstat (lua_State *L) {  /* 0.12.2, October 11, 2008; modified 0.26.0, August 06, 2009; patched 0.31.3 */
  struct stat entry;
  const char *fn;
  mode_t mode;
  struct TM *stm;
  Time64_T seconds;
  char bits[18] = "----------:-----\0";
#ifdef _WIN32
  DWORD winmodet;
#elif defined(__OS2__)
  static FILESTATUS3 fstat, *fs;
  APIRET rc;
#endif
  fn = luaL_checkstring(L, 1);
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
  if (lstat(fn, &entry) == 0) {  /* 1.12.1 */
#else
  if (stat(fn, &entry) == 0) {
#endif
    lua_newtable(L);
    mode = entry.st_mode;
    lua_pushstring(L, "mode");
    if (S_ISDIR(mode)) {
      lua_pushstring(L, "DIR");
      bits[0] = 'd';
#if defined(_WIN32) || defined(__OS2__) || defined (LUA_DOS)
      bits[11] = 'd';
#endif
    }
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
    else if (S_ISLNK(mode)) {
      lua_pushstring(L, "LINK");
      bits[0] = 'l';
    }
#elif defined(_WIN32)
    else if (issymlink(fn)) {
      lua_pushstring(L, "LINK");
      bits[0] = 'l';
    }
#endif
    else if (S_ISREG(mode))
      lua_pushstring(L, "FILE");
    else if (S_ISCHR(mode))
      lua_pushstring(L, "CHARSPECFILE");
    else if (S_ISBLK(mode))
      lua_pushstring(L, "BLOCKSPECFILE");
    else
      lua_pushstring(L, "OTHER");
    lua_settable(L, -3);
    lua_pushstring(L, "length");
    lua_pushnumber(L, entry.st_size);
    lua_settable(L, -3);
    seconds = entry.st_mtime;
    lua_pushstring(L, "date");
    lua_createtable(L, 6, 0);  /* 6 = number of entries */
    stm = localtime64(&seconds);  /* 1.12.1 */
    if (stm != NULL) {  /* 0.31.3 patch */
      lua_rawsetinumber(L, -1, 1, stm->tm_year+1900);
      lua_rawsetinumber(L, -1, 2, stm->tm_mon+1);
      lua_rawsetinumber(L, -1, 3, stm->tm_mday);
      lua_rawsetinumber(L, -1, 4, stm->tm_hour);
      lua_rawsetinumber(L, -1, 5, stm->tm_min);
      lua_rawsetinumber(L, -1, 6, stm->tm_sec);
      lua_settable(L, -3);
    }
    /* 0.25.1 file attributes additions */
    /* determine owner rights */
    lua_pushstring(L, "user");
    lua_createtable(L, 0, 3);
    setboolean(L, "read", mode & S_IRUSR);
    setboolean(L, "write", mode & S_IWUSR);
    setboolean(L, "execute", mode & S_IXUSR);
    if (mode & S_IRUSR) bits[1] = 'r';
    if (mode & S_IWUSR) bits[2] = 'w';
    if (mode & S_IXUSR) bits[3] = 'x';
#ifdef __OS2__
    rc = DosQueryPathInfo((PCSZ)fn, FIL_STANDARD, &fstat, sizeof(fstat));
    if (rc == 0) {
      fs = &fstat;  /* do not change this, otherwise Agena will crash */
      unsigned int attribs = fs->attrFile;
      setboolean(L, "hidden", attribs & FILE_HIDDEN);
      setboolean(L, "readonly", attribs & FILE_READONLY);
      setboolean(L, "system", attribs & FILE_SYSTEM);
      setboolean(L, "archived", attribs & FILE_ARCHIVED);
      setboolean(L, "directory", attribs & FILE_DIRECTORY);
      if (attribs & FILE_DIRECTORY) bits[11] = 'd';
      if (attribs & FILE_READONLY) bits[12] = 'r';
      if (attribs & FILE_HIDDEN) bits[13] = 'h';
      if (attribs & FILE_ARCHIVED) bits[14] = 'a';
      if (attribs & FILE_SYSTEM) bits[15] = 's';
    }
#elif defined(_WIN32)
    winmodet = GetFileAttributes(fn);
    setboolean(L, "hidden", winmodet & FILE_ATTRIBUTE_HIDDEN);
    setboolean(L, "readonly", winmodet & FILE_ATTRIBUTE_READONLY);
    setboolean(L, "system", winmodet & FILE_ATTRIBUTE_SYSTEM);
    setboolean(L, "archived", winmodet & FILE_ATTRIBUTE_ARCHIVE);
    if (winmodet & FILE_ATTRIBUTE_READONLY) bits[12] = 'r';
    if (winmodet & FILE_ATTRIBUTE_HIDDEN) bits[13] = 'h';
    if (winmodet & FILE_ATTRIBUTE_ARCHIVE) bits[14] = 'a';
    if (winmodet & FILE_ATTRIBUTE_SYSTEM) bits[15] = 's';
#endif
    lua_settable(L, -3);
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
    /* determine group rights */
    lua_pushstring(L, "group");
    lua_createtable(L, 0, 3);
    setboolean(L, "read", mode & S_IRGRP);
    setboolean(L, "write", mode & S_IWGRP);
    setboolean(L, "execute", mode & S_IXGRP);
    lua_settable(L, -3);
    if (mode & S_IRGRP) bits[4] = 'r';
    if (mode & S_IWGRP) bits[5] = 'w';
    if (mode & S_IXGRP) bits[6] = 'x';
    /* determine other users' rights */
    lua_pushstring(L, "other");
    lua_createtable(L, 0, 3);
    setboolean(L, "read", mode & S_IROTH);
    setboolean(L, "write", mode & S_IWOTH);
    setboolean(L, "execute", mode & S_IXOTH);
    lua_settable(L, -3);
    if (mode & S_IROTH) bits[7] = 'r';
    if (mode & S_IWOTH) bits[8] = 'w';
    if (mode & S_IXOTH) bits[9] = 'x';
#endif
    /* 0.26.0, push file mode (mode_t) and permission `bits` */
    setnumber(L, "perms", mode);
    setstring(L, "bits", bits);
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__)
    setnumber(L, "blocks", entry.st_blocks);
    setnumber(L, "blocksize", entry.st_blksize);
    setnumber(L, "inode", entry.st_ino);
#endif
    setnumber(L, "device", entry.st_dev);
  } else
    lua_pushfail(L);  /* file does not exist */
  return 1;
}


static int os_exists (lua_State *L) {
  lua_pushboolean(L, (access(luaL_checkstring(L, 1), 00|04) != -1));  /* 00 = file exists, 04 = is readable */
  return 1;
}


/* The following routines were taken from the lposix.c file in the
*  POSIX library for Lua 5.0. Based on original by Claudio Terra for Lua 3.x.
*  Luiz Henrique de Figueiredo <lhf@tecgraf.puc-rio.br>
*  05 Nov 2003 22:09:10
*/

/** mkdir(path), modified for Agena; extended in 0.13.3 to support OS/2 */
static int os_mkdir (lua_State *L) {
#ifdef _WIN32
  const char *path = luaL_checkstring(L, 1);
  return os_pushresult(L, mkdir(path), path, "os.mkdir");
#elif defined(__unix__) || defined(__OS2__) || defined(__APPLE__) || defined(__HAIKU__)
  const char *path = luaL_checkstring(L, 1);
  return os_pushresult(L, mkdir(path, 0777), path, "os.mkdir");
#else
  lua_pushfail(L);
  return 1;
#endif
}


/* chdir(path), includes ex-os.curdir code:
   print working directory; July 07, 2008; modified 0.26.0, 04.08.2009 (PATH_MAX),
   extended Agena 1.1, tuned 1.6.0 */
static int os_chdir (lua_State *L) {
  if (agn_isstring(L, 1)) {
    const char *path = agn_tostring(L, 1);  /* Agena 1.6.0 */
    return os_pushresult(L, chdir(path), path, "os.chdir");
  } else if (lua_isnil(L, 1) || lua_gettop(L) == 0) {  /* Agena 1.1.0 */
    char *buffer = (char *)malloc(sizeof(char)*PATH_MAX);
    if (buffer == NULL)  /* Agena 1.0.4 */
      luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "os.chdir");
    if (getcwd(buffer, PATH_MAX) == NULL) { /* 1.6.4 to avoid compiler warnings and unfreed memory */
      xfree(buffer);
      luaL_error(L, "Error in " LUA_QS ": internal error.", "os.chdir");  /* Agena 1.2.0 */
    }
    else {
      charreplace(buffer, '\\', '/', 1);
      lua_pushstring(L, buffer);
    }
    xfree(buffer);
  } else
    luaL_error(L, "Error in " LUA_QS ": expected a string or null.", "os.chdir");
  return 1;
}


/* rmdir(path) */
static int os_rmdir (lua_State *L) {
  const char *path = luaL_checkstring(L, 1);
  return os_pushresult(L, rmdir(path), path, "os.rmdir");
}


/* beep: sound the loudspeaker with a given frequency (first arg, a posint) and
   a duration (second arg, in seconds, a float), April 01, 2007 */

static int os_beep (lua_State *L) {
  int nargs;
#if defined(__unix__) || defined(__APPLE__) || defined(__HAIKU__)
  int i;
#endif
  lua_Number duration;
  nargs = lua_gettop(L);
  duration = 1;
#ifdef _WIN32
  if (nargs == 0) {
    putc('\007', stderr);
    lua_pushnil(L);
  } else {
    int tone;
    tone = agn_checknumber(L, 1);
    duration = agn_checknumber(L, 2);
    if (tone > 0 && duration > 0) {
      Beep(tone, duration*1000);
      lua_pushnil(L);
    } else
      lua_pushfail(L);
  }
#elif defined(__OS2__)
  if (nargs == 0) {
    putc('\007', stderr);
    lua_pushnil(L);
  } else {
    ULONG tone;
    tone = agn_checknumber(L, 1);
    duration = agn_checknumber(L, 2);
    if (tone > 0 && duration > 0) {
      if (DosBeep(tone, (ULONG)(duration*1000)))  /* invalid frequency */
        lua_pushfail(L);
      else
        lua_pushnil(L);
    } else
      lua_pushfail(L);
  }
#elif defined(__unix__) || defined(__APPLE__) || defined(__HAIKU__)
  duration = 1;
  if (nargs == 2) {
    duration = (int)agn_checknumber(L, 2);
  }
  for (i=0; i < duration; i++)
    putc('\007', stderr);
  lua_pushnil(L);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* wait: wait for given seconds; March 31, 2007 */

static int os_wait (lua_State *L) {  /* modified 2.4.0 */
  if (tools_wait(agn_checknumber(L, 1)) == 0)  /* argument < 0 or sleep function not available ? */
    lua_pushfail(L);
  else
    lua_pushnil(L);
  return 1;
}


/* Novell DOS 7 = 'IBMPcDos', '6', '00', 'pc'
   OS/2 Warp 4 Fixpack 15 = 'OS/2', '1', '2.45', 'i386'
   Windows = 'Windows', etc. */

static int os_system (lua_State *L) {
#ifdef _WIN32
  /* GREP "getWindowsVersion (struct WinVer *winver)" * when extending the list of Windows versions

   dwMajorVersion
   Major version number of the operating system. This member can be one of the following values. Value Meaning
   4 Windows NT 4.0, Windows Me, Windows 98, or Windows 95.
   5 Windows Server 2003, Windows XP, or Windows 2000
   6 Windows Vista, Windows Server 2008, Windows 7, 8, 8.1

   dwMinorVersion
   Minor version number of the operating system. This member can be one of the following values. Value Meaning
   0 Windows 2000, Windows NT 4.0, Windows 95, or Windows Vista
   1 Windows XP, Windows 2008 server
   2 Windows Server 2003, Windows 7, Windows Server 2012
   3 Windows Server 2012 RC 2, Windows 8, 8.1
   10 Windows 98
   90 Windows Me

   dwPlatformId
   Operating system platform. This member can be one of the following values. Value Meaning
   VER_PLATFORM_WIN32_NT
   2 Windows Server 2003, Windows XP, Windows 2000, or Windows NT.
   VER_PLATFORM_WIN32_WINDOWS
   1 Windows Me, Windows 98, or Windows 95.
   VER_PLATFORM_WIN32s
   0 Win32s on Windows 3.1. */

  int winver;
  struct WinVer winversion;
  static const char *versions[] = {  /* extended 0.13.4, switched "ME" and "2000" in 1.9.3 */
    "unknown", "32s", "95", "NT 4.0", "98", "ME", "2000", "XP", "Vista", "Server 2008", "Server 2003",
    "7", "8", "Server 2012", "8.1", "Server 2012 R2", "10", "10 Server", "post-10"
    /* if you add future Windows releases, extend getWindowsVersion above, as well */
  };
  winver = getWindowsVersion(&winversion);
  lua_newtable(L);
  lua_rawsetistring(L, -1, 1, "Windows");
  lua_rawsetistring(L, -1, 2, versions[winver]);
  lua_rawsetinumber(L, -1, 3, winversion.BuildNumber);
  lua_rawsetinumber(L, -1, 4, winversion.PlatformId);
  lua_rawsetinumber(L, -1, 5, winversion.MajorVersion);  /* added 0.13.4 */
  lua_rawsetinumber(L, -1, 6, winversion.MinorVersion);  /* added 0.13.4 */
  lua_rawsetinumber(L, -1, 7, winversion.ProductType);   /* added 0.13.4 */
#elif defined(__unix__) || defined(__OS2__) || defined(__APPLE__) || defined(__HAIKU__)
  /* applies to DJGPP compiled DOS code as well; on Apple returns Darwin
  version number */
  struct utsname info;
  if (uname(&info) != -1) {
#ifdef __OS2__
    APIRET result;
    ULONG a[3];
#endif
    lua_newtable(L);
    lua_rawsetistring(L, -1, 1, info.sysname);
    lua_rawsetistring(L, -1, 2, info.release);
    lua_rawsetistring(L, -1, 3, info.version);
    lua_rawsetistring(L, -1, 4, info.machine);
#ifdef __OS2__  /* 2.3.0 RC 2 eCS extension */
    result = DosQuerySysInfo(QSV_VERSION_MAJOR, QSV_VERSION_REVISION, &a[0], sizeof(a));
    if (result == 0) {
      lua_rawsetinumber(L, -1, 5, a[0]);
      lua_rawsetinumber(L, -1, 6, a[1]);
      lua_rawsetinumber(L, -1, 7, a[2]);
    }
#endif
   } else
     lua_pushfail(L);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* 2.4.0. Checks whether Agena is being run on eComStation which would be very fine. */
static int os_iseCS (lua_State *L) {
#ifdef __OS2__
  struct utsname info;
  if (uname(&info) != -1) {
    lua_pushboolean(L, strcmp(info.sysname, "OS/2") == 0);
  } else
    lua_pushfail(L);
#else
  lua_pushfalse(L);
#endif
  return 1;
}


static int os_endian (lua_State *L) {
  int r = tools_endian();
  if (r == -1)
    lua_pushfail(L);
  else
    lua_pushinteger(L, r);
  return 1;
}


static int os_isANSI (lua_State *L) {  /* 0.28.2 */
#ifdef LUA_ANSI
  lua_pushtrue(L);
#else
  lua_pushfalse(L);
#endif
  return 1;
}


/* return status of battery on laptops, works in Windows 2000 and higher. 0.14.0, March 13, 2009 */
static int os_battery (lua_State *L) {
#ifdef _WIN32
  BYTE bACLineStatus, status, bBatteryLifePercent;
  DWORD bBatteryLifeTime, bBatteryFullLifeTime;
  SYSTEM_POWER_STATUS battstat;
  int BatteryCharging, winver;
  struct WinVer windowsver;
  static const char *ACstatus[] = {"off", "on", "unknown"};
  static const char *BatteryStatusMapping[] =
    {"medium", "high", "low", "critical", "charging", "no battery", "unknown"};
  winver = getWindowsVersion(&windowsver);
  if (winver < 2 || winver == 3) {  /* Windows NT 4.0 and earlier are not supported */
    lua_pushfail(L);
    return 1;
  }
  /* get battery information by calling the Win32 API */
  GetSystemPowerStatus(&battstat);
  /* BYTE bReserved1 = battstat.Reserved1; */
  bACLineStatus = battstat.ACLineStatus;
  BatteryCharging = 0; /* not charging */
  if (bACLineStatus == 255)
    bACLineStatus = 2;
  switch (battstat.BatteryFlag) {
    case 0: /* >= 33 and <= 66 % */
      status = 0;
      break;
    case 1: /* high */
      status = 1;
      break;
    case 2: /* low */
      status = 2;
      break;
    case 4: /* critical */
      status = 3;
      break;
    case 8: case 9: case 10:  /* charging */
      status = battstat.BatteryFlag - 8;
      BatteryCharging = 1;
      break;
    case 12:  /* charging & critical */
      status = 3;
      BatteryCharging = 1;
    case 128: /* No system battery */
      status = 5;
      break;
    case 255: /* unknown status */
      status = 6;
      break;
    default:  /* got value 0 at around 45% on Acer, 10 right after reconnecting AC line  */
      status = 6;
      break;
  }
  bBatteryLifePercent = battstat.BatteryLifePercent;
  bBatteryLifeTime = battstat.BatteryLifeTime;
  bBatteryFullLifeTime = battstat.BatteryFullLifeTime;
  lua_createtable(L, 0, 0);
  setstring(L, "acline", ACstatus[bACLineStatus]);
  if (status == 4) {
    setboolean(L, "installed", 0);
  } else {
    setboolean(L, "installed", 1);
    setnumber(L, "life", bBatteryLifePercent);
    setstring(L, "status", BatteryStatusMapping[status]);
    setboolean(L, "charging", (BatteryCharging == 1));  /* 0.31.4 fix */
    setnumber(L, "flag", battstat.BatteryFlag);
    lua_pushstring(L, "lifetime");
    if (bBatteryLifeTime != -1)
      lua_pushnumber(L, bBatteryLifeTime);
    else
      lua_pushundefined(L);
    lua_settable(L, -3);
    lua_pushstring(L, "fulllifetime");
    if (bBatteryFullLifeTime != -1)
      lua_pushnumber(L, bBatteryFullLifeTime);
    else
      lua_pushundefined(L);
    lua_settable(L, -3);
  }
#elif __OS2__
#define IOCTL_POWER 0x000c
#define POWER_GETPOWERSTATUS 0x0060
  int result;
  HFILE pAPI;
  ULONG call;
  struct _Battery {
    USHORT usParamLen;
    USHORT usPowerFlags;
    UCHAR  ucACStatus;
    UCHAR  ucBatteryStatus;
    UCHAR  ucBatteryLife;
  } Battery;
  struct _Data {
    USHORT usReturn;
  } Data;
  ULONG sizeBattery, sizeData;
  result = DosOpen((PCSZ)"\\DEV\\APM$", &pAPI, &call, 0,
    FILE_NORMAL, FILE_OPEN, OPEN_ACCESS_READONLY | OPEN_SHARE_DENYNONE,
    NULL);
  if (result != 0) {
    lua_pushfail(L);
    return 1;
  }
  sizeBattery = Battery.usParamLen = sizeof(Battery);
  sizeData = sizeof(Data);
  result = DosDevIOCtl(pAPI,
    IOCTL_POWER, POWER_GETPOWERSTATUS, (PVOID)&Battery, sizeof(Battery),
    &sizeBattery, (PVOID)&Data, sizeof(Data), &sizeData);
  DosClose(pAPI);  /* 2.3.4 fix */
  if (result == ERROR_INVALID_PARAMETER) {
    lua_pushfail(L);
  } else {
    int acstatus, batterystatus;
    const char *ACstatus[] = {"off", "on", "unknown", "invalid"};
    const char *BatteryStatusMapping[] =
      {"high", "low", "critical", "charging", "unknown", "invalid"};
    lua_newtable(L);
    switch (Battery.ucACStatus) {
      case   0: acstatus = 0; break;
      case   1: acstatus = 1; break;
      case 255: acstatus = 2; break;
      default:  acstatus = 3; break;
    }
    switch (Battery.ucBatteryStatus) {
      case 0:   batterystatus = 0; break;
      case 1:   batterystatus = 1; break;
      case 2:   batterystatus = 2; break;
      case 3:   batterystatus = 3; break;
      case 255: batterystatus = 4; break;
      default:  batterystatus = 5; break;
    }
    setstring(L, "acline", ACstatus[acstatus]);
    setstring(L, "status", BatteryStatusMapping[batterystatus]);
    setnumber(L, "flags", (lua_Number)Battery.usPowerFlags);
    setboolean(L, "powermanagement", ((Battery.usPowerFlags & 0x0001) == 1));
    lua_pushstring(L, "life");
    if (Battery.ucACStatus != 1)  /* AC line is off */
      lua_pushnumber(L, (lua_Number)Battery.ucBatteryLife);
    else
      lua_pushundefined(L);
    lua_rawset(L, -3);
  }
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* 0.25.0, July 19, 2009; extended 26.07.2009, 0.25.1; patched 0.26.0, August 06, 2009 */
static int os_fcopy (lua_State *L) {
  const char *fin, *fout;
  char *buffer;
  int in, out, bufsize, result, nr;
  size_t bytes;
  struct stat entry;
  result = 0;
  fin = agn_checkstring(L, 1);
  fout = agn_checkstring(L, 2);
  if (strcmp(fin, fout) == 0) {  /* 1.8.0, prevent destroying the file to be copied if source = target */
    lua_pushfail(L);
    lua_pushstring(L, fin);
    return 2;
  }
  if ( (in = my_roopen(fin)) == -1) {
    lua_pushfail(L);
    lua_pushstring(L, fin);  /* 1.7.6 */
    return 2;
  }
  if ( (out = my_create(fout)) == -1) {
    close(in);
    lua_pushfail(L);
    lua_pushstring(L, fin);  /* 1.7.6 */
    return 2;
  }
  bufsize = agn_getbuffersize(L);  /* 2.2.0 */
  buffer = malloc(bufsize * sizeof(char));  /* 2.2.0 RC 5 */
  while ( (bytes = read(in, buffer, bufsize)) ) {
    if (bytes == -1) {  /* 1.6.4 */
      xfree(buffer);
      luaL_error(L, "Error in " LUA_QS ": could not read from file #%d.", "os.fcopy", in);
    }
    if (write(out, buffer, bytes) == -1) {  /* 1.6.4 to prevent compiler warnings */
      xfree(buffer);
      luaL_error(L, "Error in " LUA_QS ": could not write to file #%d.", "os.fcopy", out);
    }
  }
  close(in);
  close(out);
  nr = 1;
  if (bytes < 0) {
    lua_pushfail(L); lua_pushstring(L, fin); nr = 2;  /* 1.7.6 */
  } else {
    if (stat(fin, &entry) == 0) {
      /* set file permission attributes */
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
      mode_t mode = entry.st_mode;
      result = chmod(fout, (mode & S_IRUSR)|(mode & S_IWUSR)|(mode & S_IXUSR)|(mode & S_IRGRP)|(mode & S_IWGRP)|(mode & S_IXGRP)|(mode & S_IROTH)|(mode & S_IWOTH)|(mode & S_IXOTH));
#elif defined(_WIN32)
      /* added 0.26.0, 07.08.2009 */
      result = !(SetFileAttributes(fout, GetFileAttributes(fin)));
#elif defined(__OS2__)
      static FILESTATUS3 fstat, *fs;
      APIRET rc = DosQueryPathInfo((PCSZ)fin, FIL_STANDARD, &fstat, sizeof(fstat));
      if (rc == 0) {
        fs = &fstat;  /* do not change this, otherwise Agena will crash */
        DosSetPathInfo((PCSZ)fout, FIL_STANDARD, fs, sizeof(FILESTATUS3), 0);
      }
#else
      mode_t mode = entry.st_mode;
      result = chmod(fout, (mode & S_IRUSR)|(mode & S_IWUSR)|(mode & S_IXUSR));
#endif
#if (defined(_WIN32) || defined(__unix__) || defined(__APPLE__) || defined(LUA_DOS))
      /* file date and time, Agena 1.8.0 */
      struct utimbuf times;
      times.modtime = times.actime = entry.st_mtime;
      result = result || utime(fout, &times);
#endif
      if (result == 0)
        lua_pushtrue(L);
      else {
        lua_pushfail(L); lua_pushstring(L, fin); nr = 2;  /* 1.7.6 */
      }
    }
    else {
      lua_pushfail(L); lua_pushstring(L, fin); nr = 2;  /* 1.7.6 */
    }
  }
  xfree(buffer);
  return nr;
}


static int os_drives (lua_State *L) {
#if defined(_WIN32) || defined(__OS2__)
  unsigned int i, c;
  int anydrivefound;
  char drive[1];
  #ifdef _WIN32
  long buff, mask;
  buff = GetLogicalDrives();
  #else
  ULONG buff, mask, curDrive;
  APIRET rc;
  rc = DosQueryCurrentDisk(&curDrive, &buff);
  if (rc != 0)
    luaL_error(L, "Error in " LUA_QS ": could not determine drives.", "os.drives");
  #endif
  anydrivefound = c = i = 0;
  agn_createseq(L, 26);
  while( i < 26 ) {
    mask = (1 << i);
    if( (buff & mask) > 0 ) {
      drive[0] = 65 + i;
      lua_pushlstring(L, drive, 1);
      lua_seqseti(L, -2, ++c);
      /* prevent error messages if no media are inserted in floppy drives or CD-ROMs */
      anydrivefound = 1;
    }
    i++;
  }
  if (!anydrivefound) {
    agn_poptop(L);  /* delete sequence */
    lua_pushfail(L);
  }
#else
  lua_pushfail(L);
#endif
  return 1;
}


static int os_drivestat (lua_State *L) {
#ifdef _WIN32
  unsigned int drivetype;
  size_t l;
  long buff, mask;
  char drive[4];
  DWORD serial_number;
  DWORD max_component_length;
  DWORD file_system_flags;
  char name [256];
  char file_system_name[256];
  unsigned long sectors_per_cluster, bytes_per_sector, number_of_free_clusters, total_number_of_clusters;
  double freespace, totalspace;
  static const char *types[] = {
    "unknown", "no root dir", "Removable", "Fixed", "Remote", "CD-ROM", "RAMDISK"};
  const char *drivename = agn_checklstring(L, 1, &l);
  if (l < 1) {  /* empty string ? */
    lua_pushfail(L);
    return 1;
  }
  drive[0] = toupper(*drivename); drive[1] = ':'; drive[2] = '\\'; drive[3] = '\0';
  buff = GetLogicalDrives();
  mask = (1 << (drive[0]-65));
  if( (buff & mask) < 1 ) {  /* no valid drive ? */
    lua_pushfail(L);
    return 1;
  }
  /* set defaults to prevent invalid values when calling GetDiskFreeSpace */
  sectors_per_cluster = 0, bytes_per_sector = 0, number_of_free_clusters = 0, total_number_of_clusters = 0;
  /* set defaults to prevent invalid values when calling GetVolumeInformation  */
  strcpy(name, ""); strcpy(file_system_name, "");
  serial_number = 0; max_component_length = 0; file_system_flags = 0;
  drivetype = GetDriveType(drive);
  lua_createtable(L, 0, 5);
  GetVolumeInformation(drive, name,
    (sizeof (name)), &serial_number, &max_component_length, &file_system_flags,
    file_system_name, (sizeof (file_system_name)));
  if (name == NULL || strcmp(name, "") == 0)
    strcpy(name, "<none>");
  if (strlen(name) > 19) name[19] = '\0';
  if (file_system_name == NULL || strcmp(file_system_name, "") == 0)
    strcpy(file_system_name, "<unknown>");
  if (strlen(file_system_name) > 11) file_system_name[11] = '\0';
  /* prevent error messages if no media are inserted in floppy drives or CD-ROMs */
  SetErrorMode(0x0001);
  /* get info on free space on drive processed */
  GetDiskFreeSpace(drive, &sectors_per_cluster, &bytes_per_sector,
    &number_of_free_clusters, &total_number_of_clusters);
  SetErrorMode(0); /* set error mode back to normal (any exceptions printed again) */
  freespace = (double)number_of_free_clusters * (double)sectors_per_cluster * (double)bytes_per_sector;
  totalspace = (double)total_number_of_clusters * (double)sectors_per_cluster * (double)bytes_per_sector;
  setstring(L, "label", name);
  setstring(L, "drivetype", (drivetype < 7) ? types[drivetype] : "unknown");
  setstring(L, "filesystem",
    (strcmp(file_system_name, "") == 0) ? "<unknown>" : file_system_name);
  setnumber(L, "freesize", freespace);
  setnumber(L, "totalsize", totalspace);
#elif 0 && defined(__unix__) && !defined(LUA_DOS)
  /* This section has been taken from Nodir Temirkhodjaev's LuaSys package */
  const char *path = luaL_checkstring(L, 1);
  int64_t ntotal, navail, nfree;
  int res;
  struct statvfs buf;
  res = statvfs(path, &buf);
  ntotal = buf.f_blocks * buf.f_frsize;
  nfree = buf.f_bfree * buf.f_bsize;
  navail = buf.f_bavail * buf.f_bsize;
  if (!res) {
    lua_createtable(L, 0, 2);
    setnumber(L, "totalsize", (lua_Number)ntotal);
    setnumber(L, "freesize", (lua_Number)nfree);
  } else
    lua_pushfail(L);
#else
  lua_pushfail(L);
#endif
  return 1;
}


static mode_t newmode (mode_t oldmode, mode_t modeflag, int add) {
  mode_t modet = oldmode;
  if (add)
    modet |= modeflag;
  else if (modet & modeflag)
    modet -= modeflag;
  return modet;
}

#ifdef _WIN32
static DWORD winmode (DWORD oldmode, DWORD modeflag, int add) {
  DWORD winmodet = oldmode;
  if (add)
    winmodet |= modeflag;
  else if (winmodet & modeflag)
    winmodet -= modeflag;
  return winmodet;
}
#elif defined(__OS2__)
static unsigned int os2mode (unsigned int oldmode, unsigned int modeflag, int add) {
  unsigned int os2modet = oldmode;
  if (add)
    os2modet |= modeflag;
  else if (os2modet & modeflag)
    os2modet -= modeflag;
  return os2modet;
}
#endif


static Time64_T maketime (int year, int month, int day, int hour, int minute, int second) {  /* Agena 1.8.0 */
  struct TM time_str;
  if (tools_checkdatetime(year, month, day, hour, minute, second) == 0) return -2;  /* 1.9.1 */
  time_str.tm_year = year - 1900;
  time_str.tm_mon = month - 1;
  time_str.tm_mday = day;
  time_str.tm_hour = hour;
  time_str.tm_min = minute;
  time_str.tm_sec = second;
  time_str.tm_isdst = -1;
  return mktime64(&time_str);
}

static int os_fattrib (lua_State *L) {  /* 0.26.0 */
  const char *fn, *mode;
  mode_t modet;
  struct stat entry;
  int result, owner, add;
  size_t l, i;
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
  size_t j;
#elif defined(_WIN32)
  DWORD winmodet;
#elif defined(__OS2__)
  static FILESTATUS3 fstat, *fs;
  unsigned int os2modet;
  APIRET rc;
#endif
  fn = agn_checkstring(L, 1);
  if (lua_istable(L, 2)) {  /* change file access and modification date */
#if (defined(_WIN32) || defined(__unix__) || defined(__APPLE__) || defined(LUA_DOS))
    Time64_T t;
    struct utimbuf times;
    int year, month, day, hour, minute, second, nops;
    year = agn_getinumber(L, 2, 1);
    month = agn_getinumber(L, 2, 2);
    day = agn_getinumber(L, 2, 3);
    nops = agn_size(L, 2);
    hour = (nops > 3) ? agn_getinumber(L, 2, 4) : 0;
    minute = (nops > 4) ? agn_getinumber(L, 2, 5) : 0;
    second = (nops > 5) ? agn_getinumber(L, 2, 6) : 0;
    if (tools_checkdatetime(year, month, day, hour, minute, second) == 0)  /* 1.9.1 */
      luaL_error(L, "Error in " LUA_QS ": time component out of range.", "os.fattrib");
    if (year > 2037)  /* XXX */
      luaL_error(L, "Error in " LUA_QS ": year beyond 2037.", "os.fattrib");
    t = maketime(year, month, day, hour, minute, second);
    if (t != 0)
      luaL_error(L, "Error in " LUA_QS ": could not determine time.", "os.fattrib");
    times.modtime = times.actime = t;
    if (utime(fn, &times) == -1)
      lua_pushfail(L);
    else
      lua_pushtrue(L);
#else
    lua_pushfail(L);
#endif
    return 1;
  }
  modet = owner = add = 0;
#if defined(_WIN32)
  winmodet = GetFileAttributes(fn);
#elif defined(__OS2__)
  rc = DosQueryPathInfo((PCSZ)fn, FIL_STANDARD, &fstat, sizeof(fstat));
  if (rc != 0)
    luaL_error(L, "Error in " LUA_QS ": could not determine file attributes.", "os.fattrib");
  fs = &fstat;
  os2modet = fs->attrFile;
#endif
  if (stat(fn, &entry) == 0)
    modet = entry.st_mode;
  else
    luaL_error(L, "Error in " LUA_QS ": file does not exist.", "os.fattrib");
  mode = agn_checklstring(L, 2, &l);
  if (l < 3)
    luaL_error(L, "Error in " LUA_QS ": malformed settings string.", "os.fattrib");
#if !defined(__unix__) && !defined(__APPLE__) && !defined(__HAIKU__)
  mode_t modew[1] = {S_IWUSR};
  mode_t modex[1] = {S_IXUSR};
#else
#ifndef LUA_DOS
  mode_t moder[3] = {S_IRUSR, S_IRGRP, S_IROTH};
#else
  mode_t moder[1] = {S_IRUSR};
#endif
  mode_t modew[3] = {S_IWUSR, S_IWGRP, S_IWOTH};
  mode_t modex[3] = {S_IXUSR, S_IXGRP, S_IXOTH};
#endif
  switch (*mode++) {
    case 'u': case 'U': {
      owner = 0;  /* owner */
      break;
    }
    case 'g': case 'G': {
      owner = 1;  /* group */
      break;
    }
    case 'o': case 'O': {
      owner = 2;  /* other */
      break;
    }
    case 'a': case 'A': {
      owner = 3;  /* all */
      break;
    }
    default:
      luaL_error(L,
        "Error in " LUA_QS ": wrong user specification, must be `u` , `g`, `o`, or `a`.",
        "os.fattrib");
  }
#if ((!defined(__unix__) && !defined(__APPLE__) &&  !defined(__HAIKU__)) || defined(LUA_DOS))
  if (owner > 0) owner = 0;
#endif
  switch (*mode++) {
    case '+': {
      add = 1;  /* owner */
      break;
    }
    case '-': {
      add = 0;  /* group */
      break;
    }
    default:
      luaL_error(L,
        "Error in " LUA_QS ": wrong add/delete specification, must be `+` , or `-`.",
        "os.fattrib");
  }
  for (i=2; i < l; i++, mode++) {
    switch(*mode) {
#if defined(__unix__) || defined(__APPLE__) || defined(__HAIKU__)
      case 'r': case 'R': {
        if (owner < 3)
          modet = newmode(modet, moder[owner], add);
#ifndef LUA_DOS
        else
          for (j=0; j < 3; j++) {modet = newmode(modet, moder[j], add);}
#endif
        break;
      }
#endif
      case 'w': case 'W': {
        if (owner < 3)
          modet = newmode(modet, modew[owner], add);
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
        else
          for (j=0; j < 3; j++) {modet = newmode(modet, modew[j], add);}
#endif
        break;
      }
      case 'x': case 'X': {
        if (owner < 3)
          modet = newmode(modet, modex[owner], add);
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(__HAIKU__)
        else
          for (j=0; j < 3; j++) {modet = newmode(modet, modex[j], add);}
#endif
        break;
      }
#ifdef _WIN32
      case 'h': case 'H': {
        winmodet = winmode(winmodet, FILE_ATTRIBUTE_HIDDEN, add);
        break;
      }
      case 'a': case 'A': {
        winmodet = winmode(winmodet, FILE_ATTRIBUTE_ARCHIVE, add);
        break;
      }
      case 's': case 'S': {
        winmodet = winmode(winmodet, FILE_ATTRIBUTE_SYSTEM, add);
        break;
      }
      case 'r': case 'R': {
        winmodet = winmode(winmodet, FILE_ATTRIBUTE_READONLY, add);
        break;
      }
#elif defined(__OS2__)
      case 'h': case 'H': {
        os2modet = os2mode(os2modet, FILE_HIDDEN, add);
        break;
      }
      case 'a': case 'A': {
        os2modet = os2mode(os2modet, FILE_ARCHIVED, add);
        break;
      }
      case 's': case 'S': {
        os2modet = os2mode(os2modet, FILE_SYSTEM, add);
        break;
      }
      case 'r': case 'R': {
        os2modet = os2mode(os2modet, FILE_READONLY, add);
        break;
      }
#endif
      default: lua_assert(0);
    }
  }
  result = chmod(fn, modet);
#ifdef _WIN32
  result = result || !(SetFileAttributes(fn, winmodet));
#elif defined(__OS2__)
  fs->attrFile = os2modet;
  rc = DosSetPathInfo((PCSZ)fn, FIL_STANDARD, fs, sizeof(FILESTATUS3), 0);
  result = result || rc;
#endif
  if (result == 0)
     lua_pushtrue(L);
  else
     lua_pushfail(L);
  return 1;
}


/* for Windows colour depth see:
   http://stackoverflow.com/questions/1276687/how-can-i-find-out-the-current-color-depth-of-a-machine-running-vista-w7
   and http://stackoverflow.com/questions/7068620/mingw-libssl-linking-errors for proper linking of gdi32 in MinGW. */

#ifdef _WIN32
/* from MSDN: `
  int GetDeviceCaps(
    _In_  HDC hdc,
    _In_  int nIndex );` */
static int gdc (int nIndex) {  /* 2.4.0 */
  HDC dc = GetDC(NULL);
  int r = GetDeviceCaps(dc, nIndex);
  ReleaseDC(NULL, dc);
  return r;
}

#define gsm GetSystemMetrics
#endif

static int os_screensize (lua_State *L) {  /* 0.31.3 */
#ifdef _WIN32
  lua_pushnumber(L, gsm(SM_CXSCREEN));
  lua_pushnumber(L, gsm(SM_CYSCREEN));
  agn_createpair(L, -2, -1);
  lua_remove(L, -2);
  lua_remove(L, -2);
#elif defined(__OS2__)   /* 2.4.0 */
  VIOMODEINFO data;
  data.cb = sizeof(data);
  VioGetMode(&data, 0);
  lua_pushnumber(L, data.hres);
  lua_pushnumber(L, data.vres);
  agn_createpair(L, -2, -1);
  lua_remove(L, -2);
  lua_remove(L, -2);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* In eComStation and Windows, the function returns a table with the following information on the display:

resolution = a pair with the horizontal and vertical number of pixels,
depth = the colour depth in bits
monitors = the number of monitors attached to the system (Windows only)
vrefresh = the vertical refresh rate in Hertz (Windows only). */
static int os_vga (lua_State *L) {  /* 2.4.0 */
#ifdef _WIN32
  lua_createtable(L, 0, 4);
  lua_rawsetstringpairnumbers(L, -1, "resolution", gsm(SM_CXSCREEN), gsm(SM_CYSCREEN));
  lua_rawsetstringnumber(L, -1, "depth", gdc(BITSPIXEL));
  lua_rawsetstringnumber(L, -1, "vrefresh", gdc(VREFRESH));
    /* 2.4.0, from MSDN: `vertical refresh rate of the device, in cycles per second (in Hertz).
    A vertical refresh rate value of 0 or 1 represents the display hardware's default refresh rate. This default rate
    is typically set by switches on a display card or computer motherboard, or by a configuration programme that does not
    use display functions such as ChangeDisplaySettings. */
  lua_rawsetstringnumber(L, -1, "monitors", gsm(SM_CMONITORS));
#elif __OS2__
  lua_createtable(L, 0, 2);
  VIOMODEINFO data;
  data.cb = sizeof(data);
  VioGetMode(&data, 0);
  lua_rawsetstringpairnumbers(L, -1, "resolution", data.hres, data.vres);
  lua_rawsetstringnumber(L, -1, "depth", data.color);
#else
  lua_pushfail(L);
#endif
  return 1;
}


static int os_mousebuttons (lua_State *L) {  /* 0.31.3 */
#ifdef _WIN32
  lua_pushnumber(L, gsm(SM_CMOUSEBUTTONS));  /* number of mouse buttons */
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* In Windows, the function returns various information on the attached mouse by returning a table with the following
   entries:

   'mousebuttons' = number of mouse buttons; if more than one mouse is attached, the sum of all mouse
                    buttons is computed.
   'hmousewheel'  = `true` if the mouse features a horizontal mouse wheel, and `false` if not.
   'mousewheel'   = `true` if the mouse features a vertical mouse wheel, and `false` if not.
   'swapbuttons'  = `true` if the left and right mouse buttons have been swapped.
   'speed'        = an integer between 1 (slowest) and 20 (fastest).
   'threshold'    = the two mouse threshold values, x and y co-ordinates, as a pair of two numbers. */
static int os_mouse (lua_State *L) {  /* 2.4.0 */
#ifdef _WIN32
#ifndef SM_MOUSEHORIZONTALWHEELPRESENT
#define SM_MOUSEHORIZONTALWHEELPRESENT 91
#endif
  int mouseinfo[3];
  int mousespeed;
  lua_createtable(L, 0, 6);
  lua_rawsetstringnumber(L, -1, "mousebuttons", gsm(SM_CMOUSEBUTTONS));  /* number of mouse buttons */
  lua_rawsetstringboolean(L, -1, "hmousewheel", gsm(SM_MOUSEHORIZONTALWHEELPRESENT));
  /* 2.4.0; MSDN: `Nonzero if a mouse with a horizontal scroll wheel is installed; otherwise 0.` */
  lua_rawsetstringboolean(L, -1, "mousewheel", gsm(SM_MOUSEWHEELPRESENT));
  /* 2.4.0; MSDN: `Nonzero if a mouse with a vertical scroll wheel is installed; otherwise 0.` */
  lua_rawsetstringboolean(L, -1, "swapbutton", gsm(SM_SWAPBUTTON));
  /* 2.4.0; MSDN: `Nonzero if the meanings of the left and right mouse buttons are swapped; otherwise, 0.` */
  /* see http://msdn.microsoft.com/en-us/library/windows/desktop/ms724385%28v=vs.85%29.aspx */
  if (SystemParametersInfo(SPI_GETMOUSESPEED, 0, &mousespeed, 0))
    lua_rawsetstringnumber(L, -1, "speed", mousespeed);  /* from MSDN: `Retrieves the current mouse speed.
      The mouse speed determines how far the pointer will move based on the distance the mouse moves. The
      pvParam parameter must point to an integer that receives a value which ranges between 1 (slowest) and
      20 (fastest). A value of 10 is the default.
      On Windows 7, the alternative SystemParametersInfo(SPI_GETMOUSESPEED, 0, &mousespeed, 0) call definitely
      retrieves a wrong result to mousespeed[2]. */
  if (SystemParametersInfo(SPI_GETMOUSE, 0, &mouseinfo, 0))
    /* lua_rawsetstringnumber(L, -1, "Xspeed", mouseinfo[2]);  // returns wrong result [sic !] */
    lua_rawsetstringpairnumbers(L, -1, "threshold", mouseinfo[0], mouseinfo[1]);  /* the two mouse threshold
      values, x and y co-ordinates */
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* The function returns `true` if the system is connected to any network, and `false` otherwise. The function
   is available in Windows, only. The result is usually `true`. */
static int os_hasnetwork (lua_State *L) {  /* 2.4.0 */
#ifdef _WIN32
  lua_pushboolean(L, tools_getbit(gsm(SM_NETWORK), 1));  /* bit #1 contains the necessary information */
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* The function returns `true` if the computer is in docking mode, and `false` otherwise. The function is available in
   Windows, only. */
static int os_isdocked (lua_State *L) {  /* 2.4.0 */
#ifdef _WIN32
  lua_pushboolean(L, gsm(0x2004) != 0);  /* 0x2004 = SM_SYSTEMDOCKED */
  /* from MSDN: `Reflects the state of the docking mode, 0 for Undocked Mode and non-zero otherwise.` */
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* The function switches the monitor on and off (Windows and Linux), and can also put it on stand-by if the monitor
   supports this feature (Windows only).

   Pass the string 'off' as the only argument to switch off the monitor; pass 'on' to switch it on, and 'standby'
   to put it into stand-by mode. If no argument is given, the Monitor is switched on (which has no effect, if the
   screen is already active).

   On success, the function returns `true`, and `false` and a string containing the error analysis otherwise. */

#ifdef _WIN32
#ifndef SC_MONITORPOWER
#define SC_MONITORPOWER 0xF170
#endif

#ifndef HWND_BROADCAST
#define HWND_BROADCAST 0xFFFF  /* or just call GetConsoleWindow() */
#endif

#ifndef WM_SYSCOMMAND
#define WM_SYSCOMMAND 0x0112
#endif
#endif

static int os_monitor (lua_State *L) {  /* 2.4.0 */
#ifdef _WIN32
  int en, cmd, r;
  const char *command;
  cmd = 0; /* to prevent compiler warnings */
  command = luaL_optstring(L, 1, "on");
  if (strcmp(command, "on") == 0)  /* FIXME: this does not work */
    cmd = -1;
  else if (strcmp(command, "standby") == 0)  /* standby seems to be supported by few monitors, only */
    cmd = 1;
  else if (strcmp(command, "off") == 0)
    cmd = 2;
  else
    luaL_error(L, "Error in " LUA_QS ": unknown argument " LUA_QS ".", "os.monitor", command);
  r = SendMessage(GetConsoleWindow(), WM_SYSCOMMAND, SC_MONITORPOWER, cmd);
  en = GetLastError();
  if (r != 0) {
    lua_pushfalse(L);
    lua_pushstring(L, strerror(en));
    return 2;
  } else
    lua_pushtrue(L);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* The function halts, reboots, sleeps, or logoffs Windows or Mac OS X. In Windows it can also lock the current user
   session or hibernate the system.

   The function makes sure that no data loss occurs: if there is any unsaved data, the function does not start termination
   and just quits.

   To put the system into energy-saving sleep mode, pass the string 'sleep' as the only argument. To
   hibernate (save the whole system state and then shut off the PC), pass 'hibernate' (Windows only); to shut down
   the computer completely, pass 'halt'; to reboot the system, pass 'reboot'; to lock the current user session
   without logging the user off, pass 'lock'; to log-off the open session of the current user, pass
   'logoff'.

   By default, the function waits for 60 seconds before initiating the termination process. You can change this timeout
   period to another number of seconds by setting the optional second argument to any non-negative integer.

   On all other platforms, the function returns fail and does nothing. */
#if defined(XXX) && defined(__APPLE__)  /* 2.8.4: linking to Carbon framework causes memory leaks in Agena */
/* taken from Mac Developer Library, article:
   `Technical Q&A QA1134  Programmatically causing restart, shutdown and_or logout.htm`*/
OSStatus SendAppleEventToSystemProcess (AEEventID EventToSend) {
  AEAddressDesc targetDesc;
  static const ProcessSerialNumber kPSNOfSystemProcess = { 0, kSystemProcess };
  AppleEvent eventReply = {typeNull, NULL};
  AppleEvent appleEventToSend = {typeNull, NULL};
  OSStatus error = noErr;
  error = AECreateDesc(typeProcessSerialNumber, &kPSNOfSystemProcess, sizeof(kPSNOfSystemProcess),
                       &targetDesc);
  if (error != noErr) return(error);
  error = AECreateAppleEvent(kCoreEventClass, EventToSend, &targetDesc, kAutoGenerateReturnID,
                             kAnyTransactionID, &appleEventToSend);
  AEDisposeDesc(&targetDesc);
  if (error != noErr) return(error);
  error = AESend(&appleEventToSend, &eventReply, kAENoReply, kAENormalPriority, kAEDefaultTimeout, NULL, NULL);
  AEDisposeDesc(&appleEventToSend);
  if (error != noErr) return(error);
  AEDisposeDesc(&eventReply);
  return(error);
}
#endif

/* for the OS/2 specific part, see:
   http://www.programd.com/3_109a201674fc28b9_1.htm and
   Mark Kimes' implementation available at https://github.com/vonj/snippets/blob/master/os2_boot.c */

#ifdef __OS2__  /* settings for reboot option */
#define CATEGORY_DOSSYS  0xD5
#define FUNCTION_REBOOT  0xAB

static APIRET eCSshutdownall (lua_State *L) {
  APIRET rc;
  /* clear the caches */
  rc = DosShutdown(1);
  if (rc != 0)
    luaL_error(L, "Error in " LUA_QS ": could not flush caches, quitting.", "os.terminate");
  /* shut down the file system */
  rc = DosShutdown(1);
  if (rc != 0)
    luaL_error(L, "Error in " LUA_QS ": could not shut down file system, quitting.", "os.terminate");
  /* halt the system */
  return DosShutdown(0);
}
#endif

static int os_terminate (lua_State *L) {  /* 2.4.0 */
#if !(defined(_WIN32) || defined(__APPLE__) || defined(__OS2__))
  lua_pushfail(L);
#else
  int cmd, ver, r, action, wait;  /* timeout */
  const char *command;  /* *message; */
#if defined(_WIN32)
  struct WinVer winversion;
  TOKEN_PRIVILEGES tkp;  /* pointer to token structure */
  HANDLE hToken;         /* handle to process token */
  /* timeout = agnL_optinteger(L, 2, 360);  // default time-out in seconds */
  /* message = NULL; */
  ver = getWindowsVersion(&winversion);  /* returns 6 or less in Windows 2000 or earlier, since sleeps or
    hibernates are not supported here */
#elif defined(__APPLE__)
  r = ver = action = 0;
#elif defined(__OS2__)
  HFILE h;
  ULONG ulAction;
  ver = 0;
#endif
  command = luaL_optstring(L, 1, "sleep");
  wait = luaL_optinteger(L, 2, 60);
  if (wait < 0)
    luaL_error(L, "Error in " LUA_QS ": timeout must be non-negative.", "os.terminate");
  action = r = cmd = 0;
  if (strcmp(command, "sleep") == 0 && (ver == 0 || ver > 6))  /* sleep = suspend */
    cmd = 1;
  else if (strcmp(command, "hibernate") == 0 && (ver == 0 || ver > 6))
    cmd = 2;
  else if (strcmp(command, "halt") == 0) {
    cmd = 3;
    #ifdef _WIN32
    action = EWX_POWEROFF;
    #endif
    /* message = "shutting down system"; */
  }
  else if (strcmp(command, "reboot") == 0) {
    cmd = 4;
    #ifdef _WIN32
    action = EWX_REBOOT;
    #endif
    /* message = "rebooting system"; */
  }
  else if (strcmp(command, "logoff") == 0) {
    cmd = 5;
    #ifdef _WIN32
    action = EWX_LOGOFF;
    #endif
  }
  else if (strcmp(command, "lock") == 0) {
    cmd = 6;
  }
  else
    luaL_error(L, "Error in " LUA_QS ": unknown or unsupported option " LUA_QS ".",
                  "os.terminate", command);
#ifdef _WIN32
  Sleep(wait * 1000);
#elif defined(__APPLE__) || defined(__OS2__)
  sleep(wait);
#endif
#ifdef _WIN32
  /* get shutdown previleges, taken from:
     http://msdn.microsoft.com/en-us/library/windows/desktop/aa376861%28v=vs.85%29.aspx */
  if (!OpenProcessToken(GetCurrentProcess(), TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
    luaL_error(L, "Error in " LUA_QS ": could not retrieve current process token handle.", "os.terminate");
  LookupPrivilegeValue(NULL, SE_SHUTDOWN_NAME, &tkp.Privileges[0].Luid);
  tkp.PrivilegeCount = 1;  /* one privilege to set */
  tkp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
  /* get shutdown privilege for this process */
  AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);
  /* since the return value of AdjustTokenPrivileges cannot be properly tested: */
  if (GetLastError() != ERROR_SUCCESS)
    luaL_error(L, "Error in " LUA_QS ": could not change the necessary termination privilege.", "os.terminate");
  switch (cmd) {
    case 1: case 2: {  /* suspend or hibernate ? */
      r = SetSuspendState(
        cmd == 2,  /* TRUE ? -> hibernate, do not suspend/sleep */
        TRUE,      /* do not suspend immediately, instead ask for permission, only regarded in XP or earlier */
        FALSE      /* FALSE: any system wake events remain enabled */
      );
      break;
    }
    case 3: case 4: case 5: {  /* halt, reboot, or logoff ? */
      /* int r = InitiateSystemShutdown(  // !!! UNSAFE !!!
          NULL,             // shut down local computer
          (LPTSTR)message,  // message for the user
          timeout,          // time-out period, in seconds
          FALSE,            // bForceAppsClosed parameter: FALSE = ask the user to close all programmes;
                            // does not seem to work in Windows 7.
          cmd == 4          // reboot after shutdown
        );
        if (!r) luaL_error(L, "Error in " LUA_QS ": termination failed.", "os.terminate"); */
      r = ExitWindowsEx(action, 0);
      break;
    }
    case 6: {  /* lock the user ? */
      r = LockWorkStation();
      break;
    }
    default:  /* should not happen */
      luaL_error(L, "Error in " LUA_QS ": this should not happen.", "os.terminate");
  }
  /* Maybe Agena never reaches this part, for the termination commands immediately close the Agena console window. */
  /* now disable shutdown privilege */
  tkp.Privileges[0].Attributes = 0;
  AdjustTokenPrivileges(hToken, FALSE, &tkp, 0, (PTOKEN_PRIVILEGES)NULL, 0);
  if (GetLastError() != ERROR_SUCCESS)
    luaL_error(L, "Error in " LUA_QS ": could not disable termination privilege.", "os.terminate");
#elif defined(XXX) && defined(__APPLE__)  /* 2.8.4: linking to Carbon framework causes memory leaks in Agena */
  switch (cmd) {
    case 1: {  /* sleep ? */
      r = (SendAppleEventToSystemProcess(kAESleep) == noErr);  /* 0 if error occurred */
      break;
    };
    case 3: {  /* halt ? */
      r = (SendAppleEventToSystemProcess(kAEShutDown) == noErr);
      break;
    }
    case 4: {  /* reboot ? */
      r = (SendAppleEventToSystemProcess(kAERestart) == noErr);
      break;
    }
    case 5: {  /* logoff ? */
      r = (SendAppleEventToSystemProcess(kAEReallyLogOut) == noErr);
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": unknown option %s.", "os.terminate", command);
  }
#elif defined(__OS2__)
  switch (cmd) {
    case 3: {  /* halt ? */
      //r = eCSshutdownall(L) == 0;  /* why does this not work ? */
      //if (!r)
      //  luaL_error(L, "Error in " LUA_QS ": halting failed.", "os.terminate");
      //break;

      r = DosOpen((PCSZ)"\\DEV\\DOS$", &h, &ulAction,
                   0L, FILE_NORMAL, FILE_OPEN,
                   OPEN_SHARE_DENYNONE | OPEN_ACCESS_READWRITE, 0L);
      if (r != 0)
        luaL_error(L, "Error in " LUA_QS ": could not access operating system, quitting.",
                      "os.terminate");
      r = eCSshutdownall(L) == 0;  /* success ? */
      //if (r)  /* now reboot */
      //  DosDevIOCtl(h, CATEGORY_DOSSYS, FUNCTION_REBOOT, NULL, 0L, NULL, NULL, 0L, NULL);
      DosClose(h);


    }
    case 4: {  /* reboot ? */
      r = DosOpen((PCSZ)"\\DEV\\DOS$", &h, &ulAction,
                   0L, FILE_NORMAL, FILE_OPEN,
                   OPEN_SHARE_DENYNONE | OPEN_ACCESS_READWRITE, 0L);
      if (r != 0)
        luaL_error(L, "Error in " LUA_QS ": could not access operating system, quitting.",
                      "os.terminate");
      r = eCSshutdownall(L) == 0;  /* success ? */
      if (r)  /* now reboot */
        DosDevIOCtl(h, CATEGORY_DOSSYS, FUNCTION_REBOOT, NULL, 0L, NULL, NULL, 0L, NULL);
      DosClose(h);
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": unknown option %s.", "os.terminate", command);
  }
#endif
  if (r == 0)
    luaL_error(L, "Error in " LUA_QS ": %s failed.", "os.terminate", command);
  lua_pushtrue(L);
#endif
  return 1;
}


/* os.datetosec, Agena 1.8.0, 21.09.2012

   receives a date of the form [year, month, date [, hour [, minute [, second]]], with a table of all values
   being integers, and transforms it to the number of seconds elapsed since the start of an `epoch`.
   The time zone acknowledged may depend on your operating system.

   See also: os.secstodate. */

static int os_datetosecs (lua_State *L) {  /* Agena 1.8.0, extended 1.12.3 */
  Time64_T t;
  int year, month, day, hour, minute, second;
  size_t nops;
  year = month = day = hour = minute = second = 0;  /* to prevent compiler warnings */
  switch (lua_type(L, 1)) {
    case LUA_TTABLE: {  /* 1.12.3 */
      nops = agn_size(L, 1);
      if (nops < 3)
        luaL_error(L, "Error in " LUA_QS ": table must contain at least three values.", "utils.checkdate");
      year = agn_getinumber(L, 1, 1);
      month = agn_getinumber(L, 1, 2);
      day = agn_getinumber(L, 1, 3);
      hour = (nops > 3) ? agn_getinumber(L, 1, 4) : 0;
      minute = (nops > 4) ? agn_getinumber(L, 1, 5) : 0;
      second = (nops > 5) ? agn_getinumber(L, 1, 6) : 0;
      break;
    }
    case LUA_TSEQ: {  /* 1.12.3 */
      nops = agn_seqsize(L, 1);
      if (nops < 3)
        luaL_error(L, "Error in " LUA_QS ": sequence must contain at least three values.", "utils.checkdate");
      year = lua_seqgetinumber(L, 1, 1);
      month = lua_seqgetinumber(L, 1, 2);
      day = lua_seqgetinumber(L, 1, 3);
      hour = (nops > 3) ? lua_seqgetinumber(L, 1, 4) : 0;
      minute = (nops > 4) ? lua_seqgetinumber(L, 1, 5) : 0;
      second = (nops > 5) ? lua_seqgetinumber(L, 1, 6) : 0;
      break;
    }
    case LUA_TNUMBER: {
      nops = lua_gettop(L);
      if (nops < 3)
        luaL_error(L, "Error in " LUA_QS ": expected at leat three arguments of type number.", "utils.checkdate");
      year = agn_checknumber(L, 1);
      month = agn_checknumber(L, 2);
      day = agn_checknumber(L, 3);
      hour = (nops > 3) ? agn_checknumber(L, 4) : 0;
      minute = (nops > 4) ? agn_checknumber(L, 5) : 0;
      second = (nops > 5) ? agn_checknumber(L, 6) : 0;
      break;
    }
    default:
      luaL_error(L, "Error in " LUA_QS ": expected a table, sequence or at least three numbers.", "utils.checkdate");
  }
  if (tools_checkdatetime(year, month, day, hour, minute, second) == 0)  /* 1.9.1 */
    luaL_error(L, "Error in " LUA_QS ": time component out of range.", "os.datetosecs");
  t = maketime(year, month, day, hour, minute, second);
  if (t == -1)
    luaL_error(L, "Error in " LUA_QS ": could not determine time.", "os.datetosecs");
  else
    lua_pushnumber(L, t);
  return 1;
}


/* os.secstodate, Agena 1.8.0, 21.09.2012

   takes the number of seconds elapsed since the start of an epoch, in your local time zone, and returns a
   table of integers in the order: year, month, day, hour, minute, second. In case of an error, `fail` is
   returned.

   See also: os.datetosec. */

static int os_secstodate (lua_State *L) {  /* Agena 1.8.0 */
  Time64_T t;
  struct TM *stm;
  t = agn_checknumber(L, 1);
  stm = localtime64(&t);
  if (stm != NULL) {  /* 0.31.3 patch */
    lua_createtable(L, 6, 0);  /* 6 = number of entries */
    lua_rawsetinumber(L, -1, 1, stm->tm_year+1900);
    lua_rawsetinumber(L, -1, 2, stm->tm_mon+1);
    lua_rawsetinumber(L, -1, 3, stm->tm_mday);
    lua_rawsetinumber(L, -1, 4, stm->tm_hour);
    lua_rawsetinumber(L, -1, 5, stm->tm_min);
    lua_rawsetinumber(L, -1, 6, stm->tm_sec);
  } else
    lua_pushfail(L);
  return 1;
}


/* os.now, Agena 1.8.0, 21.09.2012

   returns rather low-level information on the current or given date and time in form of a dictionary: the `gmt` table
   represents the current date and time in GMT/UTC. The `localtime` table includes the same information for your local
   time zone. The `tz` entry represents the difference between your local time zone and GMT in minutes with daylight
   saving time cancelled out, and _east_ of Greenwich. The `seconds` entry is the number of seconds elapsed since
   some given start time (the `epoch`), which on most operating systems is January 01, 1970, 00:00:00.

   If no argument is passed, the function returns information on the current date and time. If a non-negative number
   is given which represents the amount of seconds elapsed since the start of the epoch, information on this date and time
   are determined (see os.datetosecs to convert a date to seconds).

   The `gmt` and `localtime` entries are of the same structure: it is a table of data of the following order:
   year, month, day, hour, minute, second, number of weekday (where 0 means Sunday, 1 is Monday, and so forth),
   the number of full days since the beginning of the year (in the range 0:365), whether daylight saving time
   is in effect at the time given (0: no, 1: yes), and the strings 'AM' or 'PM'.

   See also: os.datetosecs, os.secstodate, os.time.

*/

#define dia_ae "ae"
#define dia_ao "ao"
#define dia_CZ "cz"
#define dia_ue "ue"

/* New English calendar names */

static char *months[] = {
      "none", "January", "February", "March", "April", "May", "June", "July", "August",
      "September", "October", "November", "December" };

static char *weekdays[] = {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};

static int os_now (lua_State *L) {  /* Agena 1.8.0, extended 1.8.2 */
  Time64_T tlct, tgmt, gmttime, lcttime, gmtday, lctday;
  struct TM *stmgmt, *stmlct;
#if defined(_WIN32) || defined(__unix__) || defined(__APPLE__)
  struct timeb tp;
#elif defined(__OS2__)
  DATETIME tp;
#endif
  char ampm[3];
  double djm0, djm, djt;
  int msecs;
  if (lua_isnumber(L, 1)) {
    Time64_T t = agn_tonumber(L, 1);
    if (t < 0) luaL_error(L, "Error in " LUA_QS ": time delivered is negative.", "os.now");
    tlct = tgmt = t;
  } else {
    tlct = time(NULL);
    tgmt = time(NULL);
    if (tlct == -1 || tgmt == -1)
      luaL_error(L, "Error in " LUA_QS ": could not determine current time.", "os.now");
  }
  stmgmt = gmtime64(&tgmt);
  strftime(ampm, 3, "%p", stmgmt);
  ampm[2] = '\0';  /* better sure than sorry */
  gmttime = lcttime = gmtday = lctday = 0;
  lua_createtable(L, 0, 8);
  lua_pushstring(L, "gmt");
  if (stmgmt != NULL) {
    lua_createtable(L, 10, 0);
    lua_rawsetinumber(L, -1,  1, stmgmt->tm_year+1900);
    lua_rawsetinumber(L, -1,  2, stmgmt->tm_mon+1);
    lua_rawsetinumber(L, -1,  3, stmgmt->tm_mday);
    gmtday = stmgmt->tm_mday;
    lua_rawsetinumber(L, -1,  4, stmgmt->tm_hour);
    lua_rawsetinumber(L, -1,  5, stmgmt->tm_min);
    lua_rawsetinumber(L, -1,  6, stmgmt->tm_sec);
    lua_rawsetinumber(L, -1,  7, stmgmt->tm_wday);
    lua_rawsetinumber(L, -1,  8, stmgmt->tm_yday);
    lua_rawsetinumber(L, -1,  9, stmgmt->tm_isdst);
    lua_rawsetistring(L, -1, 10, ampm);
    lua_rawsetistring(L, -1, 11, months[stmgmt->tm_mon+1]);
    lua_rawsetistring(L, -1, 12, weekdays[stmgmt->tm_wday]);  /* Agena 1.8.2 fix */
    gmttime = stmgmt->tm_sec + stmgmt->tm_min*60 + stmgmt->tm_hour * 3600;
  } else {
    lua_pushfail(L);
  }
  lua_rawset(L, -3);
  stmlct = localtime64(&tlct);  /* put this _here_, otherwise the time would be overwritten */
  strftime(ampm, 3, "%p", stmlct);
  lua_pushstring(L, "localtime");
  if (stmgmt != NULL) {
    lua_createtable(L, 10, 0);
    lua_rawsetinumber(L, -1,  1, stmlct->tm_year+1900);
    lua_rawsetinumber(L, -1,  2, stmlct->tm_mon+1);
    lua_rawsetinumber(L, -1,  3, stmlct->tm_mday);
    lctday = stmlct->tm_mday;
    lua_rawsetinumber(L, -1,  4, stmlct->tm_hour);
    lua_rawsetinumber(L, -1,  5, stmlct->tm_min);
    lua_rawsetinumber(L, -1,  6, stmlct->tm_sec);
    lua_rawsetinumber(L, -1,  7, stmlct->tm_wday);
    lua_rawsetinumber(L, -1,  8, stmlct->tm_yday);
    lua_rawsetinumber(L, -1,  9, stmlct->tm_isdst);
    lua_rawsetistring(L, -1, 10, ampm);
    lua_rawsetistring(L, -1, 11, months[stmlct->tm_mon+1]);
    lua_rawsetistring(L, -1, 12, weekdays[stmlct->tm_wday]);  /* Agena 1.8.2 fix */
    lcttime = stmlct->tm_sec + stmlct->tm_min*60 + stmlct->tm_hour * 3600;
  } else {
    lua_pushfail(L);
  }
  lua_rawset(L, -3);
  lua_pushstring(L, "tz");
  if (lctday-gmtday == 0)
    lua_pushnumber(L, (lcttime - gmttime - stmlct->tm_isdst * 3600)/60);
  else
    lua_pushnumber(L, (lcttime - gmttime + 86400 - stmlct->tm_isdst * 3600)/60);
  lua_rawset(L, -3);
  lua_pushstring(L, "td");  /* Agena 1.8.2 */
  if (lctday-gmtday == 0)
    lua_pushnumber(L, (lcttime - gmttime)/60);
  else
    lua_pushnumber(L, (lcttime - gmttime + 86400)/60);
  lua_rawset(L, -3);
  /* set daylight saving time flag for local time zone, Agena 1.8.2 */
  lua_pushstring(L, "dst");
  lua_pushboolean(L, stmlct->tm_isdst);
  lua_rawset(L, -3);
  lua_pushstring(L, "seconds");
  lua_pushnumber(L, tgmt);  /* return time in seconds */
  lua_rawset(L, -3);
  msecs = -1;
  /* 1.11.7, get milliseconds */
  #ifdef _WIN32
  ftime(&tp);
  msecs = tp.millitm;
  #elif defined(__unix__) || defined(__APPLE__)
  if (ftime(&tp) == 0)  /* set milliseconds only when query has been successful */
    msecs = tp.millitm;
  #elif defined(__OS2__)  /* 2.3.0 RC 2 eCS extension */
    DosGetDateTime(&tp);
    msecs = tp.hundredths;
  #endif
  if (msecs != -1) {
    lua_pushstring(L, "mseconds");
    lua_pushnumber(L, msecs);
    lua_rawset(L, -3);
  }
  if (iauCal2jd(stmgmt->tm_year+1900, stmgmt->tm_mon+1, stmgmt->tm_mday, &djm0, &djm) >= 0 &&
      iauTf2d('+', stmgmt->tm_hour, stmgmt->tm_min, stmgmt->tm_sec, &djt) >= 0) {
    lua_pushstring(L, "jd");
    lua_pushnumber(L, djm0 + djm + djt);
    lua_rawset(L, -3);
  }
  return 1;
}


/* os.settime, Agena 1.8.0, 24.09.2012

   takes the number of seconds elapsed since the start of an epoch, in your local time zone, and sets the
   system clock accordingly. Agena must be run in root mode in order to change the system time. In case of
   an error, `fail` is returned. The function is only available in the Windows and UNIX versions of Agena (Solaris,
   Linux). */

static int os_settime (lua_State *L) {  /* Agena 1.8.0, 1.9.1. */
#if defined(__unix__) && !defined(LUA_DOS)
  int year, month, day, hour, minute, second, nops;
  time_t t;
#elif defined(_WIN32)
  WORD year, month, day, hour, minute, second;
  int t, nops;
  SYSTEMTIME lpSystemTime;
#elif defined(__OS2__)
  int year, month, day, hour, minute, second;
  int t, nops;
  DATETIME lpSystemTime;
#else
  lua_pushfail(L);
#endif
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(_WIN32) || defined(__OS2__)
  /* common part */
  if (!lua_istable(L, 1))
    luaL_error(L, "Error in " LUA_QS ": expected a table of integers.", "os.settime");
  year = agn_getinumber(L, 1, 1);
  month = agn_getinumber(L, 1, 2);
  day = agn_getinumber(L, 1, 3);
  nops = agn_size(L, 1);
  hour = (nops > 3) ? agn_getinumber(L, 1, 4) : 0;
  minute = (nops > 4) ? agn_getinumber(L, 1, 5) : 0;
  second = (nops > 5) ? agn_getinumber(L, 1, 6) : 0;
  if (tools_checkdatetime(year, month, day, hour, minute, second) == 0)  /* 1.9.1 */
    luaL_error(L, "Error in " LUA_QS ": time component out of range.", "os.settime");
#ifdef _WIN32
  /* Windows part */
  lpSystemTime.wYear = year;
  lpSystemTime.wMonth = month;
  lpSystemTime.wDay = day;
  lpSystemTime.wHour = hour;
  lpSystemTime.wMinute = minute;
  lpSystemTime.wSecond = second;
  lpSystemTime.wMilliseconds = lpSystemTime.wDayOfWeek = 0;  /* defaults */
  t = SetLocalTime(&lpSystemTime);  /* returns BOOL */
  agn_pushboolean(L, t == 0 ? -1 : 1);
#elif defined(__OS2__)  /* 2.3.0 RC 2 eCS extension */
  lpSystemTime.year = year;
  lpSystemTime.month = month;
  lpSystemTime.day = day;
  lpSystemTime.hours = hour;
  lpSystemTime.minutes = minute;
  lpSystemTime.seconds = second;
  lpSystemTime.hundredths = lpSystemTime.weekday = lpSystemTime.timezone = 0;  /* defaults */
  t = DosSetDateTime(&lpSystemTime);  /* returns BOOL */
  agn_pushboolean(L, t == 0 ? 1 : -1);
#else
  /* UNIX part */
  t = maketime(year, month, day, hour, minute, second);
  if (t != 0)
    luaL_error(L, "Error in " LUA_QS ": could not determine time.", "os.settime");
  if (stime(&t) == 0)
    lua_pushtrue(L);
  else
    lua_pushfail(L);
#endif
#endif
  return 1;
}


#ifdef _WIN32
/* The following Windows implementation has been taken from the LuaSys package, written by
   Nodir Temirkhodjaev; Agena 2.3.0 RC 2 */

typedef struct {
  DWORD status;
  union {
    LONG vLong;
    double vDouble;
    LONGLONG vLongLong;
    void *vPtr;
  } u;
} PDH_VALUE;

typedef long (WINAPI *PPdhOpenQuery) (LPCSTR, DWORD_PTR, HANDLE *);
typedef long (WINAPI *PPdhAddEnglishCounter) (HANDLE, LPCSTR, DWORD_PTR, HANDLE *);
typedef long (WINAPI *PPdhCollectQueryData) (HANDLE);
typedef long (WINAPI *PPdhGetFormattedCounterValue) (HANDLE, DWORD, LPDWORD, PDH_VALUE *);

#define PDH_CPU_QUERY	"\\Processor(_Total)\\% Processor Time"

static HINSTANCE hdll;
static HANDLE hquery;
static HANDLE hcounter;

static PPdhOpenQuery pPdhOpenQuery;
static PPdhAddEnglishCounter pPdhAddEnglishCounter;
static PPdhCollectQueryData pPdhCollectQueryData;
static PPdhGetFormattedCounterValue pPdhGetFormattedCounterValue;

static int getloadavg (double *loadavg) {
  PDH_VALUE value;
  int res;

  if (!hdll) {
    hdll = LoadLibrary("pdh.dll");
    if (!hdll) return -1;

    pPdhOpenQuery = (PPdhOpenQuery)
     GetProcAddress(hdll, "PdhOpenQueryA");
    pPdhAddEnglishCounter = (PPdhAddEnglishCounter)
     GetProcAddress(hdll, "PdhAddEnglishCounterA");
    pPdhCollectQueryData = (PPdhCollectQueryData)
     GetProcAddress(hdll, "PdhCollectQueryData");
    pPdhGetFormattedCounterValue = (PPdhGetFormattedCounterValue)
     GetProcAddress(hdll, "PdhGetFormattedCounterValue");

    res = pPdhOpenQuery(NULL, 0, &hquery);
    if (res) return res;

    res = pPdhAddEnglishCounter(hquery, PDH_CPU_QUERY, 0, &hcounter);
    if (res) return res;

    pPdhCollectQueryData(hquery);  /* to avoid PDH_INVALID_DATA result */
  }

  if (!hcounter) return -1;

  res = pPdhCollectQueryData(hquery);
  if (res) return res;

  res = pPdhGetFormattedCounterValue(hcounter, 0x8200, NULL, &value);
  if (res) return res;

  *loadavg = value.u.vDouble / 100.0;
  return 0;
}
#endif

static int os_cpuload (lua_State *L) {  /* Agena 1.9.1, 2.3.0 RC 2 eCS extension */
#if !(defined _WIN32) && !defined (LUA_DOS) && !(defined (__SVR4) && defined (__sun))
  double loadavg[3];
  int i;
  if (getloadavg(loadavg, 3) == -1)
    luaL_error(L, "Error in " LUA_QS ": could not determine CPU load.", "os.cpuload");
  agn_createseq(L, 3);
  for (i=0; i < 3; i++)
    lua_seqsetinumber(L, -1, i+1, loadavg[i]);
#elif _WIN32
  double loadavg;
  int i;
  struct WinVer winversion;  /* 2.9.0 fix */
  if (getWindowsVersion(&winversion) < 7) {  /* 2000 or earlier ? */
    lua_pushfail(L);
    return 1;
  }
  loadavg = 0;
  if (getloadavg(&loadavg) != 0)
    luaL_error(L, "Error in " LUA_QS ": could not determine CPU load.", "os.cpuload");
  agn_createseq(L, 3);
  for (i=0; i < 3; i++)
    lua_seqsetinumber(L, -1, i+1, (lua_Number)loadavg);
#else
  lua_pushfail(L);
#endif
  return 1;
}


static int os_pid (lua_State *L) {  /* Agena 1.9.1. */
  luaL_checkstack(L, lua_gettop(L), "too many arguments");
  lua_pushnumber(L, getpid());
  return 1;
}


/* Taken from http://www.codeproject.com/Articles/7340/Get-the-Processor-Speed-in-two-simple-ways,
   originally written by Thomas Latuske in 2004; modified for Agena by alex walz */
#ifdef _WIN32
DWORD ProcSpeedRead() {
  DWORD BufSize, dwMHz;
  HKEY hKey;
  long keyError, valueError;
  BufSize = dwMHz = _MAX_PATH;
  keyError = RegOpenKeyEx(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &hKey);
  if (keyError == ERROR_SUCCESS) {
    valueError = RegQueryValueEx(hKey, "~MHz", NULL, NULL, (LPBYTE)&dwMHz, &BufSize);  /* better sure than sorry */
    if (valueError != ERROR_SUCCESS) dwMHz = AGN_NAN;  /* info could not be read */
    RegCloseKey(hKey);
  } else
    dwMHz = AGN_NAN;  /* info could not be read */
  return dwMHz;
}

#define TOTALBYTES 1024  /* better be sure than sorry */
char *BrandRead() {
  DWORD BufSize;
  HKEY hKey;
  long keyError, valueError;
  char cpubrand[TOTALBYTES];  /* malloc will not work ! Brand info seems to be 48 bytes long, however, RegQueryValueEx
    returns the actual number of chars in the brand info. */
  cpubrand[0] = '\0';
  BufSize = sizeof(cpubrand);
  keyError = RegOpenKeyEx(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &hKey);
  if (keyError == ERROR_SUCCESS) {
    valueError = RegQueryValueEx(hKey, "ProcessorNameString", NULL, NULL, (LPBYTE)cpubrand, &BufSize);  /* better sure than sorry */
    RegCloseKey(hKey);
    if (valueError == ERROR_SUCCESS && BufSize > 0 && BufSize <= TOTALBYTES && cpubrand != NULL) {
      cpubrand[BufSize-1] = '\0';
      return strdup(cpubrand);  /* FREE return after usage ! */
    }
  }
  return NULL;
}

char *VendorRead() {
  DWORD BufSize;
  HKEY hKey;
  long keyError, valueError;
  char vendor[TOTALBYTES];  /* malloc will not work ! Brand info seems to be 48 bytes long, however, RegQueryValueEx
    returns the actual number of chars in the brand info. */
  vendor[0] = '\0';
  BufSize = sizeof(vendor);
  keyError = RegOpenKeyEx(HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0", 0, KEY_READ, &hKey);
  if (keyError == ERROR_SUCCESS) {
    valueError = RegQueryValueEx(hKey, "VendorIdentifier", NULL, NULL, (LPBYTE)vendor, &BufSize);  /* better sure than sorry */
    RegCloseKey(hKey);
    if (valueError == ERROR_SUCCESS && BufSize > 0 && BufSize <= TOTALBYTES && vendor != NULL) {
      vendor[BufSize-1] = '\0';
      return strdup(vendor);  /* FREE return after usage ! */
    }
  }
  return NULL;
}
#endif

#ifdef __APPLE__

#define TOTALBYTES 1024
/* See: http://stackoverflow.com/questions/5782012/packagemaker-differentiate-between-ppc-and-intel */
const char *cputype[] = {
  "unknown", "unknown", "unknown", "unknown", "unknown", "unknown",  /* 0 to 5 */
  "MC680x0",  /* CPU_TYPE_MC680x0   (6) */
  "x86",      /* CPU_TYPE_X86       (7) */
  "unknown", "unknown",  /* 8 to 9 */
  "MC98000"   /* CPU_TYPE_MC98000   (10) */
  "HPPA",     /* CPU_TYPE_HPPA      (11) */
  "ARM",      /* CPU_TYPE_ARM       (12) */
  "MC88000",  /* CPU_TYPE_MC88000   (13) */
  "sparc",    /* CPU_TYPE_SPARC     (14) */
  "i860",     /* CPU_TYPE_I860      (15) */
  "unknown", "unknown",  /* 16 to 17 */
  "ppc"};      /* CPU_TYPE_POWERPC  (18) */
#endif

#if defined(__sparc) || defined(__powerpc__) || defined(LUA_DOS) || defined(__OS2__) || defined(__EMX__)
void otherarch (lua_State *L, const char *str) {  /* 1.9.5 */
#if __OS2__  /* 2.3.0 RC 2 eCS extension */
  ULONG a[1];
#endif
  lua_createtable(L, 0, 2);
#if __OS2__
  if (DosQuerySysInfo(QSV_NUMPROCESSORS, QSV_NUMPROCESSORS, &a[0], sizeof(a)) == 0) {
    lua_pushstring(L, "ncpu");
    lua_pushnumber(L, a[0]);
    lua_rawset(L, -3);
  }
#endif
  lua_pushstring(L, "type");
  lua_pushstring(L, str);
  lua_rawset(L, -3);
  lua_pushstring(L, "bigendian");
  agn_pushboolean(L, tools_endian());
  lua_rawset(L, -3);
}
#endif

static int os_cpuinfo (lua_State *L) {  /* Agena 1.9.3 */
#ifdef _WIN32
  struct WinVer winversion;
  if (getWindowsVersion(&winversion) < 6) {  /* NT 4.0 or earlier ? */
    lua_pushfail(L);
    return 1;
  }
  SYSTEM_INFO sysinfo;
  GetSystemInfo(&sysinfo);
  char *brand, *vendor;
  brand = vendor = NULL;
  lua_createtable(L, 0, 8);
  lua_pushstring(L, "ncpu");
  lua_pushinteger(L, sysinfo.dwNumberOfProcessors);
  lua_rawset(L, -3);
  lua_pushstring(L, "type");
  switch (sysinfo.wProcessorArchitecture) {
    case PROCESSOR_ARCHITECTURE_AMD64: {  /* 9 */
      lua_pushstring(L, "x64");
      break;
    }
    case PROCESSOR_ARCHITECTURE_ARM: {  /* reserved */
      lua_pushstring(L, "ARM");
      break;
    }
    case PROCESSOR_ARCHITECTURE_IA64: {  /* 6 */
      lua_pushstring(L, "Itanium");
      break;
    }
    case PROCESSOR_ARCHITECTURE_INTEL: {  /* 0 */
      lua_pushstring(L, "x86");
      break;
    }
    case PROCESSOR_ARCHITECTURE_UNKNOWN: {   /* 0xffff */
      lua_pushstring(L, "unknown");
      break;
    }
    default: {
      lua_pushstring(L, "unknown");
    }
  }
  lua_rawset(L, -3);
  lua_pushstring(L, "level");
  lua_pushnumber(L, sysinfo.wProcessorLevel);
  lua_rawset(L, -3);
  lua_pushstring(L, "revision");
  lua_pushnumber(L, sysinfo.wProcessorRevision);
  lua_rawset(L, -3);
  lua_pushstring(L, "frequency");
  lua_pushnumber(L, ProcSpeedRead());
  lua_rawset(L, -3);
  brand = BrandRead();
  if (brand != NULL) {
    lua_pushstring(L, "brand");
    lua_pushstring(L, brand);
    lua_rawset(L, -3);
    xfree(brand);
  }
  vendor = VendorRead();
  if (vendor != NULL) {
    lua_pushstring(L, "vendor");
    lua_pushstring(L, vendor);
    lua_rawset(L, -3);
    xfree(vendor);
  }
  lua_pushstring(L, "bigendian");
  agn_pushboolean(L, tools_endian());
  lua_rawset(L, -3);
#elif __APPLE__
  uint64_t data;
  size_t size, brandlen, vendorlen;
  char brand[TOTALBYTES];
  char vendor[TOTALBYTES];
  brand[0] = '\0'; brandlen = TOTALBYTES;
  vendor[0] = '\0'; vendorlen = TOTALBYTES;
  data = 0;
  size = sizeof(data);
  lua_createtable(L, 0, 10);
  if (sysctlbyname("hw.cpufrequency", &data, &size, NULL, 0) >= 0) {
    lua_pushstring(L, "frequency");
    lua_pushnumber(L, data/1e6);
    lua_rawset(L, -3);
  }
  data = 0; size = sizeof(data);
  if (sysctlbyname("hw.ncpu", &data, &size, NULL, 0) >= 0) {
    lua_pushstring(L, "ncpu");
    lua_pushnumber(L, data);
    lua_rawset(L, -3);
  }
  data = 0; size = sizeof(data);
  if (sysctlbyname("hw.cputype", &data, &size, NULL, 0) >= 0) {
    lua_pushstring(L, "type");
    if (data >= 0 && data < 19) {
      uint64_t is64 = 0;
      if (sysctlbyname("hw.cpu64bit_capable", &is64, &size, NULL, 0) >= 0) {
        if (is64 && (data == 7)) lua_pushstring(L, "x64");
        else if (is64 && (data == 18)) lua_pushstring(L, "ppc64");
        else lua_pushstring(L, cputype[data]);
      } else
        lua_pushstring(L, cputype[data]);
    } else
      lua_pushstring(L, "unknown");
    lua_rawset(L, -3);
  }
  data = 0; size = sizeof(data);
  /* http://cr.yp.to/hardware/ppc.html:
     MacOS sysctl reports "hw.cputype: 18" for PowerPC, and in particular "hw.cpusubtype":
     1 for 601, 2 for 602, 3 or 4 or 5 for 603, 6 or 7 for 604, 8 for 620, 9 for 750, 10 for 7400, 11 for 7450, 100 for 970. */
  if (sysctlbyname("hw.cpusubtype", &data, &size, NULL, 0) >= 0) {
    lua_pushstring(L, "level");
    lua_pushnumber(L, data);
    lua_rawset(L, -3);
  }
  if (sysctlbyname("machdep.cpu.brand_string", &brand, &brandlen, NULL, 0) >= 0) {
    lua_pushstring(L, "brand");
    lua_pushstring(L, brand);
    lua_rawset(L, -3);
  }
  if (sysctlbyname("machdep.cpu.vendor", &vendor, &vendorlen, NULL, 0) >= 0) {
    lua_pushstring(L, "vendor");
    lua_pushstring(L, vendor);
    lua_rawset(L, -3);
  }
  data = 0; size = sizeof(data);
  if (sysctlbyname("machdep.cpu.model", &data, &size, NULL, 0) >= 0) {
    lua_pushstring(L, "model");
    lua_pushnumber(L, data);
    lua_rawset(L, -3);
  }
  data = 0; size = sizeof(data);
  if (sysctlbyname("machdep.cpu.stepping", &data, &size, NULL, 0) >= 0) {
    lua_pushstring(L, "stepping");
    lua_pushnumber(L, data);
    lua_rawset(L, -3);
  }
  lua_pushstring(L, "bigendian");
  agn_pushboolean(L, tools_endian());
  lua_rawset(L, -3);
#elif defined(__sparc)
  otherarch(L, "sparc");
#elif __powerpc__
  otherarch(L, "ppc");  /* 1.9.5 */
#elif defined(LUA_DOS) || defined(__OS2__) || defined(__EMX__)  /* 1.9.5 */
  otherarch(L, "x86");
#else
  lua_pushfail(L);
#endif
  return 1;
}


/*
* lalarm.c
* an alarm library for Lua 5.1 based on signal
* Luiz Henrique de Figueiredo <lhf@tecgraf.puc-rio.br>
* 03 May 2012 00:26:33
* This code is hereby placed in the public domain.

  The library [function] exports a single function, alarm([s, [f]]), which tells
  Lua to call f after s seconds have elapsed. This is done only once. If you want
  f to be called every s seconds, call alarm(s) inside f. Call alarm() without
  arguments or with s=0 to cancel any pending alarm.
*/

#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__)
#define NAME	"alarm handler"

static lua_State *LL = NULL;
static lua_Hook oldhook = NULL;
static int oldmask=0;
static int oldcount=0;

static void l_handler (lua_State *L, lua_Debug *ar) {
  (void)ar;
  L = LL;
  lua_sethook(L, oldhook, oldmask, oldcount);
  lua_getfield(L, LUA_REGISTRYINDEX, NAME);
  lua_call(L, 0, 0);
}

static void l_signal (int i) {	/* assert(i==SIGALRM); */
  signal(i, SIG_DFL);
  oldhook = lua_gethook(LL);
  oldmask = lua_gethookmask(LL);
  oldcount = lua_gethookcount(LL);
  lua_sethook(LL, l_handler, LUA_MASKCALL | LUA_MASKRET | LUA_MASKCOUNT, 1);
}

static int os_alarm (lua_State *L) {  /* alarm([secs, [func]]) */
  LL = L;
  switch (lua_gettop(L)) {
    case 0:
	  break;
    case 1:
	  lua_getfield(L, LUA_REGISTRYINDEX, NAME);
      if (lua_isnil(L, -1)) luaL_error(L, "no alarm handler set");
      break;
    default:
	  lua_settop(L, 2);
      luaL_checktype(L, 2, LUA_TFUNCTION);
	  lua_setfield(L, LUA_REGISTRYINDEX, NAME);
      break;
  }
  if (signal(SIGALRM, l_signal) == SIG_ERR)
    lua_pushnil(L);
  else
    lua_pushinteger(L, alarm(luaL_optinteger(L, 1, 0)));
  return 1;
}
#endif


/* CreateLink and ResolveLink have been taken from "Shell Links" in MSDN library, reproduced in parts
   by the dynamorio project; taken from sources available at http://code.google.com/p/dynamorio and
   largely modified for Agena */

#ifdef _WIN32
/* this modified version of CreateLink can also cope with file names with no absolute or relative paths. */
HRESULT CreateLink (LPCSTR lpszPathObj, LPSTR lpszPathLink, LPSTR lpszDesc) {
  int hres;
  IShellLink *psl = NULL;
  IPersistFile *ppf = NULL;
  WCHAR *wsz;
  char *ObjWorkingDir, *tmp, *cwdbuffer, *fullsourcepath;
  LPSTR link;
  cwdbuffer = fullsourcepath = NULL;
  hres = CoInitialize(NULL);
  if (hres != S_FALSE && hres != S_OK) goto error3;  /* CoUninitialize, checked */
  /* Get a pointer to the IShellLink interface */
  hres = CoCreateInstance(&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, &IID_IShellLink, (LPVOID *)&psl);
  if (!SUCCEEDED(hres)) goto error3;  /* CoUninitialize, checked */
  /* Set the path to the shortcut target, and add the description. */
  /* psl->lpVtbl->SetPath(psl, (LPCSTR)charreplace((char *)lpszPathObj, '/', '\\', 0)); */
  psl->lpVtbl->SetDescription(psl, lpszDesc);
  ObjWorkingDir = strdup(lpszPathObj);
  if (ObjWorkingDir != NULL) {
    charreplace(ObjWorkingDir, '/', '\\', 0);
    tmp = strrchr(ObjWorkingDir, '\\');
    if (tmp != NULL) {  /* source path given ? */
      tmp[0] = '\0';
      if (*ObjWorkingDir == '\0') goto error2;  /* leading slash ? */
      psl->lpVtbl->SetWorkingDirectory(psl, ObjWorkingDir);
      psl->lpVtbl->SetPath(psl, (LPCSTR)charreplace((char *)lpszPathObj, '/', '\\', 0));
    } else {  /* no source path given */
      cwdbuffer = (char *)malloc((PATH_MAX+1) * sizeof(char));
      if (tools_cwd(cwdbuffer) != 0) goto error2; /* frees cwdbuffer automatically; CoUninitialize & xfree(ObjWorkingDir) */
      psl->lpVtbl->SetWorkingDirectory(psl, cwdbuffer);
      fullsourcepath = concat(cwdbuffer, "\\", (char *)lpszPathObj);
      psl->lpVtbl->SetPath(psl, (LPCSTR)charreplace((char *)fullsourcepath, '/', '\\', 0));
    }
  } else goto error3;  /* strdup failed, no need to free ObjWorkingDir; conduct CoUninitialize */
  /* process link target now */
  charreplace(lpszPathLink, '/', '\\', 0);
  if (strrchr(lpszPathLink, '\\') == NULL) {  /* no path given ? */
    if (cwdbuffer == NULL) {  /* cwd not yet determined ? */
      cwdbuffer = (char *)malloc((PATH_MAX+1)*sizeof(char));
      if (tools_cwd(cwdbuffer) != 0) goto error2;  /* frees cwdbuffer automatically; CoUninitialize & xfree(ObjWorkingDir) */
      charreplace(cwdbuffer, '/', '\\', 0);
    }
    /* compose full link path, cwd at this point has already been determined */
    link = (LPSTR)concat(cwdbuffer, "\\", lpszPathLink, NULL);
    if (link == NULL) goto error1;  /* CoUninitialize & xfree(ObjWorkingDir) & xfree(cwdbuffer) */
  } else {  /* a path has been given, at this point CoUnIni, ObjWorkingDir, and possibly cwdbuffer */
    link = (LPSTR)concat(lpszPathLink, NULL);
    if (link == NULL) {
      if (cwdbuffer == NULL)
        goto error2;  /* xfree CoUnIni, and ObjWorkingDir */
      else
        goto error1;  /* xfree CoUnIni, cwdbuffer, and ObjWorkingDir */
    }
  }
  /* Query IShellLink for the IPersistFile interface for saving the shortcut in persistent storage. */
  /* at this point, CoIni, OWD, cwdbuffer, and link have been malloc'ed */
  hres = psl->lpVtbl->QueryInterface(psl, &IID_IPersistFile, (void **)&ppf);
  if (!SUCCEEDED(hres)) goto error0;
  /* Ensure that the string is ANSI, first determine the length of the resulting string wsz: */
  /* hres = MultiByteToWideChar(AreFileApisANSI() ? CP_ACP : CP_OEMCP, 0, lpszPathLink, -1, NULL, 0); */
  hres = MultiByteToWideChar(CP_UTF8, 0, link, -1, NULL, 0);
  if (!SUCCEEDED(hres)) goto error0;
  /* allocate memory for the buffer, plus 1 to be absolutely sure, malloc needs the number of characters,
     not the number of bytes */
  wsz = (WCHAR*)malloc(hres+1);
  if (wsz == NULL) goto error0;
  /* hres = MultiByteToWideChar(AreFileApisANSI() ? CP_ACP : CP_OEMCP, 0, lpszPathLink, -1, wsz, hres); */
  hres = MultiByteToWideChar(CP_UTF8, 0, link, -1, wsz, hres);
  if (!SUCCEEDED(hres)) goto error;
  /* Save the link by calling IPersistFile::Save. */
  hres = ppf->lpVtbl->Save(ppf, wsz, TRUE);
  ppf->lpVtbl->Release(ppf);
  psl->lpVtbl->Release(psl);
  CoUninitialize();
  xfree(ObjWorkingDir)
  xfree(link);
  xfree(cwdbuffer);
  xfree(wsz);
  return hres;

error:  /* fall through */
  xfree(wsz);

error0:
  xfree(link);

error1:
  xfree(cwdbuffer);

error2:
  xfree(ObjWorkingDir);
  if (fullsourcepath != NULL) xfree(fullsourcepath);

error3:
  CoUninitialize();
  return -1;
}

LUALIB_API int symlink (const char *src, const char *dest) {
  HRESULT res;
  res = CreateLink((LPCSTR)src, (LPSTR)dest, (LPSTR)src);
  return (int)res;
}

#define PATHLEN 4*(PATH_MAX-1)
/* ONLY call this function if the file lpszLinkFile really EXIST, otherwise the function would crash ! */
HRESULT ResolveLink(LPSTR lpszLinkFile, LPSTR lpszPath) {
  HRESULT hres;
  IShellLink* psl;
  IPersistFile* ppf;
  WCHAR *wsz;
  char szGotPath[PATHLEN];
  *lpszPath = 0;  /* assume failure */
  hres = CoInitialize(NULL);
  if (hres != S_FALSE && hres != S_OK) {
	CoUninitialize();
    return -1;
  }
  /* Get a pointer to the IShellLink interface. */
  hres = CoCreateInstance((REFCLSID)&CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER,
                          (REFIID)&IID_IShellLink, (LPVOID *)&psl);
  if (!SUCCEEDED(hres)) goto error2;
  hres = psl->lpVtbl->QueryInterface(psl, &IID_IPersistFile, (void **)&ppf);
  /* Ensure that the string is Unicode. */
  hres = MultiByteToWideChar(CP_UTF8, 0, lpszLinkFile, -1, NULL, 0);
  if (!SUCCEEDED (hres)) goto error2;
  wsz = (WCHAR*)malloc(hres+1);
  if (wsz == NULL) goto error2;
  hres = MultiByteToWideChar(CP_UTF8, 0, lpszLinkFile, -1, wsz, hres);
  if (!SUCCEEDED (hres)) goto error1;
  /* Load the shortcut. */
  hres = ppf->lpVtbl->Load(ppf, wsz, 0); /* STGM_READ); */
  if (!SUCCEEDED(hres)) goto error1;
  /* Resolve the link. */
  hres = psl->lpVtbl->Resolve(psl, NULL, 0); /* SLR_ANY_MATCH); */
  if (!SUCCEEDED(hres)) goto error1;
  /* Get the path to the link target. */
  hres = psl->lpVtbl->GetPath(psl, szGotPath, PATHLEN, NULL, SLGP_SHORTPATH);
  if (!SUCCEEDED(hres)) goto error1;
  lstrcpy(lpszPath, szGotPath);
  /* Release the pointer to the IPersistFile interface. */
  ppf->lpVtbl->Release(ppf);
  /* Release the pointer to the IShellLink interface. */
  psl->lpVtbl->Release(psl);
  CoUninitialize();
  xfree(wsz);
  return hres;

error1:
  xfree(wsz);
  /* fall through */

error2:
  CoUninitialize();
  return -1;
}

static int os_readlink (lua_State *L) {
  HRESULT res;
  char *buffer;
  const char *linkname;
  linkname = agn_checkstring(L, 1);
  if (access(linkname, 00|04) == -1) {
    lua_pushfail(L);
    return 1;
  }
  buffer = malloc(PATHLEN*sizeof(char));
  SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOOPENFILEERRORBOX);
  res = ResolveLink((char *)linkname, (LPSTR)buffer);
  SetErrorMode(0);
  if (res == -1)
    lua_pushfail(L);
  else
    lua_pushstring(L, buffer);
  xfree(buffer);
  return 1;
}
#endif


#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(_WIN32)
static int os_symlink (lua_State *L) {
  int en, r;
  const char *oldname, *newname;
  oldname = agn_checkstring(L, 1);
  newname = agn_checkstring(L, 2);
  r = symlink(oldname, newname);
  en = errno;
  if (r == -1) {
    luaL_error(L, "Error in " LUA_QS ": %s.", "os.symlink", strerror(en));
  }
  lua_pushtrue(L);
  return 1;
}
#endif

#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__)
static int os_readlink (lua_State *L) {
  int bufsize, nchars, en;
  const char *filename;
  char *buffer;
  bufsize = 1128;
  buffer = NULL;
  filename = agn_checkstring(L, 1);
  if (access(filename, 00|04) == -1) {
    lua_pushfail(L);
    return 1;
  }
  while (1) {
    buffer = (char *)realloc(buffer, bufsize);
    if (buffer == NULL)
      luaL_error(L, "Error in " LUA_QS ": memory allocation failed.", "os.readlink");
    nchars = readlink(filename, buffer, bufsize);  /* with _no_ \0 included ! */
    en = errno;
    if (nchars < 0) {
      xfree(buffer);
      lua_pushfail(L);
      if (en == EINVAL)
        /* luaL_error(L, "Error in " LUA_QS ": %s is not a symbolic link.", "os.readlink", filename); */
        lua_pushstring(L, "file is not a symbolic link");
      else
        /* luaL_error(L, "Error in " LUA_QS ": %s.", "os.readlink", strerror(en)); */
        lua_pushstring(L, strerror(en));
      return 2;
    }
    if (nchars < bufsize) {
      lua_pushlstring(L, buffer, nchars);
      xfree(buffer);
      return 1;
    }
    bufsize *= 2;
  }
}
#endif


#ifdef _WIN32  /* GCC 4.5.2 does not feature GetTickCount64 */
   #ifndef GetTickCount64
      #define GetTickCount64  GetTickCount
   #endif
#endif


#ifdef __APPLE__
CFTimeInterval getSystemUptime(void) {
  enum { NANOSECONDS_IN_SEC = 1000 * 1000 * 1000 };
  static double multiply = 0;
  if (multiply == 0) {
      mach_timebase_info_data_t s_timebase_info;
      kern_return_t result = mach_timebase_info(&s_timebase_info);
      assert(result == noErr);
      /* multiply to get value in the nano seconds */
      multiply = (double)s_timebase_info.numer / (double)s_timebase_info.denom;
      /* multiply to get value in the seconds */
      multiply /= NANOSECONDS_IN_SEC;
  }
  return mach_absolute_time() * multiply;
}
#endif


static int os_uptime (lua_State *L) {
#if defined(__OS2__)
  /* see: http://www.edm2.com/os2api/Dos/DosQuerySysInfo.html */
  ULONG sysInfo[1];
  if (DosQuerySysInfo(QSV_MS_COUNT, QSV_MS_COUNT, &sysInfo[0], sizeof(sysInfo)) != 0)
    lua_pushfail(L);
  else
    lua_pushnumber(L, sysInfo[0]/1000);  /* Value of a 32-bit, free-running counter (milliseconds/1k). Zero at boot time. */
#elif defined(_WIN32)
  /* see: http://msdn.microsoft.com/en-us/library/windows/desktop/ms724408%28v=vs.85%29.aspx */
  int winver;
  struct WinVer winversion;
  winver = getWindowsVersion(&winversion);
  if (winver < 6)  /* Win NT 4 or earlier ? */
    lua_pushfail(L);
  else if (winver < 8)  /* XP or earlier ? */
    lua_pushnumber(L, GetTickCount()/1000);  /* overflow if system has been up for more than 49.7 days. */
  else
    lua_pushnumber(L, GetTickCount64()/1000);
#elif defined(__linux__)
  /* see: http://stackoverflow.com/questions/1540627/what-api-do-i-call-to-get-the-system-uptime */
  struct sysinfo sinfo;
  if (sysinfo(&sinfo) != 0)
    lua_pushfail(L);
  else
    lua_pushnumber(L, sinfo.uptime);
/* #elif defined(__APPLE__) */ /* see: http://stackoverflow.com/questions/3269321/osx-programmatically-get-uptime */
/* struct timeval boottime;
  size_t len;
  int mib[2];
  len = sizeof(boottime);
  mib = {CTL_KERN, KERN_BOOTTIME};
  if (sysctl(mib, 2, &boottime, &len, NULL, 0) < 0)
    lua_pushfail(L);
  else {
    time_t bsec = boottime.tv_sec, csec = time(NULL);
    lua_pushnumber(L, difftime(csec, bsec));
  } */
#elif defined(__SVR4) && defined(__sun)
  /* 2.3.4, see StackOverflow article `Getting the uptime of a SunOS UNIX box in seconds only` */
  unsigned long int nBootTime, nCurrentTime;
  struct utmpx *ent;
  nBootTime = 0;
  nCurrentTime = time(NULL);
  while ( (ent = getutxent()) ) {
    if (strcmp("system boot", ent->ut_line) == 0) {
      nBootTime = ent->ut_tv.tv_sec; break;
    }
  }
  endutent();  /* do not remove this line ! */
  lua_pushnumber(L, nCurrentTime - nBootTime);
#elif defined(__APPLE__)
  /* see article OSX  programmatically get uptime at StackOverflow, advised by Speakus */
  lua_pushnumber(L, getSystemUptime());
#else
  lua_pushfail(L);
#endif
  return 1;
}


#ifdef _WIN32
/* The following code has been taken from: http://support.microsoft.com/kb/165721# */

LPTSTR szVolumeFormat = TEXT("\\\\.\\%c:");
LPTSTR szRootFormat = TEXT("%c:\\");
LPTSTR szErrorFormat = TEXT("Error %d: %s\n");

HANDLE OpenVolume (TCHAR cDriveLetter) {
  HANDLE hVolume;
  UINT uDriveType;
  TCHAR szVolumeName[8];
  TCHAR szRootName[5];
  DWORD dwAccessFlags;
  wsprintf(szRootName, szRootFormat, cDriveLetter);
  uDriveType = GetDriveType(szRootName);
  switch(uDriveType) {
    case DRIVE_REMOVABLE:
      dwAccessFlags = GENERIC_READ | GENERIC_WRITE;
      break;
    case DRIVE_CDROM:
      dwAccessFlags = GENERIC_READ;
      break;
    default:
      return INVALID_HANDLE_VALUE;
  }
  wsprintf(szVolumeName, szVolumeFormat, cDriveLetter);
  hVolume = CreateFile(szVolumeName,
                       dwAccessFlags,
                       FILE_SHARE_READ | FILE_SHARE_WRITE,
                       NULL,
                       OPEN_EXISTING,
                       0,
                       NULL );
  return hVolume;
}

BOOL CloseVolume (HANDLE hVolume) {
  return CloseHandle(hVolume);
}

#define LOCK_TIMEOUT        10000       /* 10 Seconds */
#define LOCK_RETRIES        20

BOOL LockVolume (HANDLE hVolume) {
  DWORD dwBytesReturned;
  DWORD dwSleepAmount;
  int nTryCount;
  dwSleepAmount = LOCK_TIMEOUT / LOCK_RETRIES;
  /* Do this in a loop until a timeout period has expired */
  for (nTryCount = 0; nTryCount < LOCK_RETRIES; nTryCount++) {
    if (DeviceIoControl(hVolume,
                        FSCTL_LOCK_VOLUME,
                        NULL, 0,
                        NULL, 0,
                        &dwBytesReturned,
                        NULL))
      return TRUE;
    Sleep(dwSleepAmount);
  }
  return FALSE;
}


/* 2.3.2; If the volume is currently mounted, DeviceIoControl returns a nonzero value, Otherwise,
   DeviceIoControl returns zero (0). To get extended error information, call GetLastError. */

#ifndef FSCTL_IS_VOLUME_MOUNTED
#define FSCTL_IS_VOLUME_MOUNTED  CTL_CODE(FILE_DEVICE_FILE_SYSTEM, 10, METHOD_BUFFERED, FILE_ANY_ACCESS)
#endif

BOOL HasVolumeBeenMounted (HANDLE hVolume) {
  DWORD dwBytesReturned;
  return DeviceIoControl(hVolume,
                         FSCTL_IS_VOLUME_MOUNTED,
                         NULL, 0,
                         NULL, 0,
                         &dwBytesReturned,
                         NULL);
}

BOOL DismountVolume (HANDLE hVolume) {
  DWORD dwBytesReturned;
  return DeviceIoControl(hVolume,
                         FSCTL_DISMOUNT_VOLUME,
                         NULL, 0,
                         NULL, 0,
                         &dwBytesReturned,
                         NULL);
}

BOOL PreventRemovalOfVolume (HANDLE hVolume, BOOL fPreventRemoval) {
  DWORD dwBytesReturned;
  PREVENT_MEDIA_REMOVAL PMRBuffer;
  PMRBuffer.PreventMediaRemoval = fPreventRemoval;
  return DeviceIoControl(hVolume,
                         IOCTL_STORAGE_MEDIA_REMOVAL,
                         &PMRBuffer, sizeof(PREVENT_MEDIA_REMOVAL),
                         NULL, 0,
                         &dwBytesReturned,
                         NULL);
}

BOOL AutoEjectVolume (HANDLE hVolume) {
  DWORD dwBytesReturned;
  return DeviceIoControl(hVolume,
                         IOCTL_STORAGE_EJECT_MEDIA,  /* IOCTL_STORAGE_LOAD_MEDIA */
                         NULL, 0,
                         NULL, 0,
                         &dwBytesReturned,
                         NULL);
}


/* 2.3.2; If the operation completes successfully, DeviceIoControl returns a nonzero value. If the operation
   fails or is pending, DeviceIoControl returns zero. To get extended error information, call GetLastError. */
BOOL LoadMedia (HANDLE hVolume) {
  DWORD dwBytesReturned;
  return DeviceIoControl(hVolume,
                         IOCTL_STORAGE_LOAD_MEDIA,
                         NULL, 0,
                         NULL, 0,
                         &dwBytesReturned,
                         NULL);
}

int EjectVolume (TCHAR cDriveLetter) {  /* extended for Agena 2.3.3 */
  HANDLE hVolume;
  int result = 4;  /* 0b100 */
  BOOL fRemoveSafely = FALSE;
  BOOL fAutoEject = FALSE;
  /* Open the volume. */
  hVolume = OpenVolume(cDriveLetter);
  if (hVolume == INVALID_HANDLE_VALUE)
    tools_setbit(&result, 3, 0);
  else {
    /* Lock and dismount the volume. */
    if (LockVolume(hVolume) && DismountVolume(hVolume)) {
      fRemoveSafely = TRUE;
      /* Set prevent removal to false and eject the volume. */
      if (PreventRemovalOfVolume(hVolume, FALSE) && AutoEjectVolume(hVolume))
        fAutoEject = TRUE;
      tools_setbit(&result, 1, fRemoveSafely && fAutoEject);
    }
    /* Close the volume so other processes can use the drive. */
    tools_setbit(&result, 2, CloseVolume(hVolume));
    /* fAutoEject == 1 ? -> Media in Drive has been ejected safely.
    fRemoveSafely == 1 ? -> Media in Drive can be safely removed. */
  }
  return result;
}

/* closes the CD-ROM drive tray, written for Agena 2.3.3 */
BOOL LoadVolume (TCHAR cDriveLetter) {
  HANDLE hVolume;
  int result = 4;  /* 0b100 */
  /* Open the volume. */
  hVolume = OpenVolume(cDriveLetter);
  if (hVolume == INVALID_HANDLE_VALUE) {
    tools_setbit(&result, 3, 0);
  } else {
    /* close the drive tray. */
    tools_setbit(&result, 1, LoadMedia(hVolume));
    /* Close the volume so other processes can use the drive. */
    tools_setbit(&result, 2, CloseVolume(hVolume));
  }
  return result;
}

/* checks whether a value has been mounted, written for Agena 2.3.3 */
int IsVolumeMounted (TCHAR cDriveLetter) {
  HANDLE hVolume;
  int result = 4;  /* 0b100 */
  /* Open the volume. */
  hVolume = OpenVolume(cDriveLetter);
  if (hVolume == INVALID_HANDLE_VALUE) {
    tools_setbit(&result, 3, 0);  /* invalid drive */
  } else {
    /* Check status */
    tools_setbit(&result, 1, HasVolumeBeenMounted(hVolume));
    /* Close the volume so other processes can use the drive. */
    tools_setbit(&result, 2, CloseVolume(hVolume));
  }
  return result;
}

BOOL IsRemovable (TCHAR cDriveLetter) {  /* 2.3.3, determines whether a drive is removable */
  TCHAR szRootName[5];
  wsprintf(szRootName, szRootFormat, cDriveLetter);
  return GetDriveType(szRootName) == DRIVE_REMOVABLE;
}

BOOL IsValidDrive (TCHAR cDriveLetter) {  /* 2.3.3 */
  UINT uDriveType;
  TCHAR szRootName[5];
  wsprintf(szRootName, szRootFormat, cDriveLetter);
  uDriveType = GetDriveType(szRootName);
  return uDriveType >= DRIVE_REMOVABLE && uDriveType <= DRIVE_RAMDISK;
}
#endif


#if defined(_WIN32) || defined(__linux__)
#define EJECT      0
#define CLOSETRAY  1
#endif

#ifdef __linux__

/* See J�rgen Wolf, `Linux-UNIX-Programmierung, Das umfassende Handbuch`, Galileo Computing, 3rd Ed., p. 164 */
#define CDROM "/dev/cdrom"

static int open_cdrom (void) {
  int fd = open(CDROM, O_RDONLY | O_NONBLOCK);
  if (fd == -1 && fd != ENOMEDIUM) return -1;
  else return fd;
}

static int open_tray (int cdrom) {
  if (ioctl(cdrom, CDROMEJECT) == -1) return -1;
  else return 0;
}

static int close_tray (int cdrom) {
  if (ioctl(cdrom, CDROMCLOSETRAY) == -1) return -1;
  else return 0;
}

static int stop_cdrom (int cdrom) {
  if (ioctl(cdrom, CDROMSTOP) == -1) return -1;
  else return 0;
}

#elif defined(__OS2__)
/* modified OS/2 code, for the original one see:
   http://hobbes.nmsu.edu/download/pub/os2/dev/c/cdclose.zip */
#define INCL_DOSMICS
#define IOCTL_CDROMDISK 	0x80
#define EJECT				0x44
#define CLOSETRAY 			0x45  /* Bug in toolkit */

APIRET CDTray (HFILE hCDROM, ULONG akce) {  /* 2.4.0 */
  PCSZ Signature = (PCSZ)"CD01";  /* compared to libdvdcss 1.2.10, this default is correct */
  ULONG PLength, DLength;
  struct {
    UCHAR First;
    UCHAR Last;
    ULONG Leadout;
  } DAudioDisk;
  PLength = 4;
  DLength = sizeof(DAudioDisk);
  memset(&DAudioDisk, 0, DLength);
  return DosDevIOCtl(hCDROM, IOCTL_CDROMDISK, akce, &Signature,
                     PLength, &PLength, &DAudioDisk, DLength, &DLength);
}
#endif

static int os_cdrom (lua_State *L) {
#if defined(_WIN32) || defined(__linux__) || defined(__OS2__)
  int result;
  unsigned int mode;
  size_t l;
  const char *devname, *option;
  l = result = 0;  /* to prevent compiler warnings */
#if defined(__OS2__) || defined(_WIN32)
  devname = agn_checklstring(L, 1, &l);
#else
  devname = NULL;
#endif
#if defined(__OS2__) || defined(_WIN32)
  option = agn_checkstring(L, 2);
#else
  option = agn_checkstring(L, 1);
#endif
  mode = -1;
  if ((strcmp(option, "eject") == 0) || (strcmp(option, "open") == 0))
    mode = EJECT;
  else if (strcmp(option, "close") == 0)
    mode = CLOSETRAY;
  else
    luaL_error(L, "Error in " LUA_QS ": unknown option " LUA_QS ".", "os.cdrom", option);
#if defined(__OS2__) || defined(_WIN32)
  if (l != 1)
    luaL_error(L, "Error in " LUA_QS ": drive name must be a single letter.", "os.cdrom");
#endif
#ifdef __OS2__  /* 2.4.0 */
  HFILE h;
  ULONG Action = 0;
  char *drive = concat(devname, ":", NULL);
  result = DosOpen((PCSZ)drive, &h, &Action, 0, 0,
    OPEN_ACTION_FAIL_IF_NEW | OPEN_ACTION_OPEN_IF_EXISTS,
    OPEN_FLAGS_FAIL_ON_ERROR | OPEN_FLAGS_DASD | OPEN_SHARE_DENYREADWRITE | OPEN_ACCESS_READONLY,
    NULL);
  if (result != 0) {
    xfree(drive);
    luaL_error(L, "Error in " LUA_QS ": could not access CD-ROM drive.", "os.cdrom");
  }
  xfree(drive);
  result = CDTray(h, mode);  /* to prevent compiler warnings */
  if (result != 0) lua_pushfail(L);
  else lua_pushtrue(L);
  DosClose(h);
#elif defined(_WIN32)
  if (mode == EJECT) {
    result = EjectVolume(*devname);
    if (!tools_getbit(result, 3)) lua_pushfail(L);  /* invalid drive */
    else lua_pushboolean(L, result == 7);
  } else {  /* CLOSETRAY */
    result = LoadVolume(*devname);
    if (!tools_getbit(result, 3))
      lua_pushfail(L);
    else
      lua_pushboolean(L, result == 7);
  }
#elif defined(__linux__)
  int fd = open_cdrom();
  if (fd == -1)
    luaL_error(L, "Error in " LUA_QS ": could not access CD-ROM drive.", "os.cdrom");
  if (stop_cdrom(fd) == -1)
    luaL_error(L, "Error in " LUA_QS ": could not stop CD-ROM drive.", "os.cdrom");
  if (mode == EJECT) {
    if (!open_tray(fd) == -1) lua_pushfail(L);
    else lua_pushtrue(L);
  } else {  /* CLOSETRAY */
    if (!close_tray(fd) == -1) lua_pushfail(L);
    else lua_pushtrue(L);
  }
  stop_cdrom(fd);
  if (close(fd) != 0) {
    agn_poptop(L);  /* pop result */
    luaL_error(L, "Error in " LUA_QS ": could not close CD-ROM drive handle.", "os.cdrom");
  }
#endif
#else
  lua_pushfail(L);
#endif
  return 1;
}


static int os_ismounted (lua_State *L) {  /* 2.3.3 */
#ifdef _WIN32
  int result;
  size_t l;
  const char *devname;
  l = 0;  /* to prevent compiler warnings */
  devname = agn_checklstring(L, 1, &l);
  if (l != 1)
    luaL_error(L, "Error in " LUA_QS ": drive name must be a single letter.", "os.ismounted");
  result = IsVolumeMounted(*devname);
  if (!tools_getbit(result, 3))  /* invalid drive */
    lua_pushfail(L);  /* invalid drive */
  else
    lua_pushboolean(L, result == 7);
#else
  lua_pushfail(L);
#endif
  return 1;
}


static int os_isremovable (lua_State *L) {  /* 2.3.3 */
#ifdef _WIN32
  size_t l;
  const char *devname;
  l = 0;  /* to prevent compiler warnings */
  devname = agn_checklstring(L, 1, &l);
  if (l != 1)
    luaL_error(L, "Error in " LUA_QS ": drive name must be a single letter.", "os.isremovable");
  lua_pushboolean(L, IsRemovable(*devname));
#else
  lua_pushfail(L);
#endif
  return 1;
}


#ifndef LUA_DOS  /* prevent compiler warnings */
static int os_isvaliddrive (lua_State *L) {  /* 2.3.3 */
  size_t l;
  const char *devname;
#ifdef __OS2__
  ULONG buff, mask, curDrive;
  APIRET rc;
#endif
  l = 0;  /* to prevent compiler warnings */
  devname = agn_checklstring(L, 1, &l);
  if (l != 1)
    luaL_error(L, "Error in " LUA_QS ": drive name must be a single letter.", "os.isvaliddrive");
#ifdef _WIN32
  lua_pushboolean(L, IsValidDrive(*devname));
#elif defined(__OS2__)
  rc = DosQueryCurrentDisk(&curDrive, &buff);
  if (rc != 0)
    luaL_error(L, "Error in " LUA_QS ": could not determine drives.", "os.drives");
  mask = 1 << (toupper((int)*devname) - 65);  /* uppercase table does not work */
  lua_pushboolean(L, (buff & mask) > 0);
#else
  lua_pushfail(L);
#endif
  return 1;
}
#endif

/* Returns the letter, a one character-string, of the current drive. */
static int os_curdrive (lua_State *L) {  /* 2.3.3 */
#ifdef __OS2__
  int rc;
  char s[1];
  ULONG pulDrive,    /* Pointer to the current drive number. (1=A, 2=B etc.) */
        pulLogical;  /* Pointer to a 32-bit bit area where each of the 26 lowest bits
                         represents a drive (0=A, 1=B etc.) If bit n is set(=1)
                         then the drive corresponding to n exists. */
  rc = DosQueryCurrentDisk(&pulDrive, &pulLogical);
  if (rc == 0) {
    s[0] = pulDrive + 64;
    lua_pushlstring(L, s, 1);
  } else
    lua_pushfail(L);
#elif defined(_WIN32) || defined(LUA_DOS)
  char *buffer = (char *)malloc(sizeof(char)*PATH_MAX);
  if (buffer == NULL)  /* Agena 1.0.4 */
    luaL_error(L, "Error in " LUA_QS ": memory allocation error.", "os.curdrive");
  if (getcwd(buffer, PATH_MAX) == NULL) { /* 1.6.4 to avoid compiler warnings and unfreed memory */
    xfree(buffer);
    luaL_error(L, "Error in " LUA_QS ": internal error.", "os.curdrive");  /* Agena 1.2.0 */
  }
  else
    lua_pushlstring(L, buffer, 1);
  xfree(buffer);
#else
  lua_pushfail(L);
#endif
  return 1;
}


/* The function unmounts the filesystem `fs`. If the option `true` is given for the second argument `force`,
   the function forces the disconnection even if the filesystem is in use by another process. The default is
   `false`. If your system cannot force a umount, this flag is simply ignored.

   The function works only if Agena is run with superuser rights. Depending on the operating system, it may
   only unmount filesystems that the UNIX kernel directly supports (in Linux, look into /proc/filesystems
   folder), e.g. ntfs-3g filesystems using the FUSE driver may not be unmounted.

   On success, `os.unmount` returns `true`, and `false` plus a string indicating the error reason, otherwise. */
static int os_unmount (lua_State *L) {  /* 2.4.0 */
  int r = 1;  /* one result */
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__)
  const char *mountpoint;
  int force, rc, en;
  mountpoint = agn_checkstring(L, 1);
  force = agnL_optboolean(L, 2, 0);
#if defined(__APPLE__)
  rc = unmount(mountpoint, force);
#else
  rc = umount2(mountpoint, force);
#endif
  en = errno;
  if (rc == 0)
    lua_pushtrue(L);
  else {
    lua_pushfalse(L);
    lua_pushstring(L, strerror(en));
    r++;
  }
#else
  lua_pushfail(L);
#endif
  return r;
}


/* 2.8.6, taken from lua_sys package written by Nodir Temirkhodjaev, <nodir.temir@gmail.com>, modified by Alexander Walz
   Converts each pathname argument to an absolute pathname, with symbolic links resolved to their actual targets and no .
   or .. directory entries. */
#ifndef LUA_DOS
static int os_realpath (lua_State *L) {
  const char *path = luaL_checkstring(L, 1);
#ifndef _WIN32
  char real[PATH_MAX];
  if (realpath(path, real))
    lua_pushstring(L, real);
#else
  WCHAR real[PATH_MAX];
  const int n = GetFullPathName(path, PATH_MAX, (char *)real, NULL);
  if (n != 0 && n < PATH_MAX)
    lua_pushstring(L, (const char*)real);
#endif
  else
    lua_pushfail(L);
  return 1;
}
#endif

#ifdef _WIN32
#define SYS_ERRNO		GetLastError()
#else
#define SYS_ERRNO		errno
#endif

/* 2.8.6, taken from lua_sys package written by Nodir Temirkhodjaev, <nodir.temir@gmail.com>, modified by Alexander Walz.
  With no argument, returns the message thrown by the operating system of the last occuring error */
static int os_strerror (lua_State *L) {
  int surplus = 0;
  const int err = luaL_optint(L, 1, SYS_ERRNO);
#ifndef _WIN32
#if defined(BSD) || (_POSIX_C_SOURCE >= 200112L || _XOPEN_SOURCE >= 600)
  char buf[512];
  if (!err) goto success;
  if (!strerror_r(err, buf, sizeof(buf)))
    lua_pushstring(L, buf);
#endif
  lua_pushstring(L, strerror(err));
#else
  const int flags = FORMAT_MESSAGE_IGNORE_INSERTS | FORMAT_MESSAGE_FROM_SYSTEM;
  WCHAR buf[512];
  if (!err) goto success;
  lua_pushstring(L, strerror(err));
#endif
  lua_pushinteger(L, err);
#ifdef _WIN32
  if (FormatMessageA(flags, NULL, err, 0, (char *)buf, sizeof(buf), NULL)) {
    lua_pushstring(L, (const char*)buf);  /* return translation of error message, too */
    surplus = 1;
  }
#endif
  return 2 + surplus;
#if defined(BSD) || (_POSIX_C_SOURCE >= 200112L || _XOPEN_SOURCE >= 600) || defined(_WIN32)
 success:
#endif
  lua_pushliteral(L, "OK");
  lua_pushinteger(L, err);
  return 2;
}


static const luaL_Reg syslib[] = {
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__)
  {"alarm",     os_alarm},
#endif
#if (defined(__unix__) && !defined(LUA_DOS)) || defined(__APPLE__) || defined(_WIN32)
  {"symlink",   os_symlink},          /* 1.12.1, added on June 15, 2013 */
  {"readlink",  os_readlink},         /* 1.12.1, added on June 17, 2013 */
#endif
  {"battery",   os_battery},          /* 0.14.0, added on March 13, 2009 */
  {"beep",      os_beep},             /* added on March 31, 2007 */
  {"cdrom",     os_cdrom},            /* added 2.3.3, November 25, 2014 */
  {"chdir",     os_chdir},            /* added July 07, 2008 */
  {"computername", os_computername},  /* 0.5.3  Sept 15, 2007 */
  {"cpuinfo",   os_cpuinfo},          /* added on February 07, 2013 */
  {"cpuload",   os_cpuload},          /* added on January 31, 2013 */
  {"curdrive",   os_curdrive},        /* added 2.3.3, November 30, 2014 */
  {"date",      os_date},
  {"datetosecs",   os_datetosecs},    /* added September 20, 2012 */
  {"difftime",  os_difftime},
  {"drives",    os_drives},           /* 0.26.0, 05.08.2009 */
  {"drivestat", os_drivestat},        /* 0.26.0, 05.08.2009 */
  {"endian",    os_endian},           /* 0.8.0, added on December 11, 2007 */
  {"environ",   os_environ},
  {"execute",   os_execute},          /* changed in 0.5.4 */
  {"exists",    os_exists},           /* added on April 09, 2007 */
  {"exit",      os_exit},
  {"fattrib",   os_fattrib},          /* 0.26.0, added August 06, 2009 */
  {"fcopy",     os_fcopy},            /* added on July 19, 2009 */
  {"freemem",   os_freemem},          /* 0.5.3  Sept 15, 2007 */
  {"fstat",     os_fstat},            /* added on October 11, 2008 */
  {"getenv",    os_getenv},
  {"hasnetwork",   os_hasnetwork},    /* added December 29, 2014 */
  {"isANSI",    os_isANSI},           /* added 0.28.2, 17.11.2009 */
  {"isdocked",  os_isdocked},         /* 2.4.0, December 29, 2014 */
  {"iseCS",     os_iseCS},            /* 2.4.0, January 09, 201�5 */
  {"ismounted", os_ismounted},        /* added 2.3.3, November 25, 2014 */
  {"isremovable", os_isremovable},    /* added 2.3.3, November 25, 2014 */
#ifndef LUA_DOS
  {"isvaliddrive", os_isvaliddrive},  /* added 2.3.3, November 25, 2014 */
#endif
  {"listcore",  os_listcore},         /* added on August 01, 2007 */
  {"login",     os_login},            /* 0.5.3  Sept 15, 2007 */
#if defined(_WIN32) || (defined(__unix__) && !defined(LUA_DOS)) || defined(__OS2__) || defined(__HAIKU__)  || defined(__APPLE__)
  {"memstate",  os_memstate},         /* 0.5.3  Sept 15, 2007 */
#endif
  {"mkdir",     os_mkdir},            /* added July 07, 2008 */
  {"monitor",   os_monitor},          /* added December 29, 2014 */
  {"mouse",     os_mouse},            /* added December 29, 2014 */
  {"mousebuttons", os_mousebuttons},  /* added March 28, 2010 */
  {"move",      os_move},
  {"now",       os_now},              /* added September 20, 2012 */
  {"pid",       os_pid},              /* added February 02, 2012 */
#ifndef LUA_DOS
  {"realpath",  os_realpath},         /* added September 22, 2015 */
#endif
  {"remove",    os_remove},
  {"rmdir",     os_rmdir},            /* added July 07, 2008 */
  {"screensize", os_screensize},      /* added March 28, 2010 */
  {"secstodate", os_secstodate},      /* added September 20, 2012 */
  {"setenv",    os_setenv},           /* added October 24, 2010 */
  {"setlocale", os_setlocale},
  {"settime",   os_settime},          /* added September 24, 2012 */
  {"strerror",  os_strerror},         /* 2.8.6, September 22, 2015 */
  {"system",    os_system},           /* 0.12.2  October 12, 2008 */
  {"terminate",  os_terminate},       /* 2.4.0, added December 29, 2014 */
  {"time",      os_time},
  {"tmpname",   os_tmpname},
  {"unmount",   os_unmount},          /* December 06, 2015 */
  {"uptime",    os_uptime},           /* November 25, 2014 */
  {"vga",        os_vga},             /* added on December 29, 2014 */
  {"wait",      os_wait},             /* added on March 31, 2007 */
  {NULL, NULL}
};

/* }====================================================== */



LUALIB_API int luaopen_os (lua_State *L) {
  luaL_register(L, LUA_OSLIBNAME, syslib);
  return 1;
}

