/*
** $Id: registry.c, initiated September 04, 2008 $
** Registry Access Library
** See Copyright Notice in agena.h
*/


/*
The function provides limited access to the registry, an interface between Agena and its C virtual machine which
mainly stores values used by userdata (see llist and numarray libraries), metatables of libraries written in C,
open files, and loaded libraries.

The package allows to read and write registry data in a limited way. It is useful if the debug library is not part
of a sandbox, see Chapter 6.15 Sandboxing.

The procedures provided by this package should be used instead of the debug.getregistry function which allows
to modify or even delete the registry which would jeopardise Agena integrity and stability. */

#include <stdlib.h>
#include <string.h>
#include <math.h>


#define registry_c
#define LUA_LIB

#include "agena.h"

#include "agnxlib.h"
#include "agenalib.h"
#include "agncmpt.h"  /* for ISINT */


#if !(defined(LUA_DOS) || defined(__OS2__) || defined(LUA_ANSI))
#define AGENA_REGISTRYLIBNAME "registry"
LUALIB_API int (luaopen_registry) (lua_State *L);
#endif


/* Returns a lightuserdata object, a simple C pointer, for the given string. The return must be used in calls
   to registry.anchor in order to insert new values into the registry. See also: utils.uuid. */
static int registry_anyid (lua_State *L) {  /* 2.9.2 */
  lua_pushlightuserdata(L, (void *)agn_checkstring(L, 1));
  return 1;
}


void aux_checklud (lua_State *L, int idx, const char *procname) {
  if (lua_type(L, idx) != LUA_TLIGHTUSERDATA) {
    luaL_error(L, "Error in " LUA_QS ": lightuserdata expected, got %s.", procname,
          luaL_typename(L, idx));
  }
}


/* Inserts a new key ~ value pair into the registry, where the key is a light userdata object returned by
   register.anyid, and the value the corresponding data. If the key already exists in the registry, the 
   function leaves the registry unchanged. The function returns nothing. */
static int registry_anchor (lua_State *L) {  /* 2.9.2 */
  aux_checklud(L, 1, "environ.anchor");
  if (lua_isnoneornil(L, 2)) {
    luaL_error(L, "Error in " LUA_QS ": second argument must not be null.",
      "environ.anchor", luaL_typename(L, 2));
  }
  lua_pushvalue(L, 1);  /* push lud */
  lua_gettable(L, LUA_REGISTRYINDEX);
  /* registry is now on the top */
  if (lua_isnil(L, -1)) {  /* only inject values if not yet included */
    agn_poptop(L);        /* pop null */
    lua_pushvalue(L, 1);  /* push lud again */
    lua_pushvalue(L, 2);  /* push value to be entered */
    lua_settable(L, LUA_REGISTRYINDEX);
  } else  /* do nothing */
    agn_poptop(L);  /* pop non-null value */
  /* leave nothing on stack */
  return 1;
}


/* The function returns the registry value indexed by key, which may be any type. If the registry entry is used by userdata,
   refers to loaded libraries or open files, the function just returns `null`. Otherwise, the entry is simply returned.
   If a C library metatable contains the __metatable read-only `metamethod`, `null` is returned, as well.

   With metatables defined by C libraries, it is still possible to delete or change metamethods, so extreme care should be 
   taken when referencing to metatables returned by registry.get. Especially, the __gc metamethod must not be deleted or changed. */
static int registry_get (lua_State *L) {
  int i;
  static const char *const exclude[] = {"FILE*", "_LOADED", "_LOADLIB", NULL};  /* do not return the corresponding entries */
  luaL_checkany(L, 1);
  lua_pushvalue(L, LUA_REGISTRYINDEX);
  if (agn_isnumber(L, 1) && ISINT(agn_tonumber(L, 1))) {
    agn_poptop(L);   /* pop registry */
    lua_pushnil(L);  /* do not return internal values occupied by userdata */
    return 1;
  }
  if (agn_isstring(L, 1)) {  /* do not return certain registry values */
    const char *needle = agn_tostring(L, 1);
    for (i=0; exclude[i]; i++) {
      if ((strcmp(needle, exclude[i]) == 0) || (strstr(needle, "LOADLIB:") == needle)) {  /* argument starts with one of the keys in exclude ? */
        lua_pushnil(L);
        return 1;
      }
    }
  }
  /* get field from registry */
  lua_pushvalue(L, 1);
  lua_rawget(L, -2);
  lua_remove(L, -2);  /* delete registry */
  /* is return a table and does it include a __metamethod read-only entry ?*/
  if (lua_istable(L, -1)) {
    lua_pushnil(L);
    while (lua_next(L, -2)) {
      if (lua_isstring(L, -2) && strcmp(agn_tostring(L, -2), "__metatable") == 0) {
        lua_pop(L, 3);   /* delete value, key, and table */
        lua_pushnil(L);  /* push null instead */
        break;
      }
      agn_poptop(L);  /* delete value, leave key on stack */
    }
  }
  return 1;
}


static const luaL_Reg registrylib[] = {
  {"anchor", registry_anchor},        /* added October 31, 2015 */
  {"anyid", registry_anyid},          /* added October 31, 2015 */
  {"get", registry_get},              /* added October 31, 2015 */
  {NULL, NULL}
};


/*
** Open registry library
*/
LUALIB_API int luaopen_registry (lua_State *L) {
  luaL_register(L, AGENA_REGISTRYLIBNAME, registrylib);
  return 1;
}