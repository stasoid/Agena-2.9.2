/*
** $Id: lstatlib.c, v 1.0.1 by Alexander Walz - initiated June 19, 2007
** Statistics library
** See Copyright Notice in agena.h
*/


#include <stdlib.h>
#include <string.h>
#include <math.h>

#ifdef X86ASM  /* 2.4.0 */
#include "x86math.h"
#endif

/* the following package ini declarations must be included after `#include <` and before `include #` ! */

#define stats_c
#define LUA_LIB

#include "agena.h"
#include "agnxlib.h"
#include "agenalib.h"
#include "agncmpt.h"  /* for TRUNC */
#include "agnhlps.h"  /* for tools_intpow, isnan, PI2, quicksort, k-th smallest */
#include "cephes.h"

#if !(defined(LUA_DOS) || defined(__OS2__) || defined(LUA_ANSI))
#define AGENA_STATSLIBNAME "stats"
LUALIB_API int (luaopen_stats) (lua_State *L);
#endif


/* creates an array a of type lua_Number with size n, FREE it ! */
#define createarray(a, n, procname) { \
  (a) = malloc((n)*sizeof(lua_Number)); \
  if ((a) == NULL) \
    luaL_error(L, "Error in " LUA_QS ": memory allocation failed.", (procname)); \
}


/* Computation of the arithmetic mean using Kahan-Babu�ka summation, see:
   `A generalized Kahan-Babu�ka Summation-Algorithm` by Andreas Klein, April 21, 2005 */

static lua_Number KahanBabuskaMean (lua_Number *a, size_t ii) {  /* 2.4.3 */
  size_t i;
  volatile lua_Number s, cs, ccs, t, c, cc, x;
  s = cs = ccs = 0;
  for (i=0; i < ii; i++) {
    x = a[i]/ii;
    t = s + x;
    c = (fabs(s) >= fabs(x)) ? (s - t) + x : (x - t) + s;
    s = t;
    t = cs + c;
    cc = (fabs(cs) >= fabs(c)) ? (cs - t) + c : (c - t) + cs;
    cs = t;
    ccs = ccs + cc;
  }
  return s + cs + ccs;  /* 2.4.4, no rounding in between */
}


static lua_Number KahanBabuskaSumdata (lua_Number *a, size_t ii, lua_Number p, lua_Number xm) {  /* 2.4.3 */
  size_t i;
  int isint;
  volatile lua_Number s, cs, ccs, t, c, cc, x;
  isint = ISINT(p);
  s = cs = ccs = 0;
  for (i=0; i < ii; i++) {
    if (isint) {
      if (p == 1) x = a[i] - xm;
      else if (p == 2) x = a[i]*a[i] - 2*a[i]*xm + xm*xm;
      else x = tools_intpow(a[i] - xm, p);
    } else
      x = pow(a[i] - xm, p);
    t = s + x;
    c = (fabs(s) >= fabs(x)) ? (s - t) + x : (x - t) + s;
    s = t;
    t = cs + c;
    cc = (fabs(cs) >= fabs(c)) ? (cs - t) + c : (c - t) + cs;
    cs = t;
    ccs += cc;
  }
  return (ii == 0) ? AGN_NAN : s + cs + ccs;  /* 2.4.4, no rounding in between */
}


static lua_Number KahanBabuskaSumdataLog (lua_Number *a, size_t ii, lua_Number p, lua_Number xm, int *sign) {  /* 2.5.2, idea taken from the COLT package published by CERN, Geneva */
  size_t i;
  int isint;
  volatile lua_Number s, cs, ccs, t, c, cc, x;
  isint = ISINT(p);
  s = cs = ccs = 0;
  for (i=0; i < ii; i++) {
    if (isint) {
      if (p == 1) x = a[i] - xm;
      else if (p == 2) x = a[i]*a[i] - 2*a[i]*xm + xm*xm;
      else x = tools_intpow(a[i] - xm, p);
    } else
      x = pow(a[i] - xm, p);
    if (x < 0) {
      *sign = *sign * (-1);
      x = -x;
    }
    x = log(x);  /* 2.5.3 fix */
    t = s + x;
    c = (fabs(s) >= fabs(x)) ? (s - t) + x : (x - t) + s;
    s = t;
    t = cs + c;
    cc = (fabs(cs) >= fabs(c)) ? (cs - t) + c : (c - t) + cs;
    cs = t;
    ccs += cc;
  }
  return (ii == 0) ? AGN_NAN : s + cs + ccs;
}


/* median of all values in an _already sorted table array or sequence_, June 18, 2007; tweaked Jan 13, 2008;
   faster than an Agena implementation; patched 0.25.4, August 01, 2009; patched 0.26.1, 11.08.2009;
   extended 1.6.0, April 31, 2012, extended 1.8.2, October 07, 2012; rewritten December 30, 2012 */

static lua_Number *aux_tonumarray (lua_State *L, int idx, size_t *size, const char *procname) {
  lua_Number *a, x2;
  size_t n, i, ii;
  ii = 0;
  a = NULL;  /* to prevent compiler warnings */
  switch (lua_type(L, idx)) {
    case LUA_TTABLE: {
      n = agn_asize(L, idx);
      createarray(a, n, procname);
      if (a == NULL) { *size = 0; return NULL; }
      for (i=1; i <= n; i++) {
        x2 = agn_getinumber(L, idx, i);  /* returns 0 if a value is non-numeric */
        if (!tools_isnan(x2)) a[++ii - 1] = x2;  /* 2.5.2 patch */
      }
      break;
    }
    case LUA_TSEQ: {
      n = agn_seqsize(L, idx);
      createarray(a, n, procname);
      if (a == NULL) { *size = 0; return NULL; }
      for (i=1; i <= n; i++) {
        x2 = lua_seqgetinumber(L, idx, i);
        if (!tools_isnan(x2)) a[++ii - 1] = x2;
      }
      break;
    }
    default: {
      luaL_error(L, "Error in " LUA_QS ": table or sequence expected, got %s.", procname, luaL_typename(L, idx));
    }
  }
  *size = ii;
  return a;  /* FREE it in calling function */
}


static int stats_amean (lua_State *L) {
  size_t ii;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.amean");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)  /* 2.2.3 */
    lua_pushfail(L);
  else
    lua_pushnumber(L, KahanBabuskaMean(a, ii));  /* 2.4.3 improvement */
  xfree(a);
  return 1;
}


static int stats_median (lua_State *L) {
  size_t ii;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.median");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else
    lua_pushnumber(L, ii&1 ? tools_kth_smallest(a, ii, ii/2) :
      (tools_kth_smallest(a, ii, ii/2 - 1) + tools_kth_smallest(a, ii, ii/2))/2
    );
  xfree(a);
  return 1;
}


/* Absolute deviation of all the values in a structure (the mean of the equally likely absolute deviations
   from the mean); absolute deviation is more robust as it is less sensitive to outliers. Also called `mean
   deviation`. 1.12.8, September 13, 2013, improved 2.2.0 RC 2, May 20, 2014, improved 2.2.3, 30.06.2014 */

static int stats_ad (lua_State *L) {
  size_t i, ii;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.ad");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {  /* 2.2.3 speed optimisation */
    lua_Number sum, mean;
    sum = 0;
    mean = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
    for (i=0; i < ii; i++)
      sum += fabs(a[i] - mean);  /* avoid dividing each difference by the number of observations separately */
    if (lua_isnoneornil(L, 2))
      lua_pushnumber(L, sum/ii);
    else
      lua_pushnumber(L, sum/(ii*fabs(mean)));
  }
  xfree(a);
  return 1;
}


static int stats_mad (lua_State *L) {  /* 1.12.8, September 13, 2013, improved 2.2.0 RC 2, May 20, 2014 */
  size_t i, ii;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.mad");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)  /* 2.2.3 */
    lua_pushfail(L);
  else {
    lua_Number median;
    median = ii&1 ? tools_kth_smallest(a, ii, ii/2) :
      (tools_kth_smallest(a, ii, ii/2-1) + tools_kth_smallest(a, ii, ii/2))/2;
    for (i=0; i < ii; i++)
      a[i] = fabs(a[i] - median);
    if (lua_isnoneornil(L, 2)) {
      lua_pushnumber(L, ii&1 ? tools_kth_smallest(a, ii, ii/2) :
        (tools_kth_smallest(a, ii, ii/2-1) + tools_kth_smallest(a, ii, ii/2))/2
      );
    } else {
      lua_pushnumber(
         L, ii&1 ? tools_kth_smallest(a, ii, ii/2) / median :
         (tools_kth_smallest(a, ii, ii/2-1) + tools_kth_smallest(a, ii, ii/2))/2 / median);
    }
  }
  xfree(a);
  return 1;
}


static int stats_md (lua_State *L) {  /* 2.4.1 */
  size_t i, ii;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.md");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {  /* 2.2.3 speed optimisation */
    lua_Number sum, median;
    sum = 0;
    median = ii&1 ? tools_kth_smallest(a, ii, ii/2) :
      (tools_kth_smallest(a, ii, ii/2-1) + tools_kth_smallest(a, ii, ii/2))/2;
    for (i=0; i < ii; i++)
      sum += fabs(a[i] - median);  /* avoid dividing each difference by the number of observations separately */
    if (lua_isnoneornil(L, 2))
      lua_pushnumber(L, sum/ii);
    else
      lua_pushnumber(L, sum/ii / fabs(median));
  }
  xfree(a);
  return 1;
}


/* sorts numbers in ascending order */

#define SWAP(a,b,t) { (t) = (a); (a) = (b); (b) = (t); }

/* see: http://www.ethoberon.ethz.ch/WirthPubl/AD.pdf
   `Algorithms and Data Structures` by Niklaus Wirth 1985, Oberon version: August 2004 */

/* PROCEDURE NonRecursiveQuickSort;
  CONST M = 12;
  VAR i, j, L, R, s: INTEGER; x, w: Item;
  low, high: ARRAY M OF INTEGER; (*index stack*)
  BEGIN
    s := 0; low[0] := 0; high[0] := n-1;
    REPEAT (*take top request from stack*)
      L := low[s]; R := high[s]; DEC(s);
      REPEAT (*partition a[L] ... a[R]*)
        i := L; j := R; x := a[(L+R) DIV 2];
        REPEAT
          WHILE a[i] < x DO INC(i) END ;
          WHILE x < a[j] DO DEC(j) END ;
          IF i <= j THEN
            w := a[i]; a[i] := a[j]; a[j] := w; i := i+1; j := j-1
          END
        UNTIL i > j;
        //IF i < R THEN (*stack request to sort right partition*)
        //  INC(s); low[s] := i; high[s] := R
        //END ;
        IF j - L < R - i THEN
          IF i < R THEN (*stack request for sorting right partition*)
            INC(s); low[s] := i; high[s] := R
          END ;
          R := j (*continue sorting left partition*)
        ELSE
          IF L < j THEN (*stack request for sorting left parition*)
            INC(s); low[s] := L; high[s] := j
          END;
        L := i (*continue sorting right partition*)
        END
        R := j (*now L and R delimit the left partition*)
      UNTIL L >= R
    UNTIL s = 0
  END NonRecursiveQuickSort */

#define SWAP(a,b,t) { (t) = (a); (a) = (b); (b) = (t); }

int tools_dnonrecursivequicksort (double *a, size_t n) {
  long int i, j, L, R, M, nsmall, s, *low, *high;
  double x, t;
  M = 2 * log(n)/log(2) + 1;
  nsmall = 6;
  /* index stack */
  low = malloc(M * sizeof(long int));
  if (low == NULL) return 1;
  high = malloc(M * sizeof(long int));
  if (high == NULL) {
    xfree(low);
    return 1;
  }
  /* Go ! */
  s = 0;
  low[0] = 0; high[0] = n - 1;
  do {  /* take top request from stack */
    /* if (s < 0 || s >= M) printf("WARNING!\n"); */
    L = low[s]; R = high[s]; s--;
    if (R - L + 1 > nsmall) {
      do {  /* partition a[L] ... a[R] */
        i = L; j = R; x = a[(L+R)/2];
        do {
          while (a[i] < x) i++;
          while (x < a[j]) j--;
          if (i <= j) {
            SWAP(a[i], a[j], t); i++; j--;
          }
        } while (i <= j);
        if (j - L < R - i) {
          if (i < R) {  /* stack request for sorting right partition */
            s++; low[s] = i; high[s] = R;
          }
          R = j;  /* continue sorting left partition */
        } else {
          if (L < j) {  /* stack request for sorting left parition */
            s++; low[s] = L; high[s] = j;
          }
          L = i;  /* continue sorting right partition */
        }
        /* if (i < R) { s++; low[s] = i; high[s] = R; };
        R = j;  // now L and R delimit the left partition */
      } while (L < R);
    } else {
      for (i=L; i < R; i++) {
        for (j=i; j <= R; j++) {
          if (a[i] > a[j]) SWAP(a[i], a[j], t);
        }
      }
    }
  } while (s >= 0);
  xfree(low); xfree(high);
  return 0;
}

static int stats_sorted (lua_State *L) {
  int mode;
  size_t ii;
  lua_Number *a;
  static const char *const modenames[] = {"quicksort", "pixelsort", "heapsort", "introsort", "nrquicksort", NULL};
  luaL_checkany(L, 1);
  ii = 0;
  mode = 3;  /* 0 = recursive quicksort
                1 = pixel quicksort
                2 = heapsort
                3 = introsort (default)
                4 = non-recursive quicksort ala Niklaus Wirth */
  if (lua_gettop(L) == 2)  /* option given */
    mode = (lua_isboolean(L, 2)) ? agn_istrue(L, 2) : luaL_checkoption(L, 2, "introsort", modenames);
  a = aux_tonumarray(L, 1, &ii, "stats.sorted");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {
    int type;
    size_t i;
    type = lua_type(L, 1);
    switch (mode) {
      case 0:  /* use recursive quicksort implementation */
        tools_dquicksort(a, 0, ii - 1);
        break;
      case 1:  /* 1.11.6, use pixel sort function: this _can_ be 15 % faster on older systems than the
           recursive quicksort implementation for lists of numbers in random order. Only if the list is already
           sorted in descending order, pixel sort is much slower. */
        if (pixel_qsort(a, ii) == 0) {
          xfree(a);  /* 1.12.4 */
          luaL_error(L, "Error in " LUA_QS ": internal memory allocation error (stack too large).", "stats.sorted");
        }
        break;
      case 2:  /* use heapsort, 2.3.0 */
        tools_dheapsort(a, 0, ii - 1);
        break;
      case 3:  /* use introsort (default), 2.3.0 */
        tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));
        break;
      case 4:  /* use non-recursive quicksort, 2.3.0 */
        if (tools_dnonrecursivequicksort(a, ii) == 1) {
          xfree(a);
          luaL_error(L, "Error in " LUA_QS ": internal memory allocation error (stack too large).", "stats.sorted");
        }
        break;
      default:
        xfree(a);
        luaL_error(L, "Error in " LUA_QS ": this should not happen.", "stats.sorted");
    }
    if (type == LUA_TTABLE) {
      lua_createtable(L, ii, 0);
      for (i=0; i < ii; i++)
        lua_rawsetinumber(L, -1, i + 1, a[i]);
    } else {
      agn_createseq(L, ii);
      for (i=0; i < ii; i++)
        lua_seqsetinumber(L, -1, i + 1, a[i]);
    }
  }
  xfree(a);
  return 1;
}


/* stats.smallest

   Returns the k-th smallest element in the numeric table or sequence a. If k is not given, it is set to 1.
   Code tweaking 2.2.0 RC 2, May 20, 2014 */

static int stats_smallest (lua_State *L) {
  size_t ii, k;
  lua_Number *a;
  luaL_checkany(L, 1);
  k = luaL_optinteger(L, 2, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.smallest");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else if (k < 1 || k > ii) {
    xfree(a);
    luaL_error(L, "Error in " LUA_QS ": second argument too small or too large.", "stats.smallest");
  } else
    lua_pushnumber(L, tools_kth_smallest(a, ii, k - 1));
  xfree(a);
  return 1;
}


/* tbl_minmax: returns the smallest and largest value in a list. If the option
   'sorted' is given, the list is not traversed, instead the first and the last entry
   in the list is returned.
   If the list is empty or has only one element, fail is returned. June 20, 2007;
   modified August 01, 2009, 0.25.4; modified 0.26.1, 11.08.2009, extended 1.3.3, 30.01.2011;
   patched 1.6.0, April 01, 2012 */

static int stats_minmax (lua_State *L) {
  int i, n, type;
  lua_Number min, max, number;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  const char *option = luaL_optstring(L, 2, "default");
  n = agn_nops(L, 1);
  if (n < 2) {
    lua_pushfail(L);
    return 1;
  }
  switch (type) {
    case LUA_TTABLE: {
      lua_newtable(L);
      if (strcmp(option, "sorted") == 0) {
        lua_pushinteger(L, 1);
        lua_rawgeti(L, 1, 1);
        lua_rawset(L, -3);
        lua_pushinteger(L, 2);
        lua_rawgeti(L, 1, n);
        lua_rawset(L, -3);
        return 1;
      }
      lua_pushnil(L);
      max = -HUGE_VAL; min = HUGE_VAL;  /* Agena 1.6.0 patch */
      while (lua_next(L, 1) != 0) {
        if (agn_isnumber(L, -1)) {
          number = agn_tonumber(L, -1);
          if (number < min)
            min = number;
          if (number > max)
            max = number;
        }
        agn_poptop(L);  /* pop value */
      }
      lua_rawsetinumber(L, -1, 1, min);
      lua_rawsetinumber(L, -1, 2, max);
      break;
    }
    case LUA_TSEQ: {
      agn_createseq(L, 2);
      if (strcmp(option, "sorted") == 0) {
        lua_seqgeti(L, 1, 1);
        lua_seqseti(L, -2, 1);
        lua_seqgeti(L, 1, n);
        lua_seqseti(L, -2, 2);
        return 1;
      }
      min = lua_seqgetinumber(L, 1, 1);
      max = min;
      for (i=2; i<=n; i++) {
        number = lua_seqgetinumber(L, 1, i);
        if (number < min)
          min = number;
        if (number > max)
          max = number;
      }
      lua_seqsetinumber(L, -1, 1, min);
      lua_seqsetinumber(L, -1, 2, max);
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  return 1;
}


/* IOS: Index On Stability
   operates on sorted and unsorted list but with different results ! Sum up absolute differences
   between neighbouring points and divide by the number of differences. This indicator is quite
   useful to find out how stable or volatile a distribution is.

   This C implementation is at least 3 to five times faster than the almost equivalent versions:

   stats.ios := proc(x :: table) is
      local n, result := size(x), 0;      # n: size of table, result: intermediate results
      for i from 2 to n do
         inc result, abs(x[i] - x[i-1])   # add absolute distances of neighboring values
      od;
      return result/(n - 1)               # divide by number of entries - 1 and return result
   end;

   or for short:

   stats.ios := << x :: table -> sadd(stats.deltalist(x, true))/(size x - 1) >> */

static int stats_ios (lua_State *L) {  /* 2.2.1 change */
  size_t i, n;
  int type, option;
  lua_Number result, x1, x2, ios2, max;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  n = agn_nops(L, 1);
  if (n < 2) {
    lua_pushfail(L);
    return 1;
  }
  option = !(lua_isnoneornil(L, 2));
  result = ios2 = 0;
  max = 1;
  switch (type) {
    case LUA_TTABLE: {
      if (option) {  /* scale distribution to [-infinity, 1], 2.2.1 */
        max = 0;
        for (i=1; i <= n; i++) {
          x1 = agn_getinumber(L, 1, i);
          if (fabs(x1) > fabs(max)) max = x1;
        }
      }
      x1 = agn_getinumber(L, 1, 1);
      for (i=2; i <= n; i++) {
        x2 = agn_getinumber(L, 1, i);
        result += fabs(x2 - x1)/max;
        x1 = x2;
      }
      break;
    }
    case LUA_TSEQ: {
      if (option) {  /* scale distribution to [-infinity, 1], 2.2.1 */
        max = 0;
        for (i=1; i <= n; i++) {
          x1 = lua_seqgetinumber(L, 1, i);
          if (fabs(x1) > fabs(max)) max = x1;
        }
      }
      x1 = lua_seqgetinumber(L, 1, 1);
      for (i=2; i <= n; i++) {
        x2 = lua_seqgetinumber(L, 1, i);
        result += fabs(x2 - x1)/max;
        x1 = x2;
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  lua_pushnumber(L, result/((lua_Number)n - 1));
  return 1;
}


/* sum, Agena 1.8.2, 05.10.2012; extended 1.8.3, 08.10.2012; extended 2.5.2, 06/04/2015

   Computes the sums of all numbers in a table or sequence. Contrary to the `sadd` operator, it prevents round-off
   errors during summation. Inspired by the TI-Nspire(tm) CX CAS.

   The function also accepts structures including the value `undefined`. In this case, all `undefined's` are simply
   ignored and skipped in the computation of the sums. Thus the function can be used with incomplete observations. */

void aux_createarraysumdatax (lua_State *L, lua_Number *a, size_t *size, size_t n, size_t nargs, int fngiven, int objtype,
     const char *procname) {
  size_t i, ii, j;
  lua_Number x2;
  ii = 0;
  switch (objtype) {
    case LUA_TTABLE: {
      if (!fngiven) {
        for (i=1; i <= n; i++) {
          x2 = agn_getinumber(L, 1, i);
          if (!tools_isnan(x2)) a[ii++] = x2;
        }
      } else {  /* procedure passed */
        for (i=1; i <= n; i++) {
          lua_pushvalue(L, 1);  /* push function */
          x2 = agn_getinumber(L, 2, i);
          lua_pushnumber(L, x2);
          for (j=5; j <= nargs; j++) {
            lua_pushvalue(L, j);
          }
          lua_call(L, 1 + nargs - 4, 1);  /* call function with the given arguments and one result, 1.8.3 */
          if (agn_istrue(L, -1)) { if (!tools_isnan(x2)) a[ii++] = x2; }
          agn_poptop(L);
        }
      }
      break;
    }
    case LUA_TSEQ: {
      if (!fngiven) {
        for (i=1; i <= n; i++) {
          x2 = lua_seqgetinumber(L, 1, i);
          if (!tools_isnan(x2)) a[ii++] = x2;
        }
      } else {
        for (i=1; i <= n; i++) {
          lua_pushvalue(L, 1);  /* push function */
          x2 = lua_seqgetinumber(L, 2, i);
          lua_pushnumber(L, x2);
          for (j=5; j <= nargs; j++) {
            lua_pushvalue(L, j);
          }
          lua_call(L, 1 + nargs - 4, 1);  /* call function with the given arguments and one result, 1.8.3 */
          if (agn_istrue(L, -1)) { if (!tools_isnan(x2)) a[ii++] = x2; }
          agn_poptop(L);
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  *size = ii;
}

static int stats_sumdata (lua_State *L) {
  size_t ii, n, nargs;
  int objtype, fngiven;
  lua_Number *a, p, xm;
  luaL_checkany(L, 1);
  ii = 0;
  nargs = lua_gettop(L);
  if (nargs < 1)
    luaL_error(L, "Error in " LUA_QS ": expected one or more arguments, got none.", "stats.sumdata");
  fngiven = lua_type(L, 1) == LUA_TFUNCTION;
  objtype = lua_type(L, 1 + fngiven);
  luaL_typecheck(L, objtype == LUA_TTABLE || objtype == LUA_TSEQ, 1 + fngiven, "table or sequence expected", objtype);
  p = agnL_optnumber(L, 2 + fngiven, 1);   /* the moment (power p) */
  xm = agnL_optnumber(L, 3 + fngiven, 0);  /* origin, quantity about which the moment is computed (optional value to be subtracted from x[i]) */
  n = agn_nops(L, 1 + fngiven);  /* number of elements in structure */
  createarray(a, n, "stats.sumdata");
  aux_createarraysumdatax(L, a, &ii, n, nargs, fngiven, objtype, "stats.sumdata");
  if (ii < 2)
    lua_pushfail(L);
  else
    lua_pushnumber(L, KahanBabuskaSumdata(a, ii, p, xm)); /* 2.4.3, 2.5.2 improvement */
  xfree(a);
  return 1;
}


/* Sums up the natural logarithms of all the observations in a distribution using Kahan-Babuska round-off prevention. Idea taken
   from the COLT package published by CERN. */

static int stats_sumdataln (lua_State *L) {
  size_t ii, n, nargs;
  int objtype, fngiven, sign;
  lua_Number *a, p, xm;
  luaL_checkany(L, 1);
  ii = 0;
  sign = 1;
  nargs = lua_gettop(L);
  if (nargs < 1)
    luaL_error(L, "Error in " LUA_QS ": expected one or more arguments, got none.", "stats.sumdataln");
  fngiven = lua_type(L, 1) == LUA_TFUNCTION;
  objtype = lua_type(L, 1 + fngiven);
  luaL_typecheck(L, objtype == LUA_TTABLE || objtype == LUA_TSEQ, 1 + fngiven, "table or sequence expected", objtype);
  p = agnL_optnumber(L, 2 + fngiven, 1);   /* the moment (power p) */
  xm = agnL_optnumber(L, 3 + fngiven, 0);  /* origin, quantity about which the moment is computed (optional value to be subtracted from x[i]) */
  n = agn_nops(L, 1 + fngiven);  /* number of elements in structure */
  createarray(a, n, "stats.sumdata");
  aux_createarraysumdatax(L, a, &ii, n, nargs, fngiven, objtype, "stats.sumdataln");
  if (ii < 2)
    lua_pushfail(L);
  else {
    lua_Number r;
    r = KahanBabuskaSumdataLog(a, ii, p, xm, &sign);
    lua_pushnumber(L, (sign == -1) ? AGN_NAN : r); /* 2.4.3, 2.5.2 improvement */
  }
  xfree(a);
  return 1;
}


/* Cumulative sum, Agena 1.7.9a, 11.09.2012, extended Agena 1.8.2, 05.10.2012

   Uses a modified Kahan algorithm developed by Kazufumi Ozawa published in his paper `Analysis and Improvement of
   Kahan's Summation Algorithm` to prevent round-off errors during summation. Inspired by the cumulativeSum function
   available on the TI-Nspire(tm) CX CAS.

   The function also accepts structures including the value `undefined`. In this case, all `undefined's` are simply
   included in the resulting structure and are ignored in the computation of the sums. Thus the function can be used
   with incomplete observations. */

static int stats_cumsum (lua_State *L) {
  size_t i, n;
  int type;
  volatile lua_Number q, s, sold, u, v, w, x, t;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  n = agn_nops(L, 1);
  if (n < 1) {
    lua_pushfail(L);
    return 1;
  }
  s = q = 0;
  switch (type) {
    case LUA_TTABLE: {
      lua_createtable(L, n, 0);
      for (i=1; i <= n; i++) {
        x = agn_getinumber(L, 1, i);
        if (tools_isnan(x)) {
          lua_rawsetinumber(L, -1, i, x);
          continue;
        }
        /* Kahan summation to 1) prevent overflows with too large sums and 2) round-off errors; Kahan-Babu�ka due to its nature cannot be used here */
        v = x - q;
        sold = s;
        s = s + v;
        if (fabs(x) < fabs(q)) {
          t = x;
          x = -q;
          q = t;
        }
        u = (v - x) + q;
        if (fabs(sold) < fabs(v)) {
          t = sold;
          sold = v;
          v = t;
        }
        w = (s - sold) - v;
        q = u + w;
        lua_rawsetinumber(L, -1, i, s);
        /* s contains the cumulative sum */
      }
      break;
    }
    case LUA_TSEQ: {
      agn_createseq(L, n);
      for (i=1; i <= n; i++) {
        x = lua_seqgetinumber(L, 1, i);
        if (tools_isnan(x)) {
          lua_seqsetinumber(L, -1, i, x);
          continue;
        }
        /* Kahan summation to 1) prevent overflows with too large sums and 2) round-off errors; Kahan-Babu�ka due to its nature cannot be used here */
        v = x - q;
        sold = s;
        s = s + v;  /* s contains the mean of the observation */
        if (fabs(x) < fabs(q)) {
          t = x;
          x = -q;
          q = t;
        }
        u = (v - x) + q;
        if (fabs(sold) < fabs(v)) {
          t = sold;
          sold = v;
          v = t;
        }
        w = (s - sold) - v;
        q = u + w;
        lua_seqsetinumber(L, -1, i, s);
        /* s contains the cumulative sum */
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  return 1;
}


/* checks whether all numbers in a table or sequence obj are stored in ascending order. If a value in obj is
   not a number, it is ignored. If obj is a table, you have to make sure that it does not contain holes.
   If it contains holes, apply tables.entries on obj. See also: sort. March 31, 2012, extended November 17, 2012 */

static int stats_issorted (lua_State *L) {
  size_t i, j, n, nargs;
  int type, isf;
  lua_Number x1, x2;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  if ((isf = !lua_isnoneornil(L, 2)))  /* is there a 2nd argument?  Agena 1.8.9 */
    luaL_checktype(L, 2, LUA_TFUNCTION);
  nargs = lua_gettop(L);
  n = agn_nops(L, 1);
  if (n < 2) {
    lua_pushfail(L);
    return 1;
  }
  switch (type) {
    case LUA_TTABLE: {
      x1 = agn_getinumber(L, 1, 1);
      if (isf) {  /* function passed as second argument ?, Agena 1.8.9 */
        for (i=2; i <= n; i++) {
          lua_pushvalue(L, 2);  /* push function */
          lua_pushnumber(L, x1);
          lua_rawgeti(L, 1, i);
          x2 = lua_tonumber(L, -1);
          for (j=3; j <= nargs; j++) lua_pushvalue(L, j);
          lua_call(L, nargs, 1);
          if (lua_isboolean(L, -1) && agn_isfalse(L, -1))
            return 1;
          agn_poptop(L);  /* pop result of lua_call */
          x1 = x2;
        }
        lua_pushtrue(L);
      } else {
        for (i=2; i <= n; i++) {
          x2 = agn_getinumber(L, 1, i);
          if (x1 > x2) {
            lua_pushfalse(L);
            return 1;
          }
          x1 = x2;
        }
        lua_pushtrue(L);
      }
      break;
    }
    case LUA_TSEQ: {
      x1 = lua_seqgetinumber(L, 1, 1);
      if (isf) {  /* function passed as second argument ?, Agena 1.8.9 */
        for (i=2; i <= n; i++) {
          lua_pushvalue(L, 2);  /* push function */
          lua_pushnumber(L, x1);
          lua_seqrawgeti(L, 1, i);
          x2 = lua_tonumber(L, -1);
          for (j=3; j <= nargs; j++) lua_pushvalue(L, j);
          lua_call(L, nargs, 1);
          if (lua_isboolean(L, -1) && agn_isfalse(L, -1))
            return 1;
          agn_poptop(L);  /* pop result of lua_call */
          x1 = x2;
        }
        lua_pushtrue(L);
      } else {
        for (i=2; i <= n; i++) {
          x2 = lua_seqgetinumber(L, 1, i);
          if (x1 > x2) {
            lua_pushfalse(L);
            return 1;
          }
          x1 = x2;
        }
        lua_pushtrue(L);
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  return 1;
}


/* `stats.deltalist` returns a structure of the deltas of neighbouring elements. It is an extended version of
   the TI-Nspire(tm) CX CAS version of `deltaList`. If obj is a table, you have to make sure that it does not
   contain holes. If it contains holes, apply tables.entries on obj. 12.03.2012 */

static int stats_deltalist (lua_State *L) {
  size_t i, n;
  int type, applyabs;
  lua_Number x1, x2;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  n = agn_nops(L, 1);
  applyabs = lua_toboolean(L, 2);  /* compute absolute differences ? */
  if (n < 2) {
    lua_pushfail(L);
    return 1;
  }
  switch (type) {
    case LUA_TTABLE: {
      lua_createtable(L, n-1, 0);  /* Agena 1.7.10 */
      x1 = agn_getinumber(L, 1, 1);
      if (applyabs) {
        for (i=2; i <= n; i++) {
          x2 = agn_getinumber(L, 1, i);
          lua_rawsetinumber(L, -1, i-1, fabs(x2 - x1));
          x1 = x2;
        }
      } else {
        for (i=2; i <= n; i++) {
          x2 = agn_getinumber(L, 1, i);
          lua_rawsetinumber(L, -1, i-1, x2 - x1);
          x1 = x2;
        }
      }
      break;
    }
    case LUA_TSEQ: {
      agn_createseq(L, n-1);  /* Agena 1.7.10 */
      x1 = lua_seqgetinumber(L, 1, 1);
      if (applyabs) {
        for (i=2; i <= n; i++) {
          x2 = lua_seqgetinumber(L, 1, i);
          lua_seqsetinumber(L, -1, i-1, fabs(x2 - x1));
          x1 = x2;
        }
      } else {
        for (i=2; i <= n; i++) {
          x2 = lua_seqgetinumber(L, 1, i);
          lua_seqsetinumber(L, -1, i-1, x2 - x1);
          x1 = x2;
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  return 1;
}


/* stats.tovals: convert strings in a table or sequence to numbers. If a string cannot be converted,
   it is returned unchanged. Equivalent to
      stats.tovals := << (o) -> map( << (x) -> tonumber(x) >>, o) >>,
   but up to 40 % faster. */

static int tonumber (lua_State *L, int idx) {
  lua_Number n;
  int exception, type;
  luaL_checkany(L, idx);
  type = lua_type(L, idx);  /* 2.8.1 */
  if (type == LUA_TSTRING || type == LUA_TNUMBER) {
    n = agn_tonumberx(L, idx, &exception);
    if (exception) { /* conversion failed ? Check whether string contains a complex value */
      int cexception;
#ifndef PROPCMPLX
      agn_Complex c;
      c = agn_tocomplexx(L, idx, &cexception);
#else
      lua_Number c[2];
      agn_tocomplexx(L, idx, &cexception, c);
#endif
      if (cexception == 0)
#ifndef PROPCMPLX
        agn_createcomplex(L, c);
#else
        agn_createcomplex(L, c[0], c[1]);
#endif
      else
        lua_pushvalue(L, idx);
    }
    else
      lua_pushnumber(L, n);
  } else if (type == LUA_TCOMPLEX) {
    lua_pushvalue(L, idx);
  } else {
    lua_pushfail(L);
  }
  lua_remove(L, idx - 1);  /* remove original value, 2.8.1 */
  return 1;
}

static int stats_tovals (lua_State *L) {
  switch (lua_type(L, 1)) {
    case LUA_TTABLE: {
      /* very rough guess whether table is an array or dictionary */
      size_t n = lua_objlen(L, 1);
      if (n == 0)  /* assume table is a dictionary */
        lua_createtable(L, 0, agn_size(L, 1));
      else
        lua_createtable(L, n, 0);  /* lua_objlen not always returns correct results ! */
      lua_pushnil(L);
      while (lua_next(L, 1)) {  /* push the table key and the table value */
        tonumber(L, -1);
        lua_rawset2(L, -3);  /* store value in a table, leave key on stack */
      }
      break;
    }  /* end of case LUA_TTABLE */
    case LUA_TSET: {
      agn_createset(L, agn_ssize(L, 1));
      lua_pushnil(L);
      while (lua_usnext(L, 1)) {  /* push item twice */
        tonumber(L, -1);
        lua_sinsert(L, -3);       /* store result to new set */
      }
      break;
    }  /* end of case LUA_TSET */
    case LUA_TSEQ: {
      size_t i, nops;
      nops = agn_seqsize(L, 1);
      agn_createseq(L, nops);
      for (i=0; i < nops; i++) {
        lua_seqgeti(L, 1, i+1);   /* push item */
        tonumber(L, -1);
        lua_seqinsert(L, -2);     /* store result to new sequence */
      }
      break;
    }  /* end of case LUA_TSEQ */
    default:
      luaL_error(L, "Error in " LUA_QS ": table, set, or sequence expected, got %s.", "stats.tovals",
        luaL_typename(L, 1));
  }  /* end of switch */
  return 1;
}


/*

Credit: Agena's `stats.scale` is a port of the ALGOL 60 function REASCL, being part of the NUMAL package,
originally published by The Stichting Centrum Wiskunde & Informatica, Amsterdam, The Netherlands.

The Stichting Centrum Wiskunde & Informatica (Stichting CWI) (legal successor of Stichting Mathematisch
Centrum) at Amsterdam has granted permission to Paul McJones to attach the integral NUMAL library manual
to his software preservation project web page.

( URL: http://www.softwarepreservation.org/projects/ALGOL/applications/ )

It may be freely used. It may be copied provided that the name NUMAL and the attribution to the Stichting
CWI are retained.

Original ALGOL 60 credits to REASCL:

AUTHORS  : T.J. DEKKER, W. HOFFMANN.
CONTRIBUTORS: W. HOFFMANN, S.P.N. VAN KAMPEN.
INSTITUTE: MATHEMATICAL CENTRE.
RECEIVED: 731030.

BRIEF DESCRIPTION:

The procedure REASCL (scale) normalises the the numbers in a table or sequence in such a way that
an element of maximum absolute value equals 1. The normalised numbers are returned in a new
table or sequence, where the type of return is defined by the type of the input.

RUNNING TIME: PROPORTIONAL TO N.

LANGUAGE:   ALGOL 60.

METHOD AND PERFORMANCE: SEE REF [1].

REFERENCES:
     [1].T.J. DEKKER AND W. HOFFMANN.
         ALGOL 60 PROCEDURES IN NUMERICAL ALGEBRA, PART 2.
         MC TRACT 23, 1968, MATH. CENTR., AMSTERDAM.

SOURCE TEXT(S):

 CODE 34183;
     COMMENT MCA 2413;
     PROCEDURE REASCL(A, N, N1, N2); VALUE N, N1, N2;
     INTEGER N, N1, N2; ARRAY A;
     BEGIN INTEGER I, J; REAL S;
         FOR J:= N1 STEP 1 UNTIL N2 DO
         BEGIN S:= 0;
             FOR I:= 1 STEP 1 UNTIL N DO
             IF ABS(A[I,J]) > ABS(S) THEN S:= A[I,J];
             IF S ^= 0 THEN
             FOR I:= 1 STEP 1 UNTIL N DO A[I,J]:= A[I,J] / S
         END
     END REASCL;
         EOP */

static int stats_scale (lua_State *L) {  /* optimised 2.2.0 RC 2, May 20, 2014 */
  int type, nooption;
  size_t n;
  lua_Number min, max, x;
  max = 0;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  nooption = lua_isnoneornil(L, 2);
  switch (type) {
    case LUA_TTABLE: {
      size_t c;
      n = agn_size(L, 1);
      if (n == 0) {
        lua_pushfail(L);
        return 1;
      }
      if (nooption) {
        c = 0;
        lua_pushnil(L);
        while (lua_next(L, 1)) {
          c++;
          x = agn_checknumber(L, -1);
          if (fabs(x) > fabs(max)) max = x;
          agn_poptop(L);  /* pop the number */
        }
        if (max == 0) {
          lua_pushfail(L);
          return 1;
        }
        lua_createtable(L, c, 0);
        c = 0;
        lua_pushnil(L);
        while (lua_next(L, 1)) {
          c++;
          lua_rawsetinumber(L, -3, c, agn_tonumber(L, -1)/max);
          agn_poptop(L);  /* pop the number */
        }
      } else {  /* normalise to the range [0, 1], 2.2.1 */
        min = HUGE_VAL;
        max = -HUGE_VAL;
        c = 0;
        lua_pushnil(L);
        while (lua_next(L, 1)) {
          c++;
          x = agn_checknumber(L, -1);
          if (x > max) max = x;
          if (x < min) min = x;
          agn_poptop(L);  /* pop the number */
        }
        if (fabs(max - min) == 0) {
          lua_pushfail(L);
          return 1;
        }
        lua_createtable(L, c, 0);
        c = 0;
        lua_pushnil(L);
        while (lua_next(L, 1)) {
          c++;
          lua_rawsetinumber(L, -3, c, (agn_tonumber(L, -1) - min) / (max - min));
          agn_poptop(L);  /* pop the number */
        }
      }
      break;
    }
    case LUA_TSEQ: {
      size_t i;
      n = agn_seqsize(L, 1);
      if (n == 0) {
        lua_pushfail(L);
        return 1;
      }
      if (nooption) {
        for (i=1; i <= n; i++) {
          x = lua_seqgetinumber(L, 1, i);
          if (fabs(x) > fabs(max)) max = x;
        }
        if (max == 0) {
          lua_pushfail(L);
          return 1;
        }
        agn_createseq(L, n);
        for (i=1; i <= n; i++) {
          lua_seqsetinumber(L, -1, i, lua_seqgetinumber(L, 1, i)/max);
        }
      } else {  /* normalise to the range [0, 1], 2.2.1 */
        min = HUGE_VAL;
        max = -HUGE_VAL;
        for (i=1; i <= n; i++) {
          x = lua_seqgetinumber(L, 1, i);
          if (x > max) max = x;
          if (x < min) min = x;
        }
        if (fabs(max - min) == 0) {
          lua_pushfail(L);
          return 1;
        }
        agn_createseq(L, n);
        for (i=1; i <= n; i++) {
          lua_seqsetinumber(L, -1, i, (lua_seqgetinumber(L, 1, i) - min) / (max - min));
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  return 1;
}


/* stats.colnorm: Returns the largest absolute value of the numbers in a table or sequence, and the original
   value with the largest absolute magnitude. If the structure consists entirely of one or more 'undefined's,
   then the function returns the value undefined twice. If the structure is empty, 'fail' is returned.

   This is an extended version of the TI-Nspire's colNorm funtion when passed a one-dimensional matrix. See also:
   `stats.scale`, `stats.rownorm`.

   Agena 1.8.2, 03.10.2012 */

static int stats_colnorm (lua_State *L) {
  int type, onlyundefs;
  size_t n;
  lua_Number s, x;
  type = lua_type(L, 1);  /* 2.5.0 */
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  n = agn_nops(L, 1);
  if (n == 0) {
    lua_pushfail(L);
    return 1;
  }
  s = 0;  /* largest magnitude */
  onlyundefs = 1;   /* structure contains `undefined` only */
  switch (type) {
    case LUA_TTABLE: {
      lua_pushnil(L);
      while (lua_next(L, 1)) {
        x = agn_checknumber(L, -1);
        if (!tools_isnan(x)) {
          onlyundefs = 0;
          if (fabs(x) > fabs(s)) s = x;
        }
        agn_poptop(L);  /* pop the number */
      }
      break;
    }
    case LUA_TSEQ: {
      size_t i, nops;
      nops = agn_seqsize(L, 1);
      for (i=1; i <= nops; i++) {
        x = lua_seqgetinumber(L, 1, i);
        if (!tools_isnan(x)) {
          onlyundefs = 0;
          if (fabs(x) > fabs(s)) s = x;
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  if (onlyundefs) {
    lua_pushundefined(L); lua_pushundefined(L);
  } else {
    lua_pushnumber(L, fabs(s)); lua_pushnumber(L, s);
  }
  return 2;
}


/* stats.rownorm: Returns the sum of the absolute values of the numbers in a table or sequence. If the structure
   consists entirely of one or more 'undefined's, then the function returns 'undefined'. If the structure is empty,
   'fail' is returned.

   This is a version of the TI-Nspire's rowNorm funtion when passed a one-dimensional matrix. See also:
   `stats.scale`, `stats.colnorm`.

   Agena 1.8.2, 04.10.2012 */

static int stats_rownorm (lua_State *L) {
  int type, onlyundefs;
  size_t n;
  lua_Number s, x;
  n = agn_nops(L, 1);
  if (n == 0) {
    lua_pushfail(L);
    return 1;
  }
  s = 0;  /* largest magnitude */
  onlyundefs = 1;   /* structure contains `undefined` only */
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  switch (type) {
    case LUA_TTABLE: {
      lua_pushnil(L);
      while (lua_next(L, 1)) {
        x = agn_checknumber(L, -1);
        if (!tools_isnan(x)) {
          onlyundefs = 0;
          s += fabs(x);
        }
        agn_poptop(L);  /* pop the number */
      }
      break;
    }
    case LUA_TSEQ: {
      size_t i, nops;
      nops = agn_seqsize(L, 1);
      for (i=1; i <= nops; i++) {
        x = lua_seqgetinumber(L, 1, i);
        if (!tools_isnan(x)) {
          onlyundefs = 0;
          s += fabs(x);
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  if (onlyundefs)
    lua_pushundefined(L);
  else
    lua_pushnumber(L, s);
  return 1;
}


/* Computes the probability density function for the normal distribution at the numeric value x. The defaults are
   mu = 0, with standard deviation sigma = 1; 1.10.6 */

static int stats_pdf (lua_State *L) {
  lua_Number x, mu, si, p, q;
  x = agn_checknumber(L, 1);
  mu = agnL_optnumber(L, 2, 0);
  si = agnL_optnumber(L, 3, 1);
  if (si <= 0)
    luaL_error(L, "Error in " LUA_QS ": standard deviation must be positive.", "stats.pdf");
  p = 1/(si*sqrt(PI2));
  q = -(x - mu)*(x - mu)/(2*si*si);
  lua_pushnumber(L, p * pow(_E, q));
  return 1;
}


static int stats_ndf (lua_State *L) {
  lua_Number si = agnL_optnumber(L, 1, 1);  /* 2.5.0 */
  if (si <= 0)
    luaL_error(L, "Error in " LUA_QS ": argument must be positive.", "stats.ndf");
  lua_pushnumber(L, 1/(si*sqrt(PI2)));
  return 1;
}


static int stats_nde (lua_State *L) {
  lua_Number x, mu, si;
  x = agn_checknumber(L, 1);
  mu = agnL_optnumber(L, 2, 0);
  si = agnL_optnumber(L, 3, 1);
  if (si <= 0)
    luaL_error(L, "Error in " LUA_QS ": third argument must be positive.", "stats.ndf");
  lua_pushnumber(L, exp(-(x-mu)*(x-mu)/(2*si*si)));
  return 1;
}


static int checkstructuresxx (lua_State *L, int *type, size_t *n, int *k, int *p, int *scientific,
    int *left, int *right, int outofrange, const char *procname) {  /* 2.1 RC 1 */
  luaL_checkany(L, 1);
  *type = lua_type(L, 1);
  luaL_typecheck(L, *type == LUA_TTABLE || *type == LUA_TSEQ, 1, "table or sequence expected", *type);
  luaL_typecheck(L, lua_type(L, 2) == LUA_TNUMBER, 2, "posint expected", lua_type(L, 2));
  luaL_typecheck(L, lua_type(L, 3) == LUA_TNUMBER, 3, "posint expected", lua_type(L, 3));
  *n = agn_nops(L, 1);
  if (*n < 1) {
    lua_pushfail(L);
    return 1;
  }
  *k = lua_tonumber(L, 2);  /* index of sample point */
  if (*k < 1) luaL_error(L, "Error in " LUA_QS ": second argument must be a posint.", procname);
  else if (*k > *n) luaL_error(L, "Error in " LUA_QS ": second argument too large.", procname);
  *p = lua_tonumber(L, 3);  /* period */
  if (*p < 2) luaL_error(L, "Error in " LUA_QS ": third argument must be greater than 1.", procname);
  else if (*n < *p) luaL_error(L, "Error in " LUA_QS ": too few elements in structure.", procname);
  *scientific = agnL_optboolean(L, 4, 0);  /* sample point at centre ? */
  if (*scientific) {  /* k is in the center of a period, period must be odd */
    lua_Number d, id;
    d = *p/2.0;
    id = trunc(d);
    if (d == id) luaL_error(L, "Error in " LUA_QS ": third argument must be an odd number.", procname);
    *left = *k - id;
    *right = *k + id;
  } else {
    *left = *k - *p + 1;
    *right = *k;
  }
  if (outofrange && (*left < 1 || *right > *n)) {
    lua_pushundefined(L);
    return 1;
  }
  return 0;
}

static int fillarray (lua_State *L, int idx, int type, lua_Number *a, size_t *ii, int left, int right, int reverse) {
  int i;
  size_t iii;
  lua_Number x;
  iii = 0;
  if (reverse) {
    switch (type) {
      case LUA_TTABLE: {
        for (i=right; i >= left; i--) {
          x = agn_getinumber(L, idx, i);
          if (tools_isnan(x)) return 1;
          a[++iii-1] = x;
        }
        break;
      }
      case LUA_TSEQ: {
        for (i=right; i >= left; i--) {
          x = lua_seqgetinumber(L, idx, i);
          if (tools_isnan(x)) return 1;
          a[++iii-1] = x;
        }
        break;
      }
      default: lua_assert(0);  /* should not happen */
    }
  } else {
    switch (type) {
      case LUA_TTABLE: {
        for (i=left; i <= right; i++) {
          x = agn_getinumber(L, idx, i);
          if (tools_isnan(x)) return 1;
          a[++iii-1] = x;
        }
        break;
      }
      case LUA_TSEQ: {
        for (i=left; i <= right; i++) {
          x = lua_seqgetinumber(L, idx, i);
          if (tools_isnan(x)) return 1;
          a[++iii-1] = x;
        }
        break;
      }
      default: lua_assert(0);  /* should not happen */
    }
  }
  *ii = iii;
  return 0;
}


static int stats_sma (lua_State *L) {  /* based on stats.amean */
  size_t ii, n;
  int left, right, type, scientific, k, p;  /* 1.12.3 */
  lua_Number *a, s;
  type = k = p = n = scientific = 0;  /* avoid compiler warnings */
  if (checkstructuresxx(L, &type, &n, &k, &p, &scientific, &left, &right, 1, "stats.sma")) return 1;
  createarray(a, p, "stats.sma");
  ii = 0;
  if (fillarray(L, 1, type, a, &ii, left, right, 0)) {
    xfree(a);  /* 1.12.4 */
    luaL_error(L, "Error in " LUA_QS ": structure includes `undefined`.", "stats.sma");
  }
  s = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
  xfree(a);
  lua_pushnumber(L, s);
  return 1;
}


static int stats_smm (lua_State *L) {  /* based on stats.sma */
  size_t ii, n;
  int left, right, type, scientific, k, p;  /* 1.12.3 */
  lua_Number *a;
  type = k = p = n = scientific = left = right = ii = 0;  /* avoid compiler warnings */
  if (checkstructuresxx(L, &type, &n, &k, &p, &scientific, &left, &right, 1, "stats.smm")) return 1;
  createarray(a, p, "stats.smm");
  if (fillarray(L, 1, type, a, &ii, left, right, 0)) {
    xfree(a);  /* 1.12.4 */
    luaL_error(L, "Error in " LUA_QS ": structure includes `undefined`.", "stats.smm");
  }
  /* tools_dquicksort(a, 0, ii - 1); */
  /* it does not make much sense to check for small unsorted ranges */
  tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
  lua_pushnumber(L, ii&1 ? tools_kth_smallest(a, ii, ii/2) :
    (tools_kth_smallest(a, ii, ii/2-1) + tools_kth_smallest(a, ii, ii/2))/2);
  xfree(a);
  return 1;
}


static int gsmm_iterator (lua_State *L) {
  lua_Number *a;
  size_t p, n, ii;
  int k, structure, type;
  k = lua_tonumber(L, lua_upvalueindex(2));
  p = lua_tonumber(L, lua_upvalueindex(3));
  n = lua_tonumber(L, lua_upvalueindex(4));
  if (k < 1 || (k + p - 1 > n && k <= n)) {
    lua_pushnumber(L, k + 1);
    lua_replace(L, lua_upvalueindex(2));  /* update index */
    lua_pushundefined(L);
    return 1;
  } else if (k > n) {
    lua_pushnil(L);
    return 1;
  }
  createarray(a, p, "stats.gsmm");
  ii = 0;
  structure = lua_upvalueindex(1);
  type = lua_type(L, structure);
  if (fillarray(L, structure, type, a, &ii, k, k + p - 1, 0)) {
    xfree(a);  /* 1.12.4 */
    luaL_error(L, "Error in " LUA_QS ": structure includes `undefined`.", "stats.gsmm");
  }
  /* It does not make much sense to search for small unsorted ranges */
  tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
  lua_pushnumber(L, k + 1);
  lua_replace(L, lua_upvalueindex(2));  /* update index k */
  lua_pushnumber(L, ii&1 ? tools_kth_smallest(a, ii, ii/2) :
    (tools_kth_smallest(a, ii, ii/2-1) + tools_kth_smallest(a, ii, ii/2))/2);
  xfree(a);
  return 1;  /* return median */
}

static int stats_gsmm (lua_State *L) {
  int left, right, type, k, p, scientific;
  size_t n;
  type = k = p = n = scientific = left = right = 0;  /* avoid compiler warnings */
  if (checkstructuresxx(L, &type, &n, &k, &p, &scientific, &left, &right, 0, "stats.gsmm")) return 1;
  lua_pushvalue(L, 1);      /* push structure, converting each number in the structure to an upvalue would speed up the function
                               even further, but in this case the number of samples would be limited to the maximum stack size. */
  lua_pushnumber(L, left);  /* push first sample point */
  lua_pushnumber(L, p);     /* push period */
  lua_pushnumber(L, n);     /* push size of structure */
  lua_pushcclosure(L, &gsmm_iterator, 4);  /* converts the values on the stack into upvalues and pops these three values from the stack */
  return 1;
}


static int gsma_iterator (lua_State *L) {
  lua_Number *a, s;
  size_t p, n, ii;
  int k, structure, type;
  k = lua_tonumber(L, lua_upvalueindex(2));
  p = lua_tonumber(L, lua_upvalueindex(3));
  n = lua_tonumber(L, lua_upvalueindex(4));
  if (k < 1 || (k + p - 1 > n && k <= n)) {
    lua_pushnumber(L, k + 1);
    lua_replace(L, lua_upvalueindex(2));  /* update index */
    lua_pushundefined(L);
    return 1;
  } else if (k > n) {
    lua_pushnil(L);
    return 1;
  }
  createarray(a, p, "stats.gsma");
  ii = 0;
  structure = lua_upvalueindex(1);
  type = lua_type(L, structure);
  if (fillarray(L, structure, type, a, &ii, k, k + p - 1, 0)) {
    xfree(a);  /* 1.12.4 */
    luaL_error(L, "Error in " LUA_QS ": structure includes `undefined`.", "stats.gsma");
  }
  s = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
  lua_pushnumber(L, k + 1);
  lua_replace(L, lua_upvalueindex(2));  /* update index k */
  lua_pushnumber(L, s);
  xfree(a);
  return 1;  /* return moving mean */
}

static int stats_gsma (lua_State *L) {
  int left, right, type, scientific, k, p;
  size_t n;
  type = k = p = n = scientific = left = right = 0;  /* avoid compiler warnings */
  if (checkstructuresxx(L, &type, &n, &k, &p, &scientific, &left, &right, 0, "stats.gsma")) return 1;
  lua_pushvalue(L, 1);      /* push structure, converting each number in the structure to an upvalue would speed up the function
                               even further, but in this case the number of samples would be limited to the maximum stack size. */
  lua_pushnumber(L, left);  /* push first sample point */
  lua_pushnumber(L, p);     /* push period */
  lua_pushnumber(L, n);     /* push size of structure */
  lua_pushcclosure(L, &gsma_iterator, 4);  /* converts the values on the stack into upvalues and pops these three values from the stack */
  return 1;
}


/* stats.ema (obj, k, alpha [, mode [, y0star]])

Computes the exponential moving average of a table or sequence obj up to and inclduing its k-th element.

The smoothing factor alpha is a rational number in the range [0, 1].

The function supports two algorithms: If mode is 1 (the default), then the algorithm

      r := alpha * obj[k];
      s := 1 - alpha;
      for i from k - 1 to 1 by -1 do
         r := r + alpha * s ^ i * obj[i];
      od;
      r := r + s ^ k * y0star;

is used to compute the result r. In mode 1, you can pass an explicit first estimate y0*, otherwise
the first value y0* is equal to the sample moving average of obj.

If mode is 2, then the formula

      r := obj[k];
      for i from k - 1 to 1 by -1 do
         r := r + alpha * (obj[i] - r)
      od;

is applied.

The result is a number. */

static int checkstructureema (lua_State *L, int *type, size_t *n, int *k, lua_Number *alpha, const char *procname) {  /* 2.1 RC 1
  nok: no `k` value given;
  !!! do not delete the nok parameter for the future implementation of stats.fema !!! */
  luaL_checkany(L, 1);
  *type = lua_type(L, 1);
  luaL_typecheck(L, *type == LUA_TTABLE || *type == LUA_TSEQ, 1, "table or sequence expected", *type);
  luaL_typecheck(L, lua_type(L, 2) == LUA_TNUMBER, 2, "posint expected", lua_type(L, 2));
  *n = agn_nops(L, 1);
  if (*n < 1) {
    lua_pushfail(L);
    return 1;
  }
  *k = lua_tonumber(L, 2);  /* index of sample point */
  if (*k < 1) luaL_error(L, "Error in " LUA_QS ": second argument must be a posint.", procname);
  else if (*k > *n) luaL_error(L, "Error in " LUA_QS ": second argument too large.", procname);
  *alpha = agn_checknumber(L, 3);  /* smoothing factor */
  if (*alpha < 0 || *alpha > 1)
    luaL_error(L, "Error in " LUA_QS ": smoothing factor must be in the range [0, 1].", procname);
  return 0;
}


static int aux_ema (lua_State *L, lua_Number *a,  size_t ii, lua_Number alpha, int mode, lua_Number y0star, lua_Number *r) {  /* 2.1 RC 1 */
  size_t i;
  switch (mode) {
    case 1: {  /* see http://de.wikipedia.org/wiki/Exponentielle_Gl%C3%A4ttung */
      lua_Number s;
      if (tools_isnan(y0star)) y0star = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
      *r = alpha * a[0];
      s = 1 - alpha;
      for (i=1; i < ii; i++) *r += alpha * tools_intpow(s, i) * a[i];
      *r += tools_intpow(s, ii) * y0star;
      break;
    }
    case 2: {  /* see: http://stackoverflow.com/questions/7947352/exponential-moving-average */
      *r = a[0];
      for (i=1; i < ii; i++) *r += alpha * (a[i] - *r);
      break;
    }
    default:
      return 1;
  }
  return 0;
}

static int stats_ema (lua_State *L) {  /* 2.1 RC 1 */
  size_t ii, n;
  int type, k, mode;
  lua_Number *a, alpha, r, y0star;
  ii = type = k = n = r = 0;  /* avoid compiler warnings */
  if (checkstructureema(L, &type, &n, &k, &alpha, "stats.ema")) return 1;
  mode = agnL_optinteger(L, 4, 1);
  y0star = agnL_optnumber(L, 5, AGN_NAN);
  createarray(a, k, "stats.ema");
  /* fill array in the opposite direction to allow hardware prefetching */
  if (fillarray(L, 1, type, a, &ii, 1, k, 1)) {
    xfree(a);
    luaL_error(L, "Error in " LUA_QS ": structure includes `undefined`.", "stats.ema");
  }
  if (aux_ema(L, a, ii, alpha, mode, y0star, &r)) {
    xfree(a);
    luaL_error(L, "Error in " LUA_QS ": unknown mode %d.", "stats.ema", mode);
  }
  xfree(a);
  lua_pushnumber(L, r);
  return 1;
}


static int gema_iterator (lua_State *L) {  /* 2.1 RC 1 */
  lua_Number *a;
  size_t n, ii;
  int k, structure, type, mode;
  lua_Number alpha, y0star, r;
  r = 0;
  if (lua_gettop(L) != 0)
    luaL_error(L, "Error in " LUA_QS ": iterator requires no arguments.", "stats.gema");
  k = lua_tonumber(L, lua_upvalueindex(2));
  n = lua_tonumber(L, lua_upvalueindex(3));
  alpha = lua_tonumber(L, lua_upvalueindex(4));
  mode = lua_tointeger(L, lua_upvalueindex(5));
  y0star = lua_tonumber(L, lua_upvalueindex(6));
  if (k < 1 || k > n) {
    lua_pushnil(L);
    return 1;
  }
  createarray(a, k, "stats.gema");
  ii = 0;
  structure = lua_upvalueindex(1);
  type = lua_type(L, structure);
  if (fillarray(L, structure, type, a, &ii, 1, k, 1)) {
    xfree(a);  /* 1.12.4 */
    luaL_error(L, "Error in " LUA_QS ": structure includes `undefined`.", "stats.gema");
  }
  if (aux_ema(L, a, ii, alpha, mode, y0star, &r)) {
    xfree(a);
    luaL_error(L, "Error in " LUA_QS ": unknown mode %d.", "stats.gema", mode);
  }
  lua_pushnumber(L, k + 1);
  lua_replace(L, lua_upvalueindex(2));  /* update index k */
  lua_pushnumber(L, r);
  xfree(a);
  return 1;  /* return median */
}

/*

stats.gema (obj, alpha [, mode [, y0*]])

Like stats.ema, but returns a function that, each time it is called, returns the exponential
moving average, starting with sample obj[1], and progressing with sample obj[2], obj[3], etc.
with subsequent calls. It return `null` if there are no more samples in obj. It is much faster
than `stats.ema` with large observations.

The smoothing factor alpha is a rational number in the range [0, 1].

The function supports two algorithms: If mode is 1 (the default), then the algorithm

   ...

is used to compute the result. In mode 1, you can pass an explicit first estimate y0*, otherwise
the first value y0* is equal to the sample moving average of obj.

If mode is 2, then the formula

   ...

is applied to the period.

The result is a number. */

static int stats_gema (lua_State *L) {  /* 2.1 RC 1 */
  int type, k, mode;
  lua_Number alpha, y0star;
  size_t n;
  type = k = n = 0;  /* avoid compiler warnings */
  if (checkstructureema(L, &type, &n, &k, &alpha, "stats.gema")) return 1;
  mode = agnL_optinteger(L, 4, 1);
  y0star = agnL_optnumber(L, 5, AGN_NAN);
  lua_pushvalue(L, 1);        /* push structure, converting each number in the structure to an upvalue would speed up the function
                                 even further, but in this case the number of samples would be limited to the maximum stack size. */
  lua_pushnumber(L, k);       /* push first sample point */
  lua_pushnumber(L, n);       /* push _total_ size of structure */
  lua_pushnumber(L, alpha);   /* push smoothing factor alpha */
  lua_pushnumber(L, mode);    /* push mode */
  lua_pushnumber(L, y0star);  /* push y0star */
  lua_pushcclosure(L, &gema_iterator, 6);  /* converts the values on the stack into upvalues and pops these three values from the stack */
  return 1;
}


/* returns all elements in a table or sequence obj from the p-th percentile rank up but not including
   the q-th percentile rank. p and q must be positive integers in the range (0 .. [100. If p and q
   are not given, p is set to 25, and q to 75. If q is not given, it is set to 100 - p. The type of
   return is determined by the type of obj. */

#define FLOOR(x) floor((x) + 0.5)

static int stats_prange (lua_State *L) {  /* 1.12.9 */
  size_t i, nargs, p, q, c, rankp, rankq, ii;
  int type;
  lua_Number x1, x2, *a;
  luaL_checkany(L, 1);
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  nargs = lua_gettop(L);
  if (nargs > 1) {
    p = agn_checkinteger(L, 2);
    if (p < 0 || p > 99)
      luaL_error(L, "Error in " LUA_QS ": second argument must be in the range [0, 100).", "stats.prange");
  } else
    p = 25;
  if (nargs > 2) {
    q = agn_checkinteger(L, 3);
    if (q < 0 || q > 99)
      luaL_error(L, "Error in " LUA_QS ": third argument must be in the range [0, 100).", "stats.prange");
  } else
    q = 100 - p;
  if (p > q)
    luaL_error(L, "Error in " LUA_QS ": second argument must be less than third argument.", "stats.prange");
  /* create an array and fill it */
  a = aux_tonumarray(L, 1, &ii, "stats.prange");
  if (a == NULL) return 1;  /* issue the error, 2.4.4 fix */
  if (ii < 2)
    lua_pushfail(L);
  else {
    x1 = a[0];
    for (i=1; i < ii; i++) {  /* 2.4.3 fix */
      x2 = a[i];
      if (x1 > x2) {  /* array unsorted ? -> sort it in ascending order */
        /* tools_dquicksort(a, 0, ii - 1); */ /* fix 2.1.2 */
        tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
        break;
      }
      x1 = x2;
    }
    rankp = FLOOR((lua_Number)p/100*(ii + 1));  /* 2.4.2 change to NIST standard */
    rankq = FLOOR((lua_Number)q/100*(ii + 1));  /* 2.4.2 change to NIST standard */
    c = 1;
    if (type == LUA_TTABLE) {
      lua_createtable(L, ii*(q - p)/100 + 1, 0);
      for (i=rankp; i < rankq - 1; i++)  /* 2.4.3 fix */
        lua_rawsetinumber(L, -1, c++, a[i]);
    } else {
      agn_createseq(L, ii*(q - p)/100 + 1);
      for (i=rankp; i < rankq - 1; i++)  /* 2.4.3 fix */
        lua_seqsetinumber(L, -1, c++, a[i]);
    }
  }
  xfree(a);
  return 1;
}


/* Returns the arithmetic mean of the interquartile range of a distribution Kahan-Ozawa round-off error prevention.
   If a distribution is unsorted, the function automatically sorts it non-destructively, and any non-numeric
   observations are converted to zeros. The return is a number. The interquartile range comprises all observations
   that reside between the second and third quartiles. */

static int stats_iqmean (lua_State *L) {  /* 2.4.2 */
  size_t i, ii, p, q, c, rankp, rankq;
  lua_Number x1, x2, *a;
  luaL_checkany(L, 1);
  a = aux_tonumarray(L, 1, &ii, "stats.iqmean");  /* 2.4.4 change */
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {
    p = 25; q = 100 - p;
    x1 = a[0];
    for (i=1; i < ii; i++) {
      x2 = a[i];
      if (x1 > x2) {  /* array unsorted ? -> sort it in ascending order */
        /* tools_dquicksort(a, 0, ii - 1); */ /* fix 2.1.2 / 2.4.4 fix */
        tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
        break;
      }
      x1 = x2;
    }
    rankp = FLOOR((lua_Number)p/100*(ii + 1));  /* 2.4.2 change to NIST standard */
    rankq = FLOOR((lua_Number)q/100*(ii + 1));  /* 2.4.2 change to NIST standard */
    c = 0;
    /* shift interquartile range to the beginning of a */
    for (i=rankp - 1; i < rankq - 1; i++) a[c++] = a[i];
    lua_pushnumber(L, KahanBabuskaMean(a, c));  /* 2.4.3 improvement */
  }
  xfree(a);
  return 1;
}


/* The function determines the 1st quartile Q1 and the 3rd quartile Q3 along with the median Q2 of a distribution obj and returns the trimean
(Q1 + 2*Q2 + Q3)/4 along with the median. When compared to the median, the trimean is a means to determine whether a distribution
is biased in its first or second half. If the distribution is not sorted, it automatically sorts it non-destructively.

From https://explorable.com/trimean:
`A Sample Example

For example, consider the heights of students in a class, in cm, to be 155, 158, 161, 162, 166, 170, 171, 174 and 179. It is easy to see the median of this data is 166 cm.

Now consider another class where the heights of the students, again in cm, are 162, 162, 163, 165, 166, 175, 181, 186, and 192. It can be seen that the median height of the class is again 166 cm. However, a look at the two data distributions tells us that the distributions are quite different in both these cases, even though they have the same median.

Now let us compute the trimean for the first case. The median as we saw was 166, the first quartile is 161 and the third quartile is 171. Using the formula given above, the trimean is computed as (161 + 2(166) + 171)/4 = 166.

In the second example, the median is the same 166, but the first quartile is 163 and the second quartile is 181. Now the trimean is computed as (163 + 2(166) + 181)/4 = 169.

Interpreting the Results

In the first case, we see that the trimean is the same as the median. What this essentially means is that the distribution is very even from the median, which means there are about as many data points at a given distance from the median on either side (only on an average case of course).

In the second case, the trimean is bigger than the mean. As you can see, the third quartile is farther away from the median than the first quartile, which essentially means that the data is biased in the second half of the distribution. Thus the trimean reflects this bias in data away from the median. Thus the effect of quartiles appears on the definition of trimean.` */

static int stats_trimean (lua_State *L) {  /* 2.4.2, patched 2.4.4 */
  size_t i, ii, rankp, rankq, p, q;
  lua_Number x1, x2, *a, m;
  luaL_checkany(L, 1);
  a = aux_tonumarray(L, 1, &ii, "stats.trimean");  /* 2.4.4 change */
  if (a == NULL) return 1;  /* issue the error */
  p = agnL_optinteger(L, 2, 25);  /* 2.8.1 */
  if (p < 0 || p > 99) {
    xfree(a);
    luaL_error(L, "Error in " LUA_QS ": second argument must be in the range [0, 100).", "stats.trimean");
  }
  q = 100 - p;
  if (ii < 2)
    lua_pushfail(L);
  else {
    x1 = a[0];
    for (i=1; i < ii; i++) {
      x2 = a[i];
      if (x1 > x2) {  /* array unsorted ? -> sort it in ascending order */
        /* tools_dquicksort(a, 0, ii - 1); */ /* fix 2.1.2 */
        tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
        break;
      }
      x1 = x2;
    }
    rankp = FLOOR((lua_Number)p/100*(ii + 1)) - 1;  /* position of the 1. quartile */
    m = (ii % 2 == 0) ? (a[ii/2 - 1] + a[ii/2])/2 : a[ii/2];  /* median */
    rankq = FLOOR((lua_Number)q/100*(ii + 1)) - 1;  /* position of the 3. quartile */
    lua_pushnumber(L, (a[rankp] + 2*m + a[rankq])/4);
    lua_pushnumber(L, m);
  }
  xfree(a);
  return 1 + (ii > 1);
}


/* Returns the first, second, and third quartile of a _sorted_ table or sequence. Agena 1.3.3, January 30, 2011. Ported to C with 2.4.2
   See also: http://www.vias.org/tmdatanaleng/cc_quartile.html. Also returns the lower and upper outlier limit and the interquartile range.
   stats.quartiles([-20, -4, -1, -1, 0, 1, 2, 3, 4, 4, 7, 7, 8, 11, 11, 12, 12, 15, 18, 22]) -> [0, 5.5, 12, -4, 18, 12] */

static int stats_quartiles (lua_State *L) {  /* 2.4.2, patched 2.4.4 */
  size_t i, rankp, rankq, ii, p, q, nargs;
  int type, option;
  lua_Number x1, x2, *a, *r, m;
  luaL_checkany(L, 1);
  type = lua_type(L, 1);
  a = aux_tonumarray(L, 1, &ii, "stats.quartiles");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2) {
    lua_pushfail(L);
    xfree(a);
    return 1;
  }
  nargs = lua_gettop(L);
  option = luaL_optinteger(L, 2, 0);
  x1 = a[0];
  for (i=1; i < ii; i++) {
    x2 = a[i];
    if (x1 > x2) {  /* array unsorted ? -> sort it in ascending order */
      /* tools_dquicksort(a, 0, ii - 1); */ /* fix 2.1.2 */
      tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
      break;
    }
    x1 = x2;
  }
  p = 25; q = 75;
  rankp = FLOOR((lua_Number)p/100*(ii + 1)) - 1; /* position of the 1. quartile */
  m = (ii % 2 == 0) ? (a[ii/2 - 1] + a[ii/2])/2 : a[ii/2];  /* median */
  rankq = FLOOR((lua_Number)q/100*(ii + 1)) - 1;  /* position of the 3. quartile */
  r = malloc(6 * sizeof(lua_Number));
  r[0] = a[rankp]; r[1] = m; r[2] = a[rankq];  /* 1st quartile, median, third quartile */
  if (nargs > 1) {
    switch (option) {
      case 1: lua_pushnumber(L, r[0]); break;  /* return 1st quartile, only */
      case 2: lua_pushnumber(L, r[1]); break;  /* return median, only */
      case 3: lua_pushnumber(L, r[2]); break;  /* return 3rd quartile, only */
      default: {
        xfree(a); xfree(r);
        luaL_error(L, "Error in " LUA_QS ": invalid option %d.", "stats.quartiles", option);
      }
    }
    xfree(a); xfree(r);
    return 1;
  }
  if (type == LUA_TTABLE) {
    lua_createtable(L, 6, 0);
    for (i=0; i < 3; i++) lua_rawsetinumber(L, -1, i + 1, r[i]);
  } else {
    agn_createseq(L, 6);
    for (i=0; i < 3; i++) lua_seqsetinumber(L, -1, i + 1, r[i]);
  }
  if (ii > 4 && rankp != 1) {
    lua_Number iqr, l1, u1;
    int M, A, B;
    M = -1;  /* to prevent compiler warnings */
    /* determine interquartile range */
    iqr = r[2] - r[0];
    /* compute lower outlier limit L1 */
    l1 = r[0] - 1.5*iqr;
    A = 0; B = rankp - 1;
    while (A < B) {
      M = (A + B)/2;
      if (l1 > a[M])
        A = M + 1;
      else
        B = M;
    }
    while (a[M] <= l1) M++;  /* evade round-off errors */
    r[3] = a[M];  /* use index `m` instead of a or b ! */
    /* compute upper outlier limit U1 */
    u1 = r[2] + 1.5*iqr;
    A = rankq + 1; B = ii - 1;
    while (A < B) {
      M = (A + B)/2;
      if (u1 > a[M])
        A = M + 1;
      else
        B = M;
    }
    while (a[M] >= u1) M--;  /* evade round-off errors */
    r[4] = a[M];  /* use index `m` instead of a or b ! */
    r[5] = iqr;
    if (type == LUA_TTABLE) {  /* insert `L1`,`U1`, and the interquartile range */
      for (i=3; i < 6; i++) lua_rawsetinumber(L, -1, i + 1, r[i]);
    } else {
      for (i=3; i < 6; i++) lua_seqsetinumber(L, -1, i + 1, r[i]);
    }
  }
  xfree(a); xfree(r);
  return 1;
}


/* Returns the first quartile, the median, and the third quartile of a distribution, in this order. If the number of
   observations is five or more, it also returns the minimum and the maximum observation, along with the arithmetic
   mean. The first and third quartiles are computed according to the NIST rule, see stats.percentile for further
   information. If the elements in obj are not sorted in ascending order, the function automatically sorts them
   non-destructively, and any non-numeric values are converted to zeros.

   See also: stats.quartiles. */
static int stats_fivenum (lua_State *L) {  /* 2.8.1 */
  size_t i, rankp, rankq, ii, p, q;
  int type;
  lua_Number x1, x2, *a, *r, m;
  luaL_checkany(L, 1);
  type = lua_type(L, 1);
  a = aux_tonumarray(L, 1, &ii, "stats.fivenum");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2) {
    lua_pushfail(L);
    xfree(a);
    return 1;
  }
  x1 = a[0];
  for (i=1; i < ii; i++) {
    x2 = a[i];
    if (x1 > x2) {  /* array unsorted ? -> sort it in ascending order */
      /* tools_dquicksort(a, 0, ii - 1); */ /* fix 2.1.2 */
      tools_dintrosort(a, 0, ii - 1, 0, 2*log(ii)/log(2));  /* 2.8.4 speed-up */
      break;
    }
    x1 = x2;
  }
  p = 25; q = 75;
  rankp = FLOOR((lua_Number)p/100*(ii + 1)) - 1; /* position of the 1. quartile */
  m = (ii % 2 == 0) ? (a[ii/2 - 1] + a[ii/2])/2 : a[ii/2];  /* median */
  rankq = FLOOR((lua_Number)q/100*(ii + 1)) - 1;  /* position of the 3. quartile */
  r = malloc(6 * sizeof(lua_Number));
  r[0] = a[rankp]; r[1] = m; r[2] = a[rankq];  /* 1st quartile, median, third quartile */
  if (type == LUA_TTABLE) {
    lua_createtable(L, 6, 0);
    for (i=0; i < 3; i++) lua_rawsetinumber(L, -1, i + 1, r[i]);
  } else {
    agn_createseq(L, 6);
    for (i=0; i < 3; i++) lua_seqsetinumber(L, -1, i + 1, r[i]);
  }
  if (ii > 4 && rankp != 1) {
    r[3] = a[0];       /* minumum */
    r[4] = a[ii - 1];  /* maximum */
    r[5] = KahanBabuskaMean(a, ii);  /* arithmetic mean */
    if (type == LUA_TTABLE) {  /* insert `L1`,`U1`, and the interquartile range */
      for (i=3; i < 6; i++) lua_rawsetinumber(L, -1, i + 1, r[i]);
    } else {
      for (i=3; i < 6; i++) lua_seqsetinumber(L, -1, i + 1, r[i]);
    }
  }
  xfree(a); xfree(r);
  return 1;
}


static int stats_fsum (lua_State *L) {  /* based on calc.fsum; 2.2.0 RC 2, May 19, 2014 */
  lua_Number a, b;
  size_t n;
  volatile lua_Number s, cs, ccs, t, c, cc, x;
  int nargs, i, offset, type;
  s = cs = ccs = 0;
  luaL_checktype(L, 1, LUA_TFUNCTION);
  nargs = lua_gettop(L);  /* 2.1.4 */
  luaL_checkstack(L, nargs, "too many arguments");
  type = lua_type(L, 2);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 2, "table or sequence expected", type);
  n = agn_nops(L, 2);
  a = agnL_optinteger(L, 3, 1);  /* start value */
  b = agnL_optinteger(L, 4, n);  /* stop value */
  if (a < 1 || a > n || b < 1 || b > n || a > b)
    luaL_error(L, "Error in " LUA_QS ": invalid start or stop values.", "stats.fsum");
  offset = (nargs > 4) * (nargs - 4);  /* multivariate function ? */
  while (a <= b) {
    lua_pushvalue(L, 1);  /* push function */
    lua_pushnumber(L,
      (type == LUA_TSEQ) ? agn_seqgetinumber(L, 2, a) : agn_getinumber(L, 2, a));
    for (i=5; i <= nargs; i++) lua_pushvalue(L, i);
    x = agn_ncall(L, 1 + offset, 1);
    t = s + x;
    c = (fabs(s) >= fabs(x)) ? (s - t) + x : (x - t) + s;
    s = t;
    t = cs + c;
    cc = (fabs(cs) >= fabs(c)) ? (cs - t) + c : (c - t) + cs;
    cs = t;
    ccs = ccs + cc;
    a++;
  }
  lua_pushnumber(L, s + cs + ccs);  /* no rounding in between */
  return 1;
}


static int stats_fprod (lua_State *L) {  /* based on stats.fsum; 2.2.0 RC 2, May 22, 2014 */
  lua_Number a, b;
  size_t n;
  lua_Number p;
  int nargs, i, offset, type;
  p = 1;
  luaL_checktype(L, 1, LUA_TFUNCTION);
  nargs = lua_gettop(L);  /* 2.1.4 */
  luaL_checkstack(L, nargs, "too many arguments");
  type = lua_type(L, 2);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 2, "table or sequence expected", type);
  n = agn_nops(L, 2);
  a = agnL_optinteger(L, 3, 1);  /* start value */
  b = agnL_optinteger(L, 4, n);  /* stop value */
  if (a < 1 || a > n || b < 1 || b > n || a > b)
    luaL_error(L, "Error in " LUA_QS ": invalid start or stop values.", "stats.fprod");
  offset = (nargs > 4) * (nargs - 4);  /* multivariate function ? */
  while (a <= b) {
    lua_pushvalue(L, 1);  /* push function */
    lua_pushnumber(L,
      (type == LUA_TSEQ) ? agn_seqgetinumber(L, 2, a) : agn_getinumber(L, 2, a));  /* there seems to ber no difference to differentiate this on Windows */
    for (i=5; i <= nargs; i++) lua_pushvalue(L, i);
    p *= agn_ncall(L, 1 + offset, 1);
    a++;
  }
  lua_pushnumber(L, p);
  return 1;
}


/* Gini Coefficient, 2.3.0 RC 1

Measures the inequality in a population given by the table or sequence obj. All members of the population should be numbers. `infinity's` or `undefined's` are
ignored.

It returns a number r indicating the absolute mean of the difference between every pair of observations, divided by the arithmetic mean of the population, with 0 <= r <= 1, where 0 indicates that all observations are equal, and (a theoretical value of) 1 indicates complete inequality. It is assumed that all observations are non-negative.

If the option "sorted" is given then the function assumes that all elements in
obj are already sorted in ascending order - thus computing the result much faster.

See also: http://www.statsdirect.com/help/default.htm#nonparametric_methods/gini.htm */

static int stats_gini (lua_State *L) {
  size_t ii, i, j;
  lua_Number *a, r;
  const char *option;
  lua_Number km;
  luaL_checkany(L, 1);
  ii = r = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.gini");
  if (a == NULL) return 1;  /* issue the error */
  option = luaL_optstring(L, 2, "default");
  if (ii < 2)
    lua_pushfail(L);
  else if (strcmp(option, "sorted") != 0) {
    km = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
    for (i=0; i < ii; i++) {
      for (j=0; j < ii; j++) {
        r += fabs(a[i] - a[j]);
      }
    }
    lua_pushnumber(L, r / (2 * ii*ii * km));
  } else {
    km = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
    for (i=0; i < ii; i++) {
      r += (i + 1) * (a[i] - km);
    }
    lua_pushnumber(L, r * 2/(ii*ii * km));
  }
  xfree(a);
  return 1;
}


/* stats.moment: computes the various moments p of the given data x about any origin xm for a full population.
   It is equivalent to: sum((x[i]-xm)^p, i=1 .. n)/n.

   If only the table or sequence x is given, the moment p defaults to 1, and the origin xm defaults to 0. If
   given, the moment p and the origin xm must be numbers. Beginning with 2.4.5, the function can also return the
   sample moment. */

static int stats_moment (lua_State *L) {
  size_t ii;
  int sample;
  lua_Number *a, p, xm;
  luaL_checkany(L, 1);
  p = luaL_optnumber(L, 2, 1);  /* the moment (power p) */
  xm = luaL_optnumber(L, 3, 0);  /* origin, quantity about which the moment is computed (optional value to be subtracted from x[i]) */
  sample = agnL_optboolean(L, 4, 0);  /* compute sample moment instead of population moment, 2.4.5 */
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.moment");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else
    lua_pushnumber(L, KahanBabuskaSumdata(a, ii, p, xm) / ((sample) ? ii - 1 : ii ));  /* 2.4.4 & 2.4.5 change */
  xfree(a);
  return 1;
}


static int stats_meanmed (lua_State *L) {  /* 2.2.3 / 2.3.0 RC 1 */
  size_t ii, nres;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.meanmed");
  if (a == NULL) return 1;  /* issue the error */
  nres = 1;
  if (ii < 2)
    lua_pushfail(L);
  else {
    lua_Number mean, median;
    mean = KahanBabuskaMean(a, ii);  /* 2.4.3 improvement */
    median = ii&1 ? tools_kth_smallest(a, ii, ii/2) :
      (tools_kth_smallest(a, ii, ii/2 - 1) + tools_kth_smallest(a, ii, ii/2))/2;
    if (lua_gettop(L) == 2)
      lua_pushnumber(L, mean/median);
    else {
      lua_pushnumber(L, mean);
      lua_pushnumber(L, median);
      nres++;
    }
  }
  xfree(a);
  return nres;
}


/* Returns both the artithmetic mean and the variance of a distribution using an algorithm
   developed by B. P. Welford to prevent round-off errors. By default, the population variance
   is returned unless you pass the Boolean value `true` to compute the sample variance. 2.5.3 */

static lua_Number aux_meanvar (lua_Number *a, size_t ii, lua_Number *variance) {
  size_t i;
  volatile lua_Number mean, var, delta, x;
  mean = 0; var = 0;
  for (i=0; i < ii; i++) {
    x = a[i];
    delta = x - mean;
    mean += delta/(i+1);
    var += delta*(x - mean);
  }
  *variance = var;
  return mean;
}


static int stats_meanvar (lua_State *L) {
  size_t ii, sample;
  lua_Number *a;
  luaL_checkany(L, 1);
  sample = !lua_isnoneornil(L, 2);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.meanvar");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {
    lua_Number mean, var;
    var = 0;  /* to avoid compiler warnings */
    mean = aux_meanvar(a, ii, &var);
    lua_pushnumber(L, mean);
    lua_pushnumber(L, var / (ii - sample));
  }
  xfree(a);
  return 1 + (ii > 1);
}


/* Standardises a distribution by subtracting the arithmetic mean from each observation and then dividing by the
   population standard deviation (default) of the distribution. Depending on the type of its argument,
   the return is either a new table or sequence of the respective quotients, preserving the original order of the
   observations. You may alternatively divide by the sample standard deviation by passing the optional value `true`
   as the second argument. 2.5.3 */

static int stats_standardise (lua_State *L) {
  size_t i, ii, sample;
  lua_Number *a;
  luaL_checkany(L, 1);
  sample = !lua_isnoneornil(L, 2);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.standardise");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {
    lua_Number mean, var, sd;
    var = 0;  /* to avoid compiler warnings */
    mean = aux_meanvar(a, ii, &var);
    sd = sqrt(var/(ii - sample));
    switch (lua_type(L, 1)) {
      case LUA_TTABLE:
        lua_createtable(L, ii, 0);
        for (i=0; i < ii; i++) lua_rawsetinumber(L, -1, i+1, (a[i] - mean)/sd);
        break;
      case LUA_TSEQ:
        agn_createseq(L, ii);
        for (i=0; i < ii; i++) lua_seqsetinumber(L, -1, i+1, (a[i] - mean)/sd);
        break;
      default:
        lua_assert(0);
    }
  }
  xfree(a);
  return 1;
}


/* Determines all neighbours of a given n-dimensional point in a distribution obj that lie in a
   certain Eucledian distance eps. idx is the position of the point of interest in the distribution
   - a positive integer -, and not the point itself. eps is any positive number, power is a positive
   integer with which the respective Euclidean distances and eps shall be raised before a comparison
   is conducted, its default is 2.

   The return is a sequence with the nearby points. If the fifth argument `indices` is `true`, however,
   then not the points but their positions in the distribution are returned.

   The points may be represented either as pairs (2-dimensional space), sequences of coordinates
   (n-dimensional space), or any n-dimensional vectors created by the linalg.vector function.

   See also: linalg.norm, stats.dbscan. */

static int stats_neighbours (lua_State *L) {  /* 2.3.0 RC 4 */
  lua_Number eps, power, erp, x0, x1, y0, y1, indices, *p, *q;
  size_t c, s, i, n, dim;
  int idx, type;
  p = q = NULL;  /* avoid compiler warnings */
  type = lua_type(L, 1);
  s = agn_seqsize(L, 1);
  luaL_typecheck(L, type == LUA_TSEQ, 1, "sequence expected", type);
  idx = agn_checkinteger(L, 2);
  if (idx < 1 || idx > s)
    luaL_error(L, "Error in " LUA_QS ": index %d out of range.", "stats.neighbours", idx);
  eps = agn_checknumber(L, 3);
  if (eps <= 0)
    luaL_error(L, "Error in " LUA_QS ": epsilon must be positive.", "stats.neighbours");
  power = luaL_optint(L, 4, 2);
  if (power < 1)
    luaL_error(L, "Error in " LUA_QS ": power must be a positive integer.", "stats.neighbours");
  indices = agnL_optboolean(L, 5, 0);
  erp = tools_intpow(eps, power);
  c = dim = n = 0;
  lua_seqgeti(L, 1, idx);  /* push point */
  /* determine dimension of point */
  if (lua_ispair(L, -1)) {
    dim = 2;
    type = 1;
    agn_pairgetnumbers(L, "stats.neighbours", -1, &x0, &y0);
  } else if (lua_isseq(L, -1)) {
    dim = agn_seqsize(L, -1);
    type = 0;
    if (dim < 1)
      luaL_error(L, "Error in " LUA_QS ": dimension of point at index %d is non-positive.", idx, "stats.neighbours");
    p = aux_tonumarray(L, -1, &n, "stats.neighbours");
    if (p == NULL) return 1;  /* issue the error, 2.4.4 */
    agn_poptop(L);
    if (n != dim) {
      xfree(p);
      luaL_error(L, "Error in " LUA_QS ": point at index %d includes non-finite numbers.", "stats.neighbours", idx);
    }
  } else if (agn_islinalgvector(L, -1, &dim)) {  /* linalg.vector ? */
    type = 2;
    p = aux_tonumarray(L, -1, &n, "stats.neighbours");
    if (p == NULL) return 1;  /* issue the error, 2.4.4 */
    agn_poptop(L);
  } else
    luaL_error(L, "Error in " LUA_QS ": wrong kind of point at index %d, got " LUA_QS ".",
      "stats.neighbours", idx, luaL_typename(L, -1));
  agn_createseq(L, 0);
  if (type == 1) {  /* check pairs ? */
    for (i=1; i <= s; i++) {
      lua_seqgeti(L, 1, i);
      agn_pairgetnumbers(L, "stats.neighbours", -1, &x1, &y1);  /* removes pair */
      if (i != idx &&
          tools_intpow(sqrt((x0 - x1)*(x0 - x1) + (y0 - y1)*(y0 - y1)), power) < erp) {
        c++;
        if (indices) {  /* lua_seqsetinumber is a macro, so use curly brackets */
          lua_seqsetinumber(L, -1, c, i);
        } else {
          lua_seqgeti(L, 1, i);
          lua_seqseti(L, -2, c);
        }
      }
    }
  } else if (type == 0) {  /* else check sequences of coordinates */
    lua_Number sum;
    size_t j;
    for (i=1; i <= s; i++) {
      lua_seqgeti(L, 1, i);
      if (!lua_isseq(L, -1)) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered wrong kind of point at index %d, got " LUA_QS ".",
          "stats.neighbours", i, luaL_typename(L, -1));
      }
      if (agn_seqsize(L, -1) != dim) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered point of different dimension at index %d.", "stats.neighbours", i);
      }
      q = aux_tonumarray(L, -1, &n, "stats.neighbours");
      if (q == NULL) return 1;  /* issue the error, 2.4.4 */
      agn_poptop(L);  /* pop point */
      if (n != dim) {
        xfree(p); xfree(q);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": point at index %d includes non-finite numbers.", "stats.neighbours", i);
      }
      if (i != idx) {
        sum = 0;  /* now determine Euclidean distance */
        for (j=0; j < n; j++)
          sum += (q[j] - p[j])*(q[j] - p[j]);
        if (tools_intpow(sqrt(sum), power) < erp) {
          if (indices) {  /* lua_seqsetinumber is a macro, so use curly brackets */
            lua_seqsetinumber(L, -1, ++c, i);
          } else {
            lua_seqgeti(L, 1, i);
            lua_seqseti(L, -2, ++c);
          }
        }
      }
      xfree(q);
    }
    xfree(p);
  } else {  /* else check linalg.vectors */
    lua_Number sum;
    size_t j;
    for (i=1; i <= s; i++) {
      lua_seqgeti(L, 1, i);
      if (!agn_islinalgvector(L, -1, &n)) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": wrong kind of point at index %d, got " LUA_QS ".",
          "stats.neighbours", i, luaL_typename(L, -1));
      }
      if (n != dim) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered vector of different dimension at index %d.",
          "stats.neighbours", luaL_typename(L, -1), i);
      }
      q = aux_tonumarray(L, -1, &n, "stats.neighbours");
      if (q == NULL) return 1;  /* issue the error, 2.4.4 */
      if (n != dim) {
        agn_poptop(L);
        xfree(p); xfree(q);
        luaL_error(L, "Error in " LUA_QS ": encountered malformed vector at index %d.", "stats.neighbours", i);
      }
      agn_poptop(L);  /* pop point */
      if (i != idx) {
        sum = 0;  /* now determine Euclidean distance */
        for (j=0; j < n; j++)
          sum += (q[j] - p[j])*(q[j] - p[j]);
        if (tools_intpow(sqrt(sum), power) < erp) {
          if (indices) {  /* lua_seqsetinumber is a macro, so use curly brackets */
            lua_seqsetinumber(L, -1, ++c, i);
          } else {
            lua_seqgeti(L, 1, i);
            lua_seqseti(L, -2, ++c);
          }
        }
      }
      xfree(q);
    }
    xfree(p);
  }
  agn_seqresize(L, -1, c);
  return 1;
}


/* Returns all points in a distribution o (a sequence) that are in a residing vicinity eps (a positive number)
   of each other and returns them in a new sequence.

   Contrary to `stats.neighbours`, the function does not compute in Euclidean space, but in the space
   of a single dimension dim, which is 1 by default. It is assumed that the points in o are in the correct
   order. */

/*  indices = set only the index but not the point */
#define insertcoordinate(indices, c, i) { \
  if (indices) { \
    lua_seqsetinumber(L, -1, c, i); \
  } else { \
    lua_seqgeti(L, 1, i); \
    lua_seqseti(L, -2, c); \
  } \
}

static int stats_nearby (lua_State *L) {  /* 2.4.1 */
  lua_Number eps, epsilon, x0, x1, y0, y1, indices, *p, *q;
  size_t c, s, i, n, dim, dimspace;
  int type;
  p = q = NULL;  /* avoid compiler warnings */
  type = lua_type(L, 1);
  s = agn_seqsize(L, 1);
  epsilon = agn_getepsilon(L);
  luaL_typecheck(L, type == LUA_TSEQ, 1, "sequence expected", type);
  eps = agn_checknumber(L, 2);
  if (eps <= 0)
    luaL_error(L, "Error in " LUA_QS ": epsilon must be positive.", "stats.nearby");
  dimspace = agnL_optinteger(L, 3, 1);
  if (dimspace < 1)
    luaL_error(L, "Error in " LUA_QS ": dimension must be positive.", "stats.nearby");
  indices = agnL_optboolean(L, 4, 0);
  c = dim = n = 0;
  lua_seqgeti(L, 1, 1);  /* push point */
  /* determine dimension of point */
  if (lua_ispair(L, -1)) {
    dim = 2;
    type = 1;
    agn_pairgetnumbers(L, "stats.nearby", -1, &x0, &y0);
  } else if (lua_isseq(L, -1)) {
    dim = agn_seqsize(L, -1);
    type = 0;
    if (dim < 1)
      luaL_error(L, "Error in " LUA_QS ": dimension of point at index 1 is non-positive.", "stats.nearby");
    p = aux_tonumarray(L, -1, &n, "stats.nearby");
    if (p == NULL) return 1;  /* issue the error, 2.4.4 */
    agn_poptop(L);
    if (n != dim) {
      xfree(p);
      luaL_error(L, "Error in " LUA_QS ": point at index 1 includes non-numbers.", "stats.nearby");
    }
  } else if (agn_islinalgvector(L, -1, &dim)) {  /* linalg.vector ? */
    type = 2;
    p = aux_tonumarray(L, -1, &n, "stats.nearby");
    if (p == NULL) return 1;  /* issue the error, 2.4.4 */
    agn_poptop(L);
  } else
    luaL_error(L, "Error in " LUA_QS ": wrong kind of point at index 1, got " LUA_QS ".",
      "stats.nearby", luaL_typename(L, -1));
  if (dimspace > dim)
    luaL_error(L, "Error in " LUA_QS ": dimension is invalid, maximum of %d allowed.", "stats.nearby", dim);
  agn_createseq(L, 0);
  dimspace--;  /* now go down to zero-based C arrays */
  if (type == 1) {  /* check pairs ? (no p) */
    for (i=2; i <= s; i++) {
      lua_seqgeti(L, 1, i);
      agn_pairgetnumbers(L, "stats.nearby", -1, &x1, &y1);  /* removes pair */
      if ((dimspace == 0 && tools_approx(x1 - x0, eps, epsilon)) || (dimspace == 1 && tools_approx(y1 - y0, eps, epsilon))) {
        if (i == 2) { insertcoordinate(indices, ++c, 1); }
        insertcoordinate(indices, ++c, i);
      }
      x0 = x1;
      y0 = y1;
    }
  } else if (type == 0) {  /* else check sequences of coordinates (p) */
    size_t j;
    for (i=2; i <= s; i++) {
      lua_seqgeti(L, 1, i);
      if (!lua_isseq(L, -1)) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered wrong kind of point at index %d, got " LUA_QS ".",
          "stats.nearby", i, luaL_typename(L, -1));
      }
      if (agn_seqsize(L, -1) != dim) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered point of different dimension at index %d.", "stats.nearby", i);
      }
      q = aux_tonumarray(L, -1, &n, "stats.nearby");
      if (q == NULL) return 1;  /* issue the error, 2.4.4 */
      agn_poptop(L);  /* pop point */
      if (n != dim) {
        xfree(p); xfree(q);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": point at index %d includes non-numbers.", "stats.nearby", i);
      }
      if (tools_approx(q[dimspace] - p[dimspace], eps, epsilon)) {  /* determine distance in the dimension given by dimspace */
        if (i == 2) { insertcoordinate(indices, ++c, 1); }
        insertcoordinate(indices, ++c, i);
      }
      for (j=0; j < dim; j++) p[j] = q[j];
      xfree(q);
    }
    xfree(p);
  } else {  /* else check linalg.vectors (p) */
    size_t j;
    for (i=1; i <= s; i++) {
      lua_seqgeti(L, 1, i);
      if (!agn_islinalgvector(L, -1, &n)) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": wrong kind of point at index %d, got " LUA_QS ".",
          "stats.nearby", i, luaL_typename(L, -1));
        }
      if (n != dim) {
        xfree(p);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered vector of different dimension at index %d.",
          "stats.nearby", luaL_typename(L, -1), i);
      }
      q = aux_tonumarray(L, -1, &n, "stats.nearby");
      if (q == NULL) return 1;  /* issue the error, 2.4.4 */
      if (n != dim) {
        agn_poptop(L);
        xfree(p); xfree(q);  /* 2.8.2 patch */
        luaL_error(L, "Error in " LUA_QS ": encountered malformed vector at index %d.", "stats.nearby", i);
      }
      agn_poptop(L);  /* pop point */
      if (tools_approx(q[dimspace] - p[dimspace], eps, epsilon)) {
        if (i == 2) { insertcoordinate(indices, ++c, 1); }
        insertcoordinate(indices, ++c, i);
      }
      for (j=0; j < dim; j++) p[j] = q[j];
      xfree(q);
    }
    xfree(p);
  }
  agn_seqresize(L, -1, c);
  return 1;
}


/* Computes the normalised autocorrelation of a distribution (a table or sequence) of numbers at a given lag.
   If any third argument is passed, then the un-normalised autocorrelation is returned.

   It may be used to detect periodicy in a time series.

   A distribution is autocorrelated if stats.acf returns a negative or positive value significantly different
   from zero.

   Formula as defined in the NIST Engineering Statistics Handbook
   http://www.itl.nist.gov/div898/handbook/eda/section3/eda35c.htm */

static int stats_acf (lua_State *L) {
  size_t n, i, size;
  int option, lag;
  lua_Number *a, m, ac, udmean, sum;
  udmean = sum = HUGE_VAL;
  luaL_checkany(L, 1);  /* aux_tonumarray throws errors if argument is not a table or sequence */
  size = lua_gettop(L);
  lag = agn_checkinteger(L, 2);  /* the lag */
  if (lag < 0)
    luaL_error(L, "Error in " LUA_QS ": lag must be non-negative.", "stats.acf");
  option = !lua_isnoneornil(L, 3);
  if (size >= 4 && agn_isnumber(L, 4))  /* 2.8.2 */
    udmean = agn_tonumber(L, 4);
  if (size > 4 && agn_isnumber(L, 5))  /* 2.8.2 */
    sum = agn_tonumber(L, 5);
  n = ac = 0;
  a = aux_tonumarray(L, 1, &n, "stats.acf");
  if (a == NULL) return 1;  /* issue the error */
  if (lag >= n) {
    xfree(a);  /* 2.8.2 patch */
    luaL_error(L, "Error in " LUA_QS ": lag out of upper bound.", "stats.acf");
  }
  m = (udmean == HUGE_VAL) ? KahanBabuskaMean(a, n) : udmean;  /* 2.8.2 improvement */
  sum = (sum == HUGE_VAL) ? KahanBabuskaSumdata(a, n, 2, m) : sum;  /* 2.8.2 improvement */
  for (i=0; i < n - lag; i++)
    ac += (a[i] - m) * (a[i + lag] - m);
  /* no option given ? return ac / (n * variance), i.e. a normalised result */
  lua_pushnumber(L, (option) ? ac : ac / sum);
  xfree(a);
  return 1;
}


/* Returns a sequence of autocorrelations through the given number of lags.
   If any third argument is passed, then the un-normalised autocorrelations are returned.

   Formula as defined in the NIST Engineering Statistics Handbook
   http://www.itl.nist.gov/div898/handbook/eda/section3/eda35c.htm

import stats
a := utils.readcsv('../../Downloads/lew.dat', header=true)
stats.acv(a, 0): */

static int stats_acv (lua_State *L) {
  size_t n, i, j;
  int option, lag;
  lua_Number *a, m, s, secondmoment;
  luaL_checkany(L, 1);  /* aux_tonumarray throws errors if argument is not a table or sequence */
  lag = agn_checkinteger(L, 2);  /* the maximum lag */
  if (lag < 0)
    luaL_error(L, "Error in " LUA_QS ": lag must be non-negative.", "stats.acv");  /* corrected 2.4.4 */
  option = !lua_isnoneornil(L, 3);
  n = 0;
  a = aux_tonumarray(L, 1, &n, "stats.acv");  /* corrected 2.4.4 */
  if (a == NULL) return 1;  /* issue the error */
  if (lag >= n) {
    xfree(a);  /* 2.8.2 patch */
    luaL_error(L, "Error in " LUA_QS ": lag out of upper bound.", "stats.acv");  /* corrected 2.4.4 */
  }
  m = KahanBabuskaMean(a, n);  /* 2.4.3 improvement */
  secondmoment = (option) ? 1 : KahanBabuskaSumdata(a, n, 2, m);  /* (n * variance) */
  agn_createseq(L, n - lag);
  for (j=0; j <= lag; j++) {
    s = 0;
    for (i=0; i < n - j; i++)
      s += (a[i] - m) * (a[i + j] - m);
    lua_seqsetinumber(L, -1, j + 1, (option) ? s : s / secondmoment);
  }
  xfree(a);
  return 1;
}


/* Checks whether at least one element in a table or sequence obj is non-zero and returns `true` or `false`. If the
   second argument eps, a non-negative number, is passed, the function returns `true` if at least one observation
   x in o satisfies the condition abs(x) > eps. By default eps is 0.

   Idea taken frm Matlab's any function, see: http://de.mathworks.com/help/matlab/ref/any.html. 2.4.1 */

static int stats_isany (lua_State *L) {
  size_t i, n;
  int type;
  lua_Number eps;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  eps = agnL_optnumber(L, 2, 0);
  if (eps < 0)
    luaL_error(L, "Error in " LUA_QS ": threshold must be non-negative.", "stats.isany");
  n = agn_nops(L, 1);
  if (n < 2) {
    lua_pushfail(L);
    return 1;
  }
  switch (type) {
    case LUA_TTABLE: {
      for (i=1; i <= n; i++) {
        if (fabs(agn_getinumber(L, 1, i)) > eps) {
          lua_pushtrue(L);
          return 1;
        }
      }
      break;
    }
    case LUA_TSEQ: {
      for (i=1; i <= n; i++) {
        if (fabs(agn_seqgetinumber(L, 1, i)) > eps) {  /* 2.4.2 */
          lua_pushtrue(L);
          return 1;
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  lua_pushfalse(L);
  return 1;
}


/* Checks whether all elements in a table or sequence o are non-zero and returns `true` or `false`. If the
   second argument eps, a non-negative number, is passed, the function returns `true` if all observations
   x in o satisfies the condition abs(x) > eps. By default eps is 0.

   Idea taken frm Matlab's all function, see: http://de.mathworks.com/help/matlab/ref/all.html. 2.4.1 */

static int stats_isall (lua_State *L) {
  size_t i, n;
  int type;
  lua_Number eps;
  type = lua_type(L, 1);
  luaL_typecheck(L, type == LUA_TTABLE || type == LUA_TSEQ, 1, "table or sequence expected", type);
  eps = agnL_optnumber(L, 2, 0);
  if (eps < 0)
    luaL_error(L, "Error in " LUA_QS ": threshold must be non-negative.", "stats.isall");
  n = agn_nops(L, 1);
  if (n < 2) {
    lua_pushfail(L);
    return 1;
  }
  switch (type) {
    case LUA_TTABLE: {
      for (i=1; i <= n; i++) {
        if (fabs(agn_getinumber(L, 1, i)) <= eps) {
          lua_pushfalse(L);
          return 1;
        }
      }
      break;
    }
    case LUA_TSEQ: {
      for (i=1; i <= n; i++) {
        if (fabs(agn_seqgetinumber(L, 1, i)) <= eps) {  /* 2.4.2 fix */
          lua_pushfalse(L);
          return 1;
        }
      }
      break;
    }
    default: lua_assert(0);  /* should not happen */
  }
  lua_pushtrue(L);
  return 1;
}


/* The function checks whether the given coordinate c is a pair with both its left-hand and right-hand side being numbers.
   If a second argument, a string, is given, then error messages of `stats.checkccordinate` refer to the given procedure
   procname as function issueing the error. Otherwise the error message includes a reference to `stats.checkcoordinate`. */

static int stats_checkcoordinate (lua_State *L) {  /* 2.4.1 */
  size_t nargs;
  const char *procname;
  lua_Number x, y;
  nargs = lua_gettop(L);
  procname = luaL_optstring(L, 2, "stats.checkcoordinate");
  if (nargs < 1)  /* 2.4.5 fix */
    luaL_error(L, "Error in " LUA_QS ": expected at least one argument.", procname);
  if (!lua_ispair(L, 1))
    luaL_error(L, "Error in " LUA_QS ": first argument must be a pair, got %s.",
      procname, luaL_typename(L, 1));
  agn_pairgetnumbers(L, procname, 1, &x, &y);
  lua_pushnumber(L, x);
  lua_pushnumber(L, y);
  return 2;
}


#define gamma(a)  ( ((a) > 0) ? (exp(lgamma((a)))) : (AGN_NAN) )

/* The studentst[nu] distribution has the probability density function
   GAMMA( (nu+1)/2 )/GAMMA(nu/2)/sqrt(nu*Pi)/(1+t^2/nu)^((nu+1)/2), with nu a positive integer. */

static int stats_studentst (lua_State *L) {  /* suggested by Slobodan, 2.5.1, equivalent to Maple's stats[statevalf,pdf,studentst[v]](t); */
  lua_Number t, mu, n, d;
  t = agn_checknumber(L, 1);
  mu = agn_checkinteger(L, 2);
  if (mu < 1) luaL_error(L, "Error in " LUA_QS ": number of freedom (2nd argument) must be positive.", "stats.studentst");
  n = gamma((mu + 1)/2);
  d = sqrt(mu*PI) * gamma(mu/2);
  lua_pushnumber(L, n/d * pow(1 + t*t/mu, -(mu + 1)/2));
  return 1;
}


/* The normald[mu, sigma] distribution has the probability density function:
   exp( -(x-mu)^2/2/sigma^2 ) / sqrt(2*Pi*sigma^2). positive si is the standard deviation. */

static int stats_normald (lua_State *L) {  /* suggested by Slobodan, 2.5.1, equivalent to Maple's stats[statevalf,pdf,normald[mu, sigma]](x); */
  lua_Number t, mu, si;
  t = agn_checknumber(L, 1);
  mu = agnL_optinteger(L, 2, 0);
  si = agnL_optnumber(L, 3, 1);
  if (si <= 0) luaL_error(L, "Error in " LUA_QS ": number of freedom (2nd argument) must be positive.", "stats.normald");
  lua_pushnumber(L, exp(-(t*t - 2*t*mu + mu*mu)/2/(si*si)) / sqrt(2*PI*si*si));
  return 1;
}


/* The chisquare[nu] distribution has the probability density function
   x^((nu-2)/2) exp(-x/2)/2^(nu/2)/GAMMA(nu/2), x>0, nu a posint. */

static int stats_chisquare (lua_State *L) {  /* suggested by Slobodan, 2.5.1, equivalent to Maple's stats[statevalf,pdf,chisquare[v]](x); */
  lua_Number x, mu, t1, t2;
  x = agn_checknumber(L, 1);
  if (x <= 0) luaL_error(L, "Error in " LUA_QS ": first argument must be positive.", "stats.chisquare");
  mu = agn_checkinteger(L, 2);
  if (mu < 1) luaL_error(L, "Error in " LUA_QS ": second argument must be positive.", "stats.chisquare");
  t1 = pow(x, (mu - 2)/2);
  t2 = exp(-x/2)/pow(2, mu/2)/gamma(mu/2);
  lua_pushnumber(L, t1 * t2);
  return 1;
}


/* The fratio[nu1, nu2] distribution (also known as Fischer f distribution) has the probability density function
      GAMMA( (nu1+nu2)/2)/GAMMA(nu1/2)/GAMMA(nu2/2)*(nu1/nu2)^(nu1/2)*
      x^((nu1-2)/2) / ( 1+ (nu1/nu2)*x) ^ ((nu1+nu2)/2), x>0, with nu1 and nu2 positive integers.
   Constraints: nu1, nu2 are positive integers. */

static int stats_fratio (lua_State *L) {  /* suggested by Slobodan, 2.5.1, equivalent to Maple's stats[statevalf,pdf,fratio[nu1, nu2]](x); */
  lua_Number x, nu1, nu2, t1, t2;
  x = agn_checknumber(L, 1);
  if (x <= 0) luaL_error(L, "Error in " LUA_QS ": first argument must be positive.", "stats.fratio");
  nu1 = agn_checkinteger(L, 2);
  if (nu1 < 1) luaL_error(L, "Error in " LUA_QS ": second argument must be positive.", "stats.fratio");
  nu2 = agn_checkinteger(L, 3);
  if (nu2 < 1) luaL_error(L, "Error in " LUA_QS ": third argument must be positive.", "stats.fratio");
  t1 = gamma((nu1 + nu2)/2)/gamma(nu1/2)/gamma(nu2/2)*pow(nu1/nu2, nu1/2);
  t2 = pow(x, (nu1-2)/2) / pow(1 + (nu1/nu2)*x, (nu1 + nu2)/2);
  lua_pushnumber(L, t1 * t2);
  return 1;
}


/* The cauchy[a, b] distribution has the probability density function 1/(Pi*b*(1+((x-a)/b)^2)), b>0.
   Maple V R4: stats[statevalf,pdf,cauchy[2, 3]](4); -> .73456127580874770356e-1 */

static int stats_cauchy (lua_State *L) {  /* 2.5.2, equivalent to Maple's stats[statevalf,pdf,fratio[nu1, nu2]](x); */
  lua_Number x, a, b, t;
  x = agn_checknumber(L, 1);
  a = agn_checknumber(L, 2);
  b = agn_checknumber(L, 3);
  if (b <= 0) luaL_error(L, "Error in " LUA_QS ": third argument must be non-negative.", "stats.cauchy");
  t = (x - a)/b;
  lua_pushnumber(L, 1/(PI*b*(1 + t*t)));
  return 1;
}


/* The Durbin-Watson test detects the autocorrelation in the residuals from a linear regression and returns

d = sum((obj[i]-obj[i-1])^2, i=2 .. n)/sum(obj[i]^2, i=1 .. n);

If d is equal to 2, it indicated the absence of autocorrelation. If d is less than 2, it indicates positive autocorrelation; if d is greater than 2 it indicates negative autocorrelation and that the observations are very different from each other. If d is less than 1, the regression should be checked. The function uses Kahan-Babuska roundoff prevention. */

static int stats_durbinwatson (lua_State *L) {
  size_t i, ii;
  lua_Number *a;
  luaL_checkany(L, 1);
  ii = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.durbinwatson");
  if (a == NULL) return 1;  /* issue the error */
  if (ii < 2)
    lua_pushfail(L);
  else {
    volatile lua_Number s, cs, ccs, t, c, cc, x;
    s = cs = ccs = 0;
    for (i=1; i < ii; i++) {
      x = a[i] - a[i-1];
      x *= x;
      t = s + x;
      c = (fabs(s) >= fabs(x)) ? (s - t) + x : (x - t) + s;
      s = t;
      t = cs + c;
      cc = (fabs(cs) >= fabs(c)) ? (cs - t) + c : (c - t) + cs;
      cs = t;
      ccs = ccs + cc;
    }
    lua_pushnumber(L, (s + cs + ccs)/KahanBabuskaSumdata(a, ii, 2, 0));
  }
  xfree(a);
  return 1;
}


/* Computes the covariance of distributions x and y, which is cov(x,y) = [1/n or 1/(n-1)] * sum((x[i]-mean(x)) * (y[i]-mean(y)), i = 1 .. n).
   See the math definition at http://www.cquest.utoronto.ca/geog/ggr270y/notes/not05efg.html. By default, the population
   covariance
      cov(x,y) = 1/n * sum((x[i]-mean(x)) * (y[i]-mean(y)), i = 1 .. n)
   is returned. If you pass any third argument then the sample covariance
      cov(x,y) = 1/(n-1) * sum((x[i]-mean(x)) * (y[i]-mean(y)), i = 1 .. n)
   is computed.

   The covariance indicates the tendency in the linear relationship between two distributions: if it is positive,
   the distributions are similar, if it is negative, they are not.

   This is a port of the Java function `covariance` written by Peter Gedeck and Wolfgang Hoschek in 1999, included in the
   COLT package published by CERN Geneva, see file /Colt-master/src/cern/jet/stat/Descriptive.java. The algorithm used
   is faster than the formula above. 2.5.3 */

static int stats_covar (lua_State *L) {
  size_t i, ii, jj;
  int sample;
  lua_Number *a, *b, x, y, sx, sy, sxy;
  luaL_checkany(L, 2);
  ii = jj = 0;
  a = aux_tonumarray(L, 1, &ii, "stats.covar");
  if (a == NULL) return 1;  /* issue the error */
  b = aux_tonumarray(L, 2, &jj, "stats.covar");
  if (b == NULL) return 1;  /* issue the error */
  sample = !lua_isnoneornil(L, 3);
  if (ii != jj || ii < 2)  /* in this order */
    lua_pushfail(L);
  else {
    sx = a[0]; sy = b[0]; sxy = 0;
    for (i=1; i < ii; i++) {
      x = a[i]; y = b[i];
      sx += x;
      sxy += (x - sx/(i + 1)) * (y - sy/i);
      sy += y;
    }
    lua_pushnumber(L, sxy/(ii - sample));
  }
  xfree(a); xfree(b);
  return 1;
}


/*							gdtr.c
 *
 *	Gamma distribution function
 *
 *
 *
 * SYNOPSIS:
 *
 * double a, b, x, y, gdtr();
 *
 * y = gdtr( x, a, b );
 *
 *
 *
 * DESCRIPTION:
 *
 * Returns the integral from zero to x of the gamma probability
 * density function:
 *
 *                x
 *        b       -
 *       a       | |   b-1  -at
 * y =  -----    |    t    e    dt
 *       -     | |
 *      | (b)   -
 *               0
 *
 *  The incomplete gamma integral is used, according to the
 * relation
 *
 * y = igam( b, ax ).
 *
 *
 * ACCURACY:
 *
 * See igam().
 *
 * ERROR MESSAGES:
 *
 *   message         condition      value returned
 * gdtr domain         x < 0            0.0
 *
 */


static int stats_gammad (lua_State *L) {  /* Gamma distribution function, 2.8.1 */
  lua_Number x, a, b;
  x = agn_checknumber(L, 1);
  a = agn_checknumber(L, 2);
  b = agn_checknumber(L, 3);
  if (x < 0)
    lua_pushundefined(L);
  else
    lua_pushnumber(L, igam(b, a * x));
  return 1;
}


/*							gdtrc.c
 *
 *	Complemented gamma distribution function
 *
 *
 *
 * SYNOPSIS:
 *
 * double a, b, x, y, gdtrc();
 *
 * y = gdtrc( x, a, b );
 *
 *
 *
 * DESCRIPTION:
 *
 * Returns the integral from x to infinity of the gamma
 * probability density function:
 *
 *               inf.
 *        b       -
 *       a       | |   b-1  -at
 * y =  -----    |    t    e    dt
 *       -     | |
 *      | (b)   -
 *               x
 *
 *  The incomplete gamma integral is used, according to the
 * relation
 *
 * y = igamc( b, ax ).
 *
 *
 * ACCURACY:
 *
 * See igamc().
 *
 * ERROR MESSAGES:
 *
 *   message         condition      value returned
 * gdtrc domain         x < 0            0.0
 *
 */
/*							gdtr()  */


/*
Cephes Math Library Release 2.8:  June, 2000
Copyright 1984, 1987, 1995, 2000 by Stephen L. Moshier
*/

static int stats_gammadc (lua_State *L) {  /* complemented Gamma distribution function, 2.8.1 */
  lua_Number x, a, b;
  x = agn_checknumber(L, 1);
  a = agn_checknumber(L, 2);
  b = agn_checknumber(L, 3);
  if (x < 0)
    lua_pushundefined(L);
  else
    lua_pushnumber(L, igamc(b, a * x));  /* 2.8.2 fix */
  return 1;
}


/* Inverse of Normal distribution function
 *
 * SYNOPSIS:
 *
 * double x, y, ndtri();
 *
 * x = ndtri( y );
 *
 * DESCRIPTION:
 *
 * Returns the argument, x, for which the area under the
 * Gaussian probability density function (integrated from
 * minus infinity to x) is equal to y.
 *
 * SEE ALSO: stats.normald */

static int stats_invnormald (lua_State *L) {  /* 2.8.2 */
  lua_pushnumber(L, ndtri(agn_checknumber(L, 1)));
  return 1;
}


static const luaL_Reg statslib[] = {
  {"acf", stats_acf},                       /* added on November 04, 2014 */
  {"acv", stats_acv},                       /* added on November 04, 2014 */
  {"amean", stats_amean},                   /* added on August 26, 2012 */
  {"ad", stats_ad},                         /* added on March 11, 2012 */
  {"cauchy", stats_cauchy},                 /* added on March 30, 2015 */
  {"checkcoordinate", stats_checkcoordinate},  /* added January 21, 2015 */
  {"chisquare", stats_chisquare},           /* added on March 29, 2015 */
  {"colnorm", stats_colnorm},               /* added on October 03, 2012 */
  {"covar", stats_covar},                   /* added on April 08, 2015 */
  {"cumsum", stats_cumsum},                 /* added on September 10, 2012 */
  {"deltalist", stats_deltalist},           /* added on March 12, 2012 */
  {"durbinwatson", stats_durbinwatson},     /* added on April 06, 2015 */
  {"ema", stats_ema},                       /* added on December 06, 2013 */
  {"fivenum", stats_fivenum},               /* added on June 29, 2015 */
  {"fratio", stats_fratio},                 /* added on March 29, 2015 */
  {"fsum", stats_fsum},                     /* added on May 19, 2014 */
  {"fprod", stats_fprod},                   /* added on May 19, 2014 */
  {"gammad", stats_gammad},                 /* added on July 07, 2015 */
  {"gammadc", stats_gammadc},               /* added on July 07, 2015 */
  {"gema", stats_gema},                     /* added on December 09, 2013 */
  {"gini", stats_gini},                     /* added on July 28, 2014 */
  {"gsma", stats_gsma},                     /* added on July 21, 2013 */
  {"gsmm", stats_gsmm},                     /* added on July 20, 2013 */
  {"invnormald", stats_invnormald},         /* added on July 09, 2015 */
  {"ios", stats_ios},                       /* added on March 11, 2012 */
  {"iqmean", stats_iqmean},                 /* added on February 11, 2015 */
  {"isall", stats_isall},                   /* added on January 15, 2015 */
  {"isany", stats_isany},                   /* added on January 15, 2015 */
  {"issorted", stats_issorted},             /* added on March 31, 2012 */
  {"mad", stats_mad},                       /* added on September 11, 2013 */
  {"md", stats_md},                         /* added on January 24, 2015 */
  {"meanmed", stats_meanmed},               /* added on June 30, 2014 */
  {"meanvar", stats_meanvar},               /* added on April 07, 2015 */
  {"median", stats_median},                 /* added on June 19, 2007 */
  {"minmax", stats_minmax},                 /* added on June 20, 2007 */
  {"moment", stats_moment},                 /* added on March 11, 2012 */
  {"nde", stats_nde},                       /* added on April 14, 2013 */
  {"ndf", stats_ndf},                       /* added on April 13, 2013 */
  {"neighbours", stats_neighbours},         /* added on October 31, 2014 */
  {"nearby", stats_nearby},                 /* added on January 15, 2015 */
  {"normald", stats_normald},               /* added on March 29, 2015 */
  {"pdf", stats_pdf},                       /* added on April 11, 2013 */
  {"prange", stats_prange},                 /* added on November 04, 2013 */
  {"quartiles", stats_quartiles},           /* added on February 12, 2015 */
  {"rownorm", stats_rownorm},               /* added on October 04, 2012 */
  {"scale", stats_scale},                   /* added on October 01, 2012 */
  {"sma", stats_sma},                       /* added on July 11, 2013 */
  {"smallest", stats_smallest},             /* added on December 30, 2012 */
  {"smm", stats_smm},                       /* added on July 15, 2013 */
  {"sorted", stats_sorted},                 /* added on October 07, 2012 */
  {"standardise", stats_standardise},       /* added on April 07, 2015 */
  {"studentst", stats_studentst},           /* added on March 29, 2015 */
  {"sumdata", stats_sumdata},               /* added on March 11, 2012 */
  {"sumdataln", stats_sumdataln},           /* added on April 06, 2015 */
  {"tovals", stats_tovals},                 /* added on March 11, 2012 */
  {"trimean", stats_trimean},               /* added on February 12, 2015 */
  {NULL, NULL}
};


/*
** Open stats library
*/
LUALIB_API int luaopen_stats (lua_State *L) {
  luaL_register(L, AGENA_STATSLIBNAME, statslib);
  return 1;
}

/* ====================================================================== */

